import { BoardSlot, Player, ElementField } from "./stores/useCardGame";
import { 
  applyPreBattleEffects, 
  applyBattleEffects, 
  applyPostBattleEffects,
  applyContinuousEffects,
  EffectContext 
} from "./effectLogic";

export function resolveBattles(
  board: (BoardSlot | null)[],
  placedSlotIndex: number,
  attackingPlayer: Player,
  oCardOwner: Player = "neutral",
  elementFields: ElementField[] = [],
  currentTurn: number = 1,
  skipPreBattleEffects: boolean = false
): { updatedBoard: (BoardSlot | null)[], capturedCards: number[], effectMessages: string[] } {
  let updatedBoard = [...board];
  const capturedCards: number[] = [];
  let effectMessages: string[] = [];
  
  // Determine board size and generate adjacent positions dynamically
  const boardLength = board.length;
  const gridSize = Math.sqrt(boardLength); // 3 for 3x3, 5 for 5x5
  
  // Create effect context
  const effectContext: EffectContext = {
    board: updatedBoard,
    placedSlotIndex,
    attackingPlayer,
    currentTurn,
    gridSize,
    turnCount: currentTurn
  };
  
  // Apply pre-battle effects (immediate effects like Blitzschlag, Clone, etc.)
  if (!skipPreBattleEffects) {
    const preBattleResult = applyPreBattleEffects(effectContext);
    updatedBoard = preBattleResult.modifiedBoard;
    effectMessages = [...effectMessages, ...preBattleResult.effectMessages];
  }
  
  // Function to get adjacent positions for any grid size
  const getAdjacentPositions = (index: number): number[] => {
    const row = Math.floor(index / gridSize);
    const col = index % gridSize;
    const adjacent: number[] = [];
    
    // Check all 4 directions: up, right, down, left
    const directions = [
      [-1, 0], // up
      [0, 1],  // right
      [1, 0],  // down
      [0, -1]  // left
    ];
    
    directions.forEach(([dRow, dCol]) => {
      const newRow = row + dRow;
      const newCol = col + dCol;
      
      // Check if new position is within bounds
      if (newRow >= 0 && newRow < gridSize && newCol >= 0 && newCol < gridSize) {
        adjacent.push(newRow * gridSize + newCol);
      }
    });
    
    return adjacent;
  };
  
  const adjacentPositions = getAdjacentPositions(placedSlotIndex);

  const placedCard = updatedBoard[placedSlotIndex];
  if (!placedCard) return { updatedBoard, capturedCards, effectMessages };

  // Find the O-Card position on the board
  const oCardIndex = updatedBoard.findIndex(slot => slot && slot.originalCard.id === "O");
  
  // Separate battles into O-Card battles and regular battles
  const oCardBattles: number[] = [];
  const regularBattles: number[] = [];
  
  adjacentPositions.forEach((adjacentIndex) => {
    const adjacentSlot = updatedBoard[adjacentIndex];
    if (!adjacentSlot || adjacentSlot.owner === attackingPlayer) return;
    
    // Check if this battle involves the O-Card
    if (adjacentIndex === oCardIndex || placedSlotIndex === oCardIndex) {
      oCardBattles.push(adjacentIndex);
    } else {
      regularBattles.push(adjacentIndex);
    }
  });

  // Helper function to check if a position has element bonuses  
  const getElementBonus = (position: number, cardElement?: string): number => {
    const elementField = elementFields.find(field => field.position === position);
    if (elementField && cardElement && elementField.element === cardElement) {
      return 1; // +1 bonus for matching element
    }
    return 0;
  };

  // Helper function to resolve a single battle
  const resolveSingleBattle = (adjacentIndex: number, currentOCardOwner: Player) => {
    const adjacentSlot = updatedBoard[adjacentIndex];
    if (!adjacentSlot || adjacentSlot.owner === attackingPlayer) return false;

    // Determine which sides to compare based on position relationship
    let attackValue: number;
    let defenseValue: number;

    const rowPlaced = Math.floor(placedSlotIndex / gridSize);
    const colPlaced = placedSlotIndex % gridSize;
    const rowAdjacent = Math.floor(adjacentIndex / gridSize);
    const colAdjacent = adjacentIndex % gridSize;

    // Get base card values - use originalCard for consistent comparison
    const attackCard = placedCard.originalCard || placedCard.card;
    // Always use current card values for defense to include damage from effects like Blitzschlag
    const defenseCard = adjacentSlot.card;

    if (rowAdjacent < rowPlaced) {
      // Adjacent is above
      attackValue = attackCard.top;
      defenseValue = defenseCard.bottom;
    } else if (rowAdjacent > rowPlaced) {
      // Adjacent is below
      attackValue = attackCard.bottom;
      defenseValue = defenseCard.top;
    } else if (colAdjacent < colPlaced) {
      // Adjacent is to the left
      attackValue = attackCard.left;
      defenseValue = defenseCard.right;
    } else {
      // Adjacent is to the right
      attackValue = attackCard.right;
      defenseValue = defenseCard.left;
    }

    // Apply O-Card effect to battle values
    if (attackingPlayer === currentOCardOwner && attackingPlayer !== "neutral" && attackCard.id !== "O") {
      attackValue = Math.min(9, attackValue + 1);
    }
    if (adjacentSlot.owner === currentOCardOwner && adjacentSlot.owner !== "neutral" && defenseCard.id !== "O") {
      defenseValue = Math.min(9, defenseValue + 1);
    }

    // Apply element bonuses
    const attackElementBonus = getElementBonus(placedSlotIndex, attackCard.element);
    const defenseElementBonus = getElementBonus(adjacentIndex, defenseCard.element);
    
    attackValue = Math.min(9, attackValue + attackElementBonus);
    defenseValue = Math.min(9, defenseValue + defenseElementBonus);

    // Apply effect-based battle modifications
    const battleEffectResult = applyBattleEffects(
      attackValue,
      defenseValue,
      attackCard,
      defenseCard,
      placedCard,
      adjacentSlot,
      effectContext
    );
    
    const finalAttackValue = battleEffectResult.modifiedAttackValue;
    const finalDefenseValue = battleEffectResult.modifiedDefenseValue;
    
    // Check for forced battle results (from effects like Anker, Sniper)
    if (battleEffectResult.battleWon !== null) {
      if (battleEffectResult.battleWon) {
        updatedBoard[adjacentIndex] = {
          ...adjacentSlot,
          owner: attackingPlayer
        };
        capturedCards.push(adjacentIndex);
        return true;
      }
      return false;
    }
    
    // Debug logging for Blitzschlag battles
    console.log(`Battle: ${attackCard.name || attackCard.id} (${finalAttackValue}) vs ${defenseCard.name || defenseCard.id} (${finalDefenseValue})`);
    console.log(`Attack base: ${attackValue}, Defense base: ${defenseValue}`);
    console.log(`Defense card current values:`, defenseCard);
    
    // Normal battle resolution: higher value wins
    if (finalAttackValue > finalDefenseValue) {
      console.log(`✅ ${attackCard.name || attackCard.id} captures ${defenseCard.name || defenseCard.id}!`);
      updatedBoard[adjacentIndex] = {
        ...adjacentSlot,
        owner: attackingPlayer
      };
      capturedCards.push(adjacentIndex);
      return true;
    }
    console.log(`❌ ${defenseCard.name || defenseCard.id} defends against ${attackCard.name || attackCard.id}`);
    return false;
  };

  // First, resolve all battles involving the O-Card
  let currentOCardOwner = oCardOwner;
  oCardBattles.forEach((adjacentIndex) => {
    const captured = resolveSingleBattle(adjacentIndex, currentOCardOwner);
    // Update O-Card ownership if it was captured
    if (captured && adjacentIndex === oCardIndex) {
      currentOCardOwner = attackingPlayer;
    }
  });

  // Then resolve regular battles with updated O-Card ownership
  regularBattles.forEach((adjacentIndex) => {
    resolveSingleBattle(adjacentIndex, currentOCardOwner);
  });

  // Apply post-battle effects (like Stachelrüstung)
  const postBattleResult = applyPostBattleEffects(updatedBoard, capturedCards, effectContext);
  updatedBoard = postBattleResult.modifiedBoard;
  effectMessages = [...effectMessages, ...postBattleResult.effectMessages];
  
  // Apply continuous effects (like Verstärkung, area effects)
  updatedBoard = applyContinuousEffects(updatedBoard, gridSize);
  
  return { updatedBoard, capturedCards, effectMessages };
}

export function checkWinCondition(board: (BoardSlot | null)[]): Player | "tie" | null {
  // Check if board is full
  const isBoardFull = board.every(slot => slot !== null);
  
  if (!isBoardFull) return null;

  // Count cards for each player
  let player1Count = 0;
  let player2Count = 0;

  board.forEach(slot => {
    if (slot) {
      if (slot.owner === "player1") player1Count++;
      else if (slot.owner === "player2") player2Count++;
    }
  });

  if (player1Count > player2Count) return "player1";
  if (player2Count > player1Count) return "player2";
  return "tie";
}
