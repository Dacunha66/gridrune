import { Rarity } from "./cardData";

export interface RarityUpgradeAnimation {
  type: 'rarity-upgrade' | 'rarity-sparkle';
  startTime: number;
  duration: number;
  fromRarity?: Rarity;
  toRarity?: Rarity;
}

/**
 * Creates a rarity upgrade animation configuration
 */
export function createRarityUpgradeAnimation(
  fromRarity: Rarity | undefined,
  toRarity: Rarity,
  duration: number = 2500
): RarityUpgradeAnimation {
  return {
    type: 'rarity-upgrade',
    startTime: Date.now(),
    duration,
    fromRarity,
    toRarity
  };
}

/**
 * Creates a rarity sparkle animation configuration for ambient effects
 */
export function createRaritySparkleAnimation(duration: number = 3000): RarityUpgradeAnimation {
  return {
    type: 'rarity-sparkle',
    startTime: Date.now(),
    duration
  };
}

/**
 * Determines the next rarity level for progression
 */
export function getNextRarity(currentRarity: Rarity | undefined): Rarity | null {
  const rarityOrder: Rarity[] = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'ultimate'];
  
  if (!currentRarity) {
    return 'common';
  }
  
  const currentIndex = rarityOrder.indexOf(currentRarity);
  if (currentIndex === -1 || currentIndex === rarityOrder.length - 1) {
    return null; // Already at max rarity or invalid rarity
  }
  
  return rarityOrder[currentIndex + 1];
}

/**
 * Calculates upgrade probability based on current rarity
 */
export function getUpgradeProbability(currentRarity: Rarity | undefined): number {
  switch (currentRarity) {
    case undefined:
    case 'common':
      return 0.7; // 70% chance to upgrade from common
    case 'uncommon':
      return 0.5; // 50% chance to upgrade from uncommon
    case 'rare':
      return 0.3; // 30% chance to upgrade from rare
    case 'epic':
      return 0.1; // 10% chance to upgrade from epic
    case 'legendary':
      return 0.05; // 5% chance to upgrade from legendary
    case 'ultimate':
      return 0.0; // Cannot upgrade from ultimate
    default:
      return 0.0;
  }
}

/**
 * Simulates a rarity upgrade attempt
 */
export function attemptRarityUpgrade(currentRarity: Rarity | undefined): {
  success: boolean;
  newRarity: Rarity | undefined;
  animation?: RarityUpgradeAnimation;
} {
  const probability = getUpgradeProbability(currentRarity);
  const success = Math.random() < probability;
  
  if (!success) {
    return { success: false, newRarity: currentRarity };
  }
  
  const newRarity = getNextRarity(currentRarity);
  if (!newRarity) {
    return { success: false, newRarity: currentRarity };
  }
  
  return {
    success: true,
    newRarity,
    animation: createRarityUpgradeAnimation(currentRarity, newRarity)
  };
}

/**
 * Gets rarity progression message for UI display
 */
export function getRarityProgressionMessage(fromRarity: Rarity | undefined, toRarity: Rarity): string {
  const rarityNames = {
    common: 'Gewöhnlich',
    uncommon: 'Ungewöhnlich',
    rare: 'Selten',
    epic: 'Episch',
    legendary: 'Legendär'
  };
  
  if (!fromRarity) {
    return `Karte wurde zu ${rarityNames[toRarity]} aufgewertet!`;
  }
  
  return `${rarityNames[fromRarity]} → ${rarityNames[toRarity]} Aufwertung!`;
}