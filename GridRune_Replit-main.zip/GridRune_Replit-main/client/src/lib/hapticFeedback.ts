/**
 * Haptic Feedback Utility
 * Provides vibration feedback for touch interactions on mobile devices
 */

export enum HapticType {
  LIGHT = 'light',
  MEDIUM = 'medium', 
  HEAVY = 'heavy',
  SELECTION = 'selection',
  SUCCESS = 'success',
  WARNING = 'warning',
  ERROR = 'error'
}

export interface HapticOptions {
  type?: HapticType;
  duration?: number; // For browsers that don't support typed vibration
  pattern?: number[]; // Custom vibration pattern
}

class HapticFeedbackManager {
  private isSupported: boolean;
  private isEnabled: boolean = true;

  constructor() {
    this.isSupported = 'vibrate' in navigator && typeof navigator.vibrate === 'function';
  }

  /**
   * Check if haptic feedback is supported on this device
   */
  public isHapticSupported(): boolean {
    return this.isSupported;
  }

  /**
   * Enable or disable haptic feedback
   */
  public setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
  }

  /**
   * Get current enabled state
   */
  public getEnabled(): boolean {
    return this.isEnabled;
  }

  /**
   * Trigger haptic feedback
   */
  public vibrate(options: HapticOptions = {}): void {
    if (!this.isSupported || !this.isEnabled) return;

    try {
      // If a custom pattern is provided, use it
      if (options.pattern) {
        navigator.vibrate(options.pattern);
        return;
      }

      // Use predefined patterns based on type
      switch (options.type) {
        case HapticType.LIGHT:
          navigator.vibrate(10);
          break;
        case HapticType.MEDIUM:
          navigator.vibrate(20);
          break;
        case HapticType.HEAVY:
          navigator.vibrate(40);
          break;
        case HapticType.SELECTION:
          navigator.vibrate([15, 10, 15]);
          break;
        case HapticType.SUCCESS:
          navigator.vibrate([20, 10, 20, 10, 30]);
          break;
        case HapticType.WARNING:
          navigator.vibrate([30, 20, 30]);
          break;
        case HapticType.ERROR:
          navigator.vibrate([50, 30, 50, 30, 50]);
          break;
        default:
          navigator.vibrate(options.duration || 15);
      }
    } catch (error) {
      console.warn('Haptic feedback failed:', error);
    }
  }

  /**
   * Convenience methods for common feedback types
   */
  public light(): void {
    this.vibrate({ type: HapticType.LIGHT });
  }

  public medium(): void {
    this.vibrate({ type: HapticType.MEDIUM });
  }

  public heavy(): void {
    this.vibrate({ type: HapticType.HEAVY });
  }

  public selection(): void {
    this.vibrate({ type: HapticType.SELECTION });
  }

  public success(): void {
    this.vibrate({ type: HapticType.SUCCESS });
  }

  public warning(): void {
    this.vibrate({ type: HapticType.WARNING });
  }

  public error(): void {
    this.vibrate({ type: HapticType.ERROR });
  }

  /**
   * Card-specific haptic feedback
   */
  public cardHover(): void {
    this.vibrate({ duration: 8 });
  }

  public cardSelect(): void {
    this.vibrate({ pattern: [12, 8, 12] });
  }

  public cardPlace(): void {
    this.vibrate({ pattern: [20, 15, 30] });
  }

  public cardBattle(): void {
    this.vibrate({ pattern: [30, 20, 30, 20, 40] });
  }

  public gestureSwipe(): void {
    this.vibrate({ duration: 12 });
  }

  public gestureLongPress(): void {
    this.vibrate({ pattern: [25, 15, 25] });
  }
}

// Export singleton instance
export const hapticFeedback = new HapticFeedbackManager();