import { BoardSlot, Player } from "./stores/useCardGame";
import { GameCard } from "./cardData";
import { CardEffect } from "./cardEffects";

export interface EffectContext {
  board: (BoardSlot | null)[];
  placedSlotIndex: number;
  attackingPlayer: Player;
  currentTurn: number;
  gridSize: number;
  turnCount: number;
}

// Helper function to get adjacent positions
export function getAdjacentPositions(index: number, gridSize: number): number[] {
  const row = Math.floor(index / gridSize);
  const col = index % gridSize;
  const adjacent: number[] = [];
  
  const directions = [
    [-1, 0], // up
    [0, 1],  // right
    [1, 0],  // down
    [0, -1]  // left
  ];
  
  directions.forEach(([dRow, dCol]) => {
    const newRow = row + dRow;
    const newCol = col + dCol;
    
    if (newRow >= 0 && newRow < gridSize && newCol >= 0 && newCol < gridSize) {
      adjacent.push(newRow * gridSize + newCol);
    }
  });
  
  return adjacent;
}

// Apply card effects before battle resolution
export function applyPreBattleEffects(context: EffectContext): {
  modifiedBoard: (BoardSlot | null)[];
  effectMessages: string[];
} {
  const { board, placedSlotIndex, attackingPlayer, gridSize } = context;
  let modifiedBoard = [...board];
  const effectMessages: string[] = [];
  
  const placedSlot = modifiedBoard[placedSlotIndex];
  if (!placedSlot) return { modifiedBoard, effectMessages };
  
  const effect = placedSlot.originalCard.effect;
  
  // Debug logging
  console.log(`Checking pre-battle effect: ${effect} for card ${placedSlot.originalCard.name || placedSlot.originalCard.id}`);
  
  switch (effect) {
    case "blitzschlag": {
      // Find enemy cards that can be targeted
      const enemySlots = modifiedBoard
        .map((slot, index) => ({ slot, index }))
        .filter(({ slot }) => 
          slot && 
          slot.owner !== attackingPlayer && 
          slot.owner !== "neutral" &&
          slot.originalCard.id !== "O"
        );
      
      if (enemySlots.length > 0) {
        console.log(`🗲 Blitzschlag aktiviert! ${enemySlots.length} mögliche Ziele gefunden`);
        // Return without applying damage - this will be handled by target selection
        effectMessages.push(`🗲 Blitzschlag bereit - wähle ein Ziel!`);
        
        // Set targeting mode in the context (this will be handled by the store)
        (context as any).needsTargeting = true;
        (context as any).availableTargets = enemySlots.map(({ index }) => index);
      } else {
        console.log("🗲 Blitzschlag: Keine feindlichen Ziele gefunden");
        effectMessages.push(`🗲 Blitzschlag fehlgeschlagen - keine Ziele!`);
      }
      break;
    }
    
    case "clone": {
      // Clone effect is now handled by manual target selection in the store
      // Find adjacent cards for targeting info
      const adjacentPositions = getAdjacentPositions(placedSlotIndex, gridSize);
      const adjacentCards = adjacentPositions
        .map(index => modifiedBoard[index])
        .filter(slot => slot !== null && slot.originalCard.id !== "O");
      
      if (adjacentCards.length > 0) {
        console.log(`👥 Clone aktiviert! ${adjacentCards.length} benachbarte Ziele gefunden`);
        effectMessages.push(`👥 Clone bereit - wähle ein Ziel zum Kopieren!`);
        
        // Set targeting mode in the context (this will be handled by the store)
        (context as any).needsTargeting = true;
        (context as any).availableTargets = adjacentPositions.filter(index => 
          modifiedBoard[index] !== null && modifiedBoard[index]!.originalCard.id !== "O"
        );
      } else {
        console.log("👥 Clone: Keine benachbarten Ziele gefunden");
        effectMessages.push(`👥 Clone fehlgeschlagen - keine benachbarten Karten!`);
      }
      break;
    }
    
    case "infektion": {
      // All enemy cards (except O-Card) lose -1 on all values
      modifiedBoard = modifiedBoard.map((slot, index) => {
        if (!slot || slot.owner === attackingPlayer || slot.owner === "neutral" || slot.originalCard.id === "O") {
          return slot;
        }
        
        return {
          ...slot,
          card: {
            ...slot.card,
            top: Math.max(0, slot.card.top - 1),
            right: Math.max(0, slot.card.right - 1),
            bottom: Math.max(0, slot.card.bottom - 1),
            left: Math.max(0, slot.card.left - 1)
          }
        };
      });
      effectMessages.push("🦠 Infektion schwächt alle gegnerischen Karten!");
      break;
    }
    

  }
  
  return { modifiedBoard, effectMessages };
}

// Apply effects that modify battle values
export function applyBattleEffects(
  attackValue: number,
  defenseValue: number,
  attackingCard: GameCard,
  defendingCard: GameCard,
  attackingSlot: BoardSlot,
  defendingSlot: BoardSlot,
  context: EffectContext
): { 
  modifiedAttackValue: number; 
  modifiedDefenseValue: number;
  battleWon: boolean | null; // null = normal resolution, true/false = forced result
} {
  let modifiedAttackValue = attackValue;
  let modifiedDefenseValue = defenseValue;
  let battleWon: boolean | null = null;
  
  const { board, gridSize } = context;
  
  // Debug logging for battle effects
  console.log(`Checking battle effects - Attacker: ${attackingCard.effect}, Defender: ${defendingCard.effect}`);
  
  // Apply attacking card effects
  switch (attackingCard.effect) {
    case "berserker": {
      // Double values in first combat only
      if (context.turnCount <= 2) { // First turn for each player
        modifiedAttackValue *= 2;
      }
      break;
    }
    
    case "sniper": {
      // Wins on ties
      if (modifiedAttackValue === modifiedDefenseValue) {
        battleWon = true;
      }
      break;
    }
    
    case "staerkung": {
      // +1 per adjacent own card
      const adjacentPositions = getAdjacentPositions(context.placedSlotIndex, gridSize);
      const ownAdjacentCount = adjacentPositions
        .map(index => board[index])
        .filter(slot => slot && slot.owner === attackingSlot.owner).length;
      
      modifiedAttackValue += ownAdjacentCount;
      break;
    }
  }
  
  // Apply defending card effects  
  switch (defendingCard.effect) {
    case "schild": {
      // Shield defense: break shield on first attack and remove the +1 values
      if (!defendingSlot.shieldBroken) {
        // Shield breaks but only blocks 1 point of damage
        defendingSlot.shieldBroken = true;
        
        // For regular attacks: shield completely blocks the attack
        // Card keeps its current values (no bonus to remove anymore)
        // defendingSlot.card already has the correct values
        
        console.log("🛡️ Schild aktiviert und ist jetzt zerbrochen! Angriff blockiert.");
        battleWon = false; // Shield protects from this attack
      }
      break;
    }
    
    case "anker": {
      // Cannot be captured (always wins defense)
      battleWon = false;
      break;
    }
    
    case "tarnung": {
      // Cannot be attacked for the first turn after placement
      const defendingSlotData = context.board.find((slot, index) => 
        slot?.originalCard.id === defendingCard.id
      );
      
      if (defendingSlotData?.placedOnTurn && 
          context.turnCount - defendingSlotData.placedOnTurn < 2) {
        battleWon = false;
        console.log("🥷 Tarnung aktiviert - Karte kann nicht angegriffen werden!");
      }
      break;
    }
  }
  
  return { 
    modifiedAttackValue: Math.min(9, modifiedAttackValue), 
    modifiedDefenseValue: Math.min(9, modifiedDefenseValue),
    battleWon 
  };
}

// Apply post-battle effects
export function applyPostBattleEffects(
  board: (BoardSlot | null)[],
  capturedCards: number[],
  context: EffectContext
): {
  modifiedBoard: (BoardSlot | null)[];
  effectMessages: string[];
} {
  let modifiedBoard = [...board];
  const effectMessages: string[] = [];
  
  // Handle effects that trigger after battles
  capturedCards.forEach(capturedIndex => {
    const capturedSlot = modifiedBoard[capturedIndex];
    if (!capturedSlot) return;
    
    const effect = capturedSlot.originalCard.effect;
    
    switch (effect) {
      case "stachelruestung": {
        // Attacker loses -1 on all values
        const attackerSlot = modifiedBoard[context.placedSlotIndex];
        if (attackerSlot) {
          modifiedBoard[context.placedSlotIndex] = {
            ...attackerSlot,
            card: {
              ...attackerSlot.card,
              top: Math.max(0, attackerSlot.card.top - 1),
              right: Math.max(0, attackerSlot.card.right - 1),
              bottom: Math.max(0, attackerSlot.card.bottom - 1),
              left: Math.max(0, attackerSlot.card.left - 1)
            }
          };
          effectMessages.push("🌵 Stachelrüstung verletzt den Angreifer!");
        }
        break;
      }
    }
  });
  
  return { modifiedBoard, effectMessages };
}

// Apply continuous effects (like Verstärkung, Stille, etc.)
export function applyContinuousEffects(
  board: (BoardSlot | null)[],
  gridSize: number
): (BoardSlot | null)[] {
  let modifiedBoard = [...board];
  
  // First pass: Find all cards with area effects
  const areaEffectCards = modifiedBoard
    .map((slot, index) => ({ slot, index }))
    .filter(({ slot }) => slot && (
      slot.originalCard.effect === "verstaerkung" ||
      slot.originalCard.effect === "stille"
    ));
  
  // Apply area effects
  areaEffectCards.forEach(({ slot: effectSlot, index: effectIndex }) => {
    if (!effectSlot) return;
    
    const adjacentPositions = getAdjacentPositions(effectIndex, gridSize);
    const effect = effectSlot.originalCard.effect;
    
    adjacentPositions.forEach(adjIndex => {
      const adjSlot = modifiedBoard[adjIndex];
      if (!adjSlot) return;
      
      switch (effect) {
        case "verstaerkung": {
          // Give +1 to adjacent own cards
          if (adjSlot.owner === effectSlot.owner) {
            modifiedBoard[adjIndex] = {
              ...adjSlot,
              card: {
                ...adjSlot.card,
                top: Math.min(9, adjSlot.card.top + 1),
                right: Math.min(9, adjSlot.card.right + 1),
                bottom: Math.min(9, adjSlot.card.bottom + 1),
                left: Math.min(9, adjSlot.card.left + 1)
              }
            };
          }
          break;
        }
        
        case "stille": {
          // Disable abilities of adjacent cards by nullifying their effects
          // Store original effect and temporarily disable it
          break;
        }
      }
    });
  });
  
  return modifiedBoard;
}

// Apply turn-based effects (like rotation) at the start of each turn
export function applyTurnBasedEffects(
  board: (BoardSlot | null)[],
  currentTurn: number
): {
  modifiedBoard: (BoardSlot | null)[];
  effectMessages: string[];
} {
  let modifiedBoard = [...board];
  const effectMessages: string[] = [];
  
  modifiedBoard.forEach((slot, index) => {
    if (!slot) return;
    
    const effect = slot.originalCard.effect;
    
    switch (effect) {

    }
  });
  
  return { modifiedBoard, effectMessages };
}