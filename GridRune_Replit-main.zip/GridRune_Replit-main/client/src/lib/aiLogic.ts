
import { GameCard } from "./cardData";

export interface AIMove {
  cardIndex: number;
  boardIndex: number;
}

export function getAIMove(
  aiHand: GameCard[],
  board: any[],
  playerCards: GameCard[],
  difficulty: "beginner" | "easy" | "medium" | "hard" | "insane" = "medium"
): AIMove {
  const availableSlots = board
    .map((slot, index) => ({ slot, index }))
    .filter(({ slot }) => slot === null);

  if (availableSlots.length === 0) {
    return { cardIndex: 0, boardIndex: 0 };
  }

  // Strategieauswahl basierend auf Schwierigkeit
  switch (difficulty) {
    case "beginner":
      return getBeginnerMove(aiHand, availableSlots);
    case "easy":
      return getEasyMove(aiHand, availableSlots);
    case "medium":
      return getMediumMove(aiHand, availableSlots, board);
    case "hard":
      return getHardMove(aiHand, availableSlots, board, playerCards);
    case "insane":
      return getInsaneMove(aiHand, availableSlots, board, playerCards);
    default:
      return getMediumMove(aiHand, availableSlots, board);
  }
}

function simulateCaptures(card: GameCard, boardIndex: number, board: any[]): number {
  let captures = 0;
  const row = Math.floor(boardIndex / 3);
  const col = boardIndex % 3;

  // Prüfe benachbarte Slots
  const neighbors = [
    { row: row - 1, col, direction: 'top' as const },
    { row: row + 1, col, direction: 'bottom' as const },
    { row, col: col - 1, direction: 'left' as const },
    { row, col: col + 1, direction: 'right' as const }
  ];

  for (const neighbor of neighbors) {
    if (neighbor.row >= 0 && neighbor.row < 3 && neighbor.col >= 0 && neighbor.col < 3) {
      const neighborIndex = neighbor.row * 3 + neighbor.col;
      const neighborSlot = board[neighborIndex];
      
      if (neighborSlot && neighborSlot.owner === "player1") {
        const cardValue = getCardValue(card, neighbor.direction);
        const opponentValue = getOpponentCardValue(neighborSlot.card, getOppositeDirection(neighbor.direction));
        
        if (cardValue > opponentValue) {
          captures++;
        }
      }
    }
  }

  return captures;
}

function getCardValue(card: GameCard, direction: 'top' | 'right' | 'bottom' | 'left'): number {
  switch (direction) {
    case 'top': return card.top;
    case 'right': return card.right;
    case 'bottom': return card.bottom;
    case 'left': return card.left;
  }
}

function getOpponentCardValue(card: GameCard, direction: 'top' | 'right' | 'bottom' | 'left'): number {
  switch (direction) {
    case 'top': return card.top;
    case 'right': return card.right;  
    case 'bottom': return card.bottom;
    case 'left': return card.left;
  }
}

function getOppositeDirection(direction: 'top' | 'right' | 'bottom' | 'left'): 'top' | 'right' | 'bottom' | 'left' {
  switch (direction) {
    case 'top': return 'bottom';
    case 'bottom': return 'top';
    case 'left': return 'right';
    case 'right': return 'left';
  }
}

// Anfänger AI: Spielt immer die erste Karte in den ersten verfügbaren Slot (sehr vorhersagbar)
function getBeginnerMove(aiHand: GameCard[], availableSlots: {slot: any, index: number}[]): AIMove {
  return {
    cardIndex: 0,
    boardIndex: availableSlots[0].index
  };
}

// Einfache AI: Zufällige Züge
function getEasyMove(aiHand: GameCard[], availableSlots: {slot: any, index: number}[]): AIMove {
  const randomCardIndex = Math.floor(Math.random() * aiHand.length);
  const randomSlotIndex = Math.floor(Math.random() * availableSlots.length);
  
  return {
    cardIndex: randomCardIndex,
    boardIndex: availableSlots[randomSlotIndex].index
  };
}

// Mittlere AI: Versucht Captures zu maximieren
function getMediumMove(aiHand: GameCard[], availableSlots: {slot: any, index: number}[], board: any[]): AIMove {
  let bestMove: AIMove = { cardIndex: 0, boardIndex: availableSlots[0].index };
  let maxCaptures = 0;

  for (let cardIndex = 0; cardIndex < aiHand.length; cardIndex++) {
    const card = aiHand[cardIndex];
    if (!card) continue;

    for (const { index: boardIndex } of availableSlots) {
      const captures = simulateCaptures(card, boardIndex, board);
      
      if (captures > maxCaptures) {
        maxCaptures = captures;
        bestMove = { cardIndex, boardIndex };
      }
    }
  }

  return bestMove;
}

// Schwere AI: Erweiterte Strategie mit Verteidigung
function getHardMove(aiHand: GameCard[], availableSlots: {slot: any, index: number}[], board: any[], playerCards: GameCard[]): AIMove {
  let bestMove: AIMove = { cardIndex: 0, boardIndex: availableSlots[0].index };
  let bestScore = -999;

  for (let cardIndex = 0; cardIndex < aiHand.length; cardIndex++) {
    const card = aiHand[cardIndex];
    if (!card) continue;

    for (const { index: boardIndex } of availableSlots) {
      const captures = simulateCaptures(card, boardIndex, board);
      const defensiveValue = calculateDefensiveValue(card, boardIndex, board);
      const positionalValue = calculatePositionalValue(boardIndex);
      
      // Kombiniere verschiedene Faktoren
      const totalScore = captures * 10 + defensiveValue * 5 + positionalValue * 2;
      
      if (totalScore > bestScore) {
        bestScore = totalScore;
        bestMove = { cardIndex, boardIndex };
      }
    }
  }

  return bestMove;
}

function calculateDefensiveValue(card: GameCard, boardIndex: number, board: any[]): number {
  let defensiveValue = 0;
  const row = Math.floor(boardIndex / 3);
  const col = boardIndex % 3;

  // Prüfe, wie gut diese Position gegen mögliche Angriffe verteidigt ist
  const neighbors = [
    { row: row - 1, col, direction: 'top' as const },
    { row: row + 1, col, direction: 'bottom' as const },
    { row, col: col - 1, direction: 'left' as const },
    { row, col: col + 1, direction: 'right' as const }
  ];

  for (const neighbor of neighbors) {
    if (neighbor.row >= 0 && neighbor.row < 3 && neighbor.col >= 0 && neighbor.col < 3) {
      const neighborIndex = neighbor.row * 3 + neighbor.col;
      
      // Wenn der Nachbar leer ist, könnte der Spieler dort eine gefährliche Karte platzieren
      if (!board[neighborIndex]) {
        const cardValue = getCardValue(card, neighbor.direction);
        defensiveValue += Math.min(cardValue, 5); // Belohne höhere Werte an exponierten Seiten
      }
    }
  }

  return defensiveValue;
}

function calculatePositionalValue(boardIndex: number): number {
  // Ecken und Mitte sind strategisch wertvoller
  const corners = [0, 2, 6, 8];
  const edges = [1, 3, 5, 7];
  const center = 4;

  if (boardIndex === center) return 8;
  if (corners.includes(boardIndex)) return 5;
  if (edges.includes(boardIndex)) return 3;
  return 0;
}

// Irrsinnige AI: Hochentwickelte Strategie mit mehreren Zügen im Voraus
function getInsaneMove(aiHand: GameCard[], availableSlots: {slot: any, index: number}[], board: any[], playerCards: GameCard[]): AIMove {
  let bestMove: AIMove = { cardIndex: 0, boardIndex: availableSlots[0].index };
  let bestScore = -999;

  for (let cardIndex = 0; cardIndex < aiHand.length; cardIndex++) {
    const card = aiHand[cardIndex];
    if (!card) continue;

    for (const { index: boardIndex } of availableSlots) {
      // Simuliere diesen Zug und berechne umfassenden Score
      const captures = simulateCaptures(card, boardIndex, board);
      const defensiveValue = calculateDefensiveValue(card, boardIndex, board);
      const positionalValue = calculatePositionalValue(boardIndex);
      const futureCapturePotential = calculateFutureCapturePotential(card, boardIndex, board);
      const blockingValue = calculateBlockingValue(card, boardIndex, board, playerCards);
      
      // Erweiterte Bewertung mit multiplen Faktoren
      const totalScore = 
        captures * 15 +           // Sofortige Captures sind sehr wichtig
        defensiveValue * 8 +      // Defensive Position
        positionalValue * 5 +     // Strategische Position
        futureCapturePotential * 6 + // Potential für zukünftige Captures
        blockingValue * 10;       // Blockierung von gegnerischen Strategien
      
      if (totalScore > bestScore) {
        bestScore = totalScore;
        bestMove = { cardIndex, boardIndex };
      }
    }
  }

  return bestMove;
}

function calculateFutureCapturePotential(card: GameCard, boardIndex: number, board: any[]): number {
  // Bewerte das Potential, andere Karten in zukünftigen Zügen zu erobern
  let potential = 0;
  const row = Math.floor(boardIndex / 3);
  const col = boardIndex % 3;

  const neighbors = [
    { row: row - 1, col, direction: 'top' as const },
    { row: row + 1, col, direction: 'bottom' as const },
    { row, col: col - 1, direction: 'left' as const },
    { row, col: col + 1, direction: 'right' as const }
  ];

  for (const neighbor of neighbors) {
    if (neighbor.row >= 0 && neighbor.row < 3 && neighbor.col >= 0 && neighbor.col < 3) {
      const neighborIndex = neighbor.row * 3 + neighbor.col;
      
      // Wenn der Slot leer ist, könnte dort eine eroberbare Karte platziert werden
      if (!board[neighborIndex]) {
        const cardValue = getCardValue(card, neighbor.direction);
        potential += Math.min(cardValue - 3, 4); // Potential basierend auf Kartenstärke
      }
    }
  }

  return Math.max(potential, 0);
}

function calculateBlockingValue(card: GameCard, boardIndex: number, board: any[], playerCards: GameCard[]): number {
  // Bewerte, wie gut dieser Zug gegnerische Strategien blockiert
  let blockingValue = 0;
  
  // Prüfe, ob diese Position wichtige strategische Punkte (Ecken, Mitte) blockiert
  const strategicPositions = [4, 0, 2, 6, 8]; // Mitte zuerst, dann Ecken
  if (strategicPositions.includes(boardIndex)) {
    blockingValue += 5;
  }
  
  return blockingValue;
}
