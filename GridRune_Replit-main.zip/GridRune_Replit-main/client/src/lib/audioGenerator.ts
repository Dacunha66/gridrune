// Web Audio API music generator for GridRune
export class AudioGenerator {
  private audioContext: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private oscillators: OscillatorNode[] = [];
  private isPlaying = false;

  constructor() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.gainNode = this.audioContext.createGain();
      this.gainNode.connect(this.audioContext.destination);
      this.gainNode.gain.value = 0.1; // Very quiet by default
    } catch (error) {
      console.warn('Web Audio API not supported');
    }
  }

  // Generate a simple melodic sequence
  private createMelody(baseFreq: number, pattern: number[], duration: number = 0.5) {
    if (!this.audioContext || !this.gainNode) return;

    const startTime = this.audioContext.currentTime;
    
    pattern.forEach((note, index) => {
      const frequency = baseFreq * Math.pow(2, note / 12); // Semitone calculation
      const oscillator = this.audioContext!.createOscillator();
      const envelope = this.audioContext!.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.value = frequency;
      
      // Create envelope (fade in/out)
      envelope.gain.setValueAtTime(0, startTime + index * duration);
      envelope.gain.linearRampToValueAtTime(0.05, startTime + index * duration + 0.1);
      envelope.gain.linearRampToValueAtTime(0, startTime + (index + 1) * duration);

      oscillator.connect(envelope);
      if (this.gainNode) {
        envelope.connect(this.gainNode);
      }

      oscillator.start(startTime + index * duration);
      oscillator.stop(startTime + (index + 1) * duration);
      
      this.oscillators.push(oscillator);
    });
  }

  // Different musical themes
  createZenTheme() {
    if (!this.audioContext) return;
    
    // Pentatonic scale for peaceful feel
    const melody = [0, 2, 4, 7, 9, 7, 4, 2]; // C, D, E, G, A, G, E, D
    this.createMelody(261.63, melody, 1.0); // C4 base frequency, slower tempo
    
    // Schedule next iteration
    setTimeout(() => {
      if (this.isPlaying) this.createZenTheme();
    }, 8000);
  }

  createBattleTheme() {
    if (!this.audioContext) return;
    
    // More aggressive minor scale
    const melody = [0, 3, 5, 8, 10, 8, 5, 3]; // C, Eb, F, Ab, Bb, Ab, F, Eb
    this.createMelody(220.00, melody, 0.3); // A3 base frequency, faster tempo
    
    setTimeout(() => {
      if (this.isPlaying) this.createBattleTheme();
    }, 2400);
  }

  createClassicTheme() {
    if (!this.audioContext) return;
    
    // Major scale melody
    const melody = [0, 4, 7, 12, 9, 7, 4, 0]; // C, E, G, C, A, G, E, C
    this.createMelody(293.66, melody, 0.6); // D4 base frequency, medium tempo
    
    setTimeout(() => {
      if (this.isPlaying) this.createClassicTheme();
    }, 4800);
  }

  start(theme: 'zen' | 'battle' | 'classic' = 'zen') {
    if (!this.audioContext) return;
    
    this.stop(); // Stop any current music
    this.isPlaying = true;

    // Resume audio context if suspended
    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }

    switch (theme) {
      case 'zen':
        this.createZenTheme();
        break;
      case 'battle':
        this.createBattleTheme();
        break;
      case 'classic':
        this.createClassicTheme();
        break;
    }
  }

  stop() {
    this.isPlaying = false;
    this.oscillators.forEach(osc => {
      try {
        osc.stop();
      } catch (e) {
        // Oscillator might already be stopped
      }
    });
    this.oscillators = [];
  }

  setVolume(volume: number) {
    if (this.gainNode) {
      this.gainNode.gain.value = volume * 0.1; // Keep it quiet
    }
  }

  // Convert to HTMLAudioElement-like interface for compatibility
  createCompatibleAudio(theme: 'zen' | 'battle' | 'classic') {
    const fakeAudio = {
      play: () => {
        this.start(theme);
        return Promise.resolve();
      },
      pause: () => {
        this.stop();
      },
      loop: true,
      volume: 0.1,
      currentTime: 0,
      effectName: theme.charAt(0).toUpperCase() + theme.slice(1) + '-Melodie'
    };

    return fakeAudio as any;
  }
}