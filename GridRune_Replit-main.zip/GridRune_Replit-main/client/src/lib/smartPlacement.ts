/**
 * Smart Placement System for Mobile
 * Provides intelligent placement suggestions and visual feedback
 */

import { GameCard } from "./cardData";

export interface PlacementSuggestion {
  index: number;
  score: number;
  type: 'optimal' | 'attack' | 'defense' | 'neutral';
  reasoning: string;
  expectedCaptures: number;
  vulnerabilityRisk: number;
}

export interface PlacementAnalysis {
  suggestions: PlacementSuggestion[];
  bestPlacement: PlacementSuggestion | null;
  worstPlacement: PlacementSuggestion | null;
  averageScore: number;
}

export class SmartPlacementAnalyzer {
  private boardSize = 4;
  private totalSlots = 16;

  /**
   * Analyze all possible placements for a card
   */
  analyzePlacements(
    card: GameCard,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>,
    validSlots: number[],
    playerOwner: "player1" | "player2"
  ): PlacementAnalysis {
    const suggestions: PlacementSuggestion[] = [];

    for (const slotIndex of validSlots) {
      const suggestion = this.analyzeSlot(card, board, slotIndex, playerOwner);
      suggestions.push(suggestion);
    }

    // Sort by score descending
    suggestions.sort((a, b) => b.score - a.score);

    const bestPlacement = suggestions[0] || null;
    const worstPlacement = suggestions[suggestions.length - 1] || null;
    const averageScore = suggestions.length > 0 
      ? suggestions.reduce((sum, s) => sum + s.score, 0) / suggestions.length 
      : 0;

    return {
      suggestions,
      bestPlacement,
      worstPlacement,
      averageScore
    };
  }

  /**
   * Analyze a specific slot for card placement
   */
  private analyzeSlot(
    card: GameCard,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>,
    slotIndex: number,
    playerOwner: "player1" | "player2"
  ): PlacementSuggestion {
    const adjacentSlots = this.getAdjacentSlots(slotIndex);
    const adjacentCards = adjacentSlots
      .map(index => board[index])
      .filter(slot => slot !== null);

    let score = 50; // Base score
    let expectedCaptures = 0;
    let vulnerabilityRisk = 0;
    let reasoning = '';
    let type: PlacementSuggestion['type'] = 'neutral';

    // Analyze immediate captures
    const captureAnalysis = this.analyzePotentialCaptures(card, board, slotIndex, playerOwner);
    expectedCaptures = captureAnalysis.captures;
    score += captureAnalysis.captures * 25; // +25 per capture

    // Analyze defensive value
    const defenseAnalysis = this.analyzeDefensiveValue(card, board, slotIndex, playerOwner);
    score += defenseAnalysis.defenseBonus;

    // Analyze vulnerability
    const vulnerabilityAnalysis = this.analyzeVulnerability(card, board, slotIndex, playerOwner);
    vulnerabilityRisk = vulnerabilityAnalysis.risk;
    score -= vulnerabilityAnalysis.penalty;

    // Analyze strategic positioning
    const positionAnalysis = this.analyzeStrategicPosition(slotIndex, board);
    score += positionAnalysis.bonus;

    // Determine placement type and reasoning
    if (expectedCaptures >= 2) {
      type = 'optimal';
      reasoning = `Exzellente Position! Kann ${expectedCaptures} Karten erobern.`;
    } else if (expectedCaptures >= 1) {
      type = 'attack';
      reasoning = `Gute Angriffsposition. Erobert ${expectedCaptures} Karte(n).`;
    } else if (defenseAnalysis.defenseBonus > 15) {
      type = 'defense';
      reasoning = 'Starke Verteidigungsposition. Schützt wichtige Bereiche.';
    } else if (vulnerabilityRisk > 0.7) {
      type = 'neutral';
      reasoning = 'Risiko: Position ist verwundbar für Gegenangriffe.';
    } else {
      type = 'neutral';
      reasoning = 'Neutrale Position. Weder großer Vorteil noch Nachteil.';
    }

    // Apply type-specific score modifiers
    switch (type) {
      case 'optimal':
        score *= 1.2;
        break;
      case 'attack':
        score *= 1.1;
        break;
      case 'defense':
        score *= 1.05;
        break;
    }

    return {
      index: slotIndex,
      score: Math.max(0, Math.min(100, score)),
      type,
      reasoning,
      expectedCaptures,
      vulnerabilityRisk
    };
  }

  /**
   * Analyze potential captures if card is placed at slot
   */
  private analyzePotentialCaptures(
    card: GameCard,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>,
    slotIndex: number,
    playerOwner: "player1" | "player2"
  ): { captures: number; details: string[] } {
    const adjacentSlots = this.getAdjacentSlots(slotIndex);
    const directions = ['top', 'right', 'bottom', 'left'];
    let captures = 0;
    const details: string[] = [];

    adjacentSlots.forEach((adjIndex, dirIndex) => {
      const adjacentSlot = board[adjIndex];
      if (adjacentSlot && adjacentSlot.owner !== playerOwner) {
        const direction = directions[dirIndex];
        const cardValue = this.getCardValueForDirection(card, direction);
        const adjDirection = this.getOppositeDirection(direction);
        const adjValue = this.getCardValueForDirection(adjacentSlot.card, adjDirection);

        if (cardValue > adjValue) {
          captures++;
          details.push(`${direction}: ${cardValue} > ${adjValue}`);
        }
      }
    });

    return { captures, details };
  }

  /**
   * Analyze defensive value of position
   */
  private analyzeDefensiveValue(
    card: GameCard,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>,
    slotIndex: number,
    playerOwner: "player1" | "player2"
  ): { defenseBonus: number; protectedCards: number } {
    const adjacentSlots = this.getAdjacentSlots(slotIndex);
    let defenseBonus = 0;
    let protectedCards = 0;

    // Check how many friendly cards this position would protect
    adjacentSlots.forEach((adjIndex) => {
      const adjacentSlot = board[adjIndex];
      if (adjacentSlot && adjacentSlot.owner === playerOwner) {
        protectedCards++;
        defenseBonus += 10; // +10 per protected friendly card
      }
    });

    // Bonus for corner and edge positions (harder to attack)
    if (this.isCornerPosition(slotIndex)) {
      defenseBonus += 15;
    } else if (this.isEdgePosition(slotIndex)) {
      defenseBonus += 8;
    }

    return { defenseBonus, protectedCards };
  }

  /**
   * Analyze vulnerability of position
   */
  private analyzeVulnerability(
    card: GameCard,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>,
    slotIndex: number,
    playerOwner: "player1" | "player2"
  ): { risk: number; penalty: number } {
    const adjacentSlots = this.getAdjacentSlots(slotIndex);
    const directions = ['top', 'right', 'bottom', 'left'];
    let vulnerableDirections = 0;
    let totalThreat = 0;

    adjacentSlots.forEach((adjIndex, dirIndex) => {
      const adjacentSlot = board[adjIndex];
      if (adjacentSlot && adjacentSlot.owner !== playerOwner) {
        const direction = directions[dirIndex];
        const cardValue = this.getCardValueForDirection(card, direction);
        const adjDirection = this.getOppositeDirection(direction);
        const adjValue = this.getCardValueForDirection(adjacentSlot.card, adjDirection);

        if (adjValue >= cardValue) {
          vulnerableDirections++;
          totalThreat += (adjValue - cardValue + 1);
        }
      }
    });

    const risk = vulnerableDirections / adjacentSlots.length;
    const penalty = totalThreat * 5; // Penalty based on threat level

    return { risk, penalty };
  }

  /**
   * Analyze strategic positioning value
   */
  private analyzeStrategicPosition(
    slotIndex: number,
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>
  ): { bonus: number } {
    let bonus = 0;

    // Central positions are generally more valuable
    const { row, col } = this.getRowCol(slotIndex);
    const distanceFromCenter = Math.abs(row - 1.5) + Math.abs(col - 1.5);
    bonus += Math.max(0, 10 - distanceFromCenter * 3);

    // Bonus for positions that complete patterns or control key areas
    const controlledAreas = this.calculateControlledAreas(slotIndex, board);
    bonus += controlledAreas * 5;

    return { bonus };
  }

  /**
   * Get adjacent slot indices for a given position
   */
  private getAdjacentSlots(index: number): number[] {
    const { row, col } = this.getRowCol(index);
    const adjacent: number[] = [];

    // Top
    if (row > 0) adjacent.push(this.getIndex(row - 1, col));
    // Right
    if (col < this.boardSize - 1) adjacent.push(this.getIndex(row, col + 1));
    // Bottom
    if (row < this.boardSize - 1) adjacent.push(this.getIndex(row + 1, col));
    // Left
    if (col > 0) adjacent.push(this.getIndex(row, col - 1));

    return adjacent;
  }

  /**
   * Get card value for a specific direction
   */
  private getCardValueForDirection(card: GameCard, direction: string): number {
    switch (direction) {
      case 'top': return card.top;
      case 'right': return card.right;
      case 'bottom': return card.bottom;
      case 'left': return card.left;
      default: return 0;
    }
  }

  /**
   * Get opposite direction
   */
  private getOppositeDirection(direction: string): string {
    const opposites: { [key: string]: string } = {
      'top': 'bottom',
      'right': 'left',
      'bottom': 'top',
      'left': 'right'
    };
    return opposites[direction] || direction;
  }

  /**
   * Check if position is a corner
   */
  private isCornerPosition(index: number): boolean {
    return index === 0 || index === 3 || index === 12 || index === 15;
  }

  /**
   * Check if position is an edge
   */
  private isEdgePosition(index: number): boolean {
    const { row, col } = this.getRowCol(index);
    return row === 0 || row === this.boardSize - 1 || col === 0 || col === this.boardSize - 1;
  }

  /**
   * Calculate controlled areas around position
   */
  private calculateControlledAreas(
    index: number, 
    board: Array<{ card: GameCard; owner: "player1" | "player2" } | null>
  ): number {
    // Simple implementation - count empty adjacent slots as potential control
    const adjacentSlots = this.getAdjacentSlots(index);
    return adjacentSlots.filter(adjIndex => board[adjIndex] === null).length;
  }

  /**
   * Convert index to row/col
   */
  private getRowCol(index: number): { row: number; col: number } {
    return {
      row: Math.floor(index / this.boardSize),
      col: index % this.boardSize
    };
  }

  /**
   * Convert row/col to index
   */
  private getIndex(row: number, col: number): number {
    return row * this.boardSize + col;
  }
}

// Global instance
export const smartPlacementAnalyzer = new SmartPlacementAnalyzer();