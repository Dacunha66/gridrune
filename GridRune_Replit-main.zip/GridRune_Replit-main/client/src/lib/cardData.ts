import { CardEffect } from "./cardEffects";

export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "ultimate";

export const RARITY_CONFIG = {
  common: {
    name: "Gewöhnlich",
    color: "text-gray-200",
    bgColor: "bg-gray-600",
    borderColor: "border-gray-400",
    emoji: "⚪",
    gradient: "bg-gradient-to-br from-gray-200 via-gray-300 to-gray-400",
    borderGradient: "linear-gradient(135deg, #9ca3af, #6b7280, #4b5563)",
    glowColor: "#9ca3af",
    shadowColor: "rgba(156, 163, 175, 0.3)",
    particleColors: ["#f3f4f6", "#e5e7eb", "#d1d5db"],
    intensity: 1
  },
  uncommon: {
    name: "Ungewöhnlich", 
    color: "text-green-300",
    bgColor: "bg-green-600",
    borderColor: "border-green-400",
    emoji: "🟢",
    gradient: "bg-gradient-to-br from-green-200 via-green-400 to-green-600",
    borderGradient: "linear-gradient(135deg, #4ade80, #22c55e, #16a34a)",
    glowColor: "#4ade80",
    shadowColor: "rgba(74, 222, 128, 0.4)",
    particleColors: ["#dcfce7", "#bbf7d0", "#86efac"],
    intensity: 1.2
  },
  rare: {
    name: "Selten",
    color: "text-blue-300", 
    bgColor: "bg-blue-600",
    borderColor: "border-blue-400",
    emoji: "🔵",
    gradient: "bg-gradient-to-br from-blue-200 via-blue-400 to-blue-600",
    borderGradient: "linear-gradient(135deg, #60a5fa, #3b82f6, #2563eb)",
    glowColor: "#60a5fa",
    shadowColor: "rgba(96, 165, 250, 0.5)",
    particleColors: ["#dbeafe", "#bfdbfe", "#93c5fd"],
    intensity: 1.5
  },
  epic: {
    name: "Episch",
    color: "text-purple-300",
    bgColor: "bg-purple-600", 
    borderColor: "border-purple-400",
    emoji: "🟣",
    gradient: "bg-gradient-to-br from-purple-200 via-purple-400 to-purple-600",
    borderGradient: "linear-gradient(135deg, #c084fc, #a855f7, #9333ea)",
    glowColor: "#c084fc",
    shadowColor: "rgba(192, 132, 252, 0.6)",
    particleColors: ["#f3e8ff", "#e9d5ff", "#d8b4fe"],
    intensity: 2
  },
  legendary: {
    name: "Legendär",
    color: "text-yellow-300",
    bgColor: "bg-yellow-600",
    borderColor: "border-yellow-400", 
    emoji: "🟡",
    gradient: "bg-gradient-to-br from-yellow-200 via-yellow-400 to-yellow-600",
    borderGradient: "linear-gradient(135deg, #facc15, #eab308, #ca8a04)",
    glowColor: "#facc15",
    shadowColor: "rgba(250, 204, 21, 0.6)",
    particleColors: ["#fefce8", "#fef3c7"],
    intensity: 2.0
  },
  ultimate: {
    name: "Ultimativ",
    color: "text-pink-300",
    bgColor: "bg-gradient-to-r from-red-800 to-purple-800",
    borderColor: "border-pink-400",
    emoji: "🌈",
    gradient: "bg-gradient-to-br from-red-400 via-pink-500 via-purple-500 via-blue-500 via-green-500 via-yellow-500 to-red-400",
    borderGradient: "linear-gradient(135deg, #f43f5e, #ec4899, #a855f7, #3b82f6, #10b981, #f59e0b, #ef4444)",
    glowColor: "#ec4899",
    shadowColor: "rgba(236, 72, 153, 0.8)",
    particleColors: ["#fdf2f8", "#fce7f3", "#f3e8ff", "#dbeafe", "#dcfce7", "#fef3c7", "#fef2f2"],
    intensity: 3.0
  }
} as const;

export interface GameCard {
  id: string;
  name?: string;
  image?: string;
  description?: string;
  rarity?: Rarity;
  element?: "fire" | "water" | "earth" | "lightning" | "wind" | "ice" | "nature" | "shadow" | "desert" | "crystal";
  top: number;
  right: number;
  bottom: number;
  left: number;
  effect?: CardEffect;
  isRune?: boolean; // Rune cards are spell cards with effects but no values
}

// Create the O-Card (neutral center card)
export function createOCard(): GameCard {
  return {
    id: "O",
    top: 5,
    right: 5,
    bottom: 5,
    left: 5
  };
}

// Create player deck with predefined cards
export function createPlayerDeck(player: 1 | 2): GameCard[] {
  const baseCards: Omit<GameCard, 'id'>[] = [
    { name: "Fire Dragon", image: "/images/fire-dragon.png", element: "fire", top: 8, right: 3, bottom: 4, left: 2, rarity: "legendary", effect: "sniper" },
    { name: "Water Spirit", image: "/images/water-spirit.png", element: "water", top: 5, right: 7, bottom: 3, left: 6, rarity: "epic", effect: "stille" },
    { name: "Golem", image: "/images/earth-golem.png", element: "earth", top: 2, right: 8, bottom: 7, left: 1, rarity: "legendary", effect: "schild" },
    { name: "Wind Eagle", image: "/images/wind-eagle.png", top: 9, right: 3, bottom: 2, left: 6, rarity: "epic" },
    { name: "Lightning Wolf", image: "/images/lightning-wolf.png", element: "lightning", top: 4, right: 9, bottom: 2, left: 5, rarity: "legendary", effect: "blitzschlag" },
    { name: "Ice Bear", image: "/images/ice-bear.png", element: "water", top: 7, right: 1, bottom: 6, left: 8, rarity: "uncommon" },
    { name: "Shadow Cat", image: "/images/shadow-cat.png", element: "earth", top: 3, right: 6, bottom: 9, left: 3, rarity: "epic", effect: "tarnung" },
    { name: "Crystal Phoenix", image: "/images/crystal-phoenix.png", element: "fire", top: 9, right: 4, bottom: 1, left: 7, rarity: "legendary" },
    { name: "Forest Sprite", image: "/images/forest-sprite.png", top: 1, right: 5, bottom: 5, left: 9, rarity: "common" },
    { name: "Storm Hawk", image: "/images/storm-hawk.png", element: "lightning", top: 5, right: 8, bottom: 4, left: 2, rarity: "uncommon", effect: "blitzschlag" },
    { name: "Mountain Lion", image: "/images/mountain-lion.png", element: "earth", top: 6, right: 3, bottom: 7, left: 6, rarity: "common" },
    { name: "Ocean Whale", image: "/images/ocean-whale.png", element: "water", top: 8, right: 6, bottom: 2, left: 4, rarity: "epic", effect: "verstaerkung" },
    { name: "Desert Snake", image: "/images/desert-snake.png", element: "earth", top: 2, right: 7, bottom: 8, left: 3, rarity: "rare" },
    { name: "Sky Raven", image: "/images/sky-raven.png", top: 4, right: 1, bottom: 6, left: 8, rarity: "common" },
    { name: "Flame Tiger", image: "/images/flame-tiger.png", element: "fire", top: 7, right: 9, bottom: 3, left: 1, rarity: "legendary", effect: "staerkung" }
  ];

  return baseCards.map((card, index) => ({
    ...card,
    id: `P${player}-${index + 1}`
  }));
}

// Export all available cards for deck editing
export const allCards: GameCard[] = [
  // Fire cards
  { id: "fire-dragon", name: "Fire Dragon", image: "/images/fire-dragon.png", element: "fire", top: 8, right: 2, bottom: 4, left: 6, rarity: "legendary", effect: "sniper" },
  { id: "flame-tiger", name: "Flame Tiger", image: "/images/flame-tiger.png", element: "fire", top: 6, right: 7, bottom: 3, left: 4, rarity: "rare", effect: "staerkung" },
  // Water cards
  { id: "water-spirit", name: "Water Spirit", image: "/images/water-spirit.png", element: "water", top: 3, right: 8, bottom: 5, left: 4, rarity: "rare", effect: "stille" },
  { id: "ocean-whale", name: "Ocean Whale", image: "/images/ocean-whale.png", element: "water", top: 5, right: 3, bottom: 7, left: 6, rarity: "epic", effect: "verstaerkung" },
  // Earth cards
  { id: "earth-golem", name: "Earth Golem", image: "/images/earth-golem.png", element: "earth", top: 6, right: 3, bottom: 9, left: 2, rarity: "epic", effect: "schild" },
  { id: "mountain-lion", name: "Mountain Lion", image: "/images/mountain-lion.png", element: "earth", top: 4, right: 5, bottom: 6, left: 8, rarity: "common", effect: "anker" },
  { id: "desert-snake", name: "Desert Snake", image: "/images/desert-snake.png", element: "earth", top: 2, right: 7, bottom: 8, left: 3, rarity: "uncommon", effect: "stachelruestung" },
  // Lightning cards
  { id: "lightning-wolf", name: "Lightning Wolf", image: "/images/lightning-wolf.png", element: "lightning", top: 4, right: 9, bottom: 2, left: 5, rarity: "legendary", effect: "blitzschlag" },
  { id: "storm-hawk", name: "Storm Hawk", image: "/images/storm-hawk.png", element: "lightning", top: 7, right: 4, bottom: 3, left: 6, rarity: "uncommon", effect: "blitzschlag" },
  // Wind/Air cards
  { id: "wind-eagle", name: "Wind Eagle", image: "/images/wind-eagle.png", top: 9, right: 3, bottom: 2, left: 6, rarity: "epic" },
  { id: "sky-raven", name: "Sky Raven", image: "/images/sky-raven.png", top: 5, right: 6, bottom: 4, left: 5, rarity: "common", effect: "berserker" },
  // Water cards (Ice Bear is water element)
  { id: "ice-bear", name: "Ice Bear", image: "/images/ice-bear.png", element: "water", top: 7, right: 1, bottom: 6, left: 8, rarity: "uncommon", effect: "clone" },
  // Nature cards
  { id: "forest-sprite", name: "Forest Sprite", image: "/images/forest-sprite.png", top: 1, right: 5, bottom: 5, left: 9, rarity: "common", effect: "infektion" },
  // Earth cards (Shadow Cat is earth element)
  { id: "shadow-cat", name: "Shadow Cat", image: "/images/shadow-cat.png", element: "earth", top: 3, right: 6, bottom: 9, left: 3, rarity: "epic", effect: "tarnung" },
  // Fire cards (Crystal Phoenix is fire element)
  { id: "crystal-phoenix", name: "Crystal Phoenix", image: "/images/crystal-phoenix.png", element: "fire", top: 9, right: 4, bottom: 1, left: 7, rarity: "legendary", effect: "sniper" },

  // Runenkarten (Zauberkarten ohne Werte)
  { id: "rune-light", name: "Rune des Lichts", image: "/images/Rune des Lichts.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "rare", effect: "licht", isRune: true },
  { id: "rune-mist", name: "Rune des Nebels", image: "/images/Rune des Nebels.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "epic", effect: "nebel", isRune: true },
  { id: "rune-cunning", name: "Rune der List", image: "/images/Rune der List.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "ultimate", effect: "list", isRune: true },
  { id: "rune-healing", name: "Rune der Heilung", image: "/images/Rune der Heilung.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "runenheilung", isRune: true },
  { id: "rune-mirror", name: "Rune der Spiegelung", image: "/images/Rune der Spiegelung.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "spiegelung", isRune: true },
  { id: "rune-strength", name: "Rune der Stärke", image: "/images/Rune der Stärke.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "epic", effect: "runenstärke", isRune: true },
  { id: "rune-silence", name: "Rune der Stille", image: "/images/Rune der Stille.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "runenstille", isRune: true },
  { id: "rune-fire", name: "Rune des Feuers", image: "/images/Rune des Feuers.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "ultimate", effect: "runenfeuer", isRune: true },
  { id: "rune-ice", name: "Rune des Eises", image: "/images/Rune des Eises.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "runeneis", isRune: true },
  { id: "rune-protection", name: "Rune des Schutzes", image: "/images/Rune des Schutzes.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "runenschutz", isRune: true },
  { id: "rune-void", name: "Rune der Leere", image: "/images/Rune der Leere.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "ultimate", effect: "leere", isRune: true },
  { id: "rune-discharge", name: "Rune der Entladung", image: "/images/Rune des Entladung.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "legendary", effect: "entladung", isRune: true },
  { id: "rune-control", name: "Rune der Kontrolle", image: "/images/Rune der Kontrolle.png", top: 0, right: 0, bottom: 0, left: 0, rarity: "epic", effect: "kontrolle", isRune: true }
];

// Create extended deck for 5x5 gameplay (15 cards)
export function createExtendedDeck(player?: number): GameCard[] {
  const selectedCards = allCards.slice(); // Use all available cards

  // Shuffle and select 15 random cards
  const shuffled = selectedCards.sort(() => Math.random() - 0.5);
  const deck = shuffled.slice(0, 15);

  return deck.map((card, index) => ({
    ...card,
    id: player ? `P${player}-${index + 1}` : card.id
  }));
}

export const ELEMENT_COLORS = {
  fire: "text-red-400",
  water: "text-blue-400", 
  earth: "text-yellow-600",
  lightning: "text-yellow-400",
  wind: "text-green-400",
  ice: "text-cyan-400",
  nature: "text-emerald-400",
  shadow: "text-purple-400",
  desert: "text-orange-400",
  crystal: "text-pink-400"
} as const;