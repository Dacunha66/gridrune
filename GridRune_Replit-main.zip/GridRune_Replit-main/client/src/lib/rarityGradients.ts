import { Rarity, RARITY_CONFIG } from './cardData';

/**
 * Dynamic Card Rarity Color Gradient System
 * Provides advanced visual effects based on card rarity
 */

export interface GradientAnimation {
  type: 'shimmer' | 'pulse' | 'flow' | 'sparkle' | 'aurora';
  duration: number;
  intensity: number;
}

export interface RarityVisualEffects {
  backgroundGradient: string;
  borderGradient: string;
  glowEffect: string;
  shadowEffect: string;
  animation: GradientAnimation;
  particleEffect?: {
    colors: readonly string[];
    count: number;
    speed: number;
  };
}

export function getRarityVisualEffects(rarity: Rarity | undefined): RarityVisualEffects {
  if (!rarity) {
    return {
      backgroundGradient: 'bg-gradient-to-br from-gray-600 to-gray-800',
      borderGradient: 'linear-gradient(135deg, #4b5563, #374151)',
      glowEffect: '0 0 0px rgba(107, 114, 128, 0)',
      shadowEffect: '0 2px 8px rgba(0, 0, 0, 0.2)',
      animation: { type: 'pulse', duration: 2000, intensity: 0.5 }
    };
  }

  const config = RARITY_CONFIG[rarity];

  return {
    backgroundGradient: config.gradient,
    borderGradient: config.borderGradient,
    glowEffect: `0 0 ${config.intensity * 8}px ${config.glowColor}${Math.round(config.intensity * 40).toString(16)}`,
    shadowEffect: `0 ${config.intensity * 4}px ${config.intensity * 16}px ${config.shadowColor}`,
    animation: getAnimationForRarity(rarity),
    particleEffect: config.particleColors ? {
      colors: config.particleColors,
      count: Math.floor(config.intensity * 3),
      speed: config.intensity * 0.5
    } : undefined
  };
}

function getAnimationForRarity(rarity: Rarity): GradientAnimation {
  switch (rarity) {
    case 'common':
      return { type: 'pulse', duration: 3000, intensity: 0.5 };
    case 'uncommon':
      return { type: 'shimmer', duration: 2500, intensity: 0.7 };
    case 'rare':
      return { type: 'flow', duration: 2000, intensity: 1.0 };
    case 'epic':
      return { type: 'sparkle', duration: 1500, intensity: 1.5 };
    case 'legendary':
      return { type: 'sparkle', duration: 1500, intensity: 1.5 };
    case 'ultimate':
      return { type: 'aurora', duration: 3000, intensity: 3.0 };
    default:
      return { type: 'pulse', duration: 2000, intensity: 0.5 };
  }
}

export function generateDynamicGradientCSS(rarity: Rarity | undefined, isHovered: boolean = false, isSelected: boolean = false): string {
  if (!rarity) return '';

  const config = RARITY_CONFIG[rarity];
  const baseIntensity = config.intensity;
  const hoverMultiplier = isHovered ? 1.3 : 1;
  const selectedMultiplier = isSelected ? 1.5 : 1;
  const totalIntensity = baseIntensity * hoverMultiplier * selectedMultiplier;

  return `
    background: ${config.gradient};
    border-image: ${config.borderGradient} 1;
    box-shadow: 
      ${generateGlowEffect(config.glowColor, totalIntensity)},
      ${config.shadowColor.replace(/[\d.]+\)$/, `${totalIntensity * 0.3})`)} 0 ${totalIntensity * 4}px ${totalIntensity * 16}px;
    filter: brightness(${1 + totalIntensity * 0.1});
  `;
}

function generateGlowEffect(color: string, intensity: number): string {
  const glowRadius = Math.min(intensity * 8, 32);
  const opacity = Math.min(intensity * 0.4, 0.8);
  return `0 0 ${glowRadius}px ${color}${Math.round(opacity * 255).toString(16)}`;
}

export function getRarityAnimationKeyframes(rarity: Rarity): string {
  const animation = getAnimationForRarity(rarity);

  switch (animation.type) {
    case 'shimmer':
      return `
        @keyframes rarity-shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
      `;
    case 'pulse':
      return `
        @keyframes rarity-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.02); }
        }
      `;
    case 'flow':
      return `
        @keyframes rarity-flow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `;
    case 'sparkle':
      return `
        @keyframes rarity-sparkle {
          0%, 100% { filter: brightness(1) saturate(1); }
          25% { filter: brightness(1.2) saturate(1.3); }
          50% { filter: brightness(1.4) saturate(1.5); }
          75% { filter: brightness(1.2) saturate(1.3); }
        }
      `;
    case 'aurora':
      return `
        @keyframes rarity-aurora {
          0% { 
            background-position: 0% 0%;
            filter: hue-rotate(0deg) brightness(1);
          }
          33% { 
            background-position: 100% 100%;
            filter: hue-rotate(120deg) brightness(1.2);
          }
          66% { 
            background-position: 0% 100%;
            filter: hue-rotate(240deg) brightness(1.1);
          }
          100% { 
            background-position: 0% 0%;
            filter: hue-rotate(360deg) brightness(1);
          }
        }
      `;
    default:
      return '';
  }
}

export function getParticleEffect(rarity: Rarity | undefined): readonly string[] {
  if (!rarity || !RARITY_CONFIG[rarity].particleColors) return [];
  return RARITY_CONFIG[rarity].particleColors || [];
}