/**
 * Enhanced Gesture Handler
 * Provides sophisticated touch gesture recognition for card interactions
 */

export interface TouchPoint {
  x: number;
  y: number;
  timestamp: number;
}

export interface GestureEvent {
  type: GestureType;
  startPoint: TouchPoint;
  endPoint: TouchPoint;
  deltaX: number;
  deltaY: number;
  distance: number;
  duration: number;
  velocity: number;
  element?: Element;
}

export enum GestureType {
  TAP = 'tap',
  LONG_PRESS = 'longPress',
  SWIPE_LEFT = 'swipeLeft',
  SWIPE_RIGHT = 'swipeRight',
  SWIPE_UP = 'swipeUp',
  SWIPE_DOWN = 'swipeDown',
  DOUBLE_TAP = 'doubleTap',
  PINCH = 'pinch',
  DRAG = 'drag'
}

export interface GestureOptions {
  tapThreshold?: number; // Max movement for tap (px)
  longPressDelay?: number; // Long press duration (ms)
  swipeThreshold?: number; // Min distance for swipe (px)
  swipeVelocity?: number; // Min velocity for swipe (px/ms)
  doubleTapDelay?: number; // Max time between taps (ms)
  preventScroll?: boolean; // Prevent default scroll behavior
}

export type GestureCallback = (event: GestureEvent) => void;

class GestureHandler {
  private element: HTMLElement;
  private options: GestureOptions;
  private callbacks: Map<GestureType, GestureCallback[]> = new Map();
  
  private startPoint: TouchPoint | null = null;
  private currentPoint: TouchPoint | null = null;
  private longPressTimer: NodeJS.Timeout | null = null;
  private lastTapTime: number = 0;
  private tapCount: number = 0;
  
  constructor(element: HTMLElement, options: GestureOptions = {}) {
    this.element = element;
    this.options = {
      tapThreshold: 10,
      longPressDelay: 500,
      swipeThreshold: 30,
      swipeVelocity: 0.3,
      doubleTapDelay: 300,
      preventScroll: true,
      ...options
    };
    
    this.setupEventListeners();
  }

  private setupEventListeners(): void {
    this.element.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: false });
    this.element.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: false });
    this.element.addEventListener('touchend', this.handleTouchEnd.bind(this), { passive: false });
    this.element.addEventListener('touchcancel', this.handleTouchCancel.bind(this), { passive: false });
  }

  private handleTouchStart(e: TouchEvent): void {
    if (this.options.preventScroll) {
      e.preventDefault();
    }

    const touch = e.touches[0];
    this.startPoint = {
      x: touch.clientX,
      y: touch.clientY,
      timestamp: Date.now()
    };
    this.currentPoint = { ...this.startPoint };

    // Setup long press detection
    this.longPressTimer = setTimeout(() => {
      if (this.startPoint && this.currentPoint) {
        const distance = this.calculateDistance(this.startPoint, this.currentPoint);
        if (distance < this.options.tapThreshold!) {
          this.triggerGesture(GestureType.LONG_PRESS);
        }
      }
    }, this.options.longPressDelay);
  }

  private handleTouchMove(e: TouchEvent): void {
    if (this.options.preventScroll) {
      e.preventDefault();
    }

    if (!this.startPoint) return;

    const touch = e.touches[0];
    this.currentPoint = {
      x: touch.clientX,
      y: touch.clientY,
      timestamp: Date.now()
    };

    // Cancel long press if moved too much
    const distance = this.calculateDistance(this.startPoint, this.currentPoint);
    if (distance > this.options.tapThreshold! && this.longPressTimer) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }
  }

  private handleTouchEnd(e: TouchEvent): void {
    if (this.options.preventScroll) {
      e.preventDefault();
    }

    if (!this.startPoint || !this.currentPoint) return;

    // Clear long press timer
    if (this.longPressTimer) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }

    const endPoint: TouchPoint = {
      x: e.changedTouches[0].clientX,
      y: e.changedTouches[0].clientY,
      timestamp: Date.now()
    };

    this.processGesture(this.startPoint, endPoint);
    this.reset();
  }

  private handleTouchCancel(): void {
    if (this.longPressTimer) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }
    this.reset();
  }

  private processGesture(start: TouchPoint, end: TouchPoint): void {
    const deltaX = end.x - start.x;
    const deltaY = end.y - start.y;
    const distance = this.calculateDistance(start, end);
    const duration = end.timestamp - start.timestamp;
    const velocity = distance / duration;

    // Check for tap or double tap
    if (distance < this.options.tapThreshold!) {
      const now = Date.now();
      if (now - this.lastTapTime < this.options.doubleTapDelay!) {
        this.tapCount++;
        if (this.tapCount === 2) {
          this.triggerGesture(GestureType.DOUBLE_TAP, start, end);
          this.tapCount = 0;
          return;
        }
      } else {
        this.tapCount = 1;
      }
      this.lastTapTime = now;
      
      // Delay tap to check for double tap
      setTimeout(() => {
        if (this.tapCount === 1) {
          this.triggerGesture(GestureType.TAP, start, end);
          this.tapCount = 0;
        }
      }, this.options.doubleTapDelay);
      return;
    }

    // Check for swipe
    if (distance > this.options.swipeThreshold! && velocity > this.options.swipeVelocity!) {
      const absX = Math.abs(deltaX);
      const absY = Math.abs(deltaY);

      if (absX > absY) {
        // Horizontal swipe
        if (deltaX > 0) {
          this.triggerGesture(GestureType.SWIPE_RIGHT, start, end);
        } else {
          this.triggerGesture(GestureType.SWIPE_LEFT, start, end);
        }
      } else {
        // Vertical swipe
        if (deltaY > 0) {
          this.triggerGesture(GestureType.SWIPE_DOWN, start, end);
        } else {
          this.triggerGesture(GestureType.SWIPE_UP, start, end);
        }
      }
    }
  }

  private triggerGesture(type: GestureType, start?: TouchPoint, end?: TouchPoint): void {
    if (!start) start = this.startPoint!;
    if (!end) end = this.currentPoint!;

    const gestureEvent: GestureEvent = {
      type,
      startPoint: start,
      endPoint: end,
      deltaX: end.x - start.x,
      deltaY: end.y - start.y,
      distance: this.calculateDistance(start, end),
      duration: end.timestamp - start.timestamp,
      velocity: this.calculateDistance(start, end) / (end.timestamp - start.timestamp),
      element: this.element
    };

    const callbacks = this.callbacks.get(type);
    if (callbacks) {
      callbacks.forEach(callback => callback(gestureEvent));
    }
  }

  private calculateDistance(point1: TouchPoint, point2: TouchPoint): number {
    const dx = point2.x - point1.x;
    const dy = point2.y - point1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  private reset(): void {
    this.startPoint = null;
    this.currentPoint = null;
  }

  // Public API
  public on(gesture: GestureType, callback: GestureCallback): void {
    if (!this.callbacks.has(gesture)) {
      this.callbacks.set(gesture, []);
    }
    this.callbacks.get(gesture)!.push(callback);
  }

  public off(gesture: GestureType, callback?: GestureCallback): void {
    if (!callback) {
      this.callbacks.delete(gesture);
      return;
    }

    const callbacks = this.callbacks.get(gesture);
    if (callbacks) {
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  public destroy(): void {
    this.element.removeEventListener('touchstart', this.handleTouchStart.bind(this));
    this.element.removeEventListener('touchmove', this.handleTouchMove.bind(this));
    this.element.removeEventListener('touchend', this.handleTouchEnd.bind(this));
    this.element.removeEventListener('touchcancel', this.handleTouchCancel.bind(this));
    
    if (this.longPressTimer) {
      clearTimeout(this.longPressTimer);
    }
    
    this.callbacks.clear();
  }
}

export { GestureHandler };