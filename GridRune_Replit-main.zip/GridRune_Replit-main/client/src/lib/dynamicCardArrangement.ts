import { GameCard } from "./cardData";
import { BoardSlot } from "./stores/useCardGame";

export interface CardAnalysis {
  card: GameCard;
  index: number;
  strategicValue: number;
  synergies: string[];
  threats: string[];
  bestPositions: number[];
}

export interface ArrangementStrategy {
  name: string;
  priority: number;
  description: string;
}

/**
 * Dynamic Card Arrangement Algorithm
 * Intelligently orders hand cards based on strategic value, game state, and synergies
 */
export class DynamicCardArrangement {
  private board: (BoardSlot | null)[];
  private elementFields: any[];
  private currentPlayer: "player1" | "player2";
  private gamePhase: string;

  constructor(
    board: (BoardSlot | null)[],
    elementFields: any[],
    currentPlayer: "player1" | "player2",
    gamePhase: string
  ) {
    this.board = board;
    this.elementFields = elementFields;
    this.currentPlayer = currentPlayer;
    this.gamePhase = gamePhase;
  }

  /**
   * Main arrangement function that reorders hand cards optimally
   */
  arrangeCards(hand: GameCard[]): GameCard[] {
    if (!hand || hand.length === 0) return hand;

    const analyses = hand.map((card, index) => this.analyzeCard(card, index));
    const strategies = this.determineStrategies();
    
    // Apply weighted scoring based on current strategies
    const scoredCards = analyses.map(analysis => ({
      ...analysis,
      finalScore: this.calculateFinalScore(analysis, strategies)
    }));

    // Sort by final score (highest first) and return reordered cards
    return scoredCards
      .sort((a, b) => b.finalScore - a.finalScore)
      .map(analysis => analysis.card);
  }

  /**
   * Analyze individual card for strategic value
   */
  private analyzeCard(card: GameCard, index: number): CardAnalysis {
    const strategicValue = this.calculateStrategicValue(card);
    const synergies = this.findSynergies(card);
    const threats = this.identifyThreats(card);
    const bestPositions = this.findBestPositions(card);

    return {
      card,
      index,
      strategicValue,
      synergies,
      threats,
      bestPositions
    };
  }

  /**
   * Calculate base strategic value of a card
   */
  private calculateStrategicValue(card: GameCard): number {
    let value = 0;

    // Base stat value (average of all directional values)
    const statSum = card.top + card.right + card.bottom + card.left;
    value += statSum * 0.25; // Weight stats moderately

    // Effect value multipliers
    const effectValues: Record<string, number> = {
      "blitzschlag": 15, // High value for damage effect
      "clone": 12,       // High value for versatility
      "schild": 10,      // Good defensive value
      "heilung": 8,      // Moderate healing value
      "tarnung": 7,      // Situational stealth
      "spiegelung": 6,   // Situational reflection
      "verstärkung": 5   // Minor stat boost
    };

    if (card.effect && effectValues[card.effect]) {
      value += effectValues[card.effect];
    }

    // Rarity bonus
    const rarityValues: Record<string, number> = {
      "legendary": 8,
      "epic": 5,
      "rare": 3,
      "uncommon": 2,
      "common": 1
    };

    if (card.rarity && rarityValues[card.rarity]) {
      value += rarityValues[card.rarity];
    }

    // Element field synergy bonus
    if (this.hasElementFieldSynergy(card)) {
      value += 6;
    }

    return value;
  }

  /**
   * Find synergies with board state and other cards
   */
  private findSynergies(card: GameCard): string[] {
    const synergies: string[] = [];

    // Element field synergies
    if (this.hasElementFieldSynergy(card)) {
      synergies.push(`element-${card.element}`);
    }

    // Effect synergies with board state
    if (card.effect === "heilung" && this.hasDamagedAllies()) {
      synergies.push("healing-needed");
    }

    if (card.effect === "blitzschlag" && this.hasEnemyTargets()) {
      synergies.push("blitzschlag-targets");
    }

    if (card.effect === "clone" && this.hasStrongEnemies()) {
      synergies.push("clone-opportunities");
    }

    return synergies;
  }

  /**
   * Identify potential threats this card faces
   */
  private identifyThreats(card: GameCard): string[] {
    const threats: string[] = [];

    // Check for enemy cards that could easily capture this card
    for (const slot of this.board) {
      if (slot && slot.owner !== this.currentPlayer && slot.owner !== "neutral") {
        if (this.canCapture(slot.card, card)) {
          threats.push(`threat-${slot.card.name || slot.card.id}`);
        }
      }
    }

    return threats;
  }

  /**
   * Find best board positions for this card
   */
  private findBestPositions(card: GameCard): number[] {
    const positions: number[] = [];

    for (let i = 0; i < this.board.length; i++) {
      if (!this.board[i]) { // Empty slot
        const score = this.evaluatePosition(card, i);
        if (score > 0) {
          positions.push(i);
        }
      }
    }

    // Sort positions by evaluation score
    return positions.sort((a, b) => 
      this.evaluatePosition(card, b) - this.evaluatePosition(card, a)
    ).slice(0, 3); // Return top 3 positions
  }

  /**
   * Evaluate how good a position would be for a card
   */
  private evaluatePosition(card: GameCard, position: number): number {
    let score = 0;

    // Check adjacent positions for capture opportunities
    const adjacentPositions = this.getAdjacentPositions(position);
    
    for (const adjPos of adjacentPositions) {
      const adjSlot = this.board[adjPos];
      if (adjSlot && adjSlot.owner !== this.currentPlayer) {
        // Calculate capture probability
        const direction = this.getDirection(position, adjPos);
        const cardValue = this.getCardValueInDirection(card, direction);
        const enemyValue = this.getCardValueInDirection(adjSlot.card, this.getOppositeDirection(direction));
        
        if (cardValue > enemyValue) {
          score += 10; // Capture opportunity
        }
      }
    }

    // Element field bonus
    const elementField = this.elementFields.find(field => field.position === position);
    if (elementField && elementField.element === card.element) {
      score += 8;
    }

    // Center positions are generally more valuable
    const boardSize = Math.sqrt(this.board.length);
    const centerPositions = this.getCenterPositions(boardSize);
    if (centerPositions.includes(position)) {
      score += 5;
    }

    return score;
  }

  /**
   * Determine current strategic priorities
   */
  private determineStrategies(): ArrangementStrategy[] {
    const strategies: ArrangementStrategy[] = [];

    // Aggressive strategy if we have few cards on board
    const ourCards = this.board.filter(slot => slot && slot.owner === this.currentPlayer).length;
    if (ourCards < 3) {
      strategies.push({
        name: "aggressive",
        priority: 8,
        description: "Focus on board presence"
      });
    }

    // Defensive strategy if opponent has board control
    const enemyCards = this.board.filter(slot => 
      slot && slot.owner !== this.currentPlayer && slot.owner !== "neutral"
    ).length;
    if (enemyCards > ourCards + 1) {
      strategies.push({
        name: "defensive",
        priority: 7,
        description: "Counter enemy threats"
      });
    }

    // Effect-focused strategy
    strategies.push({
      name: "effect-priority",
      priority: 6,
      description: "Prioritize special effects"
    });

    return strategies;
  }

  /**
   * Calculate final score based on analysis and strategies
   */
  private calculateFinalScore(analysis: CardAnalysis, strategies: ArrangementStrategy[]): number {
    let score = analysis.strategicValue;

    // Apply strategy bonuses
    for (const strategy of strategies) {
      switch (strategy.name) {
        case "aggressive":
          if (analysis.card.effect === "blitzschlag" || this.hasHighOffensiveStats(analysis.card)) {
            score += strategy.priority * 1.5;
          }
          break;
        case "defensive":
          if (analysis.card.effect === "schild" || analysis.card.effect === "heilung") {
            score += strategy.priority * 1.3;
          }
          break;
        case "effect-priority":
          if (analysis.card.effect) {
            score += strategy.priority;
          }
          break;
      }
    }

    // Synergy bonuses
    score += analysis.synergies.length * 3;

    // Threat penalties
    score -= analysis.threats.length * 2;

    // Position opportunity bonus
    score += analysis.bestPositions.length * 1.5;

    return score;
  }

  // Helper methods
  private hasElementFieldSynergy(card: GameCard): boolean {
    return this.elementFields.some(field => field.element === card.element);
  }

  private hasDamagedAllies(): boolean {
    return this.board.some(slot => 
      slot && slot.owner === this.currentPlayer && 
      (slot.card.top < slot.originalCard.top || 
       slot.card.right < slot.originalCard.right ||
       slot.card.bottom < slot.originalCard.bottom ||
       slot.card.left < slot.originalCard.left)
    );
  }

  private hasEnemyTargets(): boolean {
    return this.board.some(slot => 
      slot && slot.owner !== this.currentPlayer && slot.owner !== "neutral"
    );
  }

  private hasStrongEnemies(): boolean {
    return this.board.some(slot => {
      if (slot && slot.owner !== this.currentPlayer && slot.owner !== "neutral") {
        const avgStat = (slot.card.top + slot.card.right + slot.card.bottom + slot.card.left) / 4;
        return avgStat > 6;
      }
      return false;
    });
  }

  private canCapture(attacker: GameCard, defender: GameCard): boolean {
    // Simplified capture logic - would need full battle resolution logic
    const attackerAvg = (attacker.top + attacker.right + attacker.bottom + attacker.left) / 4;
    const defenderAvg = (defender.top + defender.right + defender.bottom + defender.left) / 4;
    return attackerAvg > defenderAvg + 2;
  }

  private hasHighOffensiveStats(card: GameCard): boolean {
    return Math.max(card.top, card.right, card.bottom, card.left) >= 8;
  }

  private getAdjacentPositions(position: number): number[] {
    const boardSize = Math.sqrt(this.board.length);
    const row = Math.floor(position / boardSize);
    const col = position % boardSize;
    const adjacent: number[] = [];

    // Top
    if (row > 0) adjacent.push((row - 1) * boardSize + col);
    // Right  
    if (col < boardSize - 1) adjacent.push(row * boardSize + (col + 1));
    // Bottom
    if (row < boardSize - 1) adjacent.push((row + 1) * boardSize + col);
    // Left
    if (col > 0) adjacent.push(row * boardSize + (col - 1));

    return adjacent;
  }

  private getDirection(from: number, to: number): "top" | "right" | "bottom" | "left" {
    const boardSize = Math.sqrt(this.board.length);
    const fromRow = Math.floor(from / boardSize);
    const fromCol = from % boardSize;
    const toRow = Math.floor(to / boardSize);
    const toCol = to % boardSize;

    if (toRow < fromRow) return "top";
    if (toCol > fromCol) return "right";
    if (toRow > fromRow) return "bottom";
    return "left";
  }

  private getOppositeDirection(direction: "top" | "right" | "bottom" | "left"): "top" | "right" | "bottom" | "left" {
    const opposites = { top: "bottom", right: "left", bottom: "top", left: "right" };
    return opposites[direction];
  }

  private getCardValueInDirection(card: GameCard, direction: "top" | "right" | "bottom" | "left"): number {
    return card[direction];
  }

  private getCenterPositions(boardSize: number): number[] {
    if (boardSize === 3) return [4]; // 3x3 center
    if (boardSize === 4) return [5, 6, 9, 10]; // 4x4 center positions
    return [];
  }
}

/**
 * Factory function to create and use the arrangement algorithm
 */
export function arrangeHandCards(
  hand: GameCard[],
  board: (BoardSlot | null)[],
  elementFields: any[],
  currentPlayer: "player1" | "player2",
  gamePhase: string
): GameCard[] {
  const arranger = new DynamicCardArrangement(board, elementFields, currentPlayer, gamePhase);
  return arranger.arrangeCards(hand);
}