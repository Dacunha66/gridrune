// Audio Synthesizer for dynamic battle sound effects
export class AudioSynthesizer {
  private audioContext: AudioContext | null = null;

  constructor() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn("Web Audio API not supported:", error);
    }
  }

  private async ensureAudioContext() {
    if (!this.audioContext) return null;
    
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
    return this.audioContext;
  }

  // Attack Sound: Sharp, aggressive tone
  async createAttackSound(volume: number = 0.3): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.4;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      // Sharp attack with metallic clang
      const frequency = 800 * (1 - t * 0.3); // Falling pitch
      const envelope = Math.exp(-t * 8); // Quick decay
      data[i] = Math.sin(2 * Math.PI * frequency * t) * envelope * volume * 0.5;
      
      // Add harmonics for metallic sound
      data[i] += Math.sin(2 * Math.PI * frequency * 2 * t) * envelope * volume * 0.2;
      data[i] += Math.sin(2 * Math.PI * frequency * 3 * t) * envelope * volume * 0.1;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Defense Sound: Deep, protective resonance
  async createDefenseSound(volume: number = 0.3): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.5;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      const frequency = 200 + 100 * Math.sin(t * 10); // Wobbling low frequency
      const envelope = Math.max(0, 1 - t * 2); // Gradual fade
      data[i] = Math.sin(2 * Math.PI * frequency * t) * envelope * volume;
      
      // Add bass harmonic
      data[i] += Math.sin(2 * Math.PI * frequency * 0.5 * t) * envelope * volume * 0.3;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Capture Sound: Triumphant ascending tone
  async createCaptureSound(volume: number = 0.4): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.8;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      const frequency = 400 + t * 600; // Rising pitch
      const envelope = Math.sin(t * Math.PI); // Bell curve envelope
      data[i] = Math.sin(2 * Math.PI * frequency * t) * envelope * volume * 0.6;
      
      // Add victory harmonics
      data[i] += Math.sin(2 * Math.PI * frequency * 1.5 * t) * envelope * volume * 0.3;
      data[i] += Math.sin(2 * Math.PI * frequency * 2 * t) * envelope * volume * 0.1;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Blitzschlag Sound: Electric crackling
  async createBlitzschlagSound(volume: number = 0.5): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 1.2;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      
      // Electric crackling with random elements
      const noise = (Math.random() - 0.5) * 2;
      const frequency = 1500 + 500 * Math.sin(t * 30);
      const envelope = Math.exp(-t * 2) * (1 + 0.5 * Math.sin(t * 40));
      
      data[i] = (Math.sin(2 * Math.PI * frequency * t) + noise * 0.3) * envelope * volume * 0.4;
      
      // Add high frequency sparkle
      data[i] += Math.sin(2 * Math.PI * frequency * 4 * t) * envelope * volume * 0.2;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Shield Break Sound: Shattering glass effect
  async createShieldBreakSound(volume: number = 0.4): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.6;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      
      // Shattering effect with multiple frequencies
      const freq1 = 2000 * Math.exp(-t * 3);
      const freq2 = 1500 * Math.exp(-t * 4);
      const freq3 = 3000 * Math.exp(-t * 2);
      const noise = (Math.random() - 0.5) * 2;
      const envelope = Math.exp(-t * 6);
      
      data[i] = (
        Math.sin(2 * Math.PI * freq1 * t) +
        Math.sin(2 * Math.PI * freq2 * t) * 0.7 +
        Math.sin(2 * Math.PI * freq3 * t) * 0.5 +
        noise * 0.2
      ) * envelope * volume * 0.3;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Clash Sound: Metallic collision
  async createClashSound(volume: number = 0.3): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.4;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      
      // Metallic collision with quick attack
      const frequency = 1200 * (1 - t * 0.5);
      const envelope = Math.exp(-t * 12);
      const noise = (Math.random() - 0.5) * 2;
      
      data[i] = (
        Math.sin(2 * Math.PI * frequency * t) +
        Math.sin(2 * Math.PI * frequency * 2.1 * t) * 0.5 +
        noise * 0.1
      ) * envelope * volume * 0.6;
    }

    return this.bufferToAudioElement(buffer);
  }

  // Placement Sound: Soft placement thud
  async createPlacementSound(volume: number = 0.2): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 0.3;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      
      // Soft thud with quick attack and decay
      const frequency = 150 + 50 * Math.exp(-t * 10);
      const envelope = Math.exp(-t * 8);
      
      data[i] = Math.sin(2 * Math.PI * frequency * t) * envelope * volume;
      
      // Add subtle click
      if (t < 0.01) {
        data[i] += (Math.random() - 0.5) * envelope * volume * 0.3;
      }
    }

    return this.bufferToAudioElement(buffer);
  }

  // Magical Selection Sound: Mystical chime with sparkle
  async createMagicalSelectionSound(volume: number = 0.4): Promise<HTMLAudioElement | null> {
    const context = await this.ensureAudioContext();
    if (!context) return null;

    const duration = 1.2;
    const buffer = context.createBuffer(1, context.sampleRate * duration, context.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const t = i / context.sampleRate;
      
      // Magical ascending chime
      const baseFreq = 220;
      const chimeFreq = baseFreq * (1 + t * 2); // Rising pitch
      const envelope = Math.exp(-t * 2) * (1 - Math.exp(-t * 10)); // Attack and decay
      
      // Primary magical tone
      let signal = Math.sin(2 * Math.PI * chimeFreq * t) * envelope * volume * 0.6;
      
      // Add sparkle harmonics
      signal += Math.sin(2 * Math.PI * chimeFreq * 2 * t) * envelope * volume * 0.3;
      signal += Math.sin(2 * Math.PI * chimeFreq * 3 * t) * envelope * volume * 0.2;
      
      // Add magical shimmer (high frequency sparkles)
      const shimmerFreq = 1200 + 400 * Math.sin(2 * Math.PI * 5 * t);
      const shimmerEnvelope = Math.exp(-t * 3) * Math.sin(2 * Math.PI * 8 * t) * 0.5;
      signal += Math.sin(2 * Math.PI * shimmerFreq * t) * shimmerEnvelope * volume * 0.2;
      
      data[i] = signal;
    }

    return this.bufferToAudioElement(buffer);
  }

  private bufferToAudioElement(buffer: AudioBuffer): HTMLAudioElement | null {
    try {
      // Convert AudioBuffer to WAV data URL
      const wav = this.audioBufferToWav(buffer);
      const blob = new Blob([wav], { type: 'audio/wav' });
      const url = URL.createObjectURL(blob);
      
      const audio = new Audio(url);
      audio.preload = 'auto';
      
      // Clean up URL when audio is loaded
      audio.addEventListener('loadeddata', () => {
        URL.revokeObjectURL(url);
      });
      
      return audio;
    } catch (error) {
      console.warn("Failed to create audio element:", error);
      return null;
    }
  }

  private audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
    const length = buffer.length;
    const arrayBuffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(arrayBuffer);
    const channels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);

    // Audio data
    const channelData = buffer.getChannelData(0);
    let offset = 44;
    for (let i = 0; i < length; i++) {
      const sample = Math.max(-1, Math.min(1, channelData[i]));
      view.setInt16(offset, sample * 0x7FFF, true);
      offset += 2;
    }

    return arrayBuffer;
  }
}

// Global synthesizer instance
export const audioSynthesizer = new AudioSynthesizer();