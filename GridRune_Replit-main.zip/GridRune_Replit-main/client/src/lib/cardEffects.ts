export type CardEffect =
  | "schild"
  | "staerkung"
  | "stachelruestung"
  | "berserker"
  | "clone"
  | "anker"
  | "infektion"
  | "sniper"
  | "verstaerkung"
  | "stille"
  | "blitzschlag"
  | "tarnung"
  | "schwächung"
  | "licht"
  | "nebel"
  | "list"
  | "runenheilung"
  | "spiegelung"
  | "runenstärke"
  | "runenstille"
  | "runenfeuer"
  | "runeneis"
  | "runenschutz"
  | "leere"
  | "entladung"
  | "kontrolle";

export interface EffectDefinition {
  id: CardEffect;
  name: string;
  description: string;
  symbol: string;
  color: string;
  type?: "debuff" | "buff" | "utility" | "protection" | "manipulation" | "restoration" | "transformation" | "negation" | "field_effect" | "removal" | "disruption";
}

export const CARD_EFFECTS: Record<CardEffect, EffectDefinition> = {
  schild: {
    id: "schild",
    name: "Schild",
    description: "Blockiert den ersten Angriff vollständig",
    symbol: "🛡️",
    color: "text-blue-400"
  },
  staerkung: {
    id: "staerkung",
    name: "Stärkung",
    description: "Erhöht sich pro angrenzender eigener Karte um +1 je Wert",
    symbol: "💪",
    color: "text-green-400"
  },
  stachelruestung: {
    id: "stachelruestung",
    name: "Stachelrüstung",
    description: "Bei Übernahme verliert der Angreifer –1 auf alle Werte",
    symbol: "🌵",
    color: "text-orange-400"
  },
  berserker: {
    id: "berserker",
    name: "Berserker",
    description: "Verdoppelte Werte im ersten Kampf – wird dann eine neutrale Karte",
    symbol: "⚔️",
    color: "text-red-400"
  },
  clone: {
    id: "clone",
    name: "Clone",
    description: "Kopiert die Werte einer benachbarten Karte beim Platzieren",
    symbol: "👥",
    color: "text-purple-400"
  },
  anker: {
    id: "anker",
    name: "Anker",
    description: "Diese Karte kann nicht verschoben oder zerstört werden",
    symbol: "⚓",
    color: "text-gray-400"
  },
  infektion: {
    id: "infektion",
    name: "Infektion",
    description: "Karte kämpft nicht, alle gegnerischen Karten (außer O-Karte) verlieren –1 auf alle Werte",
    symbol: "🦠",
    color: "text-green-600"
  },
  sniper: {
    id: "sniper",
    name: "Sniper",
    description: "Gewinnt auch bei Gleichstand",
    symbol: "🎯",
    color: "text-yellow-400"
  },
  verstaerkung: {
    id: "verstaerkung",
    name: "Verstärkung",
    description: "Gibt benachbarten eigenen Karten +1 auf alle Werte",
    symbol: "⬆️",
    color: "text-cyan-400"
  },

  stille: {
    id: "stille",
    name: "Stille",
    description: "Deaktiviert Fähigkeiten benachbarter Karten",
    symbol: "🤫",
    color: "text-slate-400"
  },
  blitzschlag: {
    id: "blitzschlag",
    name: "Blitzschlag",
    description: "Fügt einer gegnerischen Karten –2 zu (sofort)",
    symbol: "🗲",
    color: "text-yellow-300"
  },
  tarnung: {
    id: "tarnung",
    name: "Tarnung",
    description: "Kann in der nächsten Runde nicht angegriffen werden.",
    symbol: "🫥",
    color: "text-gray-500"
  },
  schwächung: {
    id: "schwächung",
    name: "Schwächung",
    description: "Gegnerische Karten erhalten -1 auf alle Werte für 1 Runde",
    symbol: "📉",
    color: "text-red-500",
    type: "debuff"
  },
  licht: {
    id: "licht",
    name: "Licht",
    description: "Zeigt die nächsten 2 Karten im Deck",
    symbol: "💡",
    color: "text-yellow-300",
    type: "utility"
  },
  nebel: {
    id: "nebel",
    name: "Nebel",
    description: "Karte wird in Nebel verhüllt und kann für 1 Runde nicht angegriffen werden",
    symbol: "🌫️",
    color: "text-gray-400",
    type: "protection"
  },
  list: {
    id: "list",
    name: "List",
    description: "Tauscht zwei beliebige Karten",
    symbol: "🔄",
    color: "text-purple-400",
    type: "manipulation"
  },
  runenheilung: {
    id: "runenheilung",
    name: "Runenheilung",
    description: "Setzt Werte der Karte auf den Ursprung zurück",
    symbol: "✨",
    color: "text-green-400",
    type: "restoration"
  },
  spiegelung: {
    id: "spiegelung",
    name: "Spiegelung",
    description: "Werte werden gespiegelt (links/rechts oben/unten)",
    symbol: "🪞",
    color: "text-blue-400",
    type: "transformation"
  },
  runenstärke: {
    id: "runenstärke",
    name: "Runenstärke",
    description: "Eine eigene Karte erhält +2 auf alle Werte bis zum nächsten Zug",
    symbol: "💪",
    color: "text-red-400",
    type: "buff"
  },
  runenstille: {
    name: "Runenstille",
    description: "Negiert den Effekt einer gegnerischen Karte",
    symbol: "🔇",
    color: "text-gray-500",
    type: "negation"
  },
  runenfeuer: {
    name: "Runenfeuer",
    description: "Wähle ein freies Feld - es brennt - Die Karte, die auf das Feld gelegt wird, verliert jede runde 1 Wert",
    symbol: "🔥",
    color: "text-orange-500",
    type: "field_effect"
  },
  runeneis: {
    name: "Runeneis",
    description: "Wähle ein freies Feld - es gefriert - Die Karte, die auf das Feld gelegt wird, kann nicht angreifen",
    symbol: "🧊",
    color: "text-cyan-400",
    type: "field_effect"
  },
  runenschutz: {
    name: "Runenschutz",
    description: "Wähle eine Karte - Der nächste Angriff wird vollständig blockiert",
    symbol: "🛡️",
    color: "text-blue-500",
    type: "protection"
  },
  leere: {
    name: "Leere",
    description: "Entfernt eine Karte komplett vom Spielfeld",
    symbol: "🕳️",
    color: "text-black",
    type: "removal"
  },
  entladung: {
    name: "Entladung",
    description: "Wähle ein freies Feld - es entlädt sich - Die Karte, die auf das Feld gelegt wird, erleidet -1 Wert",
    symbol: "⚡",
    color: "text-yellow-500",
    type: "field_effect"
  },
  kontrolle: {
    name: "Kontrolle",
    description: "Zerstöre 1 verdeckte Handkarte deines Gegners",
    symbol: "🎯",
    color: "text-red-600",
    type: "disruption"
  },
};

// Card to effect mapping
export const CARD_EFFECT_MAPPING: Record<string, CardEffect> = {
  "Lightning Wolf": "blitzschlag",
  "Storm Hawk": "blitzschlag",

  "Water Spirit": "stille",
  "Earth Golem": "schild",
  "Shadow Cat": "tarnung",
  "Ocean Whale": "verstaerkung",
  "Fire Dragon": "sniper",
  "Flame Tiger": "staerkung",

  "Rune of Light": "licht",
  "Rune of Mist": "nebel",
  "Rune of Cunning": "list",
  "Rune of Healing": "runenheilung",
  "Rune of Mirroring": "spiegelung",
  "Rune of Strength": "runenstärke",
  "Rune of Silence": "runenstille",
  "Rune of Fire": "runenfeuer",
  "Rune of Ice": "runeneis",
  "Rune of Protection": "runenschutz",
  "Rune of Void": "leere",
  "Rune of Discharge": "entladung",
  "Rune of Control": "kontrolle"
};

export function getCardEffect(cardName: string): EffectDefinition | null {
  const effectId = CARD_EFFECT_MAPPING[cardName];
  return effectId ? CARD_EFFECTS[effectId] : null;
}