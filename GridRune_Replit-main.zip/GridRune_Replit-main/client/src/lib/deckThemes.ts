export interface DeckTheme {
  id: string;
  name: string;
  description: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  cardBackPattern: string;
  cardBackColor: string;
  borderStyle: string;
  backgroundGradient: string;
  textColor: string;
  icon: string;
  unlocked: boolean;
  unlockCondition?: string;
  category: 'elemental' | 'mystical' | 'nature' | 'cosmic' | 'premium';
}

export interface DeckCustomization {
  theme: DeckTheme;
  name: string;
  description: string;
  tags: string[];
  color: string;
  createdAt: Date;
  lastModified: Date;
  statistics: {
    gamesPlayed: number;
    winRate: number;
    favoriteCard: string;
  };
}

// Predefined deck themes
export const DECK_THEMES: DeckTheme[] = [
  // Elemental Themes
  {
    id: 'fire-storm',
    name: 'Feuersturm',
    description: 'Brennende Leidenschaft und explosive Kraft',
    primaryColor: '#dc2626', // red-600
    secondaryColor: '#991b1b', // red-800  
    accentColor: '#fbbf24', // amber-400
    cardBackPattern: 'flame',
    cardBackColor: '#7f1d1d', // red-900
    borderStyle: 'fire-glow',
    backgroundGradient: 'from-red-900 via-red-800 to-orange-900',
    textColor: '#fef2f2', // red-50
    icon: '🔥',
    unlocked: true,
    category: 'elemental'
  },
  {
    id: 'ocean-depths',
    name: 'Meerestiefen',
    description: 'Ruhige Tiefen und fließende Stärke',
    primaryColor: '#2563eb', // blue-600
    secondaryColor: '#1e40af', // blue-700
    accentColor: '#06b6d4', // cyan-500
    cardBackPattern: 'wave',
    cardBackColor: '#1e3a8a', // blue-900
    borderStyle: 'water-flow',
    backgroundGradient: 'from-blue-900 via-blue-800 to-cyan-900',
    textColor: '#eff6ff', // blue-50
    icon: '🌊',
    unlocked: true,
    category: 'elemental'
  },
  {
    id: 'earth-guardian',
    name: 'Erdhüter',
    description: 'Unerschütterliche Stärke der Erde',
    primaryColor: '#a3a3a3', // neutral-400
    secondaryColor: '#525252', // neutral-600
    accentColor: '#eab308', // yellow-500
    cardBackPattern: 'stone',
    cardBackColor: '#404040', // neutral-700
    borderStyle: 'stone-edge',
    backgroundGradient: 'from-neutral-800 via-stone-800 to-amber-900',
    textColor: '#fafafa', // neutral-50
    icon: '🪨',
    unlocked: true,
    category: 'elemental'
  },
  {
    id: 'lightning-strike',
    name: 'Blitzschlag',
    description: 'Elektrisierendes Tempo und pure Energie',
    primaryColor: '#eab308', // yellow-500
    secondaryColor: '#ca8a04', // yellow-600
    accentColor: '#a855f7', // purple-500
    cardBackPattern: 'lightning',
    cardBackColor: '#713f12', // yellow-900
    borderStyle: 'electric-glow',
    backgroundGradient: 'from-yellow-900 via-amber-900 to-purple-900',
    textColor: '#fffbeb', // amber-50
    icon: '⚡',
    unlocked: true,
    category: 'elemental'
  },
  
  // Nature Themes
  {
    id: 'forest-whisper',
    name: 'Waldgeflüster',
    description: 'Geheimnisse des alten Waldes',
    primaryColor: '#059669', // emerald-600
    secondaryColor: '#047857', // emerald-700
    accentColor: '#84cc16', // lime-500
    cardBackPattern: 'leaf',
    cardBackColor: '#064e3b', // emerald-900
    borderStyle: 'nature-glow',
    backgroundGradient: 'from-emerald-900 via-green-800 to-lime-900',
    textColor: '#ecfdf5', // emerald-50
    icon: '🌿',
    unlocked: false,
    unlockCondition: 'Gewinne 5 Spiele mit Natur-Karten',
    category: 'nature'
  },
  {
    id: 'winter-frost',
    name: 'Winterfrost',
    description: 'Eisige Kälte und kristalline Schönheit',
    primaryColor: '#0891b2', // cyan-600
    secondaryColor: '#0e7490', // cyan-700
    accentColor: '#f0f9ff', // sky-50
    cardBackPattern: 'snowflake',
    cardBackColor: '#164e63', // cyan-900
    borderStyle: 'ice-crystal',
    backgroundGradient: 'from-cyan-900 via-blue-900 to-slate-900',
    textColor: '#f0f9ff', // sky-50
    icon: '❄️',
    unlocked: false,
    unlockCondition: 'Gewinne 3 Spiele mit Eis-Karten',
    category: 'nature'
  },
  
  // Mystical Themes
  {
    id: 'shadow-realm',
    name: 'Schattenreich',
    description: 'Dunkle Mächte und verborgene Kräfte',
    primaryColor: '#7c3aed', // violet-600
    secondaryColor: '#5b21b6', // violet-800
    accentColor: '#ec4899', // pink-500
    cardBackPattern: 'shadow',
    cardBackColor: '#2e1065', // violet-900
    borderStyle: 'shadow-glow',
    backgroundGradient: 'from-violet-900 via-purple-900 to-pink-900',
    textColor: '#f5f3ff', // violet-50
    icon: '🌙',
    unlocked: false,
    unlockCondition: 'Gewinne 10 Spiele insgesamt',
    category: 'mystical'
  },
  {
    id: 'crystal-power',
    name: 'Kristallkraft',
    description: 'Reine Energie und strahlende Macht',
    primaryColor: '#ec4899', // pink-500
    secondaryColor: '#be185d', // pink-700
    accentColor: '#a855f7', // purple-500
    cardBackPattern: 'crystal',
    cardBackColor: '#831843', // pink-900
    borderStyle: 'crystal-shine',
    backgroundGradient: 'from-pink-900 via-purple-800 to-violet-900',
    textColor: '#fdf2f8', // pink-50
    icon: '💎',
    unlocked: false,
    unlockCondition: 'Sammle 3 legendäre Karten in einem Deck',
    category: 'mystical'
  },
  
  // Cosmic Themes
  {
    id: 'stellar-void',
    name: 'Stellare Leere',
    description: 'Unendliche Weiten des Kosmos',
    primaryColor: '#1e1b4b', // indigo-900
    secondaryColor: '#312e81', // indigo-800
    accentColor: '#fbbf24', // amber-400
    cardBackPattern: 'stars',
    cardBackColor: '#0f0f23', // custom dark
    borderStyle: 'stellar-glow',
    backgroundGradient: 'from-indigo-950 via-purple-950 to-black',
    textColor: '#e0e7ff', // indigo-100
    icon: '⭐',
    unlocked: false,
    unlockCondition: 'Erreiche Spieler-Level 10',
    category: 'cosmic'
  },
  
  // Premium Themes  
  {
    id: 'golden-legend',
    name: 'Goldene Legende',
    description: 'Luxus und zeitlose Eleganz',
    primaryColor: '#d97706', // amber-600
    secondaryColor: '#92400e', // amber-700
    accentColor: '#fbbf24', // amber-400
    cardBackPattern: 'gold-ornament',
    cardBackColor: '#78350f', // amber-900
    borderStyle: 'gold-trim',
    backgroundGradient: 'from-amber-900 via-yellow-800 to-orange-900',
    textColor: '#fffbeb', // amber-50
    icon: '👑',
    unlocked: false,
    unlockCondition: 'Spezial-Belohnung für treue Spieler',
    category: 'premium'
  }
];

// Helper functions
export const getThemeById = (id: string): DeckTheme | undefined => {
  return DECK_THEMES.find(theme => theme.id === id);
};

export const getUnlockedThemes = (): DeckTheme[] => {
  return DECK_THEMES.filter(theme => theme.unlocked);
};

export const getThemesByCategory = (category: DeckTheme['category']): DeckTheme[] => {
  return DECK_THEMES.filter(theme => theme.category === category);
};

export const createDefaultCustomization = (theme: DeckTheme): DeckCustomization => {
  return {
    theme,
    name: 'Neues Deck',
    description: 'Mein benutzerdefiniertes Deck',
    tags: [],
    color: theme.primaryColor,
    createdAt: new Date(),
    lastModified: new Date(),
    statistics: {
      gamesPlayed: 0,
      winRate: 0,
      favoriteCard: ''
    }
  };
};

// CSS generation helpers
export const generateThemeCSS = (theme: DeckTheme) => {
  return {
    '--theme-primary': theme.primaryColor,
    '--theme-secondary': theme.secondaryColor,
    '--theme-accent': theme.accentColor,
    '--theme-card-back': theme.cardBackColor,
    '--theme-text': theme.textColor,
  };
};

export const getThemeGradientClass = (theme: DeckTheme) => {
  return `bg-gradient-to-br ${theme.backgroundGradient}`;
};

export const getThemeBorderClass = (theme: DeckTheme) => {
  const borderStyles: { [key: string]: string } = {
    'fire-glow': 'border-red-500 shadow-lg shadow-red-500/20',
    'water-flow': 'border-blue-500 shadow-lg shadow-blue-500/20', 
    'stone-edge': 'border-neutral-400 shadow-lg shadow-neutral-500/20',
    'electric-glow': 'border-yellow-400 shadow-lg shadow-yellow-400/20',
    'nature-glow': 'border-emerald-500 shadow-lg shadow-emerald-500/20',
    'ice-crystal': 'border-cyan-400 shadow-lg shadow-cyan-400/20',
    'shadow-glow': 'border-violet-500 shadow-lg shadow-violet-500/20',
    'crystal-shine': 'border-pink-400 shadow-lg shadow-pink-400/20',
    'stellar-glow': 'border-indigo-400 shadow-lg shadow-indigo-400/20',
    'gold-trim': 'border-amber-400 shadow-lg shadow-amber-400/20'
  };
  
  return borderStyles[theme.borderStyle] || 'border-slate-400';
};