/**
 * Mobile-First Card Selection Optimization
 * Advanced touch-based card selection system for mobile devices
 */

import { hapticFeedback } from "./hapticFeedback";

export interface SelectionSettings {
  // Visual feedback settings
  highlightDuration: number;
  selectionAnimationDuration: number;
  confirmationDelay: number;
  
  // Touch sensitivity
  tapSensitivity: number;
  longPressDuration: number;
  doubleTapWindow: number;
  
  // Smart selection features
  enableQuickSelect: boolean;
  enablePreview: boolean;
  enableSmartPlacement: boolean;
  enableGestureShortcuts: boolean;
}

export interface CardSelectionEvent {
  cardIndex: number;
  selectionType: 'tap' | 'longPress' | 'doubleTap' | 'swipe';
  timestamp: number;
  confidence: number; // 0-1 how sure we are about the selection
}

export enum SelectionMode {
  BROWSE = 'browse',        // Just browsing cards
  SELECT = 'select',        // Ready to select
  CONFIRM = 'confirm',      // Confirming selection
  PREVIEW = 'preview'       // Previewing card details
}

export enum SelectionFeedback {
  HOVER = 'hover',
  SELECT = 'select', 
  CONFIRM = 'confirm',
  CANCEL = 'cancel',
  ERROR = 'error'
}

export class MobileCardSelector {
  private settings: SelectionSettings;
  private currentMode: SelectionMode = SelectionMode.BROWSE;
  private selectedIndex: number | null = null;
  private lastTapTime: number = 0;
  private tapCount: number = 0;
  private confirmationTimer: NodeJS.Timeout | null = null;

  constructor(settings: Partial<SelectionSettings> = {}) {
    this.settings = {
      highlightDuration: 200,
      selectionAnimationDuration: 300,
      confirmationDelay: 1200,
      tapSensitivity: 15,
      longPressDuration: 400,
      doubleTapWindow: 350,
      enableQuickSelect: true,
      enablePreview: true,
      enableSmartPlacement: true,
      enableGestureShortcuts: true,
      ...settings
    };
  }

  /**
   * Process touch interaction on a card
   */
  processCardInteraction(
    cardIndex: number,
    interactionType: 'tap' | 'longPress' | 'doubleTap',
    timestamp: number = Date.now()
  ): CardSelectionEvent {
    const confidence = this.calculateSelectionConfidence(interactionType, timestamp);
    
    const event: CardSelectionEvent = {
      cardIndex,
      selectionType: interactionType,
      timestamp,
      confidence
    };

    this.handleSelectionEvent(event);
    return event;
  }

  /**
   * Calculate confidence level for selection based on interaction pattern
   */
  private calculateSelectionConfidence(
    interactionType: 'tap' | 'longPress' | 'doubleTap',
    timestamp: number
  ): number {
    let confidence = 0.5; // Base confidence
    
    // Interaction type affects confidence
    switch (interactionType) {
      case 'tap':
        confidence = 0.6;
        break;
      case 'longPress':
        confidence = 0.8;
        break;
      case 'doubleTap':
        confidence = 0.9;
        break;
    }

    // Recent taps increase confidence
    if (timestamp - this.lastTapTime < this.settings.doubleTapWindow) {
      confidence = Math.min(confidence + 0.2, 1.0);
    }

    return confidence;
  }

  /**
   * Handle selection event based on current mode and settings
   */
  private handleSelectionEvent(event: CardSelectionEvent): void {
    const { cardIndex, selectionType, confidence } = event;

    switch (this.currentMode) {
      case SelectionMode.BROWSE:
        this.handleBrowseMode(event);
        break;
      case SelectionMode.SELECT:
        this.handleSelectMode(event);
        break;
      case SelectionMode.CONFIRM:
        this.handleConfirmMode(event);
        break;
      case SelectionMode.PREVIEW:
        this.handlePreviewMode(event);
        break;
    }

    this.lastTapTime = event.timestamp;
  }

  private handleBrowseMode(event: CardSelectionEvent): void {
    const { cardIndex, selectionType, confidence } = event;

    if (selectionType === 'tap') {
      // Single tap in browse mode - highlight and prepare for selection
      this.selectedIndex = cardIndex;
      this.currentMode = SelectionMode.SELECT;
      this.provideFeedback(SelectionFeedback.HOVER);
      
      // Auto-confirm high confidence selections
      if (confidence > 0.8 && this.settings.enableQuickSelect) {
        this.autoConfirmSelection();
      }
    } else if (selectionType === 'longPress') {
      // Long press - immediate preview mode
      this.selectedIndex = cardIndex;
      this.currentMode = SelectionMode.PREVIEW;
      this.provideFeedback(SelectionFeedback.SELECT);
    } else if (selectionType === 'doubleTap') {
      // Double tap - immediate confirm
      this.selectedIndex = cardIndex;
      this.confirmSelection();
    }
  }

  private handleSelectMode(event: CardSelectionEvent): void {
    const { cardIndex, selectionType } = event;

    if (cardIndex === this.selectedIndex) {
      if (selectionType === 'tap') {
        // Tap same card - confirm selection
        this.confirmSelection();
      } else if (selectionType === 'doubleTap') {
        // Double tap - immediate confirm
        this.confirmSelection();
      }
    } else {
      // Different card selected
      this.selectedIndex = cardIndex;
      this.provideFeedback(SelectionFeedback.HOVER);
    }
  }

  private handleConfirmMode(event: CardSelectionEvent): void {
    const { cardIndex, selectionType } = event;

    if (cardIndex === this.selectedIndex && selectionType === 'tap') {
      // Tapping confirmed card again - execute action
      this.executeSelection();
    } else {
      // Different card or different interaction - reset to select mode
      this.selectedIndex = cardIndex;
      this.currentMode = SelectionMode.SELECT;
      this.provideFeedback(SelectionFeedback.HOVER);
    }
  }

  private handlePreviewMode(event: CardSelectionEvent): void {
    const { cardIndex, selectionType } = event;

    if (selectionType === 'tap') {
      if (cardIndex === this.selectedIndex) {
        // Tap previewed card - confirm selection
        this.confirmSelection();
      } else {
        // Different card - change selection
        this.selectedIndex = cardIndex;
        this.currentMode = SelectionMode.SELECT;
        this.provideFeedback(SelectionFeedback.HOVER);
      }
    }
  }

  private autoConfirmSelection(): void {
    if (this.confirmationTimer) {
      clearTimeout(this.confirmationTimer);
    }

    this.confirmationTimer = setTimeout(() => {
      this.confirmSelection();
    }, this.settings.confirmationDelay);
  }

  private confirmSelection(): void {
    if (this.confirmationTimer) {
      clearTimeout(this.confirmationTimer);
      this.confirmationTimer = null;
    }

    this.currentMode = SelectionMode.CONFIRM;
    this.provideFeedback(SelectionFeedback.CONFIRM);
    
    // Auto-execute after brief delay for visual feedback
    setTimeout(() => {
      this.executeSelection();
    }, this.settings.selectionAnimationDuration);
  }

  private executeSelection(): void {
    if (this.selectedIndex !== null) {
      this.provideFeedback(SelectionFeedback.SELECT);
      // Fire custom event for actual card selection
      this.dispatchSelectionEvent();
    }
    this.reset();
  }

  private dispatchSelectionEvent(): void {
    if (this.selectedIndex !== null) {
      const event = new CustomEvent('mobileCardSelected', {
        detail: {
          cardIndex: this.selectedIndex,
          mode: this.currentMode,
          timestamp: Date.now()
        }
      });
      document.dispatchEvent(event);
    }
  }

  private provideFeedback(type: SelectionFeedback): void {
    // Haptic feedback
    switch (type) {
      case SelectionFeedback.HOVER:
        hapticFeedback.light();
        break;
      case SelectionFeedback.SELECT:
        hapticFeedback.selection();
        break;
      case SelectionFeedback.CONFIRM:
        hapticFeedback.heavy();
        break;
      case SelectionFeedback.CANCEL:
        hapticFeedback.error();
        break;
      case SelectionFeedback.ERROR:
        hapticFeedback.error();
        break;
    }

    // Visual feedback event
    const event = new CustomEvent('mobileCardFeedback', {
      detail: {
        type,
        cardIndex: this.selectedIndex,
        mode: this.currentMode
      }
    });
    document.dispatchEvent(event);
  }

  /**
   * Get visual state for a card index
   */
  getCardVisualState(cardIndex: number): {
    isSelected: boolean;
    isConfirmed: boolean;
    isPreviewing: boolean;
    intensity: number;
  } {
    const isSelected = this.selectedIndex === cardIndex;
    
    return {
      isSelected,
      isConfirmed: isSelected && this.currentMode === SelectionMode.CONFIRM,
      isPreviewing: isSelected && this.currentMode === SelectionMode.PREVIEW,
      intensity: this.calculateVisualIntensity(cardIndex)
    };
  }

  private calculateVisualIntensity(cardIndex: number): number {
    if (this.selectedIndex !== cardIndex) return 0;
    
    switch (this.currentMode) {
      case SelectionMode.SELECT: return 0.6;
      case SelectionMode.CONFIRM: return 1.0;
      case SelectionMode.PREVIEW: return 0.8;
      default: return 0.3;
    }
  }

  /**
   * Reset selection state
   */
  reset(): void {
    this.selectedIndex = null;
    this.currentMode = SelectionMode.BROWSE;
    this.tapCount = 0;
    
    if (this.confirmationTimer) {
      clearTimeout(this.confirmationTimer);
      this.confirmationTimer = null;
    }
  }

  /**
   * Cancel current selection
   */
  cancel(): void {
    this.provideFeedback(SelectionFeedback.CANCEL);
    this.reset();
  }

  /**
   * Get current selection state
   */
  getSelectionState(): {
    mode: SelectionMode;
    selectedIndex: number | null;
    isActive: boolean;
  } {
    return {
      mode: this.currentMode,
      selectedIndex: this.selectedIndex,
      isActive: this.currentMode !== SelectionMode.BROWSE
    };
  }

  /**
   * Update settings
   */
  updateSettings(newSettings: Partial<SelectionSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
  }

  /**
   * Cleanup
   */
  destroy(): void {
    if (this.confirmationTimer) {
      clearTimeout(this.confirmationTimer);
    }
  }
}

// Global instance for easy access
export const mobileCardSelector = new MobileCardSelector();