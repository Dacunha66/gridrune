/**
 * Z-Index Management System for GridRune
 * 
 * This file defines all z-index values used throughout the application
 * to ensure proper layering and prevent UI overlap issues.
 */

export const Z_INDEX = {
  // Base layers (0-99)
  BASE: 0,
  BACKGROUND: 1,
  GAME_BOARD: 10,
  CARDS: 20,
  CARD_HOVER: 30,
  CARD_SELECTED: 40,
  
  // UI Elements (100-499)
  HEADER: 100,
  NAVIGATION: 110,
  SIDEBAR: 120,
  BUTTONS: 130,
  TOOLTIPS: 140,
  DROPDOWN: 150,
  
  // Overlays (500-799)
  OVERLAY_LOW: 500,
  OVERLAY_MEDIUM: 600,
  OVERLAY_HIGH: 700,
  
  // Modals (800-999)
  MODAL_BACKDROP: 800,
  MODAL_CONTENT: 850,
  MODAL_NESTED: 900,
  
  // Critical UI (1000-4999)
  NOTIFICATION: 1000,
  TOAST: 1100,
  CONTEXT_MENU: 1200,
  POPOVER: 1300,
  
  // Game-specific overlays (5000-7999)
  GAME_OVERLAY: 5000,
  BATTLE_EFFECTS: 5100,
  CARD_ANIMATIONS: 5200,
  PLACEMENT_GUIDE: 5300,
  TURN_INDICATOR: 5400,
  
  // System-level (8000-9999)
  LOADING_SCREEN: 8000,
  ERROR_OVERLAY: 8500,
  DEBUG_PANEL: 9000,
  CRITICAL_MODAL: 9500,
  EMERGENCY: 9999
} as const;

/**
 * Z-Index Categories for easier management
 */
export const Z_CATEGORIES = {
  GAME: {
    BACKGROUND: Z_INDEX.BACKGROUND,
    BOARD: Z_INDEX.GAME_BOARD,
    CARDS: Z_INDEX.CARDS,
    CARD_HOVER: Z_INDEX.CARD_HOVER,
    CARD_SELECTED: Z_INDEX.CARD_SELECTED,
    EFFECTS: Z_INDEX.BATTLE_EFFECTS,
    ANIMATIONS: Z_INDEX.CARD_ANIMATIONS,
    PLACEMENT_GUIDE: Z_INDEX.PLACEMENT_GUIDE,
    TURN_INDICATOR: Z_INDEX.TURN_INDICATOR,
    OVERLAY: Z_INDEX.GAME_OVERLAY
  },
  UI: {
    HEADER: Z_INDEX.HEADER,
    NAVIGATION: Z_INDEX.NAVIGATION,
    BUTTONS: Z_INDEX.BUTTONS,
    TOOLTIPS: Z_INDEX.TOOLTIPS,
    DROPDOWN: Z_INDEX.DROPDOWN,
    POPOVER: Z_INDEX.POPOVER
  },
  MODAL: {
    BACKDROP: Z_INDEX.MODAL_BACKDROP,
    CONTENT: Z_INDEX.MODAL_CONTENT,
    NESTED: Z_INDEX.MODAL_NESTED,
    CRITICAL: Z_INDEX.CRITICAL_MODAL
  },
  SYSTEM: {
    LOADING: Z_INDEX.LOADING_SCREEN,
    ERROR: Z_INDEX.ERROR_OVERLAY,
    NOTIFICATION: Z_INDEX.NOTIFICATION,
    TOAST: Z_INDEX.TOAST,
    EMERGENCY: Z_INDEX.EMERGENCY
  }
} as const;

/**
 * Helper function to get z-index values with optional offset
 */
export function getZIndex(category: keyof typeof Z_INDEX, offset: number = 0): number {
  return Z_INDEX[category] + offset;
}

/**
 * Helper function to create z-index styles
 */
export function zIndexStyle(value: number): { zIndex: number } {
  return { zIndex: value };
}

/**
 * Helper function to create z-index CSS classes
 */
export function zIndexClass(value: number): string {
  return `z-[${value}]`;
}