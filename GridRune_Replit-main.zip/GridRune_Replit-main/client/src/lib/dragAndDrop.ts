import { GameCard } from "./cardData";

export interface DragState {
  isDragging: boolean;
  draggedCard: GameCard | null;
  draggedCardIndex: number | null;
  draggedFromPlayer: 1 | 2 | null;
  dragOrigin: { x: number; y: number } | null;
  currentPosition: { x: number; y: number } | null;
  hoveredSlot: number | null;
}

export interface GridPosition {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface SnapTarget {
  slotIndex: number;
  position: GridPosition;
  isValid: boolean;
  distance: number;
}

export class DragDropManager {
  private boardElement: HTMLElement | null = null;
  private gridPositions: GridPosition[] = [];
  private snapThreshold: number = 50; // pixels
  
  constructor(boardElement?: HTMLElement) {
    if (boardElement) {
      this.setBoardElement(boardElement);
    }
  }
  
  setBoardElement(element: HTMLElement) {
    this.boardElement = element;
    this.updateGridPositions();
  }
  
  updateGridPositions() {
    if (!this.boardElement) return;
    
    const slots = this.boardElement.querySelectorAll('[data-slot-index]');
    this.gridPositions = Array.from(slots).map((slot, index) => {
      const rect = slot.getBoundingClientRect();
      const boardRect = this.boardElement!.getBoundingClientRect();
      
      return {
        x: rect.left - boardRect.left,
        y: rect.top - boardRect.top,
        width: rect.width,
        height: rect.height
      };
    });
  }
  
  getSnapTarget(currentPosition: { x: number; y: number }, validSlots: number[]): SnapTarget | null {
    if (!this.boardElement || this.gridPositions.length === 0) return null;
    
    const boardRect = this.boardElement.getBoundingClientRect();
    const relativePosition = {
      x: currentPosition.x - boardRect.left,
      y: currentPosition.y - boardRect.top
    };
    
    let closestTarget: SnapTarget | null = null;
    let minDistance = Infinity;
    
    this.gridPositions.forEach((gridPos, slotIndex) => {
      if (!validSlots.includes(slotIndex)) return;
      
      const centerX = gridPos.x + gridPos.width / 2;
      const centerY = gridPos.y + gridPos.height / 2;
      
      const distance = Math.sqrt(
        Math.pow(relativePosition.x - centerX, 2) + 
        Math.pow(relativePosition.y - centerY, 2)
      );
      
      if (distance < this.snapThreshold && distance < minDistance) {
        minDistance = distance;
        closestTarget = {
          slotIndex,
          position: gridPos,
          isValid: true,
          distance
        };
      }
    });
    
    return closestTarget;
  }
  
  getSnapPosition(target: SnapTarget): { x: number; y: number } {
    const centerX = target.position.x + target.position.width / 2;
    const centerY = target.position.y + target.position.height / 2;
    
    return { x: centerX, y: centerY };
  }
  
  isWithinDropZone(position: { x: number; y: number }): boolean {
    if (!this.boardElement) return false;
    
    const rect = this.boardElement.getBoundingClientRect();
    return (
      position.x >= rect.left &&
      position.x <= rect.right &&
      position.y >= rect.top &&
      position.y <= rect.bottom
    );
  }
}

// Utility functions for drag calculations
export const calculateDragDistance = (
  start: { x: number; y: number },
  current: { x: number; y: number }
): number => {
  return Math.sqrt(
    Math.pow(current.x - start.x, 2) + 
    Math.pow(current.y - start.y, 2)
  );
};

export const getDragDirection = (
  start: { x: number; y: number },
  current: { x: number; y: number }
): 'up' | 'down' | 'left' | 'right' | 'none' => {
  const deltaX = current.x - start.x;
  const deltaY = current.y - start.y;
  
  if (Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10) return 'none';
  
  if (Math.abs(deltaX) > Math.abs(deltaY)) {
    return deltaX > 0 ? 'right' : 'left';
  } else {
    return deltaY > 0 ? 'down' : 'up';
  }
};