import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Badge } from '../../components/AchievementBadge';

export interface PlayerMilestone {
  id: string;
  name: string;
  description: string;
  category: 'games' | 'wins' | 'collection' | 'streak' | 'time' | 'social';
  type: 'counter' | 'milestone' | 'streak' | 'cumulative';
  target: number;
  current: number;
  badgeId: string;
  isCompleted: boolean;
  completedAt?: Date;
}

interface BadgeState {
  badges: Badge[];
  milestones: PlayerMilestone[];
  playerStats: {
    totalGames: number;
    totalWins: number;
    totalCards: number;
    longestWinStreak: number;
    currentWinStreak: number;
    hoursPlayed: number;
    friendsAdded: number;
    cardsTraded: number;
    perfectGames: number;
    multiplayerGames: number;
    legendaryCards: number;
    ultimateCards: number;
    decksCreated: number;
  };
  
  // Actions
  unlockBadge: (badgeId: string) => void;
  updateMilestoneProgress: (milestoneId: string, newValue: number) => void;
  updatePlayerStats: (stats: Partial<BadgeState['playerStats']>) => void;
  checkMilestones: () => void;
  getBadgesByCategory: (category: Badge['category']) => Badge[];
  getUnlockedBadges: () => Badge[];
  getLockedBadges: () => Badge[];
  initializeBadges: () => void;
}

const defaultBadges: Badge[] = [
  // Gameplay Badges
  {
    id: 'first-victory',
    title: 'Erster Sieg',
    description: 'Gewinne dein erstes GridRune Spiel',
    icon: '🏆',
    rarity: 'bronze',
    category: 'gameplay'
  },
  {
    id: 'veteran-player',
    title: 'Veteran',
    description: 'Spiele 100 GridRune Spiele',
    icon: '🎖️',
    rarity: 'silver',
    category: 'gameplay'
  },
  {
    id: 'master-player',
    title: 'Meister',
    description: 'Gewinne 250 GridRune Spiele',
    icon: '👑',
    rarity: 'gold',
    category: 'gameplay'
  },
  
  // Collection Badges
  {
    id: 'first-legendary',
    title: 'Legendenjäger',
    description: 'Erhalte deine erste legendäre Karte',
    icon: '⭐',
    rarity: 'bronze',
    category: 'collection'
  },
  {
    id: 'master-collector',
    title: 'Meistersammler',
    description: 'Sammle alle 25 verfügbaren Karten',
    icon: '📚',
    rarity: 'platinum',
    category: 'collection'
  },
  {
    id: 'ultimate-collector',
    title: 'Ultimativer Sammler',
    description: 'Erhalte 5 ultimative Karten',
    icon: '💎',
    rarity: 'diamond',
    category: 'collection'
  },
  
  // Streak Badges
  {
    id: 'win-streak-5',
    title: 'Siegesserie',
    description: 'Gewinne 5 Spiele in Folge',
    icon: '🔥',
    rarity: 'bronze',
    category: 'streak'
  },
  {
    id: 'win-streak-10',
    title: 'Unaufhaltbar',
    description: 'Gewinne 10 Spiele in Folge',
    icon: '💥',
    rarity: 'silver',
    category: 'streak'
  },
  {
    id: 'win-streak-25',
    title: 'Legendäre Serie',
    description: 'Gewinne 25 Spiele in Folge',
    icon: '⚡',
    rarity: 'gold',
    category: 'streak'
  },
  
  // Milestone Badges
  {
    id: 'dedicated-player',
    title: 'Hingebungsvoller Spieler',
    description: 'Spiele 50 Stunden GridRune',
    icon: '⏰',
    rarity: 'silver',
    category: 'milestone'
  },
  {
    id: 'social-butterfly',
    title: 'Sozialer Schmetterling',
    description: 'Füge 20 Freunde hinzu',
    icon: '🤝',
    rarity: 'gold',
    category: 'social'
  },
  {
    id: 'perfect-strategist',
    title: 'Perfekter Stratege',
    description: 'Gewinne 10 perfekte Spiele',
    icon: '🧠',
    rarity: 'platinum',
    category: 'special'
  },
  
  // Special Badges
  {
    id: 'early-adopter',
    title: 'Early Adopter',
    description: 'Spiele GridRune in der Beta-Phase',
    icon: '🚀',
    rarity: 'diamond',
    category: 'special'
  },
  {
    id: 'community-champion',
    title: 'Community Champion',
    description: 'Erreiche Top 100 im Ranglisten-System',
    icon: '🏅',
    rarity: 'platinum',
    category: 'special'
  }
];

const defaultMilestones: PlayerMilestone[] = [
  {
    id: 'games-played-milestone',
    name: 'Spiele gespielt',
    description: 'Spiele insgesamt gespielte GridRune Spiele',
    category: 'games',
    type: 'cumulative',
    target: 100,
    current: 0,
    badgeId: 'veteran-player',
    isCompleted: false
  },
  {
    id: 'wins-milestone', 
    name: 'Gewonnene Spiele',
    description: 'Anzahl gewonnener Spiele',
    category: 'wins',
    type: 'cumulative',
    target: 250,
    current: 0,
    badgeId: 'master-player',
    isCompleted: false
  },
  {
    id: 'collection-milestone',
    name: 'Karten gesammelt',
    description: 'Sammle alle verfügbaren Karten',
    category: 'collection',
    type: 'counter',
    target: 25,
    current: 0,
    badgeId: 'master-collector',
    isCompleted: false
  },
  {
    id: 'win-streak-milestone',
    name: 'Siegesserie',
    description: 'Längste Siegesserie',
    category: 'streak',
    type: 'streak',
    target: 25,
    current: 0,
    badgeId: 'win-streak-25',
    isCompleted: false
  },
  {
    id: 'time-played-milestone',
    name: 'Spielzeit',
    description: 'Gespielte Stunden',
    category: 'time',
    type: 'cumulative',
    target: 50,
    current: 0,
    badgeId: 'dedicated-player',
    isCompleted: false
  },
  {
    id: 'social-milestone',
    name: 'Freunde hinzugefügt',
    description: 'Anzahl hinzugefügter Freunde',
    category: 'social',
    type: 'counter',
    target: 20,
    current: 0,
    badgeId: 'social-butterfly',
    isCompleted: false
  }
];

export const useBadges = create<BadgeState>()(
  persist(
    (set, get) => ({
      badges: defaultBadges,
      milestones: defaultMilestones,
      playerStats: {
        totalGames: 0,
        totalWins: 0,
        totalCards: 0,
        longestWinStreak: 0,
        currentWinStreak: 0,
        hoursPlayed: 0,
        friendsAdded: 0,
        cardsTraded: 0,
        perfectGames: 0,
        multiplayerGames: 0,
        legendaryCards: 0,
        ultimateCards: 0,
        decksCreated: 0
      },

      unlockBadge: (badgeId: string) => {
        const { badges } = get();
        const updatedBadges = badges.map(badge => 
          badge.id === badgeId && !badge.unlockedAt
            ? { ...badge, unlockedAt: new Date() }
            : badge
        );
        
        set({ badges: updatedBadges });
        console.log(`🏆 Badge unlocked: ${badgeId}`);
      },

      updateMilestoneProgress: (milestoneId: string, newValue: number) => {
        const { milestones } = get();
        const updatedMilestones = milestones.map(milestone => {
          if (milestone.id === milestoneId && !milestone.isCompleted) {
            const updatedMilestone = { ...milestone, current: newValue };
            
            // Check if milestone is completed
            if (newValue >= milestone.target) {
              updatedMilestone.isCompleted = true;
              updatedMilestone.completedAt = new Date();
              
              // Unlock associated badge
              get().unlockBadge(milestone.badgeId);
            }
            
            return updatedMilestone;
          }
          return milestone;
        });
        
        set({ milestones: updatedMilestones });
      },

      updatePlayerStats: (newStats: Partial<BadgeState['playerStats']>) => {
        const { playerStats } = get();
        const updatedStats = { ...playerStats, ...newStats };
        
        set({ playerStats: updatedStats });
        
        // Check milestones after updating stats
        get().checkMilestones();
      },

      checkMilestones: () => {
        const { playerStats, updateMilestoneProgress } = get();
        
        // Update milestone progress based on player stats
        updateMilestoneProgress('games-played-milestone', playerStats.totalGames);
        updateMilestoneProgress('wins-milestone', playerStats.totalWins);
        updateMilestoneProgress('collection-milestone', playerStats.totalCards);
        updateMilestoneProgress('win-streak-milestone', playerStats.longestWinStreak);
        updateMilestoneProgress('time-played-milestone', Math.floor(playerStats.hoursPlayed));
        updateMilestoneProgress('social-milestone', playerStats.friendsAdded);
        
        // Check for special achievements
        if (playerStats.totalWins >= 1) {
          get().unlockBadge('first-victory');
        }
        
        if (playerStats.legendaryCards >= 1) {
          get().unlockBadge('first-legendary');
        }
        
        if (playerStats.ultimateCards >= 5) {
          get().unlockBadge('ultimate-collector');
        }
        
        if (playerStats.perfectGames >= 10) {
          get().unlockBadge('perfect-strategist');
        }
        
        // Check streak badges
        if (playerStats.longestWinStreak >= 5) {
          get().unlockBadge('win-streak-5');
        }
        if (playerStats.longestWinStreak >= 10) {
          get().unlockBadge('win-streak-10');
        }
        if (playerStats.longestWinStreak >= 25) {
          get().unlockBadge('win-streak-25');
        }
      },

      getBadgesByCategory: (category: Badge['category']) => {
        return get().badges.filter(badge => badge.category === category);
      },

      getUnlockedBadges: () => {
        return get().badges.filter(badge => badge.unlockedAt);
      },

      getLockedBadges: () => {
        return get().badges.filter(badge => !badge.unlockedAt);
      },

      initializeBadges: () => {
        // Set up initial badges and check for any that should be unlocked
        get().checkMilestones();
      }
    }),
    {
      name: 'gridrune-badges',
      version: 1
    }
  )
);