import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SeasonalCard {
  id: string;
  name: string;
  nameGerman: string;
  rarity: 'Legendär' | 'Episch' | 'Selten';
  season: string;
  seasonNumber: number;
  description: string;
  descriptionGerman: string;
  artwork: string;
  values: [number, number, number, number];
  effect?: string;
  effectGerman?: string;
  isExclusive: boolean;
  unlockTier: number;
  collectedAt?: Date;
  isLimited: boolean; // Time-limited availability
}

export interface Season {
  id: string;
  name: string;
  nameGerman: string;
  number: number;
  theme: string;
  themeGerman: string;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  backgroundGradient: string;
  accentColor: string;
  description: string;
  descriptionGerman: string;
}

export interface SeasonalTier {
  tier: number;
  xpRequired: number;
  rewards: {
    diamonds?: number;
    cards?: string[];
    packs?: number;
    title?: string;
    titleGerman?: string;
    avatar?: string;
  };
  unlocked: boolean;
  claimed: boolean;
}

interface SeasonalRewardsState {
  currentSeason: Season | null;
  allSeasons: Season[];
  seasonalCards: SeasonalCard[];
  collectedSeasonalCards: string[];
  currentSeasonXP: number;
  seasonalTiers: SeasonalTier[];
  unclaimedRewards: number;
  seasonalAchievements: string[];
  
  // Actions
  initializeSeasons: () => void;
  addSeasonXP: (amount: number) => void;
  claimTierReward: (tier: number) => boolean;
  collectSeasonalCard: (cardId: string) => void;
  getAvailableSeasonalCards: () => SeasonalCard[];
  getCurrentTier: () => number;
  getNextTierProgress: () => { current: number; required: number; percentage: number };
  hasSeasonalCard: (cardId: string) => boolean;
  getSeasonProgress: () => { tier: number; totalTiers: number; percentage: number };
  unlockSeasonalAchievement: (achievementId: string) => void;
}

const seasonalCardsData: SeasonalCard[] = [
  // Season 1: Winterstürme
  {
    id: 'winter_drake',
    name: 'Frost Drake',
    nameGerman: 'Frostdrache',
    rarity: 'Legendär',
    season: 'Winter Storms',
    seasonNumber: 1,
    description: 'A legendary dragon of the frozen north',
    descriptionGerman: 'Ein legendärer Drache des gefrorenen Nordens',
    artwork: '🐲',
    values: [9, 8, 7, 9],
    effect: 'Freezes adjacent enemy cards for 1 turn',
    effectGerman: 'Friert benachbarte Gegnerkarten für 1 Runde ein',
    isExclusive: true,
    unlockTier: 10,
    isLimited: true
  },
  {
    id: 'ice_guardian',
    name: 'Ice Guardian',
    nameGerman: 'Eiswächter',
    rarity: 'Episch',
    season: 'Winter Storms',
    seasonNumber: 1,
    description: 'Guardian of the frozen realm',
    descriptionGerman: 'Wächter des gefrorenen Reiches',
    artwork: '🛡️',
    values: [7, 6, 8, 6],
    effect: 'Gains +1 defense in winter battles',
    effectGerman: 'Erhält +1 Verteidigung in Winterkämpfen',
    isExclusive: true,
    unlockTier: 5,
    isLimited: true
  },
  {
    id: 'snowstorm_mage',
    name: 'Snowstorm Mage',
    nameGerman: 'Schneesturm-Magier',
    rarity: 'Selten',
    season: 'Winter Storms',
    seasonNumber: 1,
    description: 'Master of winter magic',
    descriptionGerman: 'Meister der Wintermagie',
    artwork: '❄️',
    values: [5, 7, 6, 5],
    effect: 'Reduces enemy attack by 1',
    effectGerman: 'Reduziert Gegnerangriff um 1',
    isExclusive: true,
    unlockTier: 3,
    isLimited: true
  },
  
  // Season 2: Sakura Blüte
  {
    id: 'cherry_spirit',
    name: 'Cherry Blossom Spirit',
    nameGerman: 'Kirschblüten-Geist',
    rarity: 'Legendär',
    season: 'Sakura Bloom',
    seasonNumber: 2,
    description: 'Ethereal guardian of spring',
    descriptionGerman: 'Ätherischer Wächter des Frühlings',
    artwork: '🌸',
    values: [8, 9, 8, 7],
    effect: 'Heals adjacent friendly cards',
    effectGerman: 'Heilt benachbarte Verbündete',
    isExclusive: true,
    unlockTier: 10,
    isLimited: true
  },
  {
    id: 'samurai_honor',
    name: 'Honorable Samurai',
    nameGerman: 'Ehrenwerter Samurai',
    rarity: 'Episch',
    season: 'Sakura Bloom',
    seasonNumber: 2,
    description: 'Warrior of ancient code',
    descriptionGerman: 'Krieger des alten Kodex',
    artwork: '⚔️',
    values: [8, 6, 7, 8],
    effect: 'Cannot be captured by cards with lower honor',
    effectGerman: 'Kann nicht von Karten mit niedrigerer Ehre erobert werden',
    isExclusive: true,
    unlockTier: 7,
    isLimited: true
  }
];

const seasonsData: Season[] = [
  {
    id: 'winter_1',
    name: 'Winter Storms',
    nameGerman: 'Winterstürme',
    number: 1,
    theme: 'Ice and Snow',
    themeGerman: 'Eis und Schnee',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-03-31'),
    isActive: true,
    backgroundGradient: 'from-blue-900 via-cyan-800 to-slate-800',
    accentColor: 'cyan',
    description: 'A season of frozen battles and icy magic',
    descriptionGerman: 'Eine Saison aus gefrorenen Kämpfen und eisiger Magie'
  },
  {
    id: 'sakura_2',
    name: 'Sakura Bloom',
    nameGerman: 'Sakura Blüte',
    number: 2,
    theme: 'Cherry Blossoms',
    themeGerman: 'Kirschblüten',
    startDate: new Date('2025-04-01'),
    endDate: new Date('2025-06-30'),
    isActive: false,
    backgroundGradient: 'from-pink-900 via-rose-800 to-purple-800',
    accentColor: 'pink',
    description: 'Honor and beauty in the season of blooming',
    descriptionGerman: 'Ehre und Schönheit in der Saison der Blüte'
  }
];

export const useSeasonalRewards = create<SeasonalRewardsState>()(
  persist(
    (set, get) => ({
      currentSeason: null,
      allSeasons: [],
      seasonalCards: [],
      collectedSeasonalCards: [],
      currentSeasonXP: 0,
      seasonalTiers: [],
      unclaimedRewards: 0,
      seasonalAchievements: [],

      initializeSeasons: () => {
        const tiers: SeasonalTier[] = [];
        for (let i = 1; i <= 10; i++) {
          tiers.push({
            tier: i,
            xpRequired: i * 1000,
            rewards: {
              diamonds: i * 50,
              cards: seasonalCardsData.filter(card => card.unlockTier === i).map(c => c.id),
              packs: i <= 5 ? 1 : 2,
              ...(i === 5 && { title: 'Winter Warrior', titleGerman: 'Winter-Krieger' }),
              ...(i === 10 && { title: 'Frost Master', titleGerman: 'Frost-Meister', avatar: '❄️' })
            },
            unlocked: false,
            claimed: false
          });
        }

        set({
          allSeasons: seasonsData,
          currentSeason: seasonsData.find(s => s.isActive) || seasonsData[0],
          seasonalCards: seasonalCardsData,
          seasonalTiers: tiers
        });
      },

      addSeasonXP: (amount) => {
        const state = get();
        const newXP = state.currentSeasonXP + amount;
        const newlyUnlocked = state.seasonalTiers.filter(tier => 
          !tier.unlocked && newXP >= tier.xpRequired
        );

        set({
          currentSeasonXP: newXP,
          seasonalTiers: state.seasonalTiers.map(tier => ({
            ...tier,
            unlocked: newXP >= tier.xpRequired
          })),
          unclaimedRewards: state.unclaimedRewards + newlyUnlocked.length
        });
      },

      claimTierReward: (tier) => {
        const state = get();
        const tierData = state.seasonalTiers.find(t => t.tier === tier);
        
        if (!tierData?.unlocked || tierData.claimed) {
          return false;
        }

        const newCollectedCards = [...state.collectedSeasonalCards];
        if (tierData.rewards.cards) {
          newCollectedCards.push(...tierData.rewards.cards);
        }

        set({
          seasonalTiers: state.seasonalTiers.map(t =>
            t.tier === tier ? { ...t, claimed: true } : t
          ),
          collectedSeasonalCards: newCollectedCards,
          unclaimedRewards: Math.max(0, state.unclaimedRewards - 1)
        });

        return true;
      },

      collectSeasonalCard: (cardId) => {
        const state = get();
        const card = state.seasonalCards.find(c => c.id === cardId);
        
        if (card && !state.collectedSeasonalCards.includes(cardId)) {
          set({
            collectedSeasonalCards: [...state.collectedSeasonalCards, cardId],
            seasonalCards: state.seasonalCards.map(c =>
              c.id === cardId ? { ...c, collectedAt: new Date() } : c
            )
          });
        }
      },

      getAvailableSeasonalCards: () => {
        const state = get();
        return state.seasonalCards.filter(card => 
          state.currentSeason?.number === card.seasonNumber
        );
      },

      getCurrentTier: () => {
        const state = get();
        const unlockedTiers = state.seasonalTiers.filter(t => t.unlocked);
        return unlockedTiers.length > 0 ? Math.max(...unlockedTiers.map(t => t.tier)) : 0;
      },

      getNextTierProgress: () => {
        const state = get();
        const currentTier = get().getCurrentTier();
        const nextTier = state.seasonalTiers.find(t => t.tier === currentTier + 1);
        
        if (!nextTier) {
          return { current: state.currentSeasonXP, required: state.currentSeasonXP, percentage: 100 };
        }

        const previousTierXP = currentTier > 0 ? (currentTier * 1000) : 0;
        const current = state.currentSeasonXP - previousTierXP;
        const required = nextTier.xpRequired - previousTierXP;
        const percentage = Math.min(100, (current / required) * 100);

        return { current, required, percentage };
      },

      hasSeasonalCard: (cardId) => {
        return get().collectedSeasonalCards.includes(cardId);
      },

      getSeasonProgress: () => {
        const state = get();
        const currentTier = get().getCurrentTier();
        const totalTiers = state.seasonalTiers.length;
        const percentage = (currentTier / totalTiers) * 100;
        
        return { tier: currentTier, totalTiers, percentage };
      },

      unlockSeasonalAchievement: (achievementId) => {
        const state = get();
        if (!state.seasonalAchievements.includes(achievementId)) {
          set({
            seasonalAchievements: [...state.seasonalAchievements, achievementId]
          });
        }
      }
    }),
    {
      name: 'gridrune-seasonal-rewards',
      version: 1
    }
  )
);