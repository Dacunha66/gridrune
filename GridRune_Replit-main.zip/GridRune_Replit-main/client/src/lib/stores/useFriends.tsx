import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Friend {
  id: string;
  username: string;
  avatar: string;
  level: number;
  isOnline: boolean;
  lastSeen: Date;
  friendsSince: Date;
  gamesPlayed: number;
  mutualFriends: number;
}

interface FriendRequest {
  id: string;
  from: string;
  to: string;
  fromUsername: string;
  fromAvatar: string;
  sentAt: Date;
  status: 'pending' | 'accepted' | 'declined';
}

interface FriendsState {
  friends: Friend[];
  friendRequests: FriendRequest[];
  sentRequests: string[]; // IDs of players we sent requests to
  blockedUsers: string[];
  
  // Actions
  addFriend: (friend: Friend) => void;
  removeFriend: (friendId: string) => void;
  sendFriendRequest: (playerId: string, playerUsername: string, playerAvatar: string) => void;
  cancelFriendRequest: (playerId: string) => void;
  acceptFriendRequest: (requestId: string) => void;
  declineFriendRequest: (requestId: string) => void;
  blockUser: (userId: string) => void;
  unblockUser: (userId: string) => void;
  updateFriendStatus: (friendId: string, isOnline: boolean, lastSeen?: Date) => void;
  
  // Getters
  getFriend: (friendId: string) => Friend | undefined;
  isFriend: (playerId: string) => boolean;
  hasSentRequest: (playerId: string) => boolean;
  isBlocked: (userId: string) => boolean;
  getOnlineFriends: () => Friend[];
  getFriendRequests: () => FriendRequest[];
}

export const useFriends = create<FriendsState>()(
  persist(
    (set, get) => ({
      friends: [],
      friendRequests: [],
      sentRequests: [],
      blockedUsers: [],

      addFriend: (friend) => {
        set((state) => ({
          friends: [...state.friends, friend],
          // Remove any pending friend requests
          friendRequests: state.friendRequests.filter(req => 
            req.from !== friend.id && req.to !== friend.id
          ),
          sentRequests: state.sentRequests.filter(id => id !== friend.id)
        }));
      },

      removeFriend: (friendId) => {
        set((state) => ({
          friends: state.friends.filter(f => f.id !== friendId)
        }));
      },

      sendFriendRequest: (playerId, playerUsername, playerAvatar) => {
        if (get().hasSentRequest(playerId) || get().isFriend(playerId)) {
          return;
        }

        const newRequest: FriendRequest = {
          id: `req_${Date.now()}_${playerId}`,
          from: 'current_user', // In a real app, this would be the current user's ID
          to: playerId,
          fromUsername: 'Du', // Current user's username
          fromAvatar: '⚔️', // Current user's avatar
          sentAt: new Date(),
          status: 'pending'
        };

        set((state) => ({
          sentRequests: [...state.sentRequests, playerId]
        }));

        // Simulate friend request being processed
        setTimeout(() => {
          // Simulate 70% acceptance rate
          if (Math.random() > 0.3) {
            get().acceptFriendRequest(newRequest.id);
          } else {
            get().declineFriendRequest(newRequest.id);
          }
        }, 2000 + Math.random() * 3000); // Random delay 2-5 seconds
      },

      cancelFriendRequest: (playerId) => {
        set((state) => ({
          sentRequests: state.sentRequests.filter(id => id !== playerId)
        }));
      },

      acceptFriendRequest: (requestId) => {
        const state = get();
        const request = state.friendRequests.find(req => req.id === requestId);
        
        if (request) {
          const newFriend: Friend = {
            id: request.from,
            username: request.fromUsername,
            avatar: request.fromAvatar,
            level: Math.floor(Math.random() * 50) + 1,
            isOnline: Math.random() > 0.5,
            lastSeen: new Date(),
            friendsSince: new Date(),
            gamesPlayed: Math.floor(Math.random() * 20),
            mutualFriends: Math.floor(Math.random() * 10)
          };

          state.addFriend(newFriend);
        }

        // For demo purposes - simulate accepting sent requests
        const playerId = state.sentRequests.find(id => 
          state.friendRequests.some(req => req.to === id)
        );

        if (playerId) {
          // Create mock friend data
          const mockFriend: Friend = {
            id: playerId,
            username: `Player${Math.floor(Math.random() * 1000)}`,
            avatar: ['🦅', '⚔️', '🧙', '🎯', '🌊', '🔥', '🛡️'][Math.floor(Math.random() * 7)],
            level: Math.floor(Math.random() * 50) + 1,
            isOnline: Math.random() > 0.4,
            lastSeen: new Date(Date.now() - Math.random() * 86400000), // Random time in last 24h
            friendsSince: new Date(),
            gamesPlayed: Math.floor(Math.random() * 50),
            mutualFriends: Math.floor(Math.random() * 15)
          };

          state.addFriend(mockFriend);
        }

        set((state) => ({
          friendRequests: state.friendRequests.filter(req => req.id !== requestId)
        }));
      },

      declineFriendRequest: (requestId) => {
        set((state) => ({
          friendRequests: state.friendRequests.filter(req => req.id !== requestId),
          sentRequests: state.sentRequests.filter(id => {
            const request = state.friendRequests.find(req => req.id === requestId);
            return request ? id !== request.to : true;
          })
        }));
      },

      blockUser: (userId) => {
        set((state) => ({
          blockedUsers: [...state.blockedUsers, userId],
          friends: state.friends.filter(f => f.id !== userId)
        }));
      },

      unblockUser: (userId) => {
        set((state) => ({
          blockedUsers: state.blockedUsers.filter(id => id !== userId)
        }));
      },

      updateFriendStatus: (friendId, isOnline, lastSeen = new Date()) => {
        set((state) => ({
          friends: state.friends.map(friend =>
            friend.id === friendId
              ? { ...friend, isOnline, lastSeen }
              : friend
          )
        }));
      },

      // Getters
      getFriend: (friendId) => {
        return get().friends.find(f => f.id === friendId);
      },

      isFriend: (playerId) => {
        return get().friends.some(f => f.id === playerId);
      },

      hasSentRequest: (playerId) => {
        return get().sentRequests.includes(playerId);
      },

      isBlocked: (userId) => {
        return get().blockedUsers.includes(userId);
      },

      getOnlineFriends: () => {
        return get().friends.filter(f => f.isOnline);
      },

      getFriendRequests: () => {
        return get().friendRequests.filter(req => req.status === 'pending');
      }
    }),
    {
      name: 'gridrune-friends',
      version: 1
    }
  )
);