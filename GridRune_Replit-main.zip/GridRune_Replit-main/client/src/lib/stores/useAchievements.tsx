import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rarity: "common" | "rare" | "epic" | "legendary";
  category: "gameplay" | "collection" | "deck-building" | "social" | "progression";
  requirements: {
    type: "counter" | "milestone" | "condition";
    target?: number;
    current?: number;
  };
  reward?: {
    type: "diamonds" | "cards" | "title" | "cosmetic";
    amount?: number;
    items?: string[];
  };
  unlockedAt?: Date;
  isUnlocked: boolean;
  isNew: boolean;
}

interface AchievementState {
  achievements: Achievement[];
  totalUnlocked: number;
  pendingNotifications: Achievement[];
  
  // Actions
  unlockAchievement: (achievementId: string) => void;
  updateProgress: (achievementId: string, progress: number) => void;
  markAsViewed: (achievementId: string) => void;
  clearNotifications: () => void;
  initializeAchievements: () => void;
  
  // Event handlers
  onGameWon: () => void;
  onCardCollected: (rarity: string) => void;
  onDeckCreated: () => void;
  onTutorialCompleted: () => void;
  onFirstMultiplayerGame: () => void;
  onStreakAchieved: (streak: number) => void;
}

const defaultAchievements: Achievement[] = [
  // Gameplay Achievements
  {
    id: "first-victory",
    title: "Erster Sieg",
    description: "Gewinne dein erstes GridRune Spiel",
    icon: "🏆",
    rarity: "common",
    category: "gameplay",
    requirements: { type: "milestone", target: 1, current: 0 },
    reward: { type: "diamonds", amount: 50 },
    isUnlocked: false,
    isNew: false
  },
  {
    id: "winning-streak-5",
    title: "Siegesserie",
    description: "Gewinne 5 Spiele in Folge",
    icon: "🔥",
    rarity: "rare",
    category: "gameplay",
    requirements: { type: "counter", target: 5, current: 0 },
    reward: { type: "diamonds", amount: 150 },
    isUnlocked: false,
    isNew: false
  },
  {
    id: "perfect-game",
    title: "Perfektes Spiel",
    description: "Gewinne ein Spiel ohne eine einzige Karte zu verlieren",
    icon: "💎",
    rarity: "epic",
    category: "gameplay",
    requirements: { type: "condition" },
    reward: { type: "diamonds", amount: 300 },
    isUnlocked: false,
    isNew: false
  },
  
  // Collection Achievements
  {
    id: "first-legendary",
    title: "Legendärer Sammler",
    description: "Erhalte deine erste legendäre Karte",
    icon: "⭐",
    rarity: "rare",
    category: "collection",
    requirements: { type: "milestone", target: 1, current: 0 },
    reward: { type: "diamonds", amount: 100 },
    isUnlocked: false,
    isNew: false
  },
  {
    id: "master-collector",
    title: "Meistersammler",
    description: "Sammle alle 25 verfügbaren Karten",
    icon: "📚",
    rarity: "legendary",
    category: "collection",
    requirements: { type: "counter", target: 25, current: 0 },
    reward: { type: "diamonds", amount: 1000, items: ["Master Collector Title"] },
    isUnlocked: false,
    isNew: false
  },
  
  // Deck Building Achievements
  {
    id: "first-deck",
    title: "Deckbaumeister",
    description: "Erstelle dein erstes eigenes Deck",
    icon: "🎴",
    rarity: "common",
    category: "deck-building",
    requirements: { type: "milestone", target: 1, current: 0 },
    reward: { type: "diamonds", amount: 25 },
    isUnlocked: false,
    isNew: false
  },
  {
    id: "deck-variety",
    title: "Strategische Vielfalt",
    description: "Erstelle 5 verschiedene Decks",
    icon: "🎯",
    rarity: "rare",
    category: "deck-building",
    requirements: { type: "counter", target: 5, current: 0 },
    reward: { type: "diamonds", amount: 200 },
    isUnlocked: false,
    isNew: false
  },
  
  // Tutorial & Progression
  {
    id: "tutorial-master",
    title: "Lernbereit",
    description: "Schließe das Tutorial ab",
    icon: "🎓",
    rarity: "common",
    category: "progression",
    requirements: { type: "milestone", target: 1, current: 0 },
    reward: { type: "diamonds", amount: 25 },
    isUnlocked: false,
    isNew: false
  },
  
  // Social & Multiplayer
  {
    id: "multiplayer-debut",
    title: "Online Krieger",
    description: "Spiele dein erstes Multiplayer-Spiel",
    icon: "🌐",
    rarity: "common",
    category: "social",
    requirements: { type: "milestone", target: 1, current: 0 },
    reward: { type: "diamonds", amount: 75 },
    isUnlocked: false,
    isNew: false
  },
  {
    id: "trading-master",
    title: "Handelsexperte",
    description: "Tausche erfolgreich 10 Karten mit anderen Spielern",
    icon: "🤝",
    rarity: "rare",
    category: "social",
    requirements: { type: "counter", target: 10, current: 0 },
    reward: { type: "diamonds", amount: 250 },
    isUnlocked: false,
    isNew: false
  }
];

export const useAchievements = create<AchievementState>()(
  persist(
    (set, get) => ({
      achievements: [],
      totalUnlocked: 0,
      pendingNotifications: [],

      initializeAchievements: () => {
        const currentAchievements = get().achievements;
        if (currentAchievements.length === 0) {
          set({ achievements: [...defaultAchievements] });
        }
      },

      unlockAchievement: (achievementId: string) => {
        const { achievements, pendingNotifications } = get();
        const achievementIndex = achievements.findIndex(a => a.id === achievementId);
        
        if (achievementIndex === -1 || achievements[achievementIndex].isUnlocked) return;

        const updatedAchievements = [...achievements];
        const unlockedAchievement = {
          ...updatedAchievements[achievementIndex],
          isUnlocked: true,
          isNew: true,
          unlockedAt: new Date()
        };
        
        updatedAchievements[achievementIndex] = unlockedAchievement;

        set({
          achievements: updatedAchievements,
          totalUnlocked: get().totalUnlocked + 1,
          pendingNotifications: [...pendingNotifications, unlockedAchievement]
        });

        console.log(`🏆 Achievement unlocked: ${unlockedAchievement.title}`);
      },

      updateProgress: (achievementId: string, progress: number) => {
        const { achievements } = get();
        const achievementIndex = achievements.findIndex(a => a.id === achievementId);
        
        if (achievementIndex === -1 || achievements[achievementIndex].isUnlocked) return;

        const updatedAchievements = [...achievements];
        const achievement = updatedAchievements[achievementIndex];
        
        if (achievement.requirements.type === "counter" || achievement.requirements.type === "milestone") {
          achievement.requirements.current = Math.max(
            achievement.requirements.current || 0,
            progress
          );

          // Check if achievement should be unlocked
          if (achievement.requirements.target && 
              achievement.requirements.current >= achievement.requirements.target) {
            get().unlockAchievement(achievementId);
            return;
          }
        }

        set({ achievements: updatedAchievements });
      },

      markAsViewed: (achievementId: string) => {
        const { achievements } = get();
        const updatedAchievements = achievements.map(a => 
          a.id === achievementId ? { ...a, isNew: false } : a
        );
        set({ achievements: updatedAchievements });
      },

      clearNotifications: () => {
        set({ pendingNotifications: [] });
      },

      // Event Handlers
      onGameWon: () => {
        get().updateProgress("first-victory", 1);
      },

      onCardCollected: (rarity: string) => {
        if (rarity === "legendary") {
          get().updateProgress("first-legendary", 1);
        }
        // Update master collector progress
        const { achievements } = get();
        const masterCollector = achievements.find(a => a.id === "master-collector");
        if (masterCollector && masterCollector.requirements.current !== undefined) {
          get().updateProgress("master-collector", masterCollector.requirements.current + 1);
        }
      },

      onDeckCreated: () => {
        get().updateProgress("first-deck", 1);
        const { achievements } = get();
        const deckVariety = achievements.find(a => a.id === "deck-variety");
        if (deckVariety && deckVariety.requirements.current !== undefined) {
          get().updateProgress("deck-variety", deckVariety.requirements.current + 1);
        }
      },

      onTutorialCompleted: () => {
        get().unlockAchievement("tutorial-master");
      },

      onFirstMultiplayerGame: () => {
        get().unlockAchievement("multiplayer-debut");
      },

      onStreakAchieved: (streak: number) => {
        if (streak >= 5) {
          get().unlockAchievement("winning-streak-5");
        }
      }
    }),
    {
      name: "gridrune-achievements",
      partialize: (state) => ({
        achievements: state.achievements,
        totalUnlocked: state.totalUnlocked
      })
    }
  )
);