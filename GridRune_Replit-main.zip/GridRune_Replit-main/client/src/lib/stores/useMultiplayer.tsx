import { create } from "zustand";
import { io, Socket } from "socket.io-client";

interface MultiplayerState {
  socket: Socket | null;
  isConnected: boolean;
  roomId: string | null;
  playerId: string | null;
  playerName: string;
  roomPlayers: Array<{ id: string; name: string; ready: boolean }>;
  isHost: boolean;
  gameStarted: boolean;
  
  // Actions
  connect: () => void;
  disconnect: () => void;
  joinRoom: (roomId: string, playerName: string) => void;
  leaveRoom: () => void;
  toggleReady: () => void;
  sendGameMove: (move: any) => void;
  setPlayerName: (name: string) => void;
}

export const useMultiplayer = create<MultiplayerState>((set, get) => ({
  socket: null,
  isConnected: false,
  roomId: null,
  playerId: null,
  playerName: "",
  roomPlayers: [],
  isHost: false,
  gameStarted: false,

  connect: () => {
    const socket = io("http://localhost:5000");
    
    socket.on('connect', () => {
      set({ 
        socket, 
        isConnected: true,
        playerId: socket.id 
      });
      console.log('Connected to multiplayer server');
    });

    socket.on('disconnect', () => {
      set({ 
        isConnected: false,
        roomId: null,
        playerId: null,
        roomPlayers: [],
        gameStarted: false
      });
      console.log('Disconnected from multiplayer server');
    });

    socket.on('joinedRoom', (data: { roomId: string; playerId: string }) => {
      set({ 
        roomId: data.roomId,
        playerId: data.playerId 
      });
      console.log(`Joined room: ${data.roomId}`);
    });

    socket.on('roomUpdate', (players: Array<{ id: string; name: string; ready: boolean }>) => {
      const { playerId } = get();
      const isHost = players.length > 0 && players[0].id === playerId;
      
      set({ 
        roomPlayers: players,
        isHost 
      });
      console.log('Room updated:', players);
    });

    socket.on('gameStart', () => {
      set({ gameStarted: true });
      console.log('Game starting!');
    });

    socket.on('opponentMove', (move: any) => {
      // This will be handled by the game store
      console.log('Received opponent move:', move);
    });

    socket.on('playerDisconnected', (playerId: string) => {
      console.log('Player disconnected:', playerId);
      // Handle player disconnect
    });

    socket.on('roomFull', () => {
      console.log('Room is full');
      alert('Room is full!');
    });

    set({ socket });
  },

  disconnect: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
    }
    set({ 
      socket: null,
      isConnected: false,
      roomId: null,
      playerId: null,
      roomPlayers: [],
      gameStarted: false
    });
  },

  joinRoom: (roomId: string, playerName: string) => {
    const { socket } = get();
    if (socket) {
      socket.emit('joinRoom', { roomId, playerName });
      set({ playerName });
    }
  },

  leaveRoom: () => {
    const { socket, roomId } = get();
    if (socket && roomId) {
      socket.leave(roomId);
      set({ 
        roomId: null,
        roomPlayers: [],
        gameStarted: false 
      });
    }
  },

  toggleReady: () => {
    const { socket, roomId } = get();
    if (socket && roomId) {
      socket.emit('playerReady', { roomId });
    }
  },

  sendGameMove: (move: any) => {
    const { socket, roomId } = get();
    if (socket && roomId) {
      socket.emit('gameMove', { roomId, move });
    }
  },

  setPlayerName: (name: string) => {
    set({ playerName: name });
  }
}));