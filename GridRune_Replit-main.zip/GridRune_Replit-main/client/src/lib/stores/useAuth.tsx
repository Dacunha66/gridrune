import { create } from "zustand";
import { User } from "../../../shared/schema";

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isGuest: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  login: (username: string, password: string) => Promise<void>;
  register: (userData: {
    username: string;
    email: string;
    password: string;
    displayName: string;
  }) => Promise<void>;
  loginAsGuest: () => void;
  logout: () => void;
  clearError: () => void;
  checkAuthStatus: () => Promise<void>;
  updateProfile: (profileData: {
    displayName?: string;
    profileImage?: string;
    favoriteAvatar?: string;
  }) => Promise<void>;
}

export const useAuth = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isGuest: false,
  isLoading: false,
  error: null,

  login: async (username: string, password: string) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Anmeldung fehlgeschlagen');
      }

      const userData = await response.json();
      set({ 
        user: userData, 
        isAuthenticated: true, 
        isLoading: false, 
        error: null 
      });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Unbekannter Fehler',
        isLoading: false,
        isAuthenticated: false,
        user: null
      });
    }
  },

  register: async (userData) => {
    set({ isLoading: true, error: null });
    
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Registrierung fehlgeschlagen');
      }

      const newUser = await response.json();
      set({ 
        user: newUser, 
        isAuthenticated: true, 
        isLoading: false, 
        error: null 
      });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Unbekannter Fehler',
        isLoading: false,
        isAuthenticated: false,
        user: null
      });
    }
  },

  loginAsGuest: () => {
    const guestUser: User = {
      id: -1,
      username: 'guest',
      email: 'guest@example.com',
      password: '',
      displayName: 'Gastspieler',
      profileImage: 'default_avatar.png',
      level: 1,
      experience: 0,
      totalGames: 0,
      totalWins: 0,
      totalLosses: 0,
      winStreak: 0,
      bestWinStreak: 0,
      favoriteAvatar: 'warrior',
      isOnline: true,
      lastSeen: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    set({ 
      user: guestUser, 
      isAuthenticated: true, 
      isGuest: true,
      isLoading: false, 
      error: null 
    });
  },

  logout: async () => {
    const { isGuest } = get();
    
    if (!isGuest) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          credentials: 'include',
        });
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
    
    set({ 
      user: null, 
      isAuthenticated: false, 
      isGuest: false,
      error: null 
    });
  },

  clearError: () => {
    set({ error: null });
  },

  checkAuthStatus: async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();
        set({ 
          user: userData, 
          isAuthenticated: true,
          isGuest: false
        });
      } else {
        set({ 
          user: null, 
          isAuthenticated: false,
          isGuest: false
        });
      }
    } catch (error) {
      console.error('Auth check error:', error);
      set({ 
        user: null, 
        isAuthenticated: false,
        isGuest: false
      });
    }
  },

  updateProfile: async (profileData) => {
    const { isGuest, user } = get();
    
    if (isGuest && user) {
      // Update guest profile locally only
      const updatedUser = {
        ...user,
        ...profileData,
        updatedAt: new Date()
      };
      set({ user: updatedUser });
      return;
    }

    set({ isLoading: true, error: null });
    
    try {
      const response = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(profileData),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Profil-Update fehlgeschlagen');
      }

      const updatedUser = await response.json();
      set({ 
        user: updatedUser, 
        isLoading: false, 
        error: null 
      });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Unbekannter Fehler',
        isLoading: false
      });
    }
  },
}));