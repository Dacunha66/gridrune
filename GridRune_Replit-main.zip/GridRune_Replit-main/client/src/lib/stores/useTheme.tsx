import { create } from "zustand";

export type ThemeType = 
  | "dawn"      // Early game (turns 1-3)
  | "morning"   // Mid-early game (turns 4-6)
  | "noon"      // Mid game (turns 7-9)
  | "sunset"    // Late mid game (turns 10-12)
  | "dusk"      // Late game (turns 13-15)
  | "night"     // Final turns (16+)
  | "victory"   // Game won
  | "defeat";   // Game lost

export interface ThemeConfig {
  name: string;
  background: string;
  overlay: string;
  accent: string;
  description: string;
}

export const themeConfigs: Record<ThemeType, ThemeConfig> = {
  dawn: {
    name: "Dawn",
    background: "bg-gradient-to-br from-purple-900 via-pink-800 to-orange-600",
    overlay: "bg-purple-900/10",
    accent: "border-pink-400/30",
    description: "The battle begins as dawn breaks"
  },
  morning: {
    name: "Morning",
    background: "bg-gradient-to-br from-blue-600 via-cyan-500 to-yellow-400",
    overlay: "bg-blue-600/10",
    accent: "border-cyan-400/30",
    description: "Morning light illuminates the battlefield"
  },
  noon: {
    name: "High Noon",
    background: "bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500",
    overlay: "bg-yellow-400/10",
    accent: "border-orange-400/30",
    description: "The sun reaches its peak as battles intensify"
  },
  sunset: {
    name: "Sunset",
    background: "bg-gradient-to-br from-orange-600 via-red-600 to-purple-700",
    overlay: "bg-orange-600/10",
    accent: "border-red-400/30",
    description: "Sunset paints the sky as the battle reaches climax"
  },
  dusk: {
    name: "Dusk",
    background: "bg-gradient-to-br from-purple-800 via-indigo-800 to-blue-900",
    overlay: "bg-purple-800/10",
    accent: "border-indigo-400/30",
    description: "Twilight falls upon the decisive moments"
  },
  night: {
    name: "Night",
    background: "bg-gradient-to-br from-gray-900 via-blue-900 to-black",
    overlay: "bg-gray-900/20",
    accent: "border-blue-400/30",
    description: "Night shrouds the final confrontation"
  },
  victory: {
    name: "Victory",
    background: "bg-gradient-to-br from-yellow-300 via-gold-400 to-amber-500",
    overlay: "bg-yellow-300/10",
    accent: "border-gold-400/50",
    description: "Golden light celebrates your triumph"
  },
  defeat: {
    name: "Defeat",
    background: "bg-gradient-to-br from-red-900 via-red-800 to-gray-900",
    overlay: "bg-red-900/20",
    accent: "border-red-600/30",
    description: "Darkness marks the end of battle"
  }
};

interface ThemeStore {
  currentTheme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  updateThemeBasedOnProgress: (turnCount: number, gamePhase: string, gameStatus?: string) => void;
  getThemeConfig: () => ThemeConfig;
}

export const useTheme = create<ThemeStore>((set, get) => ({
  currentTheme: "dawn",
  
  setTheme: (theme: ThemeType) => {
    set({ currentTheme: theme });
  },
  
  updateThemeBasedOnProgress: (turnCount: number, gamePhase: string, gameStatus?: string) => {
    // Handle game end states first
    if (gameStatus === "won") {
      set({ currentTheme: "victory" });
      return;
    }
    if (gameStatus === "lost") {
      set({ currentTheme: "defeat" });
      return;
    }
    
    // Skip theme changes during special phases
    if (gamePhase === "coin-flip" || gamePhase === "place-o-card") {
      return;
    }
    
    // Determine theme based on turn count
    let newTheme: ThemeType;
    if (turnCount <= 3) {
      newTheme = "dawn";
    } else if (turnCount <= 6) {
      newTheme = "morning";
    } else if (turnCount <= 9) {
      newTheme = "noon";
    } else if (turnCount <= 12) {
      newTheme = "sunset";
    } else if (turnCount <= 15) {
      newTheme = "dusk";
    } else {
      newTheme = "night";
    }
    
    // Only update if theme actually changed
    if (get().currentTheme !== newTheme) {
      console.log(`🎨 Theme transition: ${get().currentTheme} → ${newTheme} (Turn ${turnCount})`);
      set({ currentTheme: newTheme });
    }
  },
  
  getThemeConfig: () => {
    return themeConfigs[get().currentTheme];
  }
}));