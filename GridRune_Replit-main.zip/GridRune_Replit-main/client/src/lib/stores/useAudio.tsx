import { create } from "zustand";

interface AudioState {
  backgroundMusic: HTMLAudioElement | null;
  backgroundMusicTracks: HTMLAudioElement[];
  currentTrackIndex: number;
  hitSound: HTMLAudioElement | null;
  successSound: HTMLAudioElement | null;
  // Battle sound effects
  attackSound: HTMLAudioElement | null;
  defenseSound: HTMLAudioElement | null;
  captureSound: HTMLAudioElement | null;
  blitzschlagSound: HTMLAudioElement | null;
  shieldBreakSound: HTMLAudioElement | null;
  clashSound: HTMLAudioElement | null;
  placementSound: HTMLAudioElement | null;
  magicalSelectionSound: HTMLAudioElement | null;
  isMuted: boolean;
  masterVolume: number;
  musicVolume: number;
  effectsVolume: number;
  isBackgroundMusicPlaying: boolean;
  
  // Setter functions
  setBackgroundMusic: (music: HTMLAudioElement) => void;
  setBackgroundMusicTracks: (tracks: HTMLAudioElement[]) => void;
  setHitSound: (sound: HTMLAudioElement) => void;
  setSuccessSound: (sound: HTMLAudioElement) => void;
  // Battle sound setters
  setAttackSound: (sound: HTMLAudioElement) => void;
  setDefenseSound: (sound: HTMLAudioElement) => void;
  setCaptureSound: (sound: HTMLAudioElement) => void;
  setBlitzschlagSound: (sound: HTMLAudioElement) => void;
  setShieldBreakSound: (sound: HTMLAudioElement) => void;
  setClashSound: (sound: HTMLAudioElement) => void;
  setPlacementSound: (sound: HTMLAudioElement) => void;
  setMagicalSelectionSound: (sound: HTMLAudioElement) => void;
  
  // Control functions
  toggleMute: () => void;
  toggleBackgroundMusic: () => void;
  changeBackgroundTrack: () => void;
  setMasterVolume: (volume: number) => void;
  setMusicVolume: (volume: number) => void;
  setEffectsVolume: (volume: number) => void;
  playHit: () => void;
  playSuccess: () => void;
  // Battle sound players
  playAttackSound: () => void;
  playDefenseSound: () => void;
  playCaptureSound: () => void;
  playBlitzschlagSound: () => void;
  playShieldBreakSound: () => void;
  playClashSound: () => void;
  playPlacementSound: () => void;
  playMagicalSelectionSound: () => void;
}

export const useAudio = create<AudioState>((set, get) => ({
  backgroundMusic: null,
  backgroundMusicTracks: [],
  currentTrackIndex: 0,
  hitSound: null,
  successSound: null,
  // Battle sound effects
  attackSound: null,
  defenseSound: null,
  captureSound: null,
  blitzschlagSound: null,
  shieldBreakSound: null,
  clashSound: null,
  placementSound: null,
  magicalSelectionSound: null,
  isMuted: false, // Start unmuted now
  masterVolume: 0.7,
  musicVolume: 0.5,
  effectsVolume: 0.6,
  isBackgroundMusicPlaying: false,
  
  setBackgroundMusic: (music) => {
    set({ backgroundMusic: music });
    
    // Apply initial volume settings
    const { musicVolume, masterVolume } = get();
    music.volume = musicVolume * masterVolume;
  },
  setBackgroundMusicTracks: (tracks) => {
    set({ backgroundMusicTracks: tracks });
    
    // Set the first track as current background music
    if (tracks.length > 0) {
      const { musicVolume, masterVolume } = get();
      tracks[0].volume = musicVolume * masterVolume;
      set({ backgroundMusic: tracks[0] });
    }
  },
  setHitSound: (sound) => set({ hitSound: sound }),
  setSuccessSound: (sound) => set({ successSound: sound }),
  
  // Battle sound setters
  setAttackSound: (sound) => set({ attackSound: sound }),
  setDefenseSound: (sound) => set({ defenseSound: sound }),
  setCaptureSound: (sound) => set({ captureSound: sound }),
  setBlitzschlagSound: (sound) => set({ blitzschlagSound: sound }),
  setShieldBreakSound: (sound) => set({ shieldBreakSound: sound }),
  setClashSound: (sound) => set({ clashSound: sound }),
  setPlacementSound: (sound) => set({ placementSound: sound }),
  setMagicalSelectionSound: (sound) => set({ magicalSelectionSound: sound }),
  
  toggleMute: () => {
    const { isMuted, backgroundMusic } = get();
    const newMutedState = !isMuted;
    
    set({ isMuted: newMutedState });
    
    // Pause/resume background music based on mute state
    if (backgroundMusic) {
      if (newMutedState) {
        backgroundMusic.pause();
        set({ isBackgroundMusicPlaying: false });
      } else {
        const { musicVolume, masterVolume } = get();
        backgroundMusic.volume = musicVolume * masterVolume;
        backgroundMusic.play().catch(error => {
          console.log("Background music play prevented:", error);
        });
        set({ isBackgroundMusicPlaying: true });
      }
    }
    
    console.log(`Sound ${newMutedState ? 'muted' : 'unmuted'}`);
  },

  toggleBackgroundMusic: () => {
    const { backgroundMusic, isBackgroundMusicPlaying, isMuted } = get();
    
    if (!backgroundMusic || isMuted) return;
    
    if (isBackgroundMusicPlaying) {
      backgroundMusic.pause();
      set({ isBackgroundMusicPlaying: false });
    } else {
      const { musicVolume, masterVolume } = get();
      backgroundMusic.volume = musicVolume * masterVolume;
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
      set({ isBackgroundMusicPlaying: true });
    }
  },

  changeBackgroundTrack: () => {
    const { backgroundMusicTracks, currentTrackIndex, isBackgroundMusicPlaying, musicVolume, masterVolume, isMuted } = get();
    
    if (backgroundMusicTracks.length <= 1) return; // Need at least 2 tracks to change
    
    // Pause current track
    const currentTrack = backgroundMusicTracks[currentTrackIndex];
    if (currentTrack) {
      currentTrack.pause();
      currentTrack.currentTime = 0; // Reset to beginning
    }
    
    // Calculate next track index
    const nextIndex = (currentTrackIndex + 1) % backgroundMusicTracks.length;
    const nextTrack = backgroundMusicTracks[nextIndex];
    
    if (nextTrack) {
      // Apply volume settings
      nextTrack.volume = musicVolume * masterVolume;
      
      // Update state
      set({ 
        backgroundMusic: nextTrack, 
        currentTrackIndex: nextIndex 
      });
      
      // Play if music was playing and not muted
      if (isBackgroundMusicPlaying && !isMuted) {
        nextTrack.play().catch(error => {
          console.log("Background music play prevented:", error);
        });
      }
      
      const trackName = (nextTrack as any)?.effectName || `Track ${nextIndex + 1}`;
      console.log(`Background music changed to: ${trackName}`);
    }
  },

  setMasterVolume: (volume) => {
    set({ masterVolume: volume });
    
    const { backgroundMusic, musicVolume, isBackgroundMusicPlaying, isMuted } = get();
    if (backgroundMusic && isBackgroundMusicPlaying && !isMuted) {
      backgroundMusic.volume = musicVolume * volume;
    }
  },

  setMusicVolume: (volume) => {
    set({ musicVolume: volume });
    
    const { backgroundMusic, masterVolume, isBackgroundMusicPlaying, isMuted } = get();
    if (backgroundMusic && isBackgroundMusicPlaying && !isMuted) {
      backgroundMusic.volume = volume * masterVolume;
    }
  },

  setEffectsVolume: (volume) => {
    set({ effectsVolume: volume });
  },
  
  playHit: () => {
    const { hitSound, isMuted, effectsVolume, masterVolume } = get();
    if (hitSound) {
      if (isMuted) {
        console.log("Hit sound skipped (muted)");
        return;
      }
      
      // Clone the sound to allow overlapping playback
      const soundClone = hitSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume;
      soundClone.play().catch(error => {
        console.log("Hit sound play prevented:", error);
      });
    }
  },
  
  playSuccess: () => {
    const { successSound, isMuted, effectsVolume, masterVolume } = get();
    if (successSound) {
      if (isMuted) {
        console.log("Success sound skipped (muted)");
        return;
      }
      
      successSound.currentTime = 0;
      successSound.volume = effectsVolume * masterVolume;
      successSound.play().catch(error => {
        console.log("Success sound play prevented:", error);
      });
    }
  },

  // Battle sound players
  playAttackSound: () => {
    const { attackSound, isMuted, effectsVolume, masterVolume } = get();
    if (attackSound && !isMuted) {
      const soundClone = attackSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 0.8;
      soundClone.play().catch(error => console.log("Attack sound play prevented:", error));
    }
  },

  playDefenseSound: () => {
    const { defenseSound, isMuted, effectsVolume, masterVolume } = get();
    if (defenseSound && !isMuted) {
      const soundClone = defenseSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 0.7;
      soundClone.play().catch(error => console.log("Defense sound play prevented:", error));
    }
  },

  playCaptureSound: () => {
    const { captureSound, isMuted, effectsVolume, masterVolume } = get();
    if (captureSound && !isMuted) {
      const soundClone = captureSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 0.9;
      soundClone.play().catch(error => console.log("Capture sound play prevented:", error));
    }
  },

  playBlitzschlagSound: () => {
    const { blitzschlagSound, isMuted, effectsVolume, masterVolume } = get();
    if (blitzschlagSound && !isMuted) {
      const soundClone = blitzschlagSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 1.0;
      soundClone.play().catch(error => console.log("Blitzschlag sound play prevented:", error));
    }
  },

  playShieldBreakSound: () => {
    const { shieldBreakSound, isMuted, effectsVolume, masterVolume } = get();
    if (shieldBreakSound && !isMuted) {
      const soundClone = shieldBreakSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 0.85;
      soundClone.play().catch(error => console.log("Shield break sound play prevented:", error));
    }
  },

  playClashSound: () => {
    const { clashSound, isMuted, effectsVolume, masterVolume } = get();
    if (clashSound && !isMuted) {
      const soundClone = clashSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = effectsVolume * masterVolume * 0.75;
      soundClone.play().catch(error => console.log("Clash sound play prevented:", error));
    }
  },

  playPlacementSound: () => {
    // Sound disabled per user request
    return;
  },

  playMagicalSelectionSound: () => {
    // Sound disabled per user request
    return;
  }
}));
