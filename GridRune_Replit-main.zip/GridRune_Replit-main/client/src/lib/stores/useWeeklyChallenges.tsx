import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface ChallengeTask {
  id: string;
  type: 'wins' | 'games_played' | 'cards_collected' | 'deck_created' | 'ai_defeats' | 'multiplayer_games' | 'perfect_games' | 'streak';
  target: number;
  progress: number;
  name: string;
  nameGerman: string;
  description: string;
  descriptionGerman: string;
  reward: {
    xp: number;
    diamonds?: number;
    gold?: number;
    cards?: string[];
    packs?: number;
  };
  difficulty: 'Einfach' | 'Mittel' | 'Schwer' | 'Episch';
  completed: boolean;
  completedAt?: Date;
}

export interface WeeklyChallenge {
  id: string;
  week: number;
  year: number;
  startDate: Date;
  endDate: Date;
  title: string;
  titleGerman: string;
  description: string;
  descriptionGerman: string;
  tasks: ChallengeTask[];
  theme: string;
  themeGerman: string;
  isActive: boolean;
  totalParticipants: number;
  rewardPool: {
    diamonds: number;
    exclusiveCards: string[];
    titles: string[];
  };
}

export interface LeaderboardEntry {
  playerId: string;
  playerName: string;
  avatar: string;
  tasksCompleted: number;
  totalXP: number;
  completionTime: Date;
  rank: number;
  country?: string;
  badge?: string;
  isCurrentUser?: boolean;
}

export interface WeeklyChallengesState {
  currentChallenge: WeeklyChallenge | null;
  allChallenges: WeeklyChallenge[];
  userProgress: Map<string, number>;
  globalLeaderboard: LeaderboardEntry[];
  userRank: number;
  weeklyXPEarned: number;
  challengesCompleted: string[];
  
  // Actions
  initializeWeeklyChallenges: () => void;
  updateTaskProgress: (taskId: string, progress: number) => void;
  completeTask: (taskId: string) => void;
  getActiveChallenge: () => WeeklyChallenge | null;
  getLeaderboard: () => LeaderboardEntry[];
  getUserRank: () => number;
  addChallengeXP: (amount: number) => void;
  resetWeeklyProgress: () => void;
  generateNewChallenge: () => void;
  getCompletedTasksCount: () => number;
}

const SAMPLE_CHALLENGES = [
  {
    id: 'week-1-2025',
    week: 1,
    year: 2025,
    startDate: new Date('2025-01-06T00:00:00Z'),
    endDate: new Date('2025-01-13T23:59:59Z'),
    title: 'Grid Master Challenge',
    titleGerman: 'Gitter-Meister Herausforderung',
    description: 'Prove your strategic mastery in this week\'s challenges',
    descriptionGerman: 'Beweise deine strategische Meisterschaft in den Herausforderungen dieser Woche',
    theme: 'Strategy',
    themeGerman: 'Strategie',
    isActive: true,
    totalParticipants: 0,
    rewardPool: {
      diamonds: 250,
      exclusiveCards: ['challenge_champion', 'weekly_warrior'],
      titles: ['Grid Master', 'Weekly Champion']
    },
    tasks: [
      {
        id: 'win_5_games',
        type: 'wins',
        target: 5,
        progress: 5,
        name: 'Victory Streak',
        nameGerman: 'Siegesserie',
        description: 'Win 5 games in any mode',
        descriptionGerman: 'Gewinne 5 Spiele in beliebigem Modus',
        reward: { xp: 100, diamonds: 25, gold: 500 },
        difficulty: 'Einfach',
        completed: true
      },
      {
        id: 'play_10_games',
        type: 'games_played',
        target: 10,
        progress: 10,
        name: 'Game Explorer',
        nameGerman: 'Spiel-Entdecker',
        description: 'Play 10 games total',
        descriptionGerman: 'Spiele insgesamt 10 Spiele',
        reward: { xp: 75, diamonds: 15, gold: 300 },
        difficulty: 'Einfach',
        completed: true
      },
      {
        id: 'defeat_ai_hard',
        type: 'ai_defeats',
        target: 3,
        progress: 0,
        name: 'AI Challenger',
        nameGerman: 'KI-Herausforderer',
        description: 'Defeat hard AI 3 times',
        descriptionGerman: 'Besiege die schwere KI 3 Mal',
        reward: { xp: 200, diamonds: 50, gold: 1000, cards: ['legendary_ai_slayer'] },
        difficulty: 'Schwer',
        completed: false
      },
      {
        id: 'perfect_games',
        type: 'perfect_games',
        target: 2,
        progress: 0,
        name: 'Flawless Victory',
        nameGerman: 'Perfekter Sieg',
        description: 'Win 2 games without losing any cards',
        descriptionGerman: 'Gewinne 2 Spiele ohne Karten zu verlieren',
        reward: { xp: 300, diamonds: 75, gold: 1500, packs: 2 },
        difficulty: 'Episch',
        completed: false
      },
      {
        id: 'create_deck',
        type: 'deck_created',
        target: 1,
        progress: 0,
        name: 'Deck Architect',
        nameGerman: 'Deck-Architekt',
        description: 'Create a new deck',
        descriptionGerman: 'Erstelle ein neues Deck',
        reward: { xp: 50, diamonds: 10, gold: 200 },
        difficulty: 'Einfach',
        completed: false
      }
    ]
  }
];

const SAMPLE_LEADERBOARD: LeaderboardEntry[] = [
  { playerId: 'player1', playerName: 'GridMaster_Pro', avatar: '🏆', tasksCompleted: 5, totalXP: 725, completionTime: new Date(), rank: 1, country: 'DE', badge: 'Champion' },
  { playerId: 'player2', playerName: 'CardStrategist', avatar: '⚔️', tasksCompleted: 4, totalXP: 625, completionTime: new Date(), rank: 2, country: 'US', badge: 'Master' },
  { playerId: 'player3', playerName: 'DeckBuilder99', avatar: '🎯', tasksCompleted: 4, totalXP: 575, completionTime: new Date(), rank: 3, country: 'UK', badge: 'Expert' },
  { playerId: 'player4', playerName: 'AISlayer', avatar: '🤖', tasksCompleted: 3, totalXP: 475, completionTime: new Date(), rank: 4, country: 'FR', badge: 'Veteran' },
  { playerId: 'player5', playerName: 'ChallengeHero', avatar: '⭐', tasksCompleted: 3, totalXP: 425, completionTime: new Date(), rank: 5, country: 'CA', badge: 'Rising' },
  { playerId: 'current_user', playerName: 'Du', avatar: '👤', tasksCompleted: 0, totalXP: 0, completionTime: new Date(), rank: 156, isCurrentUser: true }
];

export const useWeeklyChallenges = create<WeeklyChallengesState>()(
  persist(
    (set, get) => ({
      currentChallenge: null,
      allChallenges: [],
      userProgress: new Map(),
      globalLeaderboard: [],
      userRank: 0,
      weeklyXPEarned: 0,
      challengesCompleted: [],

      initializeWeeklyChallenges: () => {
        const state = get();
        if (state.allChallenges.length === 0) {
          const currentChallenge = SAMPLE_CHALLENGES[0];
          
          set({
            allChallenges: SAMPLE_CHALLENGES,
            currentChallenge,
            globalLeaderboard: SAMPLE_LEADERBOARD,
            userRank: 156
          });
        }
      },

      updateTaskProgress: (taskId: string, progress: number) => {
        const state = get();
        if (!state.currentChallenge) return;

        const updatedTasks = state.currentChallenge.tasks.map(task => {
          if (task.id === taskId) {
            const newProgress = Math.min(progress, task.target);
            const wasCompleted = task.completed;
            const isNowCompleted = newProgress >= task.target && !wasCompleted;
            
            if (isNowCompleted) {
              // Task just completed
              return {
                ...task,
                progress: newProgress,
                completed: true,
                completedAt: new Date()
              };
            }
            
            return {
              ...task,
              progress: newProgress
            };
          }
          return task;
        });

        const updatedChallenge = {
          ...state.currentChallenge,
          tasks: updatedTasks
        };

        set({
          currentChallenge: updatedChallenge,
          allChallenges: state.allChallenges.map(c => 
            c.id === updatedChallenge.id ? updatedChallenge : c
          )
        });
      },

      completeTask: (taskId: string) => {
        const state = get();
        if (!state.currentChallenge) return;

        const task = state.currentChallenge.tasks.find(t => t.id === taskId);
        if (!task || task.completed) return;

        // Update task completion
        get().updateTaskProgress(taskId, task.target);
        
        // Add XP reward
        get().addChallengeXP(task.reward.xp);
        
        // Add to completed challenges
        set({
          challengesCompleted: [...state.challengesCompleted, taskId]
        });
      },

      getActiveChallenge: () => {
        const state = get();
        return state.currentChallenge;
      },

      getLeaderboard: () => {
        const state = get();
        return state.globalLeaderboard;
      },

      getUserRank: () => {
        const state = get();
        return state.userRank;
      },

      addChallengeXP: (amount: number) => {
        const state = get();
        set({
          weeklyXPEarned: state.weeklyXPEarned + amount
        });
        
        // Update user position on leaderboard
        const userEntry = state.globalLeaderboard.find(entry => entry.isCurrentUser);
        if (userEntry) {
          userEntry.totalXP += amount;
          userEntry.tasksCompleted = state.currentChallenge?.tasks.filter(t => t.completed).length || 0;
          
          // Sort leaderboard and update ranks
          const sortedLeaderboard = state.globalLeaderboard.sort((a, b) => {
            if (b.totalXP !== a.totalXP) return b.totalXP - a.totalXP;
            return b.tasksCompleted - a.tasksCompleted;
          });
          
          sortedLeaderboard.forEach((entry, index) => {
            entry.rank = index + 1;
          });
          
          const newUserRank = userEntry.rank;
          
          set({
            globalLeaderboard: sortedLeaderboard,
            userRank: newUserRank
          });
        }
      },

      resetWeeklyProgress: () => {
        set({
          weeklyXPEarned: 0,
          challengesCompleted: [],
          userProgress: new Map()
        });
      },

      generateNewChallenge: () => {
        // This would be called weekly to generate new challenges
        // For now, it resets the current challenge
        const state = get();
        if (state.currentChallenge) {
          const resetChallenge = {
            ...state.currentChallenge,
            tasks: state.currentChallenge.tasks.map(task => ({
              ...task,
              progress: 0,
              completed: false,
              completedAt: undefined
            }))
          };
          
          set({
            currentChallenge: resetChallenge,
            weeklyXPEarned: 0,
            challengesCompleted: []
          });
        }
      },

      getCompletedTasksCount: () => {
        const state = get();
        if (!state.currentChallenge) return 0;
        return state.currentChallenge.tasks.filter(task => task.completed).length;
      }
    }),
    {
      name: 'weekly-challenges-storage',
      partialize: (state) => ({
        currentChallenge: state.currentChallenge,
        allChallenges: state.allChallenges,
        userProgress: Array.from(state.userProgress.entries()),
        weeklyXPEarned: state.weeklyXPEarned,
        challengesCompleted: state.challengesCompleted,
        userRank: state.userRank
      })
    }
  )
);