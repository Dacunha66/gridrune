import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface PlayerStats {
  level: number;
  xp: number;
  totalXp: number;
  gold: number;
  diamonds: number;
  packs: number;
  titles: string[];
  gamesPlayed: number;
  gamesWon: number;
  cardsCollected: number;
  questsCompleted: number;
  achievementsUnlocked: number;
  joinDate: Date;
}

export interface QuestReward {
  xp?: number;
  gold?: number;
  diamonds?: number;
  packs?: number;
  title?: string;
}

export interface PlayerProgressState {
  stats: PlayerStats;
  claimedQuests: string[];
  claimedAchievements: string[];
  
  // Actions
  addReward: (reward: QuestReward) => void;
  claimQuest: (questId: string, reward: QuestReward) => void;
  claimAchievement: (achievementId: string, reward: QuestReward) => void;
  addXp: (amount: number) => void;
  addGold: (amount: number) => void;
  addDiamonds: (amount: number) => void;
  addPacks: (amount: number) => void;
  addTitle: (title: string) => void;
  incrementGamesPlayed: () => void;
  incrementGamesWon: () => void;
  incrementCardsCollected: (amount?: number) => void;
  incrementQuestsCompleted: () => void;
  incrementAchievementsUnlocked: () => void;
  resetStats: () => void;
  getXpForNextLevel: () => number;
  getLevelProgress: () => number;
}

const getXpRequiredForLevel = (level: number): number => {
  // Progressive XP requirement: 100 * level^1.5
  return Math.floor(100 * Math.pow(level, 1.5));
};

const calculateLevel = (totalXp: number): number => {
  let level = 1;
  let xpForCurrentLevel = 0;
  
  while (xpForCurrentLevel <= totalXp) {
    level++;
    xpForCurrentLevel += getXpRequiredForLevel(level - 1);
  }
  
  return level - 1;
};

const getXpInCurrentLevel = (totalXp: number, level: number): number => {
  let xpForPreviousLevels = 0;
  for (let i = 1; i < level; i++) {
    xpForPreviousLevels += getXpRequiredForLevel(i);
  }
  return totalXp - xpForPreviousLevels;
};

const initialStats: PlayerStats = {
  level: 1,
  xp: 0,
  totalXp: 0,
  gold: 1000, // Starting gold
  diamonds: 50, // Starting diamonds
  packs: 0, // Starting packs to open
  titles: [],
  gamesPlayed: 0,
  gamesWon: 0,
  cardsCollected: 25, // Starting with basic deck
  questsCompleted: 0,
  achievementsUnlocked: 0,
  joinDate: new Date()
};

export const usePlayerProgress = create<PlayerProgressState>()(
  persist(
    (set, get) => ({
      stats: initialStats,
      claimedQuests: [],
      claimedAchievements: [],

      addReward: (reward: QuestReward) => {
        set((state) => {
          const newStats = { ...state.stats };
          
          if (reward.xp) {
            newStats.totalXp += reward.xp;
            newStats.level = calculateLevel(newStats.totalXp);
            newStats.xp = getXpInCurrentLevel(newStats.totalXp, newStats.level);
          }
          
          if (reward.gold) {
            newStats.gold += reward.gold;
          }
          
          if (reward.diamonds) {
            newStats.diamonds += reward.diamonds;
          }
          
          if (reward.packs) {
            newStats.packs += reward.packs;
          }
          
          if (reward.title && !newStats.titles.includes(reward.title)) {
            newStats.titles.push(reward.title);
          }
          
          return { ...state, stats: newStats };
        });
      },

      claimQuest: (questId: string, reward: QuestReward) => {
        const { claimedQuests } = get();
        const safeClaimedQuests = Array.isArray(claimedQuests) ? claimedQuests : [];
        if (safeClaimedQuests.includes(questId)) return;
        
        set((state) => ({
          ...state,
          claimedQuests: [...(Array.isArray(state.claimedQuests) ? state.claimedQuests : []), questId]
        }));
        
        get().addReward(reward);
        get().incrementQuestsCompleted();
      },

      claimAchievement: (achievementId: string, reward: QuestReward) => {
        const { claimedAchievements } = get();
        const safeClaimedAchievements = Array.isArray(claimedAchievements) ? claimedAchievements : [];
        if (safeClaimedAchievements.includes(achievementId)) return;
        
        set((state) => ({
          ...state,
          claimedAchievements: [...(Array.isArray(state.claimedAchievements) ? state.claimedAchievements : []), achievementId]
        }));
        
        get().addReward(reward);
        get().incrementAchievementsUnlocked();
      },

      addXp: (amount: number) => {
        set((state) => {
          const newStats = { ...state.stats };
          newStats.totalXp += amount;
          newStats.level = calculateLevel(newStats.totalXp);
          newStats.xp = getXpInCurrentLevel(newStats.totalXp, newStats.level);
          return { ...state, stats: newStats };
        });
      },

      addGold: (amount: number) => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, gold: state.stats.gold + amount }
        }));
      },

      addDiamonds: (amount: number) => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, diamonds: state.stats.diamonds + amount }
        }));
      },

      addPacks: (amount: number) => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, packs: state.stats.packs + amount }
        }));
      },

      addTitle: (title: string) => {
        set((state) => {
          if (state.stats.titles.includes(title)) return state;
          return {
            ...state,
            stats: { ...state.stats, titles: [...state.stats.titles, title] }
          };
        });
      },

      incrementGamesPlayed: () => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, gamesPlayed: state.stats.gamesPlayed + 1 }
        }));
      },

      incrementGamesWon: () => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, gamesWon: state.stats.gamesWon + 1 }
        }));
      },

      incrementCardsCollected: (amount = 1) => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, cardsCollected: state.stats.cardsCollected + amount }
        }));
      },

      incrementQuestsCompleted: () => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, questsCompleted: state.stats.questsCompleted + 1 }
        }));
      },

      incrementAchievementsUnlocked: () => {
        set((state) => ({
          ...state,
          stats: { ...state.stats, achievementsUnlocked: state.stats.achievementsUnlocked + 1 }
        }));
      },

      resetStats: () => {
        set({
          stats: { ...initialStats, joinDate: new Date() },
          claimedQuests: [],
          claimedAchievements: []
        });
      },

      getXpForNextLevel: () => {
        const { stats } = get();
        return getXpRequiredForLevel(stats.level);
      },

      getLevelProgress: () => {
        const { stats } = get();
        const xpForNextLevel = getXpRequiredForLevel(stats.level);
        return (stats.xp / xpForNextLevel) * 100;
      }
    }),
    {
      name: 'player-progress-storage'
    }
  )
);