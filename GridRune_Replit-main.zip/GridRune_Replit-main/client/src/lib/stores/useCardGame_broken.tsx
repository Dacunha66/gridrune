import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { GameCard, createPlayerDeck, createOCard, createExtendedDeck } from "../cardData";
import { Avatar, AVAILABLE_AVATARS } from '../../components/AvatarSelector';

type Element = "fire" | "water" | "earth" | "lightning" | "wind" | "ice" | "nature" | "shadow" | "desert" | "crystal";
import { resolveBattles, checkWinCondition } from "../gameLogic";
import { applyTurnBasedEffects, applyContinuousEffects } from "../effectLogic";
import { useAudio } from "./useAudio";
import { useTheme } from "./useTheme";

export type GamePhase = "menu" | "ready" | "coin-flip" | "place-o-card" | "playing" | "ended" | "deck-editor" | "deck-management" | "deck-creator" | "card-collection" | "player-profile" | "blitzschlag-target" | "clone-target" | "multiplayer-lobby" | "rarity-demo" | "deck-theme-customizer" | "card-flip-demo" | "shop" | "story" | "ranked-matchmaking" | "season-rewards" | "achievements" | "seasonal-rewards" | "weekly-challenges";
export type Player = "player1" | "player2" | "neutral";
export type GameMode = "local" | "ai" | "multiplayer" | "ranked";
export type AIDifficulty = "beginner" | "easy" | "medium" | "hard" | "insane";
export type BoardSize = "4x4";

export interface ElementField {
  element: Element;
  position: number;
}

export interface BoardSlot {
  card: GameCard;
  originalCard: GameCard; // Store original card values without any effects
  owner: Player;
  placedOnTurn?: number; // Track when card was placed for turn-based effects
  shieldBroken?: boolean; // Track if shield effect has been used

}

export interface SelectedCard {
  player: 1 | 2;
  cardIndex: number;
}

interface CardGameState {
  gamePhase: GamePhase;
  currentPlayer: 1 | 2;
  board: (BoardSlot | null)[];
  elementFields: ElementField[];
  player1Hand: GameCard[];
  player2Hand: GameCard[];
  player1Deck: GameCard[];
  player2Deck: GameCard[];
  player1Cards: GameCard[];
  selectedCard: SelectedCard | null;
  winner: Player | "tie" | null;
  
  // Deck Management System
  savedDecks: { name: string; cards: GameCard[]; boardSize: BoardSize; customization?: any }[];
  currentEditingDeck: number | null; // Index of deck being edited
  selectedDeckForGame: number; // Index of deck selected for game
  
  // Player Profile System
  player1Name: string;
  player2Name: string;
  player1Avatar: Avatar;
  player2Avatar: Avatar;
  showAvatarCustomization: boolean;
  customizingPlayer: 1 | 2 | null;
  player1Score: number;
  player2Score: number;
  oCardOwner: Player;
  effectMessages: string[];
  turnCount: number;
  gameMode: GameMode | null;
  aiDifficulty: AIDifficulty;
  boardSize: BoardSize;
  coinFlipWinner: 1 | 2 | null;
  coinFlipResult: "heads" | "tails" | null;
  blitzschlagCardIndex: number | null; // Index of card that triggered blitzschlag
  blitzschlagTargets: number[]; // Available target indices for blitzschlag
  cloneCardIndex: number | null; // Index of card that triggered clone
  cloneTargets: number[]; // Available target indices for clone
  
  // Battle animation states
  battleAnimations: {
    [key: number]: {
      type: 'attacking' | 'defending' | 'captured' | 'blitzschlag' | 'shield-break' | 'clash' | 'glow' | 'placed';
      startTime: number;
      duration: number;
      damageNumbers?: { value: number; type: 'damage' | 'heal' }[];
    }
  };

  // Enhanced visual placement guide
  showPlacementGuide: boolean;
  validPlacementSlots: number[];
  highlightedSlot: number | null;
  placementStrategies: { [slotIndex: number]: 'aggressive' | 'defensive' | 'neutral' | 'optimal' };
  showStrategicHints: boolean;
  
  // Multiplayer specific
  isMultiplayer: boolean;
  isOnlinePlayer: boolean;

  // Actions
  setGameMode: (mode: GameMode) => void;
  setAIDifficulty: (difficulty: AIDifficulty) => void;
  setBoardSize: (size: BoardSize) => void;
  setGamePhase: (phase: GamePhase) => void;
  setPlayer1Cards: (cards: GameCard[]) => void;
  
  // Deck Management actions
  saveDeck: (name: string, cards: GameCard[], boardSize: BoardSize) => void;
  importDeck: (name: string, cards: GameCard[], boardSize: BoardSize) => void;
  deleteDeck: (index: number) => void;
  selectDeckForGame: (index: number) => void;
  setCurrentEditingDeck: (index: number | null) => void;
  initializeGame: () => void;
  resetToMenu: () => void;
  selectCard: (player: 1 | 2, cardIndex: number) => void;
  placeCard: (slotIndex: number) => void;
  makeAIMove: () => void;
  switchTurn: () => void;
  calculateScores: () => void;
  flipCoin: (playerChoice: "heads" | "tails") => void;
  setDiceWinner: (winner: 1 | 2) => void;
  placeOCard: (slotIndex: number) => void;
  selectBlitzschlagTarget: (targetIndex: number) => void;
  selectCloneTarget: (targetIndex: number) => void;
  startMultiplayerGame: () => void;
  
  // Animation actions
  triggerBattleAnimation: (cardIndex: number, type: 'attacking' | 'defending' | 'captured' | 'blitzschlag' | 'shield-break' | 'clash' | 'glow' | 'placed', duration?: number, damageNumbers?: { value: number; type: 'damage' | 'heal' }[]) => void;
  clearBattleAnimation: (cardIndex: number) => void;
  clearAllAnimations: () => void;

  // Enhanced placement guide actions
  setShowPlacementGuide: (show: boolean) => void;
  setShowStrategicHints: (show: boolean) => void;
  updateValidPlacementSlots: () => void;
  calculatePlacementStrategies: () => void;
  setHighlightedSlot: (slotIndex: number | null) => void;
  
  // Avatar System actions
  showAvatarCustomizationDialog: (player: 1 | 2) => void;
  hideAvatarCustomization: () => void;
  setPlayerProfile: (player: 1 | 2, name: string, avatar: Avatar) => void;
}

// Implement a simple AI move selection (can be improved)
const getAIMove = (aiHand: GameCard[], board: (BoardSlot | null)[], playerHand: GameCard[]) => {
  const availableSlots: number[] = [];
  board.forEach((slot, index) => {
    if (!slot) {
      availableSlots.push(index);
    }
  });

  let bestCardIndex = 0;
  let bestBoardIndex = -1;

  // Simple AI: Place the first available card in the first available slot
  if (availableSlots.length > 0 && aiHand.length > 0) {
    bestBoardIndex = availableSlots[0];
    bestCardIndex = 0;
  }

  return { cardIndex: bestCardIndex, boardIndex: bestBoardIndex };
};

export const useCardGame = create<CardGameState>()(
  subscribeWithSelector((set, get) => ({
    gamePhase: "menu",
    currentPlayer: 1,
    board: Array(16).fill(null),
    elementFields: [],
    player1Hand: [],
    player2Hand: [],
    player1Deck: [],
    player2Deck: [],
    player1Cards: createPlayerDeck(1),
    selectedCard: null,
    winner: null,
    
    // Deck Management System initial state
    savedDecks: [
      { name: "Hauptspiel-Deck", cards: createExtendedDeck(1).slice(0, 15), boardSize: "4x4" as BoardSize, customization: {} },
      { name: "Alternatives Deck", cards: createExtendedDeck(2).slice(0, 15), boardSize: "4x4" as BoardSize, customization: {} }
    ],
    currentEditingDeck: null,
    selectedDeckForGame: 0, // Default to first 4x4 deck
    player1Score: 0,
    player2Score: 0,
    oCardOwner: "neutral",
    gameMode: null,
    aiDifficulty: "medium",
    boardSize: "4x4",
    coinFlipWinner: null,
    coinFlipResult: null,
    blitzschlagCardIndex: null,
    blitzschlagTargets: [],
    cloneCardIndex: null,
    cloneTargets: [],
    
    // Battle animation states
    battleAnimations: {},

    // Enhanced visual placement guide
    showPlacementGuide: true,
    validPlacementSlots: [],
    highlightedSlot: null,
    placementStrategies: {},
    showStrategicHints: true,
    
    isMultiplayer: false,
    isOnlinePlayer: false,
    effectMessages: [],
    turnCount: 1,
    
    // Player Profile System initial values
    player1Name: "Spieler 1",
    player2Name: "Spieler 2", 
    player1Avatar: AVAILABLE_AVATARS[0], // Default to warrior
    player2Avatar: AVAILABLE_AVATARS[4], // Default to dragon
    showAvatarCustomization: false,
    customizingPlayer: null,

    setGameMode: (mode: GameMode) => {
      set({ gameMode: mode });
    },

    setAIDifficulty: (difficulty: AIDifficulty) => {
      set({ aiDifficulty: difficulty });
    },

    setBoardSize: (size: BoardSize) => {
      // Only 4x4 is supported now
      const boardLength = 16;
      set({ 
        boardSize: size,
        board: Array(boardLength).fill(null)
      });
    },

    setGamePhase: (phase: GamePhase) => {
      set({ gamePhase: phase });
    },

    setPlayer1Cards: (cards: GameCard[]) => {
      set({ player1Cards: cards });
    },

    startGame: (mode: GameMode, difficulty?: AIDifficulty) => {
      const state = get();
      
      // Always use 4x4 board size
      const gameboardSize: BoardSize = "4x4";
      
      // Find appropriate deck for the game mode
      let selectedDeck = state.savedDecks[state.selectedDeckForGame];
      
      // If no selected deck or wrong board size, find matching deck
      if (!selectedDeck || selectedDeck.boardSize !== gameboardSize) {
        selectedDeck = state.savedDecks.find(deck => deck.boardSize === gameboardSize) || state.savedDecks[0];
      }
      
      const deckCards = selectedDeck ? selectedDeck.cards : createExtendedDeck(1).slice(0, 15);
      
      set({
        gamePhase: "coin-flip",
        gameMode: mode,
        aiDifficulty: difficulty || "medium",
        boardSize: gameboardSize,
        player1Cards: deckCards
      });
      
      // Initialize the game with new board size
      get().initializeGame();
    },
    
    initializeGame: () => {
      const { player1Cards, boardSize } = get();
      
      // Initialize theme to dawn
      const { updateThemeBasedOnProgress } = useTheme.getState();
      updateThemeBasedOnProgress(1, "ready");
      // Only 4x4 is supported - always use 15 cards
      const deckSize = 15;
      
      // For 4x4, use player's custom deck if they have 15 cards, otherwise create extended deck
      const player1Deck = player1Cards.length >= 15 ? player1Cards.slice(0, 15) : createExtendedDeck(1).slice(0, 15);
      const player2Deck = createExtendedDeck(2).slice(0, 15);

      // Shuffle decks
      const shuffledDeck1 = [...player1Deck].sort(() => Math.random() - 0.5);
      const shuffledDeck2 = [...player2Deck].sort(() => Math.random() - 0.5);

      // Deal 5 cards to each player
      const player1Hand = shuffledDeck1.slice(0, 5);
      const player2Hand = shuffledDeck2.slice(0, 5);

      // Initialize board for 4x4 - no center position
      const boardLength = 16;
      const centerIndex = -1; // No center in 4x4 grid (even dimensions)
      const newBoard = Array(boardLength).fill(null);
      
      // Don't place O-Card yet - it will be placed after coin flip by the winner

      // Don't generate element fields yet - they will be generated after O-Card placement
      let elementFields: ElementField[] = [];
      
      if (false) { // Disable element field generation until after O-Card is placed
        const elements: Element[] = ["fire", "lightning", "water", "earth"];
        const availablePositions = Array.from({ length: boardLength }, (_, i) => i)
          .filter(i => centerIndex === -1 || i !== centerIndex); // Exclude center position if it exists
        
        const numElements = 4; // 4x4 mode always uses 4 elements
        
        for (let i = 0; i < numElements; i++) {
          const randomElementIndex = Math.floor(Math.random() * elements.length);
          const randomPositionIndex = Math.floor(Math.random() * availablePositions.length);
          
          elementFields.push({
            element: elements[randomElementIndex],
            position: availablePositions[randomPositionIndex]
          });
          
          // Remove used position
          availablePositions.splice(randomPositionIndex, 1);
        }
      }

      // All game modes start with coin flip to determine who places the O-Card
      const initialGamePhase: GamePhase = "coin-flip";
      const initialScore = 0; // Start with 0, O-Card will be placed after coin flip

      set({
        gamePhase: initialGamePhase,
        currentPlayer: 1,
        board: newBoard,
        elementFields,
        player1Hand,
        player2Hand,
        player1Deck: shuffledDeck1,
        player2Deck: shuffledDeck2,
        selectedCard: null,
        winner: null,
        player1Score: 0,
        player2Score: 0,
        oCardOwner: "neutral",
        coinFlipWinner: null,
        coinFlipResult: null
      });
    },

    selectCard: (player: 1 | 2, cardIndex: number) => {
      const { currentPlayer, gamePhase } = get();

      if (gamePhase !== "playing" || currentPlayer !== player) return;

      set({
        selectedCard: { player, cardIndex }
      });

      // Update valid placement slots when a card is selected
      get().updateValidPlacementSlots();
    },

    placeCard: (slotIndex: number) => {
      const { 
        selectedCard, 
        board, 
        player1Hand, 
        player2Hand, 
        currentPlayer,
        oCardOwner,
        boardSize,
        elementFields
      } = get();

      if (!selectedCard || board[slotIndex]) return;

      const hand = selectedCard.player === 1 ? player1Hand : player2Hand;
      const cardToPlace = hand[selectedCard.cardIndex];
      const playerOwner = selectedCard.player === 1 ? "player1" : "player2";

      // Place card on board (always store original values)
      const newBoard = [...board];
      const { turnCount } = get();
      
      // Shield cards no longer get +1 bonus, they just block the first attack completely
      let modifiedCard = { ...cardToPlace };
      
      newBoard[slotIndex] = {
        card: modifiedCard,
        originalCard: cardToPlace, // Store original values without shield bonus
        owner: playerOwner,
        placedOnTurn: turnCount, // Track when the card was placed (current turn number)
        shieldBroken: false // Shield starts intact
      };
      
      // Check if placed card has blitzschlag effect
      const placedCard = newBoard[slotIndex];
      if (placedCard && placedCard.originalCard.effect === "blitzschlag") {
        // Find available targets for blitzschlag
        const enemyTargets = newBoard
          .map((slot, index) => ({ slot, index }))
          .filter(({ slot }) => 
            slot && 
            slot.owner !== playerOwner && 
            slot.owner !== "neutral" &&
            slot.originalCard.id !== "O"
          )
          .map(({ index }) => index);
        
        if (enemyTargets.length > 0) {
          // Check if it's AI's turn and auto-select target
          const { gameMode, currentPlayer } = get();
          if (gameMode === "ai" && currentPlayer === 2) {
            // AI automatically selects the strongest enemy target
            const bestTarget = enemyTargets.reduce((bestIndex, targetIndex) => {
              const currentSlot = newBoard[bestIndex];
              const candidateSlot = newBoard[targetIndex];
              
              if (!currentSlot || !candidateSlot) return bestIndex;
              
              // Calculate total strength of current best vs candidate
              const currentTotal = currentSlot.card.top + currentSlot.card.right + currentSlot.card.bottom + currentSlot.card.left;
              const candidateTotal = candidateSlot.card.top + candidateSlot.card.right + candidateSlot.card.bottom + candidateSlot.card.left;
              
              return candidateTotal > currentTotal ? targetIndex : bestIndex;
            }, enemyTargets[0]);
            
            // Set the targeting state temporarily for the selectBlitzschlagTarget function
            set({
              board: newBoard,
              gamePhase: "blitzschlag-target",
              blitzschlagCardIndex: slotIndex,
              blitzschlagTargets: enemyTargets
            });
            
            // Auto-select target after short delay
            setTimeout(() => {
              get().selectBlitzschlagTarget(bestTarget);
            }, 1000);
            
            return;
          } else {
            // Enter targeting mode for human player
            set({
              board: newBoard,
              gamePhase: "blitzschlag-target",
              blitzschlagCardIndex: slotIndex,
              blitzschlagTargets: enemyTargets
            });
            return; // Don't continue with normal battle resolution
          }
        }
      }
      
      // Check if placed card has clone effect
      if (placedCard && placedCard.originalCard.effect === "clone") {
        // Find adjacent cards to clone from
        const gridSize = Math.sqrt(newBoard.length);
        const getAdjacentPositions = (index: number) => {
          const positions = [];
          const row = Math.floor(index / gridSize);
          const col = index % gridSize;
          
          if (row > 0) positions.push(index - gridSize); // above
          if (row < gridSize - 1) positions.push(index + gridSize); // below
          if (col > 0) positions.push(index - 1); // left
          if (col < gridSize - 1) positions.push(index + 1); // right
          
          return positions;
        };
        
        const adjacentTargets = getAdjacentPositions(slotIndex)
          .filter(index => newBoard[index] !== null)
          .filter(index => newBoard[index]!.originalCard.id !== "O");
        
        if (adjacentTargets.length > 0) {
          // Check if it's AI's turn and auto-select target
          const { gameMode, currentPlayer } = get();
          if (gameMode === "ai" && currentPlayer === 2) {
            // AI automatically selects the strongest adjacent card to clone
            const bestTarget = adjacentTargets.reduce((bestIndex, targetIndex) => {
              const currentSlot = newBoard[bestIndex];
              const candidateSlot = newBoard[targetIndex];
              
              if (!currentSlot || !candidateSlot) return bestIndex;
              
              // Calculate total strength of current best vs candidate
              const currentTotal = currentSlot.card.top + currentSlot.card.right + currentSlot.card.bottom + currentSlot.card.left;
              const candidateTotal = candidateSlot.card.top + candidateSlot.card.right + candidateSlot.card.bottom + candidateSlot.card.left;
              
              return candidateTotal > currentTotal ? targetIndex : bestIndex;
            }, adjacentTargets[0]);
            
            // Set the targeting state temporarily
            set({
              board: newBoard,
              gamePhase: "clone-target",
              cloneCardIndex: slotIndex,
              cloneTargets: adjacentTargets
            });
            
            // Auto-select target after short delay
            setTimeout(() => {
              get().selectCloneTarget(bestTarget);
            }, 1000);
            
            return;
          } else {
            // Enter clone targeting mode for human player
            set({
              board: newBoard,
              gamePhase: "clone-target",
              cloneCardIndex: slotIndex,
              cloneTargets: adjacentTargets
            });
            return; // Don't continue with normal battle resolution
          }
        }
      }
      
      // Resolve battles normally with animations
      const { triggerBattleAnimation } = get();
      
      // Store original shield states before battle resolution
      const shieldStatesBefore = newBoard.map(slot => 
        slot && slot.originalCard.effect === "schild" ? !slot.shieldBroken : null
      );
      
      // Trigger card placement animation
      triggerBattleAnimation(slotIndex, 'placed', 800);
      
      const { updatedBoard, capturedCards, effectMessages } = resolveBattles(newBoard, slotIndex, playerOwner, oCardOwner, elementFields, turnCount);

      // Check for shield breaks during battle and trigger shield-break animations
      updatedBoard.forEach((slot, index) => {
        if (slot && 
            slot.originalCard.effect === "schild" && 
            shieldStatesBefore[index] === true && 
            slot.shieldBroken) {
          // Shield was intact before battle but now broken - trigger shield break animation
          setTimeout(() => {
            triggerBattleAnimation(index, 'shield-break', 1000);
          }, 300); // Slight delay after placement animation
        }
      });

      // Trigger battle animations for captured cards
      capturedCards.forEach((cardIndex, i) => {
        setTimeout(() => {
          triggerBattleAnimation(cardIndex, 'captured', 1200);
        }, 500 + i * 100); // Stagger animations after potential shield breaks
      });

      // Remove card from hand
      const newHand = hand.filter((_, index) => index !== selectedCard.cardIndex);

      // Update O-Card owner if it was captured
      let newOCardOwner = oCardOwner;
      
      // Find the O-Card position on the board (it can be anywhere in 4x4 mode)
      const oCardIndex = updatedBoard.findIndex(slot => slot && slot.originalCard.id === "O");
      if (oCardIndex !== -1 && capturedCards.includes(oCardIndex)) {
        newOCardOwner = playerOwner;
      }

      // Apply O-Card effect and element bonuses to all cards on the board
      const finalBoard = updatedBoard.map((slot, index) => {
        if (!slot) return slot;

        let oCardBonus = 0;
        let elementBonus = 0;

        // Apply +1 effect to cards owned by the O-Card controller (except O-Card itself)
        if (slot.owner === newOCardOwner && newOCardOwner !== "neutral" && slot.originalCard.id !== "O") {
          oCardBonus = 1;
        }

        // Apply element bonus if card element matches field element
        const elementField = elementFields.find(field => field.position === index);
        if (elementField && slot.originalCard.element && elementField.element === slot.originalCard.element) {
          elementBonus = 1;
        }

        const totalBonus = oCardBonus + elementBonus;

        // Recalculate card values based on original card plus current bonuses
        // This ensures proper removal of old O-card bonuses when ownership changes
        let baseCard = slot.originalCard;
        
        // For cards with damage effects (like Blitzschlag), calculate damage amount
        let damageAmount = 0;
        if (slot.card.top < slot.originalCard.top) {
          damageAmount = slot.originalCard.top - slot.card.top;
        }
        
        return {
          ...slot,
          card: {
            ...baseCard,
            top: Math.min(9, Math.max(0, baseCard.top + totalBonus - damageAmount)),
            right: Math.min(9, Math.max(0, baseCard.right + totalBonus - damageAmount)),
            bottom: Math.min(9, Math.max(0, baseCard.bottom + totalBonus - damageAmount)),
            left: Math.min(9, Math.max(0, baseCard.left + totalBonus - damageAmount))
          }
        };
      });

      // Play sound effects
      const { playHit, playSuccess } = useAudio.getState();
      if (capturedCards.length > 0) {
        playHit();
      }

      // Update state
      if (selectedCard.player === 1) {
        set({
          board: finalBoard,
          player1Hand: newHand,
          selectedCard: null,
          oCardOwner: newOCardOwner,
          effectMessages: effectMessages
        });
      } else {
        set({
          board: finalBoard,
          player2Hand: newHand,
          selectedCard: null,
          oCardOwner: newOCardOwner,
          effectMessages: effectMessages
        });
      }

      // Calculate scores and check win condition
      get().calculateScores();

      const winResult = checkWinCondition(updatedBoard);
      if (winResult) {
        const { playSuccess } = useAudio.getState();
        playSuccess();
        set({
          gamePhase: "ended",
          winner: winResult
        });
      } else {
        get().switchTurn();
      }
    },

    makeAIMove: () => {
      const { 
        player2Hand, 
        board, 
        player1Hand, 
        gameMode, 
        aiDifficulty,
        gamePhase,
        currentPlayer 
      } = get();

      // Only make AI move if it's AI mode, playing phase, and AI's turn
      if (gameMode !== "ai" || gamePhase !== "playing" || currentPlayer !== 2 || player2Hand.length === 0) {
        return;
      }

      // Import AI logic
      import("../aiLogic").then(({ getAIMove }) => {
        const aiMove = getAIMove(player2Hand, board, player1Hand, aiDifficulty);
        
        // Select the AI card first
        get().selectCard(2, aiMove.cardIndex);
        
        // Then place it after a short delay for better UX
        setTimeout(() => {
          get().placeCard(aiMove.boardIndex);
        }, 800); // 800ms delay so user can see what's happening
      });
    },

    switchTurn: () => {
      const { currentPlayer, gameMode, player1Deck, player2Deck, player1Hand, player2Hand, boardSize, turnCount, board } = get();
      const newPlayer = currentPlayer === 1 ? 2 : 1;
      
      // Apply turn-based effects like rotation at the END of the turn (before switching)
      const gridSize = Math.sqrt(board.length);
      
      const turnBasedResult = applyTurnBasedEffects(board, turnCount + 1);
      let updatedBoard = turnBasedResult.modifiedBoard;
      const turnEffectMessages = turnBasedResult.effectMessages;
      
      // Apply continuous effects like verstärkung
      updatedBoard = applyContinuousEffects(updatedBoard, gridSize);
      
      // Check win condition after applying turn-based effects
      const winResult = checkWinCondition(updatedBoard);
      if (winResult) {
        const { playSuccess } = useAudio.getState();
        playSuccess();
        
        // Update theme for game end
        const { updateThemeBasedOnProgress } = useTheme.getState();
        const gameStatus = winResult === "player1" ? "won" : winResult === "player2" ? "lost" : undefined;
        updateThemeBasedOnProgress(turnCount + 1, "ended", gameStatus);
        
        set({
          gamePhase: "ended",
          winner: winResult,
          board: updatedBoard
        });
        return; // Don't continue with turn switching if game ended
      }
      
      // Draw a card from deck to maintain 5 cards in hand (for all board sizes except 3x3)
      let newPlayer1Hand = [...player1Hand];
      let newPlayer2Hand = [...player2Hand];
      let newPlayer1Deck = [...player1Deck];
      let newPlayer2Deck = [...player2Deck];
      
      // Always maintain 5 cards in hand for 4x4 mode
      const maxHandSize = 5;
      const startingDeckIndex = 5; // First 5 cards are initial hand
      
      if (newPlayer === 1 && player1Deck.length > startingDeckIndex && player1Hand.length < maxHandSize) {
        // Player 1's turn, draw card for player 1
        newPlayer1Hand.push(player1Deck[startingDeckIndex]);
        newPlayer1Deck = player1Deck.slice(0, startingDeckIndex).concat(player1Deck.slice(startingDeckIndex + 1));
      } else if (newPlayer === 2 && player2Deck.length > startingDeckIndex && player2Hand.length < maxHandSize) {
        // Player 2's turn, draw card for player 2
        newPlayer2Hand.push(player2Deck[startingDeckIndex]);
        newPlayer2Deck = player2Deck.slice(0, startingDeckIndex).concat(player2Deck.slice(startingDeckIndex + 1));
      }
      
      console.log(`Turn ${turnCount + 1}: Turn-based effects applied`, { turnEffectMessages });
      
      set({
        currentPlayer: newPlayer,
        board: updatedBoard,
        player1Hand: newPlayer1Hand,
        player2Hand: newPlayer2Hand,
        player1Deck: newPlayer1Deck,
        player2Deck: newPlayer2Deck,
        turnCount: turnCount + 1,
        effectMessages: turnEffectMessages // Show turn-based effect messages
      });
      
      // Update theme based on new turn count
      const { updateThemeBasedOnProgress } = useTheme.getState();
      updateThemeBasedOnProgress(turnCount + 1, get().gamePhase);

      // If it's AI mode and now AI's turn, make AI move after short delay
      if (gameMode === "ai" && newPlayer === 2) {
        setTimeout(() => {
          get().makeAIMove();
        }, 1000); // 1 second delay before AI moves
      }
    },

    calculateScores: () => {
      const { board } = get();
      let player1Score = 0;
      let player2Score = 0;

      board.forEach((slot) => {
        if (slot) {
          if (slot.owner === "player1") {
            player1Score++;
          } else if (slot.owner === "player2") {
            player2Score++;
          }
          // Neutral cards don't count towards either player
        }
      });

      set({
        player1Score,
        player2Score
      });
    },

    startMultiplayerGame: () => {
      set({
        gamePhase: "coin-flip",
        gameMode: "multiplayer",
        isMultiplayer: true,
        turnCount: 1
      });
    },

    resetToMenu: () => {
      set({
        gamePhase: "menu",
        currentPlayer: 1,
        board: Array(16).fill(null),
        elementFields: [],
        player1Hand: [],
        player2Hand: [],
        player1Deck: [],
        player2Deck: [],
        selectedCard: null,
        winner: null,
        player1Score: 0,
        player2Score: 0,
        oCardOwner: "neutral",
        gameMode: null,
        aiDifficulty: "medium",
        coinFlipWinner: null,
        coinFlipResult: null,
        effectMessages: [],
        turnCount: 1
      });
    },

    flipCoin: (playerChoice: "heads" | "tails") => {
      // Simulate coin flip
      const coinResult: "heads" | "tails" = Math.random() < 0.5 ? "heads" : "tails";
      const winner: 1 | 2 = coinResult === playerChoice ? 1 : 2;
      
      set({
        coinFlipResult: coinResult,
        coinFlipWinner: winner,
        gamePhase: "place-o-card",
        currentPlayer: winner
      });
    },

    setDiceWinner: (winner: 1 | 2) => {
      set({
        coinFlipWinner: winner,
        gamePhase: "place-o-card", 
        currentPlayer: winner
      });
    },

    placeOCard: (slotIndex: number) => {
      const { board, coinFlipWinner, boardSize } = get();
      
      if (board[slotIndex]) return; // Slot already occupied
      
      const oCard = createOCard();
      const newBoard = [...board];
      newBoard[slotIndex] = {
        card: oCard,
        originalCard: oCard,
        owner: "neutral" as Player
      };
      
      // Generate element fields after O-Card is placed (for 4x4 mode)
      const elements: Element[] = ["fire", "lightning", "water", "earth"];
      const boardLength = newBoard.length;
      const availablePositions = Array.from({ length: boardLength }, (_, i) => i)
        .filter(i => i !== slotIndex); // Exclude O-Card position
      
      // Always use 4 elements for 4x4 mode
      const numElements = 4;
      
      const elementFields: ElementField[] = [];
      for (let i = 0; i < numElements; i++) {
        const randomElementIndex = Math.floor(Math.random() * elements.length);
        const randomPositionIndex = Math.floor(Math.random() * availablePositions.length);
        
        elementFields.push({
          element: elements[randomElementIndex],
          position: availablePositions[randomPositionIndex]
        });
        
        // Remove used position
        availablePositions.splice(randomPositionIndex, 1);
      }
      
      set({
        board: newBoard,
        elementFields, // Set the generated element fields
        gamePhase: "playing",
        currentPlayer: 1, // Reset to player 1 to start the actual game
        player1Score: 1, // Player gets 1 point for the O-Card
        player2Score: 0
      });
    },

    selectBlitzschlagTarget: (targetIndex: number) => {
      const { board, blitzschlagCardIndex, blitzschlagTargets, currentPlayer } = get();
      
      if (blitzschlagCardIndex === null || !blitzschlagTargets.includes(targetIndex)) {
        console.log(`🗲 Blitzschlag target selection failed - cardIndex: ${blitzschlagCardIndex}, targetIndex: ${targetIndex}, validTargets: ${blitzschlagTargets}`);
        return;
      }
      
      // Apply damage to selected target
      const newBoard = [...board];
      const targetSlot = newBoard[targetIndex];
      
      if (targetSlot) {
        console.log(`🗲 Blitzschlag targeting ${targetSlot.originalCard.name || targetSlot.originalCard.id} at position ${targetIndex}`);
        console.log(`   Target current values BEFORE damage: ${targetSlot.card.top},${targetSlot.card.right},${targetSlot.card.bottom},${targetSlot.card.left}`);
        // Check if target has shield effect and handle shield breaking
        if (targetSlot.originalCard.effect === "schild" && !targetSlot.shieldBroken) {
          // Shield absorbs 1 damage and breaks, remaining 1 damage goes through
          newBoard[targetIndex] = {
            ...targetSlot,
            shieldBroken: true,
            card: {
              ...targetSlot.card,
              // Remove shield bonus (-1) + remaining Blitzschlag damage (-1) = original values - 1
              top: Math.max(0, targetSlot.originalCard.top - 1),
              right: Math.max(0, targetSlot.originalCard.right - 1),
              bottom: Math.max(0, targetSlot.originalCard.bottom - 1),
              left: Math.max(0, targetSlot.originalCard.left - 1)
            }
          };
          console.log(`🛡️ Schild von ${targetSlot.originalCard.name || targetSlot.originalCard.id} absorbiert 1 Schaden und zerbricht! Restschaden: -1`);
        } else {
          // Normal Blitzschlag damage for non-shield cards or already broken shields
          // Apply damage to current values, not original values
          newBoard[targetIndex] = {
            ...targetSlot,
            card: {
              ...targetSlot.card,
              top: Math.max(0, targetSlot.card.top - 2),
              right: Math.max(0, targetSlot.card.right - 2),
              bottom: Math.max(0, targetSlot.card.bottom - 2),
              left: Math.max(0, targetSlot.card.left - 2)
            }
          };
          const newValues = {
            top: Math.max(0, targetSlot.card.top - 2),
            right: Math.max(0, targetSlot.card.right - 2),
            bottom: Math.max(0, targetSlot.card.bottom - 2),
            left: Math.max(0, targetSlot.card.left - 2)
          };
          console.log(`🗲 Blitzschlag: ${targetSlot.originalCard.name || targetSlot.originalCard.id} verliert 2 von allen Werten`);
          console.log(`   Vorher: ${targetSlot.card.top},${targetSlot.card.right},${targetSlot.card.bottom},${targetSlot.card.left}`);
          console.log(`   Nachher: ${newValues.top},${newValues.right},${newValues.bottom},${newValues.left}`);
        }
        
        console.log(`🗲 Blitzschlag trifft ${targetSlot.originalCard.name || targetSlot.originalCard.id}!`);
        console.log(`   Ziel final values AFTER damage: ${newBoard[targetIndex]?.card.top},${newBoard[targetIndex]?.card.right},${newBoard[targetIndex]?.card.bottom},${newBoard[targetIndex]?.card.left}`);
      }
      
      // Trigger Blitzschlag animation
      const { triggerBattleAnimation } = get();
      const damageAmount = targetSlot?.originalCard.effect === "schild" && !targetSlot?.shieldBroken ? 1 : 2;
      
      if (targetSlot?.originalCard.effect === "schild" && !targetSlot?.shieldBroken) {
        // Shield break animation first
        triggerBattleAnimation(targetIndex, 'shield-break', 1000);
        setTimeout(() => {
          triggerBattleAnimation(targetIndex, 'blitzschlag', 1200, [{ value: damageAmount, type: 'damage' }]);
        }, 500);
      } else {
        // Direct Blitzschlag animation
        triggerBattleAnimation(targetIndex, 'blitzschlag', 1500, [{ value: damageAmount, type: 'damage' }]);
      }
      
      // Continue with normal battles after Blitzschlag effect
      const { updatedBoard, capturedCards, effectMessages } = resolveBattles(
        newBoard, 
        blitzschlagCardIndex, 
        currentPlayer === 1 ? "player1" : "player2", 
        get().oCardOwner, 
        get().elementFields, 
        get().turnCount,
        true // Skip pre-battle effects since we already handled Blitzschlag
      );
      
      // Continue with existing game logic from placeCard
      const { oCardOwner, elementFields } = get();
      
      // Update O-Card owner if it was captured
      let newOCardOwner = oCardOwner;
      const oCardIndex = updatedBoard.findIndex(slot => slot && slot.originalCard.id === "O");
      if (oCardIndex !== -1 && capturedCards.includes(oCardIndex)) {
        newOCardOwner = currentPlayer === 1 ? "player1" : "player2";
      }

      // Apply O-Card effect and element bonuses to all cards
      const finalBoard = updatedBoard.map((slot, index) => {
        if (!slot) return slot;

        let oCardBonus = 0;
        let elementBonus = 0;

        if (slot.owner === newOCardOwner && newOCardOwner !== "neutral" && slot.originalCard.id !== "O") {
          oCardBonus = 1;
        }

        const elementField = elementFields.find(field => field.position === index);
        if (elementField && slot.originalCard.element && elementField.element === slot.originalCard.element) {
          elementBonus = 1;
        }

        const totalBonus = oCardBonus + elementBonus;

        // Recalculate card values based on original card plus current bonuses
        // This ensures proper removal of old O-card bonuses when ownership changes
        let baseCard = slot.originalCard;
        
        // For cards with damage effects (like Blitzschlag), calculate damage amount
        let damageAmount = 0;
        if (slot.card.top < slot.originalCard.top) {
          damageAmount = slot.originalCard.top - slot.card.top;
        }
        
        return {
          ...slot,
          card: {
            ...baseCard,
            top: Math.min(9, Math.max(0, baseCard.top + totalBonus - damageAmount)),
            right: Math.min(9, Math.max(0, baseCard.right + totalBonus - damageAmount)),
            bottom: Math.min(9, Math.max(0, baseCard.bottom + totalBonus - damageAmount)),
            left: Math.min(9, Math.max(0, baseCard.left + totalBonus - damageAmount))
          }
        };
      });

      // Play sound effects
      const { playHit } = useAudio.getState();
      if (capturedCards.length > 0) {
        playHit();
      }

      set({
        board: finalBoard,
        oCardOwner: newOCardOwner,
        effectMessages: [`🗲 Blitzschlag trifft ${targetSlot?.originalCard.name || targetSlot?.originalCard.id}!`, ...effectMessages],
        gamePhase: "playing",
        blitzschlagCardIndex: null,
        blitzschlagTargets: [],
        cloneCardIndex: null,
        cloneTargets: []
      });

      // Calculate scores and check win condition
      get().calculateScores();
      const winResult = checkWinCondition(finalBoard);
      if (winResult) {
        const { playSuccess } = useAudio.getState();
        playSuccess();
        
        // Update theme for game end
        const { updateThemeBasedOnProgress } = useTheme.getState();
        const gameStatus = winResult === "player1" ? "won" : winResult === "player2" ? "lost" : undefined;
        updateThemeBasedOnProgress(get().turnCount, "ended", gameStatus);
        
        set({
          gamePhase: "ended",
          winner: winResult
        });
      } else {
        get().switchTurn();
      }
    },

    selectCloneTarget: (targetIndex: number) => {
      const { board, cloneCardIndex, cloneTargets, currentPlayer, oCardOwner, elementFields, turnCount } = get();
      
      if (cloneCardIndex === null || !cloneTargets.includes(targetIndex)) {
        return;
      }
      
      // Clone values from selected target
      const newBoard = [...board];
      const cloneSlot = newBoard[cloneCardIndex];
      const targetSlot = newBoard[targetIndex];
      
      if (cloneSlot && targetSlot) {
        newBoard[cloneCardIndex] = {
          ...cloneSlot,
          card: {
            ...cloneSlot.card,
            top: targetSlot.originalCard.top,
            right: targetSlot.originalCard.right,
            bottom: targetSlot.originalCard.bottom,
            left: targetSlot.originalCard.left
          }
        };
        
        console.log(`👥 Clone kopiert Werte von ${targetSlot.originalCard.name || targetSlot.originalCard.id}!`);
      }
      
      // Continue with normal battle resolution
      const { updatedBoard, capturedCards, effectMessages } = resolveBattles(
        newBoard, 
        cloneCardIndex, 
        currentPlayer === 1 ? "player1" : "player2", 
        oCardOwner, 
        elementFields, 
        turnCount
      );
      
      // Apply final effects and cleanup
      set({
        board: updatedBoard,
        gamePhase: "playing",
        cloneCardIndex: null,
        cloneTargets: [],
        effectMessages: [`👥 Clone kopiert Werte von ${targetSlot?.originalCard.name || 'Ziel'}!`, ...effectMessages]
      });
      
      // Calculate scores and check win condition
      get().calculateScores();
      const winResult = checkWinCondition(updatedBoard);
      if (winResult) {
        const { playSuccess } = useAudio.getState();
        playSuccess();
        set({
          gamePhase: "ended",
          winner: winResult
        });
      } else {
        get().switchTurn();
      }
    },

    // Animation actions
    triggerBattleAnimation: (cardIndex: number, type: 'attacking' | 'defending' | 'captured' | 'blitzschlag' | 'shield-break' | 'clash' | 'glow' | 'placed', duration: number = 1000, damageNumbers?: { value: number; type: 'damage' | 'heal' }[]) => {
      const { battleAnimations } = get();
      set({
        battleAnimations: {
          ...battleAnimations,
          [cardIndex]: {
            type,
            startTime: Date.now(),
            duration,
            damageNumbers
          }
        }
      });

      // Auto-clear animation after duration
      setTimeout(() => {
        get().clearBattleAnimation(cardIndex);
      }, duration);
    },

    clearBattleAnimation: (cardIndex: number) => {
      const { battleAnimations } = get();
      const newAnimations = { ...battleAnimations };
      delete newAnimations[cardIndex];
      set({ battleAnimations: newAnimations });
    },

    clearAllAnimations: () => {
      set({ battleAnimations: {} });
    },

    // Avatar System actions
    showAvatarCustomizationDialog: (player: 1 | 2) => {
      set({ 
        showAvatarCustomization: true,
        customizingPlayer: player
      });
    },

    hideAvatarCustomization: () => {
      set({ 
        showAvatarCustomization: false,
        customizingPlayer: null
      });
    },

    setPlayerProfile: (player: 1 | 2, name: string, avatar: Avatar) => {
      if (player === 1) {
        set({ 
          player1Name: name,
          player1Avatar: avatar,
          showAvatarCustomization: false,
          customizingPlayer: null
        });
      } else {
        set({ 
          player2Name: name,
          player2Avatar: avatar,
          showAvatarCustomization: false,
          customizingPlayer: null
        });
      }
    },

    // Deck Management actions
    saveDeck: (name: string, cards: GameCard[], boardSize: BoardSize) => {
      const { savedDecks } = get();
      const newDeck = { name, cards: [...cards], boardSize };
      
      // Check if we already have 5 decks (max limit)
      if (savedDecks.length >= 5) {
        console.log("Maximum deck limit (5) reached");
        return;
      }
      
      set({ savedDecks: [...savedDecks, newDeck] });
    },

    importDeck: (name: string, cards: GameCard[], boardSize: BoardSize) => {
      const { savedDecks } = get();
      const newDeck = { name: `${name} (Importiert)`, cards: [...cards], boardSize };
      
      // Check if we already have 5 decks (max limit)
      if (savedDecks.length >= 5) {
        console.log("Maximum deck limit (5) reached - cannot import deck");
        return;
      }
      
      set({ savedDecks: [...savedDecks, newDeck] });
    },

    deleteDeck: (index: number) => {
      const { savedDecks } = get();
      const newDecks = savedDecks.filter((_, i) => i !== index);
      set({ savedDecks: newDecks });
    },

    selectDeckForGame: (index: number) => {
      const { savedDecks } = get();
      if (index >= 0 && index < savedDecks.length) {
        const selectedDeck = savedDecks[index];
        set({ 
          selectedDeckForGame: index,
          player1Cards: [...selectedDeck.cards],
          boardSize: selectedDeck.boardSize
        });
      }
    },

    setCurrentEditingDeck: (index: number | null) => {
      set({ currentEditingDeck: index });
    },

    // Placement guide actions
    setShowPlacementGuide: (show: boolean) => {
      set({ showPlacementGuide: show });
    },

    updateValidPlacementSlots: () => {
      const { board, gamePhase, selectedCard } = get();
      
      // Only show placement guides when a card is selected and it's the playing phase
      if (!selectedCard || (gamePhase !== "playing" && gamePhase !== "place-o-card")) {
        set({ validPlacementSlots: [], placementStrategies: {} });
        return;
      }

      // Find all empty slots as valid placement positions
      const validSlots: number[] = [];
      board.forEach((slot, index) => {
        if (!slot) {
          validSlots.push(index);
        }
      });

      set({ validPlacementSlots: validSlots });
      
      // Calculate strategic recommendations for each valid slot
      get().calculatePlacementStrategies();
    },

    calculatePlacementStrategies: () => {
      const { board, selectedCard, validPlacementSlots, currentPlayer, player1Hand, player2Hand } = get();
      
      if (!selectedCard || validPlacementSlots.length === 0) {
        set({ placementStrategies: {} });
        return;
      }

      const strategies: { [slotIndex: number]: 'aggressive' | 'defensive' | 'neutral' | 'optimal' } = {};
      const gridSize = 4; // 4x4 board
      
      // Get the selected card
      const currentHand = selectedCard.player === 1 ? player1Hand : player2Hand;
      const placingCard = currentHand[selectedCard.cardIndex];
      
      if (!placingCard) {
        set({ placementStrategies: {} });
        return;
      }

      validPlacementSlots.forEach(slotIndex => {
        let strategy: 'aggressive' | 'defensive' | 'neutral' | 'optimal' = 'neutral';
        let score = 0;
        
        // Get adjacent positions for this slot
        const row = Math.floor(slotIndex / gridSize);
        const col = slotIndex % gridSize;
        const adjacentPositions: number[] = [];
        
        // Check all 4 directions
        const directions = [[-1, 0], [0, 1], [1, 0], [0, -1]]; // up, right, down, left
        directions.forEach(([dRow, dCol], dirIndex) => {
          const newRow = row + dRow;
          const newCol = col + dCol;
          if (newRow >= 0 && newRow < gridSize && newCol >= 0 && newCol < gridSize) {
            adjacentPositions.push(newRow * gridSize + newCol);
          }
        });

        // Analyze adjacent cards
        let enemyCardCount = 0;
        let friendlyCardCount = 0;
        let captureCount = 0;
        let defensiveValue = 0;
        
        adjacentPositions.forEach((adjPos, dirIndex) => {
          const adjSlot = board[adjPos];
          if (adjSlot) {
            const isEnemy = (selectedCard.player === 1 && adjSlot.owner === "player2") ||
                           (selectedCard.player === 2 && adjSlot.owner === "player1");
            const isFriendly = (selectedCard.player === 1 && adjSlot.owner === "player1") ||
                              (selectedCard.player === 2 && adjSlot.owner === "player2");
            
            if (isEnemy) {
              enemyCardCount++;
              // Check if we can capture this card
              const ourValue = dirIndex === 0 ? placingCard.top :
                              dirIndex === 1 ? placingCard.right :
                              dirIndex === 2 ? placingCard.bottom :
                              placingCard.left;
              const theirValue = dirIndex === 0 ? adjSlot.card.bottom :
                                dirIndex === 1 ? adjSlot.card.left :
                                dirIndex === 2 ? adjSlot.card.top :
                                adjSlot.card.right;
              
              if (ourValue > theirValue) {
                captureCount++;
                score += 10; // High score for captures
              } else if (ourValue === theirValue) {
                score += 2; // Small bonus for ties
              }
            }
            
            if (isFriendly) {
              friendlyCardCount++;
              defensiveValue += 3; // Bonus for protecting friendly cards
            }
          }
        });

        // Corner and edge analysis
        const isCorner = (row === 0 || row === gridSize - 1) && (col === 0 || col === gridSize - 1);
        const isEdge = row === 0 || row === gridSize - 1 || col === 0 || col === gridSize - 1;
        
        if (isCorner) {
          score += 2; // Corners are generally safer
          defensiveValue += 2;
        } else if (isEdge) {
          score += 1; // Edges are somewhat safer
          defensiveValue += 1;
        }

        // Determine strategy based on analysis
        if (captureCount >= 2) {
          strategy = 'optimal'; // Can capture multiple cards
          score += 20;
        } else if (captureCount >= 1) {
          strategy = 'aggressive'; // Can capture at least one card
          score += 10;
        } else if (friendlyCardCount >= 2 || defensiveValue >= 5) {
          strategy = 'defensive'; // Good for protecting existing cards
        } else if (enemyCardCount >= 2) {
          strategy = 'defensive'; // Surrounded by enemies, defensive positioning
        }

        strategies[slotIndex] = strategy;
      });

      set({ placementStrategies: strategies });
    },

    setShowStrategicHints: (show: boolean) => {
      set({ showStrategicHints: show });
    },

    setHighlightedSlot: (slotIndex: number | null) => {
      set({ highlightedSlot: slotIndex });
    }
  }))
);