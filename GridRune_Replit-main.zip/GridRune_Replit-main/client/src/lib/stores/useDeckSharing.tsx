import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { GameCard } from '../cardData';
import { BoardSize } from './useCardGame';

export interface SharedDeck {
  id: string;
  name: string;
  cards: GameCard[];
  boardSize: BoardSize;
  shareCode: string;
  createdBy: string;
  createdAt: Date;
  description?: string;
  tags?: string[];
  likes: number;
  downloads: number;
  isPublic: boolean;
  version: string;
}

export interface DeckShareData {
  name: string;
  cards: GameCard[];
  boardSize: BoardSize;
  description?: string;
  tags?: string[];
  createdBy: string;
  version: string;
}

interface DeckSharingState {
  sharedDecks: SharedDeck[];
  favoriteDecks: string[];
  importHistory: string[];
  
  // Actions
  generateShareCode: (deckData: DeckShareData) => string;
  shareDeck: (deckData: DeckShareData) => SharedDeck;
  importDeck: (shareCode: string) => SharedDeck | null;
  validateShareCode: (shareCode: string) => boolean;
  likeDeck: (shareCode: string) => void;
  addToFavorites: (shareCode: string) => void;
  removeFromFavorites: (shareCode: string) => void;
  getPopularDecks: () => SharedDeck[];
  getRecentDecks: () => SharedDeck[];
  searchDecks: (query: string) => SharedDeck[];
  exportDeckToClipboard: (deckData: DeckShareData) => Promise<boolean>;
  importDeckFromClipboard: () => Promise<SharedDeck | null>;
}

// Sample shared decks for demonstration
const SAMPLE_SHARED_DECKS: SharedDeck[] = [
  {
    id: 'deck-1',
    name: 'Legendärer Blitz-Angriff',
    cards: [], // Will be populated with actual cards
    boardSize: '3x3',
    shareCode: 'GR-BLITZ-2025-A1B2C3',
    createdBy: 'DragonMaster',
    createdAt: new Date('2025-01-01'),
    description: 'Aggressive Deck mit starken Angriffseffekten und Blitzschlag-Kombos',
    tags: ['Aggressive', 'Blitzschlag', 'Legendär'],
    likes: 142,
    downloads: 89,
    isPublic: true,
    version: '1.0'
  },
  {
    id: 'deck-2',
    name: 'Verteidiger-Elite',
    cards: [],
    boardSize: '3x3',
    shareCode: 'GR-DEFEND-2025-X9Y8Z7',
    createdBy: 'ShieldHero',
    createdAt: new Date('2025-01-02'),
    description: 'Defensives Deck mit starken Schilden und Heilungseffekten',
    tags: ['Defensiv', 'Schild', 'Kontrolle'],
    likes: 98,
    downloads: 67,
    isPublic: true,
    version: '1.0'
  },
  {
    id: 'deck-3',
    name: 'Elementar-Fusion',
    cards: [],
    boardSize: '4x4',
    shareCode: 'GR-ELEM-2025-F5G6H7',
    createdBy: 'ElementWizard',
    createdAt: new Date('2025-01-03'),
    description: 'Deck mit starken Elementar-Kombos und Verwandlungseffekten',
    tags: ['Elementar', 'Fusion', 'Episch'],
    likes: 76,
    downloads: 45,
    isPublic: true,
    version: '1.0'
  }
];

function generateRandomShareCode(): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segments = [];
  
  // Format: GR-XXXX-YYYY-ZZZZZZ
  segments.push('GR');
  segments.push(Array.from({length: 4}, () => characters.charAt(Math.floor(Math.random() * characters.length))).join(''));
  segments.push(new Date().getFullYear().toString());
  segments.push(Array.from({length: 6}, () => characters.charAt(Math.floor(Math.random() * characters.length))).join(''));
  
  return segments.join('-');
}

function encodeDeckData(deckData: DeckShareData): string {
  try {
    const compactData = {
      n: deckData.name,
      c: deckData.cards.map(card => card.id),
      b: deckData.boardSize,
      d: deckData.description || '',
      t: deckData.tags || [],
      by: deckData.createdBy,
      v: deckData.version
    };
    
    return btoa(JSON.stringify(compactData));
  } catch (error) {
    console.error('Failed to encode deck data:', error);
    return '';
  }
}

function decodeDeckData(encodedData: string, allCards: GameCard[]): DeckShareData | null {
  try {
    const compactData = JSON.parse(atob(encodedData));
    
    const cards = compactData.c
      .map((cardId: string) => allCards.find(card => card.id === cardId))
      .filter(Boolean);
    
    if (cards.length === 0) {
      return null;
    }
    
    return {
      name: compactData.n,
      cards,
      boardSize: compactData.b,
      description: compactData.d,
      tags: compactData.t,
      createdBy: compactData.by,
      version: compactData.v
    };
  } catch (error) {
    console.error('Failed to decode deck data:', error);
    return null;
  }
}

export const useDeckSharing = create<DeckSharingState>()(
  persist(
    (set, get) => ({
      sharedDecks: SAMPLE_SHARED_DECKS,
      favoriteDecks: [],
      importHistory: [],

      generateShareCode: (deckData: DeckShareData) => {
        return generateRandomShareCode();
      },

      shareDeck: (deckData: DeckShareData) => {
        const shareCode = generateRandomShareCode();
        const sharedDeck: SharedDeck = {
          id: `deck-${Date.now()}`,
          ...deckData,
          shareCode,
          createdAt: new Date(),
          likes: 0,
          downloads: 0,
          isPublic: true
        };

        set(state => ({
          sharedDecks: [...state.sharedDecks, sharedDeck]
        }));

        return sharedDeck;
      },

      importDeck: (shareCode: string) => {
        const state = get();
        const deck = state.sharedDecks.find(d => d.shareCode === shareCode);
        
        if (deck) {
          // Increment download count
          set(state => ({
            sharedDecks: state.sharedDecks.map(d => 
              d.shareCode === shareCode 
                ? { ...d, downloads: d.downloads + 1 }
                : d
            ),
            importHistory: [shareCode, ...state.importHistory.filter(code => code !== shareCode)].slice(0, 20)
          }));
          
          return deck;
        }
        
        return null;
      },

      validateShareCode: (shareCode: string) => {
        const codePattern = /^GR-[A-Z0-9]{4}-\d{4}-[A-Z0-9]{6}$/;
        return codePattern.test(shareCode);
      },

      likeDeck: (shareCode: string) => {
        set(state => ({
          sharedDecks: state.sharedDecks.map(deck =>
            deck.shareCode === shareCode
              ? { ...deck, likes: deck.likes + 1 }
              : deck
          )
        }));
      },

      addToFavorites: (shareCode: string) => {
        set(state => ({
          favoriteDecks: [...new Set([...state.favoriteDecks, shareCode])]
        }));
      },

      removeFromFavorites: (shareCode: string) => {
        set(state => ({
          favoriteDecks: state.favoriteDecks.filter(code => code !== shareCode)
        }));
      },

      getPopularDecks: () => {
        const state = get();
        return [...state.sharedDecks]
          .filter(deck => deck.isPublic)
          .sort((a, b) => (b.likes + b.downloads) - (a.likes + a.downloads))
          .slice(0, 10);
      },

      getRecentDecks: () => {
        const state = get();
        return [...state.sharedDecks]
          .filter(deck => deck.isPublic)
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 10);
      },

      searchDecks: (query: string) => {
        const state = get();
        const lowercaseQuery = query.toLowerCase();
        
        return state.sharedDecks.filter(deck => 
          deck.isPublic && (
            deck.name.toLowerCase().includes(lowercaseQuery) ||
            deck.description?.toLowerCase().includes(lowercaseQuery) ||
            deck.tags?.some(tag => tag.toLowerCase().includes(lowercaseQuery)) ||
            deck.createdBy.toLowerCase().includes(lowercaseQuery)
          )
        );
      },

      exportDeckToClipboard: async (deckData: DeckShareData) => {
        try {
          const shareCode = generateRandomShareCode();
          const encodedData = encodeDeckData(deckData);
          const shareText = `🎴 GridRune Deck: ${deckData.name}\n📋 Code: ${shareCode}\n💾 Daten: ${encodedData}\n\n🎮 Importiere dieses Deck in GridRune!`;
          
          await navigator.clipboard.writeText(shareText);
          return true;
        } catch (error) {
          console.error('Failed to copy to clipboard:', error);
          return false;
        }
      },

      importDeckFromClipboard: async () => {
        try {
          const clipboardText = await navigator.clipboard.readText();
          
          // Extract encoded data from clipboard text
          const dataMatch = clipboardText.match(/💾 Daten: ([A-Za-z0-9+/=]+)/);
          if (!dataMatch) return null;
          
          const encodedData = dataMatch[1];
          // Note: In a real implementation, we'd need access to allCards here
          // For now, we'll return a mock deck
          return null;
        } catch (error) {
          console.error('Failed to read from clipboard:', error);
          return null;
        }
      }
    }),
    {
      name: 'deck-sharing-storage',
      partialize: (state) => ({
        sharedDecks: state.sharedDecks,
        favoriteDecks: state.favoriteDecks,
        importHistory: state.importHistory
      })
    }
  )
);