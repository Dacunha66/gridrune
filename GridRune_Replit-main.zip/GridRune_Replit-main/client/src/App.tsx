import { useEffect, useState } from "react";
import { GameBoard } from "./components/GameBoard";
import { PlayerHand } from "./components/PlayerHand";

import { GameUI } from "./components/GameUI";
import { EffectMessages } from "./components/EffectMessages";
import { StartScreen } from "./components/StartScreen";
import { GameEndScreen } from "./components/GameEndScreen";
import { DeckEditor } from "./components/DeckEditor";
import { DeckManagement } from "./components/DeckManagement";
import { DeckCreator } from "./components/DeckCreator";
import { CardCollection } from "./components/CardCollection";
import { LoginScreen } from "./components/LoginScreen";
import { EnhancedPlayerProfile } from "./components/EnhancedPlayerProfile";
import { DiceRollScreen } from "./components/DiceRollScreen";
import { useCardGame } from "./lib/stores/useCardGame";
import { useAudio } from "./lib/stores/useAudio";
import { useAuth } from "./lib/stores/useAuth";
import { MultiplayerLobby } from "./components/MultiplayerLobby";
import { AvatarCustomization } from "./components/AvatarCustomization";
import { TurnIndicator } from "./components/TurnIndicator";
import { RarityDemo } from "./components/RarityDemo";
import { DeckThemeCustomizer } from "./components/DeckThemeCustomizer";
import { CardFlipDemo } from "./components/CardFlipDemo";
import { Shop } from "./components/Shop";
import { GameStory } from "./components/GameStory";
import { RankedMatchmaking } from "./components/RankedMatchmaking";
import { SeasonRewards } from "./components/SeasonRewards";
import { AchievementsPanel } from "./components/AchievementsPanel";
import { AchievementNotificationManager } from "./components/AchievementNotification";
import { FriendRequestNotifications } from "./components/FriendRequestNotification";
import { MobileGameLayout } from "./components/MobileGameLayout";
import { SeasonalRewards } from "./components/SeasonalRewards";
import WeeklyChallenges from "./components/WeeklyChallenges";
import { MobileTutorial } from "./components/MobileTutorial";
import { useAchievements } from "./lib/stores/useAchievements";
import GlobalAchievementProvider from "./components/GlobalAchievementProvider";
import { BadgeProvider } from "./components/BadgeProvider";
import { BadgeIntegrationHelper } from "./components/BadgeIntegrationHelper";
import { AudioInitializer } from "./components/AudioInitializer";
import { LayerManagerProvider } from "./contexts/LayerManagerContext";


import "@fontsource/inter";

function App() {
  const { 
    gamePhase, 
    gameMode,
    currentPlayer,
    coinFlipWinner, 
    showAvatarCustomization,
    customizingPlayer,
    hideAvatarCustomization,
    setPlayerProfile,
    player1Name,
    player2Name,
    player1Avatar,
    player2Avatar,
    setGamePhase
  } = useCardGame();
  const { setBackgroundMusic, setBackgroundMusicTracks, setHitSound, setSuccessSound, toggleBackgroundMusic } = useAudio();
  const { isAuthenticated, checkAuthStatus, user } = useAuth();
  const { initializeAchievements } = useAchievements();
  
  // Mobile tutorial state
  const [showMobileTutorial, setShowMobileTutorial] = useState(false);

  // Check if user is on mobile and if they haven't seen the tutorial
  useEffect(() => {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || 
                     (window.innerWidth <= 768);
    const hasSeenTutorial = localStorage.getItem('mobileTutorialCompleted') === 'true';
    
    // Show tutorial for first-time mobile users after a short delay
    if (isMobile && !hasSeenTutorial && gamePhase === 'playing') {
      const timer = setTimeout(() => {
        setShowMobileTutorial(true);
      }, 2000); // Show after 2 seconds to let user orient themselves
      
      return () => clearTimeout(timer);
    }
  }, [gamePhase]);

  useEffect(() => {
    // Import and initialize the audio generator
    import('./lib/audioGenerator').then(({ AudioGenerator }) => {
      const generator = new AudioGenerator();
      
      // Create synthetic music tracks with completely different melodies
      const backgroundTracks = [
        generator.createCompatibleAudio('zen'),     // Pentatonic peaceful melody
        generator.createCompatibleAudio('classic'), // Major scale uplifting melody  
        generator.createCompatibleAudio('battle'),  // Minor scale intense melody
      ];
      
      const hitSound = new Audio("/sounds/hit.mp3");
      const successSound = new Audio("/sounds/success.mp3");
      
      setBackgroundMusicTracks(backgroundTracks);
      setBackgroundMusic(backgroundTracks[0]); // Set zen theme as default
      setHitSound(hitSound);
      setSuccessSound(successSound);
    }).catch(() => {
      // Fallback to original system if Web Audio API fails
      const createProcessedTrack = (audioSrc: string, effectName: string) => {
        const audio = new Audio(audioSrc);
        audio.loop = true;
        audio.preload = "auto";
        (audio as any).effectName = effectName;
        return audio;
      };

      const backgroundTracks = [
        createProcessedTrack("/sounds/success.mp3", "Zen-Modus"),
        createProcessedTrack("/sounds/background.mp3", "Klassisch"), 
        createProcessedTrack("/sounds/hit.mp3", "Kampf-Modus"),
      ];
      
      backgroundTracks[0].volume = 0.4;
      backgroundTracks[0].playbackRate = 0.7;
      backgroundTracks[1].volume = 0.6;
      backgroundTracks[2].volume = 0.8;
      backgroundTracks[2].playbackRate = 1.3;
      
      const hitSound = new Audio("/sounds/hit.mp3");
      const successSound = new Audio("/sounds/success.mp3");
      
      setBackgroundMusicTracks(backgroundTracks);
      setBackgroundMusic(backgroundTracks[0]);
      setHitSound(hitSound);
      setSuccessSound(successSound);
    });

    // Check authentication status
    checkAuthStatus();
    
    // Initialize achievements
    initializeAchievements();
  }, [setBackgroundMusic, setBackgroundMusicTracks, setHitSound, setSuccessSound, checkAuthStatus, initializeAchievements]);

  // Auto-start background music when authenticated and on start screen
  useEffect(() => {
    if (isAuthenticated && gamePhase === "menu") {
      // Small delay to ensure audio is loaded and user has interacted
      const timer = setTimeout(() => {
        toggleBackgroundMusic();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isAuthenticated, gamePhase, toggleBackgroundMusic]);

  // Show login screen if not authenticated
  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  // Show start screen if game phase is menu
  if (gamePhase === "menu") {
    return <StartScreen />;
  }

  // Show end screen if game phase is ended
  if (gamePhase === "ended") {
    return <GameEndScreen />;
  }

  // Show deck editor if game phase is deck-editor
  if (gamePhase === "deck-editor") {
    return <DeckEditor />;
  }

  // Show deck management screen
  if (gamePhase === "deck-management") {
    return <DeckManagement />;
  }

  // Show deck creator screen
  if (gamePhase === "deck-creator") {
    return <DeckCreator />;
  }

  // Show card collection screen
  if (gamePhase === "card-collection") {
    return <CardCollection />;
  }

  // Show player profile screen
  if (gamePhase === "player-profile") {
    return <EnhancedPlayerProfile onBack={() => setGamePhase("menu")} />;
  }

  // Show rarity demo screen
  if (gamePhase === "rarity-demo") {
    return <RarityDemo />;
  }

  // Show deck theme customizer screen
  if (gamePhase === "deck-theme-customizer") {
    return <DeckThemeCustomizer />;
  }

  // Show card flip animation demo
  if (gamePhase === "card-flip-demo") {
    return <CardFlipDemo />;
  }

  // Show shop screen
  if (gamePhase === "shop") {
    return <Shop />;
  }

  // Show story screen
  if (gamePhase === "story") {
    return <GameStory />;
  }

  // Show ranked matchmaking screen
  if (gamePhase === "ranked-matchmaking") {
    return (
      <RankedMatchmaking 
        onStartMatch={(matchData) => {
          // Start ranked game with 4x4 board and proper initialization
          const gameStore = useCardGame.getState();
          gameStore.setGameMode("ai");
          gameStore.setAIDifficulty("medium");
          gameStore.setBoardSize("4x4");
          gameStore.initializeGame();
          setGamePhase("coin-flip");
        }}
        onBack={() => setGamePhase("menu")}
        currentUser={{
          id: "user-1",
          username: user?.displayName || "Spieler",
          rankedPoints: user?.level ? user.level * 100 : 0, // Temporary calculation
          currentRank: "bronze_iii", // Default rank
          seasonWins: 12,
          seasonLosses: 8,
          winStreak: 3
        }}
      />
    );
  }

  // Show season rewards screen
  if (gamePhase === "season-rewards") {
    return (
      <SeasonRewards 
        onBack={() => setGamePhase("menu")}
        currentRank="bronze_iii" // Default rank for now
        seasonEndsIn={15}
      />
    );
  }

  // Show achievements screen
  if (gamePhase === "achievements") {
    return (
      <AchievementsPanel 
        onBack={() => setGamePhase("menu")}
      />
    );
  }

  if (gamePhase === "seasonal-rewards") {
    return (
      <SeasonalRewards 
        onBack={() => setGamePhase("menu")}
      />
    );
  }

  if (gamePhase === "weekly-challenges") {
    return (
      <WeeklyChallenges 
        onBack={() => setGamePhase("menu")}
      />
    );
  }

  // Show multiplayer lobby if game phase is multiplayer-lobby
  if (gamePhase === "multiplayer-lobby") {
    return <MultiplayerLobby />;
  }

  // Show dice roll screen for all game modes
  if (gamePhase === "coin-flip") {
    return <DiceRollScreen />;
  }

  // Show O-Card placement screen after coin flip
  if (gamePhase === "place-o-card") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-2 sm:p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">O-Karte platzieren</h2>
            <p className="text-slate-300">
              {coinFlipWinner === 1 ? "Du darfst" : "Spieler 2 darf"} die O-Karte frei auf einem beliebigen Feld platzieren
            </p>
          </div>
          <div className="flex justify-center">
            <GameBoard />
          </div>
        </div>
      </div>
    );
  }

  // Show Blitzschlag target selection screen
  if (gamePhase === "blitzschlag-target") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-2 sm:p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">🗲 Blitzschlag-Ziel wählen</h2>
            <p className="text-slate-300">
              Wähle eine gegnerische Karte aus, die -2 Schaden erhalten soll
            </p>
          </div>
          <div className="flex justify-center">
            <GameBoard />
          </div>
        </div>
      </div>
    );
  }

  // Show Clone target selection screen
  if (gamePhase === "clone-target") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-2 sm:p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">👥 Clone-Ziel wählen</h2>
            <p className="text-slate-300">
              Wähle eine benachbarte Karte aus, deren Werte kopiert werden sollen
            </p>
          </div>
          <div className="flex justify-center">
            <GameBoard />
          </div>
        </div>
      </div>
    );
  }

  return (
    <LayerManagerProvider>
      <BadgeProvider>
        <GlobalAchievementProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white py-2 sm:p-4">
      <div className="max-w-6xl mx-auto px-2 sm:px-0">
        {/* Desktop GameUI */}
        <div className="hidden lg:block">
          <GameUI onShowMobileTutorial={() => setShowMobileTutorial(true)} />
        </div>
        
        {/* Mobile Layout - New Fixed Layout with Swipe Navigation */}
        <div className="lg:hidden">
          <MobileGameLayout onShowMobileTutorial={() => setShowMobileTutorial(true)} />
        </div>
        
        {/* Desktop Layout */}
        <div className="hidden lg:flex flex-row gap-8 items-start justify-center">
          <div className="order-1">
            <PlayerHand player={1} />
          </div>
          
          <div className="order-2 flex-shrink-0">
            <GameBoard />
          </div>
          
          <div className="order-3">
            <PlayerHand player={2} />
          </div>
        </div>
      </div>
      

      
      {/* Global Effect Messages */}
      <EffectMessages />

      {/* Avatar Customization Dialog */}
      {showAvatarCustomization && customizingPlayer && (
        <AvatarCustomization
          onSave={(name, avatar) => setPlayerProfile(customizingPlayer, name, avatar)}
          onCancel={hideAvatarCustomization}
          currentPlayerName={customizingPlayer === 1 ? player1Name : player2Name}
          currentAvatar={customizingPlayer === 1 ? player1Avatar : player2Avatar}
          isPlayer2={customizingPlayer === 2}
        />
      )}

      {/* Achievement Notification Manager */}
      <AchievementNotificationManager />

      {/* Friend Request Notifications */}
      <FriendRequestNotifications />
      
      {/* Mobile Tutorial */}
      <MobileTutorial
        isVisible={showMobileTutorial}
        onClose={() => setShowMobileTutorial(false)}
      />
      
      {/* Audio System Initializer */}
      <AudioInitializer />
      
      {/* Badge Integration Helper */}
      <BadgeIntegrationHelper />
        </div>
      </GlobalAchievementProvider>
    </BadgeProvider>
    </LayerManagerProvider>
  );
}

export default App;
