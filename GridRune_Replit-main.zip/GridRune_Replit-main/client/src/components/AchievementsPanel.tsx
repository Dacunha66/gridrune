import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAchievements, Achievement } from "../lib/stores/useAchievements";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ArrowLeft, Trophy, Lock, Star, Gift, Diamond, Target, Users, Palette, Gamepad2, BookOpen } from "lucide-react";
import { cn } from "../lib/utils";

interface AchievementsPanelProps {
  onBack: () => void;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "gameplay": return Gamepad2;
    case "collection": return Star;
    case "deck-building": return Palette;
    case "social": return Users;
    case "progression": return Target;
    default: return BookOpen;
  }
};

const getRarityStyles = (rarity: string) => {
  switch (rarity) {
    case "legendary":
      return {
        gradient: "from-yellow-400 via-amber-500 to-orange-600",
        bg: "bg-gradient-to-br from-yellow-50 to-amber-100 dark:from-yellow-900/20 dark:to-amber-800/20",
        border: "border-yellow-400",
        text: "text-yellow-600 dark:text-yellow-400",
        glow: "shadow-lg shadow-yellow-500/20"
      };
    case "epic":
      return {
        gradient: "from-purple-400 via-violet-500 to-indigo-600",
        bg: "bg-gradient-to-br from-purple-50 to-indigo-100 dark:from-purple-900/20 dark:to-indigo-800/20",
        border: "border-purple-400", 
        text: "text-purple-600 dark:text-purple-400",
        glow: "shadow-lg shadow-purple-500/20"
      };
    case "rare":
      return {
        gradient: "from-blue-400 via-cyan-500 to-teal-600",
        bg: "bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-blue-900/20 dark:to-cyan-800/20",
        border: "border-blue-400",
        text: "text-blue-600 dark:text-blue-400", 
        glow: "shadow-lg shadow-blue-500/20"
      };
    default:
      return {
        gradient: "from-gray-400 via-slate-500 to-gray-600",
        bg: "bg-gradient-to-br from-gray-50 to-slate-100 dark:from-gray-800/20 dark:to-slate-700/20",
        border: "border-gray-400",
        text: "text-gray-600 dark:text-gray-400",
        glow: "shadow-lg shadow-gray-500/20"
      };
  }
};

const AchievementCard = React.forwardRef<HTMLDivElement, { achievement: Achievement; index: number }>(({ achievement, index }, ref) => {
  const styles = getRarityStyles(achievement.rarity);
  const isLocked = !achievement.isUnlocked;
  const hasProgress = achievement.requirements.type !== "condition" && 
                     achievement.requirements.current !== undefined && 
                     achievement.requirements.target !== undefined;
  
  const progressPercentage = hasProgress 
    ? Math.min((achievement.requirements.current! / achievement.requirements.target!) * 100, 100)
    : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, type: "spring", stiffness: 200, damping: 20 }}
      whileHover={{ scale: 1.02, y: -2 }}
      className="relative"
    >
      <Card className={cn(
        "relative overflow-hidden transition-all duration-300",
        isLocked 
          ? "bg-slate-800/50 border-slate-600/50 opacity-75" 
          : `${styles.bg} border-2 ${styles.border} ${styles.glow}`,
        achievement.isNew && "ring-2 ring-yellow-400 ring-opacity-50"
      )}>
        {/* New badge */}
        {achievement.isNew && (
          <motion.div
            initial={{ scale: 0, rotate: -45 }}
            animate={{ scale: 1, rotate: 0 }}
            className="absolute top-2 right-2 z-10"
          >
            <Badge className="bg-yellow-500 text-yellow-900 font-bold text-xs">
              NEU
            </Badge>
          </motion.div>
        )}

        {/* Lock overlay for locked achievements */}
        {isLocked && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-10">
            <Lock className="w-8 h-8 text-slate-400" />
          </div>
        )}

        {/* Sparkle animation for legendary unlocked achievements */}
        {achievement.isUnlocked && achievement.rarity === "legendary" && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            animate={{ opacity: [0.3, 0.7, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {[...Array(4)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute"
                style={{
                  left: `${15 + (i * 20)}%`,
                  top: `${10 + (i % 2) * 60}%`
                }}
                animate={{
                  scale: [0.5, 1, 0.5],
                  rotate: [0, 180, 360]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.5
                }}
              >
                <Star className="w-3 h-3 text-yellow-400 opacity-60" />
              </motion.div>
            ))}
          </motion.div>
        )}

        <CardHeader className="pb-3">
          <div className="flex items-start gap-3">
            <motion.div
              className="text-2xl"
              animate={achievement.isUnlocked ? { 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1]
              } : {}}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 5 }}
            >
              {achievement.icon}
            </motion.div>
            <div className="flex-1 min-w-0">
              <CardTitle className={cn(
                "text-lg font-bold truncate",
                isLocked ? "text-slate-400" : "text-white"
              )}>
                {achievement.title}
              </CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs font-medium capitalize",
                    isLocked ? "border-slate-500 text-slate-400" : styles.text
                  )}
                >
                  {achievement.rarity}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  {achievement.category.replace("-", " ")}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          <p className={cn(
            "text-sm mb-3",
            isLocked ? "text-slate-500" : "text-slate-300"
          )}>
            {achievement.description}
          </p>

          {/* Progress bar for counter/milestone achievements */}
          {hasProgress && !isLocked && (
            <div className="mb-3">
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-400">Fortschritt</span>
                <span className={styles.text}>
                  {achievement.requirements.current} / {achievement.requirements.target}
                </span>
              </div>
              <Progress 
                value={progressPercentage} 
                className="h-2"
              />
            </div>
          )}

          {/* Reward information */}
          {achievement.reward && achievement.isUnlocked && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className={cn(
                "flex items-center gap-2 p-2 rounded-lg border",
                styles.bg,
                styles.border
              )}
            >
              <Gift className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-medium text-white">
                {achievement.reward.type === "diamonds" && (
                  <span className="flex items-center gap-1">
                    <Diamond className="w-3 h-3 text-cyan-300" />
                    {achievement.reward.amount} Diamanten
                  </span>
                )}
              </span>
            </motion.div>
          )}

          {/* Unlock date */}
          {achievement.unlockedAt && (
            <div className="text-xs text-slate-500 mt-2">
              Freigeschaltet: {new Date(achievement.unlockedAt).toLocaleDateString('de-DE')}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
});

export function AchievementsPanel({ onBack }: AchievementsPanelProps) {
  const { achievements, totalUnlocked } = useAchievements();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { filteredAchievements, categories, stats } = useMemo(() => {
    const filtered = selectedCategory === "all" 
      ? achievements 
      : achievements.filter(a => a.category === selectedCategory);

    const categorySet = new Set(achievements.map(a => a.category));
    const cats = Array.from(categorySet);

    const categoryStats = cats.map(category => {
      const categoryAchievements = achievements.filter(a => a.category === category);
      const unlockedCount = categoryAchievements.filter(a => a.isUnlocked).length;
      return {
        category,
        total: categoryAchievements.length,
        unlocked: unlockedCount,
        percentage: Math.round((unlockedCount / categoryAchievements.length) * 100)
      };
    });

    return {
      filteredAchievements: filtered,
      categories: cats,
      stats: categoryStats
    };
  }, [achievements, selectedCategory]);

  const overallPercentage = Math.round((totalUnlocked / achievements.length) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={onBack}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück
          </Button>
          
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
              <Trophy className="w-8 h-8 text-yellow-400" />
              Erfolge
            </h1>
            <div className="text-slate-300">
              {totalUnlocked} von {achievements.length} freigeschaltet ({overallPercentage}%)
            </div>
          </div>
          
          <div className="w-32" />
        </div>

        {/* Overall Progress */}
        <Card className="bg-slate-800 border-slate-600 mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-300">Gesamtfortschritt</span>
                  <span className="text-sm text-yellow-400 font-bold">{overallPercentage}%</span>
                </div>
                <Progress value={overallPercentage} className="h-3" />
              </div>
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="text-3xl"
              >
                🏆
              </motion.div>
            </div>
          </CardContent>
        </Card>

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-6">
          <TabsList className="grid grid-cols-6 w-full bg-slate-800 border border-slate-600">
            <TabsTrigger value="all" className="data-[state=active]:bg-slate-600">
              Alle
            </TabsTrigger>
            {categories.map(category => {
              const Icon = getCategoryIcon(category);
              const stat = stats.find(s => s.category === category);
              return (
                <TabsTrigger 
                  key={category} 
                  value={category}
                  className="data-[state=active]:bg-slate-600 flex items-center gap-2"
                >
                  <Icon className="w-4 h-4" />
                  <span className="capitalize hidden sm:inline">
                    {category.replace("-", " ")}
                  </span>
                  {stat && (
                    <Badge variant="outline" className="text-xs">
                      {stat.unlocked}/{stat.total}
                    </Badge>
                  )}
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>

        {/* Achievements Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"
          layout
        >
          <AnimatePresence mode="popLayout">
            {filteredAchievements.map((achievement, index) => (
              <AchievementCard 
                key={achievement.id}
                achievement={achievement}
                index={index}
              />
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredAchievements.length === 0 && (
          <div className="text-center py-12">
            <Trophy className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">Keine Erfolge in dieser Kategorie</p>
          </div>
        )}
      </div>
    </div>
  );
}