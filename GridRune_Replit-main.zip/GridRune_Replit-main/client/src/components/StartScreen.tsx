import React, { useState } from "react";
import { motion } from "framer-motion";
import { useCardGame, type BoardSize } from "../lib/stores/useCardGame";
import { useAuth } from "../lib/stores/useAuth";
import { Button } from "./ui/button";
import { Bot, Users, Library, Globe, User, Trophy, LogOut, ShoppingCart, ArrowLeftRight, Play, BookOpen, Crown, Sparkles, Target, X } from "lucide-react";

import TradingPlatform from './TradingPlatform';
import OnboardingTutorial from './OnboardingTutorial';
import { CommunityLeaderboard } from './CommunityLeaderboard';
import QuestHub from './QuestHub';
import QuestAchievementShowcase from './QuestAchievementShowcase';
import PlayerStatsHeader from './PlayerStatsHeader';
import AchievementTestButton from './AchievementTestButton';
import { AudioControls } from './AudioControls';
import { CardShuffleTransition } from './CardShuffleTransition';
import { DeckManager } from './DeckManager';
import { useCardShuffle } from '../hooks/useCardShuffle';
import { useWeeklyChallenges } from '../lib/stores/useWeeklyChallenges';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { DynamicBackground } from './DynamicBackground';


export function StartScreen() {
  const { 
    setGameMode, 
    setAIDifficulty, 
    aiDifficulty, 
    setGamePhase, 
    setBoardSize, 
    boardSize
  } = useCardGame();
  const { user, logout, isGuest } = useAuth();
  const { getCompletedTasksCount } = useWeeklyChallenges();
  const { stats } = usePlayerProgress();
  const { isShuffling, triggerShuffle, completeShuffle } = useCardShuffle();
  const [showGameModes, setShowGameModes] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showQuestHub, setShowQuestHub] = useState(false);
  const [showAchievementGallery, setShowAchievementGallery] = useState(false);
  const [showTrading, setShowTrading] = useState(false);
  const [showDeckManager, setShowDeckManager] = useState(false);


  // Get completed quests count for badge
  const completedQuestsCount = getCompletedTasksCount();

  const handleGameModeSelect = (mode: "local" | "ai" | "multiplayer") => {
    triggerShuffle(() => {
      if (mode === "multiplayer") {
        setGamePhase("multiplayer-lobby");
      } else {
        // Initialize game with proper deck setup - always use 4x4
        const gameboardSize: BoardSize = "4x4";
        setGameMode(mode);
        if (mode === "ai") {
          setAIDifficulty(aiDifficulty);
        }
        setBoardSize(gameboardSize);
        setGamePhase("coin-flip");
        // Initialize the game properly
        setTimeout(() => {
          const gameStore = useCardGame.getState();
          gameStore.initializeGame();
        }, 50);
      }
    });
  };

  return (
    <DynamicBackground dominantRarity="legendary" intensity={1.0}>
      <div className="min-h-screen text-white flex items-center justify-center p-4 relative overflow-hidden">
      {/* Traditional Japanese background patterns */}
      <div className="absolute inset-0 opacity-5">
        <div className="h-full w-full bg-gradient-to-r from-transparent via-amber-500 to-transparent transform rotate-45 scale-150"></div>
        <div className="absolute top-0 left-0 h-full w-full bg-gradient-to-l from-transparent via-red-500 to-transparent transform -rotate-45 scale-150"></div>
      </div>
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Stats Header über dem Logo - Desktop */}
        <div className="hidden md:flex justify-center mb-8">
          <div className="bg-gradient-to-r from-amber-100/20 to-amber-200/20 p-4 rounded-lg border-2 border-amber-600/50 backdrop-blur-sm">
            <div className="flex items-center space-x-6">
              <div className="text-sm text-amber-200" style={{ fontFamily: 'serif' }}>
                Willkommen zurück, <span className="text-amber-100 font-bold">{user?.displayName}</span>
                {isGuest && <span className="text-yellow-300 ml-2">(Gast)</span>}
              </div>
              <PlayerStatsHeader className="bg-slate-900/30" />
              <AudioControls />
              {!isGuest && (
                <Button
                  onClick={logout}
                  variant="outline"
                  size="sm"
                  className="bg-gradient-to-br from-red-700 to-red-900 border-2 border-red-500 text-red-100 hover:from-red-600 hover:to-red-800 font-semibold"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Abmelden
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Stats Header über dem Logo - Mobile */}
        <div className="md:hidden mb-6">
          <div className="bg-gradient-to-r from-amber-100/20 to-amber-200/20 p-3 rounded-lg border-2 border-amber-600/50 backdrop-blur-sm mx-2">
            {/* Willkommenstext zentriert */}
            <div className="text-center mb-3">
              <div className="text-xs text-amber-200" style={{ fontFamily: 'serif' }}>
                Willkommen zurück, <span className="text-amber-100 font-bold">{user?.displayName}</span>
                {isGuest && <span className="text-yellow-300 ml-1">(Gast)</span>}
              </div>
            </div>
            
            {/* Stats zentriert */}
            <div className="flex justify-center mb-3">
              <PlayerStatsHeader className="bg-slate-900/30" />
            </div>

            {/* Abmelden Button für normale Nutzer */}
            {!isGuest && (
              <div className="flex justify-center">
                <Button
                  onClick={logout}
                  variant="outline"
                  size="sm"
                  className="bg-gradient-to-br from-red-700 to-red-900 border-2 border-red-500 text-red-100 hover:from-red-600 hover:to-red-800 font-semibold"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Abmelden
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Desktop: Logo mit Buttons seitlich, Mobile: Logo oben, Buttons unten */}
        <div className="mb-12">
          {/* Desktop Layout */}
          <div className="hidden md:flex items-center justify-center space-x-8">
            {/* Quests Button links */}
            <div className="relative">
              <Button
                onClick={() => setShowQuestHub(true)}
                variant="outline"
                size="lg"
                className="bg-gradient-to-br from-orange-600 to-red-700 border-2 border-orange-400 text-orange-100 hover:from-orange-500 hover:to-red-600 font-semibold"
              >
                <Target className="w-5 h-5 mr-2" />
                <span>Quests</span>
              </Button>
              {completedQuestsCount > 0 && (
                <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center border-2 border-white shadow-lg animate-pulse">
                  {completedQuestsCount}
                </div>
              )}
            </div>

            {/* Logo - perfekt zentriert */}
            <img 
              src="/gridrune-logo-transparent.png" 
              alt="GridRune Logo" 
              className="h-60"
              style={{
                filter: 'drop-shadow(4px 4px 8px rgba(0, 0, 0, 0.7))'
              }}
            />

            {/* Profil Button rechts */}
            <div className="flex flex-col items-center space-y-3">
              <Button
                onClick={() => setGamePhase("player-profile")}
                variant="outline"
                size="lg"
                className="bg-gradient-to-br from-amber-600 to-red-700 border-2 border-amber-400 text-amber-100 hover:from-amber-500 hover:to-red-600 font-semibold"
              >
                <User className="w-5 h-5 mr-2" />
                <span>Profil</span>
              </Button>
              {isGuest && (
                <Button
                  onClick={logout}
                  variant="outline"
                  size="sm"
                  className="bg-gradient-to-br from-red-700 to-red-900 border-2 border-red-500 text-red-100 hover:from-red-600 hover:to-red-800 font-semibold"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  <span>Beenden</span>
                </Button>
              )}
            </div>
          </div>

          {/* Mobile Layout */}
          <div className="md:hidden">
            {/* Logo zentriert */}
            <div className="flex justify-center mb-8">
              <img 
                src="/gridrune-logo-transparent.png" 
                alt="GridRune Logo" 
                className="h-48"
                style={{
                  filter: 'drop-shadow(4px 4px 8px rgba(0, 0, 0, 0.7))'
                }}
              />
            </div>

            {/* Buttons unter dem Logo */}
            <div className="flex justify-center items-center space-x-4">
              <div className="relative">
                <Button
                  onClick={() => setShowQuestHub(true)}
                  variant="outline"
                  size="lg"
                  className="bg-gradient-to-br from-orange-600 to-red-700 border-2 border-orange-400 text-orange-100 hover:from-orange-500 hover:to-red-600 font-semibold"
                >
                  <Target className="w-5 h-5" />
                </Button>
                {completedQuestsCount > 0 && (
                  <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center border-2 border-white shadow-lg animate-pulse">
                    {completedQuestsCount}
                  </div>
                )}
              </div>

              <Button
                onClick={() => setGamePhase("player-profile")}
                variant="outline"
                size="lg"
                className="bg-gradient-to-br from-amber-600 to-red-700 border-2 border-amber-400 text-amber-100 hover:from-amber-500 hover:to-red-600 font-semibold"
              >
                <User className="w-5 h-5" />
              </Button>

              <AudioControls />



              {isGuest && (
                <Button
                  onClick={logout}
                  variant="outline"
                  size="lg"
                  className="bg-gradient-to-br from-red-700 to-red-900 border-2 border-red-500 text-red-100 hover:from-red-600 hover:to-red-800 font-semibold"
                >
                  <LogOut className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>



        <div className="grid grid-cols-2 md:grid-cols-2 gap-2 md:gap-2 max-w-xs md:max-w-4xl mx-auto px-4 md:px-0 relative">
          {/* 1. 戦闘 (Battle) - Main Game Menu */}
          <motion.div
            whileHover={{ scale: 1.02, rotateY: 5 }}
            whileTap={{ scale: 0.98 }}
            className="bg-gradient-to-br from-amber-100 to-amber-200 p-2 md:p-6 mx-0 rounded-lg shadow-2xl cursor-pointer border-2 md:border-4 border-red-700 col-span-2 md:col-span-2 relative h-14 md:h-auto flex md:block items-center md:items-start justify-center md:justify-start"
            style={{
              background: 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)',
              boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)',
              zIndex: showGameModes ? 60 : 10
            }}
            onClick={() => setShowGameModes(!showGameModes)}
          >
            {/* Traditional war banner effect */}
            <div className="absolute top-0 left-0 w-full h-1 md:h-2 bg-gradient-to-r from-red-700 via-amber-500 to-red-700"></div>
            <div className="text-center md:text-center">
              <div className="hidden md:flex w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-red-700 to-red-900 rounded-full items-center justify-center border-4 border-amber-400 shadow-lg">
                <Play className="w-8 h-8 text-amber-100" />
              </div>
              <h3 className="text-lg md:text-3xl font-bold text-red-900" style={{
                fontFamily: 'serif',
                textShadow: '2px 2px 4px rgba(139, 69, 19, 0.3)'
              }}>
                Spielen
              </h3>
              <p className="hidden md:block text-red-800 text-lg font-semibold mb-4">Wähle deinen Spielmodus</p>
              
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ 
                  opacity: showGameModes ? 1 : 0, 
                  height: showGameModes ? 'auto' : 0 
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden relative z-50"
              >
                <div className="bg-gradient-to-br from-amber-50/90 to-amber-100/90 p-6 rounded-lg border-2 border-amber-600 mt-6 backdrop-blur-sm shadow-2xl relative z-50">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Online Multiplayer with sub-options */}
                    <div className="space-y-4">
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        className="bg-gradient-to-br from-blue-600 to-blue-800 p-4 rounded-lg text-white text-center shadow-lg border-2 border-blue-400"
                      >
                        <div className="w-12 h-12 mx-auto mb-3 bg-blue-500 rounded-full flex items-center justify-center">
                          <Globe className="w-6 h-6" />
                        </div>
                        <h3 className="font-bold text-lg mb-2">Online</h3>
                        <p className="text-sm text-blue-200">Gegen echte Spieler</p>
                      </motion.div>
                      
                      {/* Online sub-options */}
                      <div className="space-y-2">
                        <motion.button
                          whileHover={{ scale: 1.05, x: 5 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowGameModes(false);
                            triggerShuffle(() => setGamePhase('ranked-matchmaking'));
                          }}
                          className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 text-white p-3 rounded-lg border-2 border-yellow-400 font-semibold shadow-md hover:from-yellow-500 hover:to-orange-500"
                        >
                          🏆 Rangliste
                        </motion.button>
                        
                        <motion.button
                          whileHover={{ scale: 1.05, x: 5 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleGameModeSelect('multiplayer');
                          }}
                          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white p-3 rounded-lg border-2 border-blue-400 font-semibold shadow-md hover:from-blue-500 hover:to-blue-600"
                        >
                          🎮 Freies Spiel
                        </motion.button>
                      </div>
                    </div>

                    {/* VS Mich selbst (Local) */}
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleGameModeSelect('local');
                      }}
                      className="bg-gradient-to-br from-green-600 to-green-800 p-4 rounded-lg text-white text-center shadow-lg border-2 border-green-400 cursor-pointer"
                    >
                      <div className="w-12 h-12 mx-auto mb-3 bg-green-500 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">VS Mich selbst</h3>
                      <p className="text-sm text-green-200">Lokal (2 Spieler)</p>
                      <p className="text-xs text-green-300 mt-2">Gemeinsam am PC</p>
                    </motion.div>

                    {/* VS KI */}
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleGameModeSelect('ai');
                      }}
                      className="bg-gradient-to-br from-purple-600 to-purple-800 p-4 rounded-lg text-white text-center shadow-lg border-2 border-purple-400 cursor-pointer"
                    >
                      <div className="w-12 h-12 mx-auto mb-3 bg-purple-500 rounded-full flex items-center justify-center">
                        <Bot className="w-6 h-6" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">VS KI</h3>
                      <p className="text-sm text-purple-200">Künstliche Intelligenz</p>
                      
                      {/* AI Difficulty Selector */}
                      <div className="mt-3">
                        <span className="text-xs text-purple-200 block mb-2">Schwierigkeit:</span>
                        <select
                          value={aiDifficulty}
                          onChange={(e) => {
                            e.stopPropagation();
                            setAIDifficulty(e.target.value as "beginner" | "easy" | "medium" | "hard" | "insane");
                          }}
                          className="w-full text-xs bg-purple-700 border border-purple-500 rounded px-2 py-1 text-white"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value="beginner">🟢 Anfänger</option>
                          <option value="easy">⭐ Einfach</option>
                          <option value="medium">⭐⭐ Mittel</option>
                          <option value="hard">⭐⭐⭐ Schwer</option>
                          <option value="insane">💀 Irrsinnig</option>
                        </select>
                      </div>
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* 2. 武器庫 (Arsenal) - Deck Management */}
          <motion.div
            whileHover={{ scale: 1.05, rotateY: -5 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 md:p-6 mx-0 rounded-lg shadow-2xl cursor-pointer border-2 md:border-4 border-amber-600 relative h-14 md:h-auto flex md:block items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)',
              boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)',
              zIndex: showGameModes ? 5 : 10
            }}
            onClick={() => setGamePhase("deck-management")}
          >
            <div className="absolute top-0 left-0 w-full h-1 md:h-2 bg-gradient-to-r from-amber-700 via-orange-500 to-amber-700"></div>
            <div className="text-center">
              <div className="hidden md:flex w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-amber-600 to-amber-800 rounded-lg items-center justify-center border-4 border-orange-400 shadow-lg transform rotate-3">
                <Library className="w-8 h-8 text-amber-100" />
              </div>
              <h3 className="text-lg md:text-2xl font-bold text-amber-900" style={{
                fontFamily: 'serif',
                textShadow: '2px 2px 4px rgba(139, 69, 19, 0.3)'
              }}>
                Deck verwalten
              </h3>
              <p className="hidden md:block text-amber-700 text-xs mt-1">Verwalte deine Karten-Sammlung und erstelle Strategien</p>
            </div>
          </motion.div>

          {/* 3. 交易所 (Trading Post) */}
          <motion.div
            whileHover={{ scale: 1.05, rotateY: 5 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 md:p-6 mx-0 rounded-lg shadow-2xl cursor-pointer border-2 md:border-4 border-indigo-600 relative h-14 md:h-auto flex md:block items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)',
              boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)',
              zIndex: showGameModes ? 5 : 10
            }}
            onClick={() => setShowTrading(true)}
          >
            <div className="absolute top-0 left-0 w-full h-1 md:h-2 bg-gradient-to-r from-indigo-700 via-purple-500 to-indigo-700"></div>
            <div className="text-center">
              <div className="hidden md:flex w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-lg items-center justify-center border-4 border-purple-400 shadow-lg transform -rotate-3">
                <ArrowLeftRight className="w-8 h-8 text-indigo-100" />
              </div>
              <h3 className="text-lg md:text-2xl font-bold text-indigo-900" style={{
                fontFamily: 'serif',
                textShadow: '2px 2px 4px rgba(139, 69, 19, 0.3)'
              }}>
                Kartenhandel
              </h3>
              <p className="hidden md:block text-indigo-700 text-xs mt-1 mb-4">Tausche Karten mit anderen Spielern</p>
            </div>
          </motion.div>

          {/* 4. 商人の館 (Merchant's Hall) - Shop */}
          <motion.div
            whileHover={{ scale: 1.02, rotateX: 2 }}
            whileTap={{ scale: 0.98 }}
            className="p-2 md:p-6 mx-0 rounded-lg shadow-2xl cursor-pointer border-2 md:border-4 border-yellow-600 col-span-2 relative h-14 md:h-auto flex md:block items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)',
              boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)',
              zIndex: showGameModes ? 5 : 10
            }}
            onClick={() => triggerShuffle(() => setGamePhase('shop'))}
          >
            {stats.packs > 0 && (
              <div className="absolute -top-2 md:-top-3 -right-2 md:-right-3 bg-purple-500 text-white text-xs md:text-sm font-bold rounded-full w-6 h-6 md:w-8 md:h-8 flex items-center justify-center border-2 border-white shadow-lg animate-pulse z-50">
                {stats.packs}
              </div>
            )}
            <div className="absolute top-0 left-0 w-full h-1 md:h-2 bg-gradient-to-r from-yellow-700 via-amber-500 to-yellow-700"></div>
            <div className="text-center">
              <div className="hidden md:flex w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-600 to-yellow-800 rounded-full items-center justify-center border-4 border-amber-400 shadow-lg">
                <ShoppingCart className="w-10 h-10 text-yellow-100" />
              </div>
              <h3 className="text-lg md:text-3xl font-bold text-yellow-900" style={{
                fontFamily: 'serif',
                textShadow: '2px 2px 4px rgba(139, 69, 19, 0.3)'
              }}>
                Shop
                {stats.packs > 0 && (
                  <span className="hidden md:inline text-purple-600 text-lg ml-2">🎁</span>
                )}
              </h3>
              <p className="hidden md:block text-yellow-700 text-sm mt-1">
                Kaufe neue Kartenpacks und erweitere deine Sammlung
                {stats.packs > 0 && (
                  <span className="text-purple-600 font-bold ml-2">• {stats.packs} kostenlose Packs!</span>
                )}
              </p>
            </div>
          </motion.div>
        </div>

        <div className="text-center mt-12">
          {/* Traditional scroll for story and tutorial */}
          <div className="bg-gradient-to-br from-amber-100 to-amber-200 p-4 rounded-lg border-3 border-amber-700 mb-6 inline-block shadow-lg">
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={() => setShowTutorial(true)}
                variant="outline"
                className="bg-gradient-to-r from-green-700 to-blue-700 border-2 border-amber-500 text-amber-100 hover:from-green-600 hover:to-blue-600 font-bold"
                style={{ fontFamily: 'serif' }}
              >
                <Play className="w-5 h-5 mr-2" />
                Tutorial starten
              </Button>
              <Button
                onClick={() => triggerShuffle(() => setGamePhase('story'))}
                variant="outline"
                className="bg-gradient-to-r from-purple-700 to-red-700 border-2 border-amber-500 text-amber-100 hover:from-purple-600 hover:to-red-600 font-bold"
                style={{ fontFamily: 'serif' }}
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Die Geschichte von GridRune
              </Button>
            </div>
          </div>
          <div className="bg-gradient-to-br from-amber-100/20 to-amber-200/20 p-4 rounded-lg border border-amber-600/50 backdrop-blur-sm">
            <p className="text-amber-200 text-sm font-semibold" style={{ fontFamily: 'serif' }}>
GridRune ist ein strategisches Kartenspiel. Platziere deine Karten geschickt, um die Karten deines Gegners zu erobern!
            </p>
          </div>
        </div>
      </div>

      {/* Tutorial Modal */}
      {showTutorial && (
        <OnboardingTutorial
          onComplete={() => {
            setShowTutorial(false);
            setShowGameModes(true); // Show game modes after tutorial completion
          }}
          onClose={() => setShowTutorial(false)}
        />
      )}

      {/* Community Leaderboard Modal */}
      {showLeaderboard && (
        <CommunityLeaderboard onBack={() => setShowLeaderboard(false)} />
      )}

      {/* Quest Hub Modal */}
      {showQuestHub && (
        <QuestHub
          isOpen={showQuestHub}
          onClose={() => setShowQuestHub(false)}
        />
      )}

      {/* Achievement Gallery Modal */}
      {showAchievementGallery && (
        <QuestAchievementShowcase
          isOpen={showAchievementGallery}
          onClose={() => setShowAchievementGallery(false)}
        />
      )}

      {/* Trading Platform Modal */}
      {showTrading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto border-4 border-amber-600 shadow-2xl">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-amber-900" style={{ fontFamily: 'serif' }}>
                  🏪 Kartenhandel
                </h2>
                <Button
                  onClick={() => setShowTrading(false)}
                  variant="outline"
                  className="bg-red-600 text-white hover:bg-red-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
              <TradingPlatform />
            </div>
          </div>
        </div>
      )}

      {/* Deck Manager Modal */}
      {showDeckManager && (
        <DeckManager
          isOpen={showDeckManager}
          onClose={() => setShowDeckManager(false)}
        />
      )}

      {/* Card Shuffle Transition */}
      <CardShuffleTransition
        isVisible={isShuffling}
        onComplete={completeShuffle}
        duration={800}
      />

      </div>
    </DynamicBackground>
  );
}