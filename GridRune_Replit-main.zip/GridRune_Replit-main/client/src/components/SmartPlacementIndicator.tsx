/**
 * Smart Placement Indicator Component
 * Shows visual placement suggestions for mobile users
 */

import React from 'react';
import { motion } from 'framer-motion';
import { PlacementSuggestion } from '../lib/smartPlacement';

interface SmartPlacementIndicatorProps {
  suggestion: PlacementSuggestion;
  isVisible: boolean;
  intensity?: number;
}

export function SmartPlacementIndicator({
  suggestion,
  isVisible,
  intensity = 1
}: SmartPlacementIndicatorProps) {
  const getIndicatorStyle = () => {
    switch (suggestion.type) {
      case 'optimal':
        return {
          borderColor: 'rgb(147, 51, 234)', // Purple
          backgroundColor: 'rgba(147, 51, 234, 0.1)',
          icon: '⭐',
          gradient: 'from-purple-500 to-pink-500'
        };
      case 'attack':
        return {
          borderColor: 'rgb(239, 68, 68)', // Red
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          icon: '⚔️',
          gradient: 'from-red-500 to-orange-500'
        };
      case 'defense':
        return {
          borderColor: 'rgb(59, 130, 246)', // Blue
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          icon: '🛡️',
          gradient: 'from-blue-500 to-cyan-500'
        };
      default:
        return {
          borderColor: 'rgb(156, 163, 175)', // Gray
          backgroundColor: 'rgba(156, 163, 175, 0.1)',
          icon: '🎯',
          gradient: 'from-gray-500 to-slate-500'
        };
    }
  };

  const style = getIndicatorStyle();
  const opacity = intensity * (suggestion.score / 100);

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ 
        scale: 1, 
        opacity: opacity,
        borderColor: style.borderColor,
        backgroundColor: style.backgroundColor
      }}
      exit={{ scale: 0, opacity: 0 }}
      className="absolute inset-0 pointer-events-none rounded-lg border-2 flex items-center justify-center"
      style={{
        borderStyle: 'dashed',
        borderWidth: '2px',
      }}
    >
      {/* Center Icon */}
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          rotate: suggestion.type === 'optimal' ? [0, 5, -5, 0] : 0
        }}
        transition={{ 
          duration: 2, 
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="text-2xl"
      >
        {style.icon}
      </motion.div>

      {/* Score Indicator */}
      <motion.div
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute -top-3 -right-3"
      >
        <div className={`
          px-2 py-1 rounded-full text-xs font-bold text-white
          bg-gradient-to-r ${style.gradient}
          shadow-lg border border-white/20
        `}>
          {Math.round(suggestion.score)}
        </div>
      </motion.div>

      {/* Expected Captures Indicator */}
      {suggestion.expectedCaptures > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute -bottom-2 left-1/2 transform -translate-x-1/2"
        >
          <div className="bg-green-600 text-white text-xs px-2 py-1 rounded-full font-bold shadow-lg">
            +{suggestion.expectedCaptures}
          </div>
        </motion.div>
      )}

      {/* Vulnerability Warning */}
      {suggestion.vulnerabilityRisk > 0.6 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="absolute -top-2 -left-2"
        >
          <div className="w-4 h-4 bg-yellow-500 rounded-full flex items-center justify-center">
            <span className="text-xs">⚠️</span>
          </div>
        </motion.div>
      )}

      {/* Pulse Effect for Optimal Placements */}
      {suggestion.type === 'optimal' && (
        <motion.div
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.3, 0, 0.3]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 rounded-lg border-2 border-purple-400"
        />
      )}
    </motion.div>
  );
}

export default SmartPlacementIndicator;