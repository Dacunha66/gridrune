import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GameCard, Rarity, RARITY_CONFIG } from '../lib/cardData';
import { Button } from './ui/button';
import { Card as CardComponent } from './Card';
import { getRarityVisualEffects } from '../lib/rarityGradients';

const demoCards: GameCard[] = [
  {
    id: 'demo-common',
    name: 'Stone Golem',
    rarity: 'common',
    element: 'earth',
    top: 3, right: 5, bottom: 4, left: 2
  },
  {
    id: 'demo-uncommon',
    name: 'Forest Guardian',
    rarity: 'uncommon',
    element: 'nature',
    top: 5, right: 3, bottom: 6, left: 4
  },
  {
    id: 'demo-rare',
    name: 'Storm Caller',
    rarity: 'rare',
    element: 'lightning',
    top: 7, right: 6, bottom: 4, left: 5
  },
  {
    id: 'demo-epic',
    name: 'Shadow Assassin',
    rarity: 'epic',
    element: 'shadow',
    top: 8, right: 7, bottom: 5, left: 6
  },
  {
    id: 'demo-legendary',
    name: 'Dragon Emperor',
    rarity: 'legendary',
    element: 'fire',
    top: 9, right: 8, bottom: 7, left: 9
  },
  {
    id: 'demo-ultimate',
    name: 'Cosmic Entity',
    rarity: 'ultimate',
    element: 'crystal',
    top: 9, right: 9, bottom: 9, left: 9
  }
];

export function RarityDemo() {
  const [selectedRarity, setSelectedRarity] = useState<Rarity>('common');
  const [showEffects, setShowEffects] = useState(true);

  const selectedCard = demoCards.find(card => card.rarity === selectedRarity);
  const rarityEffects = getRarityVisualEffects(selectedRarity);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-white">Dynamic Rarity Gradient System</h1>
        <p className="text-gray-300">Experience the enhanced visual effects for each card rarity</p>
      </div>

      {/* Rarity Selector */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {(Object.keys(RARITY_CONFIG) as Rarity[]).map((rarity) => (
          <Button
            key={rarity}
            onClick={() => setSelectedRarity(rarity)}
            variant={selectedRarity === rarity ? 'default' : 'outline'}
            className={`h-12 ${selectedRarity === rarity ? 'ring-2 ring-blue-500' : ''}`}
            style={{
              backgroundColor: selectedRarity === rarity ? RARITY_CONFIG[rarity].glowColor : undefined,
              borderColor: RARITY_CONFIG[rarity].glowColor
            }}
          >
            {RARITY_CONFIG[rarity].emoji} {RARITY_CONFIG[rarity].name}
          </Button>
        ))}
      </div>

      {/* Effects Toggle */}
      <div className="flex justify-center">
        <Button
          onClick={() => setShowEffects(!showEffects)}
          variant={showEffects ? 'default' : 'outline'}
          className="bg-purple-600 hover:bg-purple-700"
        >
          {showEffects ? '✨ Effekte aktiv' : '🚫 Effekte deaktiviert'}
        </Button>
      </div>

      {/* Card Display */}
      <div className="flex justify-center">
        <motion.div
          key={selectedRarity}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="relative"
        >
          {selectedCard && (
            <div className="transform scale-150">
              <CardComponent
                card={selectedCard}
                size="large"
                isClickable={false}
                isOnBoard={false}
                animation={showEffects ? { 
                  type: 'rarity-sparkle',
                  startTime: Date.now(),
                  duration: 3000
                } : undefined}
              />
            </div>
          )}
        </motion.div>
      </div>

      {/* Visual Effects Information */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 space-y-4">
          <h3 className="text-xl font-semibold text-white">Rarity Properties</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-300">Name:</span>
              <span className="text-white">{RARITY_CONFIG[selectedRarity].name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Intensity:</span>
              <span className="text-white">{RARITY_CONFIG[selectedRarity].intensity}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Animation:</span>
              <span className="text-white capitalize">{rarityEffects.animation.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Duration:</span>
              <span className="text-white">{rarityEffects.animation.duration}ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Particles:</span>
              <span className="text-white">{rarityEffects.particleEffect?.count || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 space-y-4">
          <h3 className="text-xl font-semibold text-white">Visual Effects</h3>
          <div className="space-y-3">
            <div>
              <span className="text-gray-300 text-sm">Background Gradient:</span>
              <div 
                className="h-8 rounded mt-1 border border-gray-600"
                style={{ background: rarityEffects.backgroundGradient.replace('bg-gradient-to-br', 'linear-gradient(135deg,') + ')' }}
              />
            </div>
            <div>
              <span className="text-gray-300 text-sm">Glow Color:</span>
              <div 
                className="h-8 rounded mt-1 border border-gray-600"
                style={{ 
                  backgroundColor: RARITY_CONFIG[selectedRarity].glowColor,
                  boxShadow: `0 0 20px ${RARITY_CONFIG[selectedRarity].glowColor}`
                }}
              />
            </div>
            {rarityEffects.particleEffect && (
              <div>
                <span className="text-gray-300 text-sm">Particle Colors:</span>
                <div className="flex gap-1 mt-1">
                  {rarityEffects.particleEffect.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-6 h-6 rounded border border-gray-600"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Multiple Cards Showcase */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-white text-center">All Rarity Levels</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 justify-items-center">
          {demoCards.map((card) => (
            <motion.div
              key={card.id}
              whileHover={{ scale: 1.05 }}
              className="transform scale-90"
            >
              <CardComponent
                card={card}
                size="small"
                isClickable={false}
                isOnBoard={false}
                animation={showEffects ? { 
                  type: 'rarity-sparkle',
                  startTime: Date.now(),
                  duration: 3000
                } : undefined}
              />
            </motion.div>
          ))}
        </div>
      </div>

      <div className="text-center text-gray-400 text-sm">
        <p>✨ Dynamic rarity gradients enhance card visual hierarchy</p>
        <p>🎨 Each rarity tier features unique animations and particle effects</p>
        <p>⚡ Real-time visual feedback based on card importance</p>
      </div>
    </div>
  );
}