import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Card } from './Card';
import { Button } from './ui/button';
import { useCardGame } from '../lib/stores/useCardGame';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { useAudio } from '../lib/stores/useAudio';
import { GameCard, createExtendedDeck } from '../lib/cardData';
import { cn } from '../lib/utils';
import { ModalBackdrop } from './ui/LayeredContainer';
import { 
  Save, 
  RotateCcw, 
  Plus, 
  Minus, 
  Search, 
  Filter, 
  SortAsc, 
  SortDesc,
  Grid3x3,
  Shuffle,
  X,
  Check,
  BookOpen,
  Trash2
} from 'lucide-react';

interface DeckManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DragState {
  isDragging: boolean;
  draggedCard: GameCard | null;
  draggedIndex: number | null;
  sourceType: 'deck' | 'collection' | null;
  offset: { x: number; y: number };
}

export function DeckManager({ isOpen, onClose }: DeckManagerProps) {
  const { 
    player1Deck, 
    setPlayer1Deck 
  } = useCardGame();
  
  const { playPlacementSound, playMagicalSelectionSound } = useAudio();
  
  // Use extended deck as available cards for deck building
  const availableCards = createExtendedDeck();
  const [currentDeck, setCurrentDeck] = useState<GameCard[]>([...player1Deck]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRarity, setSelectedRarity] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'rarity' | 'power'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [dragState, setDragState] = useState<DragState>({
    isDragging: false,
    draggedCard: null,
    draggedIndex: null,
    sourceType: null,
    offset: { x: 0, y: 0 }
  });

  const deckContainerRef = useRef<HTMLDivElement>(null);
  const collectionContainerRef = useRef<HTMLDivElement>(null);

  // Filter and sort collection
  const filteredCollection = availableCards
    .filter(card => {
      const cardName = card.name || 'Unnamed Card';
      const matchesSearch = cardName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRarity = selectedRarity === 'all' || card.rarity === selectedRarity;
      return matchesSearch && matchesRarity;
    })
    .sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          const aName = a.name || 'Unnamed Card';
          const bName = b.name || 'Unnamed Card';
          comparison = aName.localeCompare(bName);
          break;
        case 'rarity':
          const rarityOrder = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
          const aRarity = a.rarity || 'common';
          const bRarity = b.rarity || 'common';
          comparison = rarityOrder.indexOf(aRarity) - rarityOrder.indexOf(bRarity);
          break;
        case 'power':
          const aPower = a.top + a.right + a.bottom + a.left;
          const bPower = b.top + b.right + b.bottom + b.left;
          comparison = aPower - bPower;
          break;
      }
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  // Handle drag start
  const handleDragStart = (card: GameCard, index: number, sourceType: 'deck' | 'collection', event: any) => {
    playMagicalSelectionSound();
    
    const rect = event.currentTarget.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    
    setDragState({
      isDragging: true,
      draggedCard: card,
      draggedIndex: index,
      sourceType,
      offset: { x: offsetX, y: offsetY }
    });
  };

  // Handle drag end
  const handleDragEnd = (info: PanInfo) => {
    if (!dragState.draggedCard || !dragState.sourceType) return;

    const dropPoint = { x: info.point.x, y: info.point.y };
    
    // Check if dropped on deck area
    if (deckContainerRef.current) {
      const deckRect = deckContainerRef.current.getBoundingClientRect();
      const isOverDeck = (
        dropPoint.x >= deckRect.left &&
        dropPoint.x <= deckRect.right &&
        dropPoint.y >= deckRect.top &&
        dropPoint.y <= deckRect.bottom
      );

      if (isOverDeck && dragState.sourceType === 'collection') {
        // Add card to deck if there's space
        if (currentDeck.length < 5) {
          setCurrentDeck(prev => [...prev, dragState.draggedCard!]);
          playPlacementSound();
        }
      }
    }

    // Check if dropped on collection area (remove from deck)
    if (collectionContainerRef.current && dragState.sourceType === 'deck') {
      const collectionRect = collectionContainerRef.current.getBoundingClientRect();
      const isOverCollection = (
        dropPoint.x >= collectionRect.left &&
        dropPoint.x <= collectionRect.right &&
        dropPoint.y >= collectionRect.top &&
        dropPoint.y <= collectionRect.bottom
      );

      if (isOverCollection && dragState.draggedIndex !== null) {
        setCurrentDeck(prev => prev.filter((_, index) => index !== dragState.draggedIndex));
        playPlacementSound();
      }
    }

    // Reset drag state
    setDragState({
      isDragging: false,
      draggedCard: null,
      draggedIndex: null,
      sourceType: null,
      offset: { x: 0, y: 0 }
    });
  };

  // Save deck changes
  const handleSaveDeck = () => {
    setPlayer1Deck(currentDeck);
    playMagicalSelectionSound();
    onClose();
  };

  // Reset deck to original
  const handleResetDeck = () => {
    setCurrentDeck([...player1Deck]);
    playMagicalSelectionSound();
  };

  // Auto-build deck
  const handleAutoBuild = () => {
    const sortedByPower = filteredCollection
      .sort((a, b) => {
        const aPower = a.top + a.right + a.bottom + a.left;
        const bPower = b.top + b.right + b.bottom + b.left;
        return bPower - aPower;
      })
      .slice(0, 5);
    
    setCurrentDeck(sortedByPower);
    playMagicalSelectionSound();
  };

  if (!isOpen) return null;

  return (
    <ModalBackdrop onClose={onClose}>
      <div className="bg-slate-900 rounded-xl border border-slate-600 w-full max-w-6xl h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 to-indigo-900 p-4 border-b border-slate-600">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-purple-300" />
              <h2 className="text-xl font-bold text-white">Deck-Manager</h2>
              <div className="text-sm text-purple-300">
                {currentDeck.length}/5 Karten
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={handleResetDeck}
                variant="outline"
                size="sm"
                className="border-slate-500 text-slate-300"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Zurücksetzen
              </Button>
              <Button
                onClick={handleAutoBuild}
                variant="outline"
                size="sm"
                className="border-slate-500 text-slate-300"
              >
                <Shuffle className="w-4 h-4 mr-2" />
                Auto-Build
              </Button>
              <Button
                onClick={handleSaveDeck}
                className="bg-green-600 hover:bg-green-700"
                disabled={currentDeck.length === 0}
              >
                <Save className="w-4 h-4 mr-2" />
                Speichern
              </Button>
              <Button
                onClick={onClose}
                variant="outline"
                size="sm"
                className="border-slate-500 text-slate-300"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex h-full">
          {/* Current Deck */}
          <div className="w-1/3 border-r border-slate-600 p-4">
            <h3 className="text-lg font-semibold text-white mb-4 text-center">
              Aktuelles Deck
            </h3>
            
            <div 
              ref={deckContainerRef}
              className={cn(
                "min-h-[400px] border-2 border-dashed rounded-lg p-4 transition-colors",
                dragState.isDragging && dragState.sourceType === 'collection'
                  ? "border-green-400 bg-green-400/10"
                  : "border-slate-600"
              )}
            >
              <AnimatePresence>
                {currentDeck.map((card, index) => (
                  <motion.div
                    key={`${card.id}-${index}`}
                    layout
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="mb-3 cursor-grab active:cursor-grabbing"
                    drag
                    dragMomentum={false}
                    onDragStart={(event) => handleDragStart(card, index, 'deck', event)}
                    onDragEnd={(_, info) => handleDragEnd(info)}
                    whileDrag={{ scale: 1.1, rotate: 5, zIndex: 1000 }}
                  >
                    <Card 
                      card={card} 
                      size="small"
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {currentDeck.length === 0 && (
                <div className="text-center text-slate-400 mt-20">
                  <BookOpen className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Ziehe Karten hierher</p>
                  <p className="text-sm">um dein Deck zu erstellen</p>
                </div>
              )}
            </div>
          </div>

          {/* Card Collection */}
          <div className="flex-1 p-4">
            {/* Search and Filter Controls */}
            <div className="mb-4 space-y-3">
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Karten suchen..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                
                <select
                  value={selectedRarity}
                  onChange={(e) => setSelectedRarity(e.target.value)}
                  className="px-3 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="all">Alle Seltenheiten</option>
                  <option value="common">Gewöhnlich</option>
                  <option value="uncommon">Ungewöhnlich</option>
                  <option value="rare">Selten</option>
                  <option value="epic">Episch</option>
                  <option value="legendary">Legendär</option>
                </select>
                
                <select
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [newSortBy, newSortOrder] = e.target.value.split('-') as [typeof sortBy, typeof sortOrder];
                    setSortBy(newSortBy);
                    setSortOrder(newSortOrder);
                  }}
                  className="px-3 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="name-asc">Name A-Z</option>
                  <option value="name-desc">Name Z-A</option>
                  <option value="rarity-asc">Seltenheit ↑</option>
                  <option value="rarity-desc">Seltenheit ↓</option>
                  <option value="power-desc">Stärke ↓</option>
                  <option value="power-asc">Stärke ↑</option>
                </select>
              </div>
            </div>

            {/* Card Grid */}
            <div 
  ref={collectionContainerRef}
  className={cn(
    "grid gap-6 max-h-[calc(100vh-300px)] overflow-y-auto p-4 rounded-lg transition-colors",
    dragState.isDragging && dragState.sourceType === 'deck'
      ? "bg-red-400/10 border-2 border-red-400 border-dashed"
      : ""
  )}
  style={{ 
    gridTemplateColumns: 'repeat(2, 1fr)',  // Erzwingt 2 Spalten
    display: 'grid'
  }}
>
  <AnimatePresence>
    {filteredCollection.map((card: GameCard, index: number) => (
      <motion.div
        key={card.id}
        layout
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="cursor-grab active:cursor-grabbing"
        drag
        dragMomentum={false}
        onDragStart={(event) => handleDragStart(card, index, 'collection', event)}
        onDragEnd={(_, info) => handleDragEnd(info)}
        whileDrag={{ scale: 1.1, rotate: 5, zIndex: 1000 }}
        whileHover={{ scale: 1.05 }}
      >
        <Card 
          card={card} 
          size="large"  // Stellt sicher, dass die Karten größer angezeigt werden
        />
      </motion.div>
    ))}
  </AnimatePresence>
</div>
            
            {filteredCollection.length === 0 && (
              <div className="text-center text-slate-400 mt-20">
                <Filter className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Keine Karten gefunden</p>
                <p className="text-sm">Versuche andere Suchkriterien</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </ModalBackdrop>
  );
}