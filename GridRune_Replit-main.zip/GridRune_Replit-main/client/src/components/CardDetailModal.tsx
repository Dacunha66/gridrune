import React from 'react';
import { motion } from 'framer-motion';
import { GameCard, ELEMENT_COLORS, RARITY_CONFIG } from '../lib/cardData';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { X, Shield, Zap, RotateCw } from 'lucide-react';
import { CARD_EFFECTS } from '../lib/cardEffects';

interface CardDetailModalProps {
  card: GameCard | null;
  isOpen: boolean;
  onClose: () => void;
}

const getEffectIcon = (effect: string) => {
  switch (effect) {
    case 'Schild':
      return <Shield className="w-4 h-4" />;
    case 'Blitzschlag':
      return <Zap className="w-4 h-4" />;
    case 'Drehung':
      return <RotateCw className="w-4 h-4" />;
    default:
      return null;
  }
};

const getEffectDescription = (effect: string) => {
  if (effect && CARD_EFFECTS[effect as keyof typeof CARD_EFFECTS]) {
    return CARD_EFFECTS[effect as keyof typeof CARD_EFFECTS].description;
  }
  return 'Unbekannter Effekt';
};

export function CardDetailModal({ card, isOpen, onClose }: CardDetailModalProps) {
  if (!card) return null;

  const rarity = card.rarity || 'common';
  const rarityConfig = RARITY_CONFIG[rarity];
  const elementColor = card.element ? ELEMENT_COLORS[card.element] : 'text-gray-400';
  
  const getRarityDisplayName = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'Gewöhnlich';
      case 'uncommon': return 'Ungewöhnlich';
      case 'rare': return 'Selten';
      case 'epic': return 'Episch';
      case 'legendary': return 'Legendär';
      default: return rarityConfig.name;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] bg-gradient-to-b from-slate-900 via-red-950 to-black border-4 border-amber-600 p-0 overflow-y-auto shadow-2xl">
        <DialogHeader className="sr-only">
          <DialogTitle>{card.name} - Kartendetails</DialogTitle>
          <DialogDescription>Detaillierte Ansicht der Karte mit allen Werten und Effekten</DialogDescription>
        </DialogHeader>
        <div className="relative">
          {/* Traditional Japanese border pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="h-full w-full bg-gradient-to-r from-transparent via-amber-500 to-transparent transform rotate-45 scale-150"></div>
            <div className="absolute top-0 left-0 h-full w-full bg-gradient-to-l from-transparent via-red-500 to-transparent transform -rotate-45 scale-150"></div>
          </div>
          
          {/* Header with close button - samurai style */}
          <div className="absolute top-2 right-2 z-50">
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-600 to-red-700 border-2 border-amber-400 flex items-center justify-center text-white hover:from-amber-500 hover:to-red-600 transition-all shadow-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Card Display */}
          <div className="p-6">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="relative"
            >
              {/* Large Card - Samurai scroll style */}
              <div
                className="relative w-52 h-72 mx-auto border-4 shadow-2xl"
                style={{
                  borderColor: rarity === 'legendary' ? '#fbbf24' : 
                              rarity === 'epic' ? '#a855f7' :
                              rarity === 'rare' ? '#3b82f6' :
                              rarity === 'uncommon' ? '#10b981' : '#6b7280',
                  background: `linear-gradient(180deg, 
                    #f7f3e9 0%, 
                    #f0e6d2 20%, 
                    #e8d8bb 40%, 
                    #dcc7a4 60%, 
                    #d4bd96 80%, 
                    #c9af82 100%)`,
                  borderRadius: '15px 15px 8px 8px',
                  boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.3), 0 8px 32px rgba(0, 0, 0, 0.6)'
                }}
              >
                {/* Card name banner at top */}
                <div
                  className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20"
                  style={{ minWidth: 'fit-content' }}
                >
                  <div
                    className="relative px-6 py-2 text-sm font-bold border-2 whitespace-nowrap shadow-lg rounded-lg"
                    style={{
                      backgroundColor: rarity === 'legendary' ? '#fbbf24' : 
                                     rarity === 'epic' ? '#a855f7' :
                                     rarity === 'rare' ? '#3b82f6' :
                                     rarity === 'uncommon' ? '#10b981' : '#6b7280',
                      borderColor: rarity === 'legendary' ? '#d97706' : 
                                  rarity === 'epic' ? '#7c3aed' :
                                  rarity === 'rare' ? '#1d4ed8' :
                                  rarity === 'uncommon' ? '#047857' : '#374151',
                      color: rarity === 'legendary' ? '#000' : '#fff',
                      textShadow: '1px 1px 2px rgba(0,0,0,0.5)'
                    }}
                  >
                    {card.name}
                  </div>
                </div>

                {/* Traditional scroll texture background */}
                <div className="absolute inset-0 opacity-20">
                  <div className="w-full h-full bg-gradient-to-br from-amber-100 to-amber-200 rounded-lg"></div>
                  <div className="absolute inset-0 bg-gradient-radial from-transparent via-amber-900/10 to-amber-900/20 rounded-lg"></div>
                </div>

                {/* Card image with traditional frame */}
                {card.image && (
                  <div className="absolute inset-4 rounded-lg overflow-hidden border-2 border-amber-800/40 bg-gradient-to-br from-slate-100 to-slate-200">
                    <img 
                      src={card.image} 
                      alt={card.name}
                      className="w-full h-full object-cover opacity-80 mix-blend-multiply"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-amber-900/20 to-transparent"></div>
                  </div>
                )}

                {/* Rarity positioned at bottom like battle cards */}
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 z-20">
                  <div
                    className="px-4 py-1 text-sm font-bold border-2 rounded shadow-lg"
                    style={{
                      backgroundColor: rarity === 'legendary' ? '#fbbf24' : 
                                     rarity === 'epic' ? '#a855f7' :
                                     rarity === 'rare' ? '#3b82f6' :
                                     rarity === 'uncommon' ? '#10b981' : '#6b7280',
                      borderColor: rarity === 'legendary' ? '#d97706' : 
                                  rarity === 'epic' ? '#7c3aed' :
                                  rarity === 'rare' ? '#1d4ed8' :
                                  rarity === 'uncommon' ? '#047857' : '#374151',
                      color: rarity === 'legendary' ? '#000' : '#fff',
                      textShadow: '1px 1px 2px rgba(0,0,0,0.5)'
                    }}
                  >
                    {getRarityDisplayName(rarity)}
                  </div>
                </div>
              </div>


            </motion.div>

            {/* Traditional scroll details */}
            <div className="mt-6 space-y-4 bg-gradient-to-br from-amber-50 to-amber-100 p-4 rounded-lg border-2 border-amber-600 shadow-inner">
              {/* Warrior Information */}
              <div>
                <h4 className="text-amber-900 font-bold mb-3 text-lg border-b-2 border-red-800 pb-1" style={{
                  fontFamily: 'serif',
                  textShadow: '1px 1px 2px rgba(139, 69, 19, 0.3)'
                }}>
Karteninformationen
                </h4>
                <div className="space-y-3 bg-amber-100/50 p-3 rounded border border-amber-700/30">
                  <div className="flex justify-between text-sm">
                    <span className="text-amber-800 font-semibold">Name:</span>
                    <span className="text-red-900 font-bold">{card.name}</span>
                  </div>
                  {card.element && (
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-800 font-semibold">Element:</span>
                      <span className="text-red-800 font-bold">
                        {card.element === 'fire' ? '🔥 Feuer' : 
                         card.element === 'water' ? '🌊 Wasser' : 
                         card.element === 'earth' ? '🌍 Erde' : 
                         card.element === 'lightning' ? '⚡ Blitz' : '💨 Luft'}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-amber-800 font-semibold">Seltenheit:</span>
                    <Badge 
                      className="text-xs font-bold border-2 shadow-sm"
                      style={{ 
                        backgroundColor: rarity === 'legendary' ? '#fbbf24' : 
                                        rarity === 'epic' ? '#a855f7' :
                                        rarity === 'rare' ? '#3b82f6' :
                                        rarity === 'uncommon' ? '#10b981' : '#6b7280',
                        borderColor: rarity === 'legendary' ? '#d97706' : 
                                    rarity === 'epic' ? '#7c3aed' :
                                    rarity === 'rare' ? '#1d4ed8' :
                                    rarity === 'uncommon' ? '#047857' : '#374151',
                        color: rarity === 'legendary' ? '#000' : '#fff' 
                      }}
                    >
                      {getRarityDisplayName(rarity)}
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-amber-800 font-semibold">Kampfwerte:</span>
                    <div className="flex gap-2">
                      <span className="text-red-700 font-bold">⬆️ {card.top}</span>
                      <span className="text-yellow-700 font-bold">➡️ {card.right}</span>
                      <span className="text-green-700 font-bold">⬇️ {card.bottom}</span>
                      <span className="text-blue-700 font-bold">⬅️ {card.left}</span>
                    </div>
                  </div>
                </div>
              </div>



              {/* Special Technique */}
              {card.effect && (
                <>
                  <div className="h-0.5 bg-gradient-to-r from-transparent via-red-800 to-transparent"></div>
                  <div>
                    <h4 className="text-amber-900 font-bold mb-3 text-lg border-b-2 border-red-800 pb-1 flex items-center gap-2" style={{
                      fontFamily: 'serif',
                      textShadow: '1px 1px 2px rgba(139, 69, 19, 0.3)'
                    }}>
                      {getEffectIcon(card.effect)}
Spezialeffekt: {card.effect}
                    </h4>
                    <div className="bg-gradient-to-br from-red-50 to-red-100 p-4 rounded-lg border-2 border-red-700 shadow-inner">
                      <p className="text-red-900 text-sm font-medium leading-relaxed" style={{
                        textShadow: '0.5px 0.5px 1px rgba(0,0,0,0.1)'
                      }}>
                        {getEffectDescription(card.effect)}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}