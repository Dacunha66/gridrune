import { useCardGame } from "../lib/stores/useCardGame";
import { cn } from "../lib/utils";
import { useState, useEffect } from "react";

export function TurnIndicator() {
  const { 
    currentPlayer, 
    gamePhase, 
    gameMode,
    player1Name,
    player2Name,
    player1Avatar,
    player2Avatar
  } = useCardGame();

  const [isBlinking, setIsBlinking] = useState(true);

  // Stop blinking after 2 seconds when turn changes
  useEffect(() => {
    setIsBlinking(true);
    const timer = setTimeout(() => {
      setIsBlinking(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, [currentPlayer, gamePhase]);

  // Don't show during initial phases or when game is ended
  if (gamePhase !== "playing" && gamePhase !== "blitzschlag-target" && gamePhase !== "clone-target") {
    return null;
  }

  const isPlayer1Turn = currentPlayer === 1;
  const currentPlayerName = isPlayer1Turn 
    ? (gameMode === 'ai' ? 'Du' : (player1Name || 'Spieler 1'))
    : (gameMode === 'ai' ? 'KI' : (player2Name || 'Spieler 2'));
  
  const currentAvatar = isPlayer1Turn ? player1Avatar : player2Avatar;

  return (
    <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
      <div className={cn(
        "relative w-12 h-12 sm:w-16 sm:h-16 rounded-full shadow-2xl transition-all duration-500 border-2 sm:border-4",
        isBlinking ? "animate-pulse" : "",
        isPlayer1Turn 
          ? "bg-blue-600/90 border-blue-300" 
          : "bg-red-600/90 border-red-300"
      )}>
        {/* Player Avatar */}
        <div className="absolute inset-1 sm:inset-2 rounded-full overflow-hidden flex items-center justify-center text-lg sm:text-2xl bg-white/10 backdrop-blur-sm">
          {currentAvatar.emoji}
        </div>
        
        {/* Status indicator dot for special effects */}
        {(gamePhase === "blitzschlag-target" || gamePhase === "clone-target") && (
          <div className="absolute -top-0.5 -right-0.5 sm:-top-1 sm:-right-1 w-4 h-4 sm:w-5 sm:h-5 bg-yellow-400 rounded-full border border-white sm:border-2 flex items-center justify-center animate-bounce">
            <div className="text-xs">
              {gamePhase === "blitzschlag-target" ? "⚡" : "👥"}
            </div>
          </div>
        )}
      </div>

      {/* Glowing effect - only when blinking */}
      {isBlinking && (
        <div className={cn(
          "absolute inset-0 rounded-full opacity-30 animate-ping",
          isPlayer1Turn 
            ? "bg-blue-400" 
            : "bg-red-400"
        )} />
      )}
    </div>
  );
}