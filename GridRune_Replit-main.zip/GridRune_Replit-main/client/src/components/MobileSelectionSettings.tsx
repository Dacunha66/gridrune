/**
 * Mobile Selection Settings Component
 * Allows users to customize mobile card selection behavior
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Volume2, VolumeX, Smartphone, Brain, Target } from 'lucide-react';
import { mobileCardSelector } from '../lib/mobileCardSelection';
import { hapticFeedback } from '../lib/hapticFeedback';

interface MobileSelectionSettingsProps {
  isVisible: boolean;
  onClose: () => void;
}

export function MobileSelectionSettings({
  isVisible,
  onClose
}: MobileSelectionSettingsProps) {
  const [settings, setSettings] = useState({
    enableQuickSelect: true,
    enablePreview: true,
    enableSmartPlacement: true,
    enableGestureShortcuts: true,
    hapticIntensity: 1,
    confirmationDelay: 1200,
    longPressDuration: 400,
    showTutorial: true
  });

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('mobileCardSelectionSettings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...settings, ...parsed });
      } catch (e) {
        console.warn('Failed to parse mobile selection settings');
      }
    }
  }, []);

  // Save settings to localStorage and update mobile card selector
  const updateSettings = (newSettings: Partial<typeof settings>) => {
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);
    localStorage.setItem('mobileCardSelectionSettings', JSON.stringify(updatedSettings));
    
    // Update mobile card selector settings
    mobileCardSelector.updateSettings({
      enableQuickSelect: updatedSettings.enableQuickSelect,
      enablePreview: updatedSettings.enablePreview,
      enableSmartPlacement: updatedSettings.enableSmartPlacement,
      enableGestureShortcuts: updatedSettings.enableGestureShortcuts,
      confirmationDelay: updatedSettings.confirmationDelay,
      longPressDuration: updatedSettings.longPressDuration
    });
  };

  const testHaptic = (intensity: 'light' | 'medium' | 'heavy') => {
    switch (intensity) {
      case 'light':
        hapticFeedback.light();
        break;
      case 'medium':
        hapticFeedback.medium();
        break;
      case 'heavy':
        hapticFeedback.heavy();
        break;
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-slate-900 rounded-xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto border border-slate-600"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Mobile Einstellungen
              </h2>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white"
              >
                ×
              </button>
            </div>

            <div className="space-y-6">
              {/* Quick Features */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Schnellauswahl
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Schnellauswahl aktivieren</span>
                    <button
                      onClick={() => updateSettings({ enableQuickSelect: !settings.enableQuickSelect })}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.enableQuickSelect ? 'bg-blue-500' : 'bg-slate-600'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                        settings.enableQuickSelect ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Kartenvorschau</span>
                    <button
                      onClick={() => updateSettings({ enablePreview: !settings.enablePreview })}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.enablePreview ? 'bg-blue-500' : 'bg-slate-600'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                        settings.enablePreview ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Gesten-Shortcuts</span>
                    <button
                      onClick={() => updateSettings({ enableGestureShortcuts: !settings.enableGestureShortcuts })}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings.enableGestureShortcuts ? 'bg-blue-500' : 'bg-slate-600'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                        settings.enableGestureShortcuts ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Smart Placement */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  Intelligente Platzierung
                </h3>
                <div className="flex items-center justify-between">
                  <span className="text-slate-300">Platzierungshilfen anzeigen</span>
                  <button
                    onClick={() => updateSettings({ enableSmartPlacement: !settings.enableSmartPlacement })}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      settings.enableSmartPlacement ? 'bg-purple-500' : 'bg-slate-600'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      settings.enableSmartPlacement ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
              </div>

              {/* Timing Settings */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3">Zeiteinstellungen</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-slate-300 mb-2">
                      Bestätigungsverzögerung: {settings.confirmationDelay}ms
                    </label>
                    <input
                      type="range"
                      min="500"
                      max="2000"
                      step="100"
                      value={settings.confirmationDelay}
                      onChange={(e) => updateSettings({ confirmationDelay: parseInt(e.target.value) })}
                      className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-slate-300 mb-2">
                      Lang-Drück-Dauer: {settings.longPressDuration}ms
                    </label>
                    <input
                      type="range"
                      min="200"
                      max="800"
                      step="50"
                      value={settings.longPressDuration}
                      onChange={(e) => updateSettings({ longPressDuration: parseInt(e.target.value) })}
                      className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Haptic Feedback */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3">Haptisches Feedback</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-slate-300 mb-2">
                      Intensität: {Math.round(settings.hapticIntensity * 100)}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={settings.hapticIntensity}
                      onChange={(e) => updateSettings({ hapticIntensity: parseFloat(e.target.value) })}
                      className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => testHaptic('light')}
                      className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 px-3 rounded text-sm"
                    >
                      Leicht
                    </button>
                    <button
                      onClick={() => testHaptic('medium')}
                      className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 px-3 rounded text-sm"
                    >
                      Mittel
                    </button>
                    <button
                      onClick={() => testHaptic('heavy')}
                      className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 px-3 rounded text-sm"
                    >
                      Stark
                    </button>
                  </div>
                </div>
              </div>

              {/* Tutorial */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3">Tutorial</h3>
                <button
                  onClick={() => {
                    localStorage.removeItem('mobileCardSelectionGuide');
                    updateSettings({ showTutorial: true });
                    onClose();
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded"
                >
                  Tutorial erneut anzeigen
                </button>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-600">
              <button
                onClick={onClose}
                className="w-full bg-slate-700 hover:bg-slate-600 text-white py-2 px-4 rounded"
              >
                Schließen
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default MobileSelectionSettings;