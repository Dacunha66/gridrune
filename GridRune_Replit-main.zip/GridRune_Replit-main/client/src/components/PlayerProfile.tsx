import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import QuestAchievementShowcase from './QuestAchievementShowcase';
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { PlayerBadgeShowcase } from './PlayerBadgeShowcase';
import { BadgeCollection } from './AchievementBadge';
import { useBadges } from '../lib/stores/useBadges';
import { Progress } from "./ui/progress";
import { 
  User, 
  Trophy, 
  Target, 
  Calendar, 
  TrendingUp, 
  Award, 
  Star, 
  Crown, 
  Zap,
  ArrowLeft,
  Edit3,
  Save,
  X,
  Users
} from "lucide-react";
import { useAuth } from "../lib/stores/useAuth";
import { AvatarDisplay } from "./AvatarSelector";
import { AVAILABLE_AVATARS } from "./AvatarCustomization";
import { CommunityLeaderboard } from "./CommunityLeaderboard";

interface Achievement {
  id: number;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string;
}

interface PlayerStat {
  statType: string;
  value: number;
}

interface GameHistoryEntry {
  id: number;
  opponent: string;
  result: 'win' | 'loss' | 'draw';
  gameMode: string;
  boardSize: string;
  playedAt: string;
}

export function PlayerProfile({ onBack }: { onBack: () => void }) {
  const { user, updateProfile, isLoading, isGuest } = useAuth();
  const { badges, getUnlockedBadges, playerStats } = useBadges();
  const [isEditing, setIsEditing] = useState(false);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [stats, setStats] = useState<PlayerStat[]>([]);
  const [gameHistory, setGameHistory] = useState<GameHistoryEntry[]>([]);
  const [showAchievementGallery, setShowAchievementGallery] = useState(false);
  const [showBadgeShowcase, setShowBadgeShowcase] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [editForm, setEditForm] = useState({
    displayName: user?.displayName || "",
    favoriteAvatar: user?.favoriteAvatar || "warrior"
  });

  useEffect(() => {
    if (user && !isGuest) {
      loadPlayerData();
    } else if (isGuest) {
      // Set empty data for guest users
      setAchievements([]);
      setStats([]);
      setGameHistory([]);
    }
  }, [user, isGuest]);

  const loadPlayerData = async () => {
    try {
      // Load achievements
      const achievementsRes = await fetch('/api/player/achievements', {
        credentials: 'include'
      });
      if (achievementsRes.ok) {
        setAchievements(await achievementsRes.json());
      }

      // Load stats
      const statsRes = await fetch('/api/player/stats', {
        credentials: 'include'
      });
      if (statsRes.ok) {
        setStats(await statsRes.json());
      }

      // Load game history
      const historyRes = await fetch('/api/player/history', {
        credentials: 'include'
      });
      if (historyRes.ok) {
        setGameHistory(await historyRes.json());
      }
    } catch (error) {
      console.error('Error loading player data:', error);
    }
  };

  const handleSaveProfile = async () => {
    await updateProfile(editForm);
    setIsEditing(false);
  };

  const getExperienceForLevel = (level: number) => {
    return level * 1000; // 1000 XP per level
  };

  const getProgressToNextLevel = () => {
    if (!user) return 0;
    const currentLevelXP = getExperienceForLevel(user.level - 1);
    const nextLevelXP = getExperienceForLevel(user.level);
    const progress = ((user.experience - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
    return Math.max(0, Math.min(100, progress));
  };

  const getWinRate = () => {
    if (!user || user.totalGames === 0) return 0;
    return Math.round((user.totalWins / user.totalGames) * 100);
  };

  const getStatValue = (statType: string) => {
    const stat = stats.find(s => s.statType === statType);
    return stat?.value || 0;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  if (!user) {
    return null;
  }

  if (showAchievementGallery) {
    return (
      <QuestAchievementShowcase 
        isOpen={true} 
        onClose={() => setShowAchievementGallery(false)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={onBack}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zum Menü
          </Button>
          
          <div className="text-center">
            <h1 className="text-3xl font-bold">Spielerprofil</h1>
            {isGuest && (
              <p className="text-sm text-yellow-400 mt-1">Gast-Modus</p>
            )}
          </div>
          
          <div className="flex space-x-2">
            <Button
              onClick={() => setShowAchievementGallery(true)}
              variant="outline"
              className="bg-gradient-to-br from-purple-600 to-violet-700 border-2 border-purple-400 text-purple-100 hover:from-purple-500 hover:to-violet-600 font-semibold"
            >
              <Trophy className="w-4 h-4 mr-2" />
              Erfolge
            </Button>
            <Button
              onClick={() => setShowBadgeShowcase(true)}
              variant="outline"
              className="bg-gradient-to-br from-amber-600 to-orange-700 border-2 border-amber-400 text-amber-100 hover:from-amber-500 hover:to-orange-600 font-semibold"
            >
              <Award className="w-4 h-4 mr-2" />
              Abzeichen
            </Button>
            <Button
              onClick={() => setShowLeaderboard(true)}
              variant="outline"
              className="bg-gradient-to-br from-blue-600 to-cyan-700 border-2 border-blue-400 text-blue-100 hover:from-blue-500 hover:to-cyan-600 font-semibold"
            >
              <Users className="w-4 h-4 mr-2" />
              Community
            </Button>
            <Button
              onClick={() => setIsEditing(!isEditing)}
              variant="outline"
              className="text-white border-slate-600 hover:bg-slate-700"
            >
              {isEditing ? (
                <>
                  <X className="w-4 h-4 mr-2" />
                  Abbrechen
                </>
              ) : (
                <>
                  <Edit3 className="w-4 h-4 mr-2" />
                  Bearbeiten
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Profile Overview */}
        <Card className="bg-slate-800 border-slate-600 mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              {/* Avatar */}
              <div className="relative">
                <AvatarDisplay 
                  avatar={AVAILABLE_AVATARS.find(a => a.id === user.favoriteAvatar) || AVAILABLE_AVATARS[0]}
                  size="large"
                  showName={false}
                />
                <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-1">
                  <Crown className="w-4 h-4 text-yellow-900" />
                </div>
              </div>

              {/* Basic Info */}
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white">Anzeigename</Label>
                      <Input
                        value={editForm.displayName}
                        onChange={(e) => setEditForm(prev => ({ ...prev, displayName: e.target.value }))}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Lieblings-Avatar</Label>
                      <select
                        value={editForm.favoriteAvatar}
                        onChange={(e) => setEditForm(prev => ({ ...prev, favoriteAvatar: e.target.value }))}
                        className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-white"
                      >
                        {AVAILABLE_AVATARS.map(avatar => (
                          <option key={avatar.id} value={avatar.id}>
                            {avatar.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <Button 
                      onClick={handleSaveProfile}
                      disabled={isLoading}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {isLoading ? "Speichern..." : "Speichern"}
                    </Button>
                  </div>
                ) : (
                  <>
                    <h2 className="text-2xl font-bold text-white mb-2">{user.displayName}</h2>
                    <p className="text-slate-300 mb-1">@{user.username}</p>
                    <div className="flex items-center space-x-4 mb-4">
                      <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                        <Star className="w-3 h-3 mr-1" />
                        Level {user.level}
                      </Badge>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        <Zap className="w-3 h-3 mr-1" />
                        {user.experience} XP
                      </Badge>
                      {!isGuest && (
                        <Badge variant="outline" className="text-blue-400 border-blue-400">
                          Mitglied seit {formatDate(user.createdAt)}
                        </Badge>
                      )}
                      {isGuest && (
                        <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                          Gast-Modus
                        </Badge>
                      )}
                    </div>
                    
                    {/* Badge Collection Preview */}
                    <div className="mt-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-semibold text-white">Abzeichen</h4>
                        <button
                          onClick={() => setShowBadgeShowcase(true)}
                          className="text-xs text-blue-400 hover:text-blue-300"
                        >
                          Alle ansehen
                        </button>
                      </div>
                      <BadgeCollection
                        badges={badges}
                        maxDisplay={4}
                        size="small"
                        onBadgeClick={() => setShowBadgeShowcase(true)}
                      />
                    </div>
                    
                    {/* Level Progress */}
                    <div>
                      <div className="flex justify-between text-sm text-slate-300 mb-1">
                        <span>Level {user.level}</span>
                        <span>Level {user.level + 1}</span>
                      </div>
                      <Progress value={getProgressToNextLevel()} className="h-2" />
                      <p className="text-xs text-slate-400 mt-1">
                        {Math.round(getProgressToNextLevel())}% zum nächsten Level
                      </p>
                    </div>
                  </>
                )}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-slate-700 rounded-lg p-4">
                  <div className="text-2xl font-bold text-green-400">{user.totalWins}</div>
                  <div className="text-sm text-slate-300">Siege</div>
                </div>
                <div className="bg-slate-700 rounded-lg p-4">
                  <div className="text-2xl font-bold text-blue-400">{getWinRate()}%</div>
                  <div className="text-sm text-slate-300">Siegrate</div>
                </div>
                <div className="bg-slate-700 rounded-lg p-4">
                  <div className="text-2xl font-bold text-purple-400">{user.bestWinStreak}</div>
                  <div className="text-sm text-slate-300">Beste Serie</div>
                </div>
                <div className="bg-slate-700 rounded-lg p-4">
                  <div className="text-2xl font-bold text-yellow-400">{user.totalGames}</div>
                  <div className="text-sm text-slate-300">Spiele</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Information */}
        <Tabs defaultValue="badges" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="badges" className="text-white data-[state=active]:bg-slate-700">
              <Award className="w-4 h-4 mr-2" />
              Abzeichen
            </TabsTrigger>
            <TabsTrigger value="achievements" className="text-white data-[state=active]:bg-slate-700">
              <Trophy className="w-4 h-4 mr-2" />
              Erfolge
            </TabsTrigger>
            <TabsTrigger value="statistics" className="text-white data-[state=active]:bg-slate-700">
              <TrendingUp className="w-4 h-4 mr-2" />
              Statistiken
            </TabsTrigger>
            <TabsTrigger value="history" className="text-white data-[state=active]:bg-slate-700">
              <Calendar className="w-4 h-4 mr-2" />
              Spielverlauf
            </TabsTrigger>
          </TabsList>

          <TabsContent value="badges" className="mt-6">
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">Meine Abzeichen</CardTitle>
                  <div className="text-sm text-slate-400">
                    {getUnlockedBadges().length} / {badges.length} freigeschaltet
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isGuest ? (
                  <div className="text-center py-8">
                    <Award className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-400">Abzeichen sind im Gast-Modus nicht verfügbar</p>
                    <p className="text-slate-500 text-sm mt-2">Registriere dich, um deinen Fortschritt zu verfolgen!</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Progress Overview */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-slate-700 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-yellow-400">{getUnlockedBadges().length}</div>
                        <div className="text-sm text-slate-300">Freigeschaltet</div>
                      </div>
                      <div className="bg-slate-700 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-green-400">{playerStats.totalWins}</div>
                        <div className="text-sm text-slate-300">Siege</div>
                      </div>
                      <div className="bg-slate-700 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-blue-400">{playerStats.longestWinStreak}</div>
                        <div className="text-sm text-slate-300">Beste Serie</div>
                      </div>
                      <div className="bg-slate-700 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-purple-400">{playerStats.totalCards}</div>
                        <div className="text-sm text-slate-300">Karten</div>
                      </div>
                    </div>

                    {/* Badge Collection */}
                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold text-white">Alle Abzeichen</h3>
                        <Button
                          onClick={() => setShowBadgeShowcase(true)}
                          variant="outline"
                          size="sm"
                          className="text-blue-400 border-blue-400 hover:bg-blue-400 hover:text-white"
                        >
                          Details anzeigen
                        </Button>
                      </div>
                      <BadgeCollection
                        badges={badges}
                        maxDisplay={12}
                        size="medium"
                        onBadgeClick={() => setShowBadgeShowcase(true)}
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="mt-6">
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white">Errungenschaften</CardTitle>
              </CardHeader>
              <CardContent>
                {isGuest ? (
                  <div className="text-center py-8">
                    <Award className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-400">Errungenschaften sind im Gast-Modus nicht verfügbar</p>
                    <p className="text-slate-500 text-sm mt-2">Registriere dich, um deinen Fortschritt zu speichern!</p>
                  </div>
                ) : achievements.length === 0 ? (
                  <div className="text-center py-8">
                    <Award className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-400">Noch keine Errungenschaften freigeschaltet</p>
                    <p className="text-slate-500 text-sm mt-2">Spiele mehr, um Erfolge zu erzielen!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {achievements.map((achievement) => (
                      <div 
                        key={achievement.id}
                        className="bg-slate-700 rounded-lg p-4 border border-slate-600"
                      >
                        <div className="flex items-center mb-2">
                          <div className="text-2xl mr-3">{achievement.icon}</div>
                          <div>
                            <h3 className="font-semibold text-white">{achievement.title}</h3>
                            <p className="text-sm text-slate-300">{achievement.description}</p>
                          </div>
                        </div>
                        <p className="text-xs text-slate-400">
                          Freigeschaltet am {formatDate(achievement.unlockedAt)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="statistics" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-600">
                <CardHeader>
                  <CardTitle className="text-white">Kampf-Statistiken</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Karten gespielt:</span>
                    <span className="text-white font-semibold">{getStatValue('cards_played')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Kämpfe gewonnen:</span>
                    <span className="text-white font-semibold">{getStatValue('battles_won')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Effekte ausgelöst:</span>
                    <span className="text-white font-semibold">{getStatValue('effects_triggered')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Karten erobert:</span>
                    <span className="text-white font-semibold">{getStatValue('cards_captured')}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-600">
                <CardHeader>
                  <CardTitle className="text-white">Spiel-Statistiken</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Aktuelle Serie:</span>
                    <span className="text-white font-semibold">{user.winStreak}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Niederlagen:</span>
                    <span className="text-white font-semibold">{user.totalLosses}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Durchschnittliche Spieldauer:</span>
                    <span className="text-white font-semibold">{getStatValue('avg_game_duration')} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Lieblings-Boardgröße:</span>
                    <span className="text-white font-semibold">{getStatValue('favorite_board_size') || '3x3'}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white">Letzte Spiele</CardTitle>
              </CardHeader>
              <CardContent>
                {isGuest ? (
                  <div className="text-center py-8">
                    <Calendar className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-400">Spielverlauf ist im Gast-Modus nicht verfügbar</p>
                    <p className="text-slate-500 text-sm mt-2">Registriere dich, um deinen Spielverlauf zu verfolgen!</p>
                  </div>
                ) : gameHistory.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-400">Noch keine Spiele gespielt</p>
                    <p className="text-slate-500 text-sm mt-2">Starte dein erstes Spiel!</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {gameHistory.slice(0, 10).map((game) => (
                      <div 
                        key={game.id}
                        className="flex items-center justify-between bg-slate-700 rounded-lg p-4"
                      >
                        <div className="flex items-center space-x-4">
                          <div className={`w-3 h-3 rounded-full ${
                            game.result === 'win' ? 'bg-green-400' : 
                            game.result === 'loss' ? 'bg-red-400' : 'bg-yellow-400'
                          }`} />
                          <div>
                            <p className="text-white font-medium">
                              vs {game.opponent}
                            </p>
                            <p className="text-sm text-slate-300">
                              {game.gameMode} • {game.boardSize}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant={game.result === 'win' ? 'default' : 'secondary'}
                            className={
                              game.result === 'win' ? 'bg-green-600' : 
                              game.result === 'loss' ? 'bg-red-600' : 'bg-yellow-600'
                            }
                          >
                            {game.result === 'win' ? 'Sieg' : 
                             game.result === 'loss' ? 'Niederlage' : 'Unentschieden'}
                          </Badge>
                          <p className="text-xs text-slate-400 mt-1">
                            {formatDate(game.playedAt)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Achievement Gallery Modal */}
      {showAchievementGallery && (
        <QuestAchievementShowcase
          isOpen={showAchievementGallery}
          onClose={() => setShowAchievementGallery(false)}
        />
      )}

      {/* Badge Showcase Modal */}
      {showBadgeShowcase && (
        <PlayerBadgeShowcase
          isOpen={showBadgeShowcase}
          onClose={() => setShowBadgeShowcase(false)}
        />
      )}

      {/* Community Leaderboard Modal */}
      {showLeaderboard && (
        <CommunityLeaderboard onBack={() => setShowLeaderboard(false)} />
      )}
    </div>
  );
}