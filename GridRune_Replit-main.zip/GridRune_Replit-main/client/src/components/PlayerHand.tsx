import { useCardGame } from "../lib/stores/useCardGame";
import { useAudio } from "../lib/stores/useAudio";
import { Card } from "./Card";
import { cn } from "../lib/utils";
import { useState, useRef, useEffect } from "react";
import { motion, PanInfo } from "framer-motion";
import { DragDropManager, calculateDragDistance } from "../lib/dragAndDrop";

interface PlayerHandProps {
  player: 1 | 2;
}

export function PlayerHand({ player }: PlayerHandProps) {
  const {
    player1Hand,
    player2Hand,
    selectedCard,
    selectCard,
    currentPlayer,
    gamePhase,
    gameMode,
    updateValidPlacementSlots,
    startCardDrag,
    updateDragPosition,
    endCardDrag,
    dragState
  } = useCardGame();
  
  const { playMagicalSelectionSound } = useAudio();

  // Use dynamic arrangement if enabled
  const { getArrangedHand, dynamicArrangementEnabled } = useCardGame();
  const originalHand = player === 1 ? player1Hand : player2Hand;
  const hand = dynamicArrangementEnabled 
    ? getArrangedHand(player) 
    : originalHand;
  const isCurrentPlayer = currentPlayer === player;
  const playerName = player === 1 ? "Blue Player" : "Red Player";
  const playerColor = player === 1 ? "text-blue-400" : "text-red-400";
  const isAIPlayer = gameMode === 'ai' && player === 2;

  // Mobile state
  const [isMobile, setIsMobile] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768); // md breakpoint
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Reset card index if it's out of bounds (when cards are played)
  useEffect(() => {
    if (currentCardIndex >= hand.length && hand.length > 0) {
      setCurrentCardIndex(Math.max(0, hand.length - 4));
    }
  }, [hand.length, currentCardIndex]);

  const handleCardClick = (index: number) => {
    if (isCurrentPlayer && gamePhase === "playing") {
      console.log(`🃏 Player ${player} selecting card ${index}: ${hand[index]?.name}`);
      console.log(`🔍 Current selectedCard before selection:`, selectedCard);
      
      // Sound disabled per user request
      
      selectCard(player, index);
      setTimeout(() => updateValidPlacementSlots(), 50);
    }
  };

  // Drag to board handlers
  const handleCardDragStart = (index: number, event: PointerEvent) => {
    if (!isCurrentPlayer || gamePhase !== "playing") return;
    
    const startPos = { x: event.clientX, y: event.clientY };
    setCardDragState({
      startPosition: startPos,
      isDragToBoard: false
    });
    
    startCardDrag(hand[index], index, player, startPos);
  };

  const handleCardDragMove = (event: PointerEvent) => {
    if (!dragState.isDragging || !cardDragState.startPosition) return;
    
    const currentPos = { x: event.clientX, y: event.clientY };
    const distance = calculateDragDistance(cardDragState.startPosition, currentPos);
    
    // If dragged more than 30px, consider it a drag to board
    if (distance > 30 && !cardDragState.isDragToBoard) {
      setCardDragState(prev => ({ ...prev, isDragToBoard: true }));
    }
    
    updateDragPosition(currentPos);
  };

  const handleCardDragEnd = () => {
    if (dragState.isDragging) {
      endCardDrag();
    }
    setCardDragState({
      startPosition: null,
      isDragToBoard: false
    });
  };

  // Mobile swipe navigation
  const nextCard = () => {
    if (currentCardIndex < hand.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
    }
  };

  const previousCard = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1);
    }
  };

  // Enhanced real-time drag with seamless card updates
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartTime, setDragStartTime] = useState(0);
  const [lastDragVelocity, setLastDragVelocity] = useState(0);
  
  // Drag and drop manager
  const [dragManager] = useState(() => new DragDropManager());
  const [cardDragState, setCardDragState] = useState<{
    startPosition: { x: number; y: number } | null;
    isDragToBoard: boolean;
  }>({
    startPosition: null,
    isDragToBoard: false
  });

  const handleDragStart = () => {
    setIsDragging(true);
    setDragStartTime(Date.now());
    setLastDragVelocity(0);
  };

  const handleDrag = (event: any, info: PanInfo) => {
    setDragOffset(info.offset.x);
    setLastDragVelocity(info.velocity.x);
  };

  const handleDragEnd = (event: any, info: PanInfo) => {
    setIsDragging(false);
    setDragOffset(0);
    
    const offset = info.offset.x;
    const velocity = info.velocity.x;
    const dragDuration = Date.now() - dragStartTime;
    
    // More conservative thresholds for stable behavior
    const cardWidth = 70;
    const minimumDragThreshold = 25; // Higher threshold to prevent accidental swipes
    const velocityThreshold = 200; // Higher velocity threshold
    
    // Calculate target index with simpler, more stable logic
    let targetIndex = currentCardIndex;
    
    // Only change card if drag is significant enough
    if (Math.abs(offset) > minimumDragThreshold) {
      if (offset < -minimumDragThreshold && currentCardIndex < hand.length - 1) {
        targetIndex = currentCardIndex + 1; // Swipe left -> next card
      } else if (offset > minimumDragThreshold && currentCardIndex > 0) {
        targetIndex = currentCardIndex - 1; // Swipe right -> previous card
      }
    }
    
    // Velocity-based navigation only for clear fast swipes
    if (Math.abs(velocity) > velocityThreshold && Math.abs(offset) > 10) {
      if (velocity < -velocityThreshold && currentCardIndex < hand.length - 1) {
        targetIndex = currentCardIndex + 1;
      } else if (velocity > velocityThreshold && currentCardIndex > 0) {
        targetIndex = currentCardIndex - 1;
      }
    }
    
    // Only update if there's a meaningful change
    if (targetIndex !== currentCardIndex) {
      setCurrentCardIndex(targetIndex);
    }
  };

  // Calculate dynamic card offset for continuous scrolling with centering
  const getCardOffset = () => {
    const cardWidth = 70;
    const containerWidth = window.innerWidth - 32; // Account for padding
    const cardsVisibleWidth = hand.length * cardWidth + (hand.length - 1) * 16; // Cards + gaps
    const extraPadding = 60; // Extra space to ensure last card is fully accessible
    const centeringOffset = (containerWidth - cardsVisibleWidth - extraPadding) / 2;
    
    if (!isDragging) {
      return centeringOffset - currentCardIndex * cardWidth;
    }
    
    // Apply drag offset for smooth real-time movement
    const baseOffset = centeringOffset - currentCardIndex * cardWidth;
    return baseOffset + dragOffset;
  };

  // Calculate enhanced dynamic drag constraints with seamless boundaries
  const getDragConstraints = () => {
    const cardWidth = 70;
    const containerWidth = window.innerWidth - 32;
    const totalCardsWidth = hand.length * cardWidth + (hand.length - 1) * 16;
    
    // Calculate maximum drag distances based on card positions
    const maxLeftOffset = currentCardIndex * cardWidth;
    const maxRightOffset = Math.max(0, (hand.length - currentCardIndex - 1) * cardWidth);
    
    // Conservative padding for stable behavior
    const basePadding = 40; // Reduced base padding
    const edgePadding = 15; // Minimal edge padding
    
    // Simple padding calculation
    const leftPadding = basePadding;
    const rightPadding = basePadding;
    
    // Conservative constraints to prevent unwanted movement
    const maxLeftDrag = Math.min(maxRightOffset + rightPadding, containerWidth * 0.3);
    const maxRightDrag = Math.min(maxLeftOffset + leftPadding, containerWidth * 0.3);
    
    return {
      left: -maxLeftDrag,
      right: maxRightDrag
    };
  };

  return (
    <div className={cn(
      "relative h-full",
      isMobile ? "p-0 z-20" : "p-2 sm:p-4 z-30"
    )} style={{ overflow: isMobile ? 'visible' : 'auto' }}>
      
      {/* Only show player name on desktop */}
      {!isMobile && (
        <h3 className={cn("text-xs font-bold mb-1 text-center", playerColor)}>
          {gameMode === 'ai' ? (player === 1 ? "Du" : "KI") : playerName}
          {isCurrentPlayer && gamePhase === "playing" && (
            <span className="text-xs text-white/70"> • Dein Zug</span>
          )}
        </h3>
      )}

      {/* Mobile Hand Cards - 5 Cards with Seamless Swipe Navigation */}
      {isMobile && !isAIPlayer ? (
        <div className="flex flex-col items-center space-y-1 h-[120px] relative">
          {/* Swipe Indicators */}
          <div className="absolute left-2 top-1/2 -translate-y-1/2 z-10">
            <motion.div
              className="w-6 h-6 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center"
              animate={{
                opacity: currentCardIndex > 0 ? [0.4, 0.8, 0.4] : 0.2,
                scale: currentCardIndex > 0 ? [1, 1.1, 1] : 0.8,
              }}
              transition={{
                duration: 2,
                repeat: currentCardIndex > 0 ? Infinity : 0,
                ease: "easeInOut"
              }}
            >
              <span className="text-xs text-white/70">←</span>
            </motion.div>
          </div>
          
          <div className="absolute right-2 top-1/2 -translate-y-1/2 z-10">
            <motion.div
              className="w-6 h-6 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center"
              animate={{
                opacity: currentCardIndex < hand.length - 1 ? [0.4, 0.8, 0.4] : 0.2,
                scale: currentCardIndex < hand.length - 1 ? [1, 1.1, 1] : 0.8,
              }}
              transition={{
                duration: 2,
                repeat: currentCardIndex < hand.length - 1 ? Infinity : 0,
                ease: "easeInOut"
              }}
            >
              <span className="text-xs text-white/70">→</span>
            </motion.div>
          </div>



          {/* Main card display area with enhanced swipe support */}
          <div className="w-full overflow-visible px-2 py-4 h-full flex items-center justify-center">
            <motion.div 
              className="flex gap-4 cursor-grab active:cursor-grabbing select-none"
              style={{ 
                transform: `translateX(${getCardOffset()}px)`,
                width: `${hand.length * 70 + 120}px`, // Extra width to ensure last card accessibility
                filter: isDragging ? 'drop-shadow(0 8px 16px rgba(0,0,0,0.3))' : 'none'
              }}
              drag="x"
              dragConstraints={getDragConstraints()}
              dragElastic={{
                top: 0,
                bottom: 0,
                left: 0.05, // Reduced elastic for more stable behavior
                right: 0.05
              }}
              dragMomentum={false} // Disable momentum to prevent unwanted movement
              dragTransition={{
                bounceStiffness: 600,
                bounceDamping: 60,
                power: 0.1,
                timeConstant: 100
              }}
              onDragStart={handleDragStart}
              onDrag={handleDrag}
              onDragEnd={handleDragEnd}
              whileDrag={{ 
                cursor: "grabbing",
                scale: 1.02, // Subtle scale for tactile feedback
                transition: { duration: 0.1 }
              }}
              whileTap={{
                scale: 0.98
              }}
              transition={{
                type: "spring",
                stiffness: 300, // Reduced for more stable positioning
                damping: 50,    // Increased damping for less vibration
                mass: 1,        // Normal mass for stable behavior
                velocity: 0     // No velocity inheritance to prevent unwanted movement
              }}
            >
            {/* Enhanced card display with seamless swiping feedback */}
            {hand.map((card, cardIndex) => (
              <motion.div 
                key={`mobile-${cardIndex}`} 
                className="flex-shrink-0 relative"
                whileHover={{ 
                  scale: 1.02,
                  y: -1,
                  transition: { duration: 0.3 }
                }}
                whileTap={{ 
                  scale: 0.98,
                  transition: { duration: 0.15 }
                }}
                animate={{
                  // Stable positioning without excessive animation
                  scale: isDragging && cardIndex === currentCardIndex ? 1.03 : 1,
                  y: isDragging && cardIndex === currentCardIndex ? -2 : 0,
                  opacity: 1 // Always keep cards fully visible
                }}
                transition={{
                  type: "spring",
                  stiffness: 200,
                  damping: 35
                }}
              >
                {/* Enhanced Selection Triangle with animation */}
                {selectedCard?.player === player && selectedCard?.cardIndex === cardIndex && (
                  <motion.div 
                    className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-30"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  >
                    <motion.div 
                      className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[14px] border-t-blue-500 shadow-lg"
                      animate={{
                        borderTopColor: ["#3b82f6", "#60a5fa", "#3b82f6"],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                  </motion.div>
                )}
                
                <Card
                  card={card}
                  owner={player === 1 ? "player1" : "player2"}
                  isSelected={selectedCard?.player === player && selectedCard?.cardIndex === cardIndex}
                  onClick={() => handleCardClick(cardIndex)}
                  onPointerDown={(e) => handleCardDragStart(cardIndex, e.nativeEvent)}
                  onPointerMove={(e) => handleCardDragMove(e.nativeEvent)}
                  onPointerUp={handleCardDragEnd}
                  onPointerCancel={handleCardDragEnd}
                  isClickable={isCurrentPlayer && gamePhase === "playing"}
                  isDisabled={!isCurrentPlayer || gamePhase !== "playing"}
                  size="tiny"
                />
              </motion.div>
            ))}
            {/* Extra space after last card to ensure full accessibility */}
            <div className="w-20 flex-shrink-0"></div>
            </motion.div>
          </div>
        </div>
      ) : (
        /* Desktop Grid Interface */
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:flex md:flex-wrap md:gap-2 lg:space-y-3 lg:flex-col lg:flex-nowrap justify-center lg:justify-start">
          {hand.map((card, index) => (
            card ? (
              isAIPlayer ? (
                // Hide AI cards - show only small card back
                <div
                  key={`ai-hidden-${index}`}
                  className="w-8 sm:w-12 h-10 sm:h-16 bg-gradient-to-br from-slate-700 to-slate-900 border border-red-600 rounded flex items-center justify-center"
                >
                  <div className="text-red-400 text-sm font-bold">?</div>
                </div>
              ) : (
                <div key={`${card.id}-${index}`} className="relative">
                  {/* Blue Selection Triangle for Desktop - Above top value */}
                  {selectedCard?.player === player && selectedCard?.cardIndex === index && (
                    <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-30">
                      <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[14px] border-t-blue-500 animate-pulse shadow-lg"></div>
                    </div>
                  )}
                  <Card
                    card={card}
                    owner={player === 1 ? "player1" : "player2"}
                    isSelected={selectedCard?.player === player && selectedCard?.cardIndex === index}
                    onClick={() => handleCardClick(index)}
                    onPointerDown={(e) => handleCardDragStart(index, e.nativeEvent)}
                    onPointerMove={(e) => handleCardDragMove(e.nativeEvent)}
                    onPointerUp={handleCardDragEnd}
                    onPointerCancel={handleCardDragEnd}
                    isClickable={isCurrentPlayer && gamePhase === "playing"}
                    isDisabled={!isCurrentPlayer || gamePhase !== "playing"}
                  />
                </div>
              )
            ) : null
          ))}
        </div>
      )}

      {/* Desktop Card Counter */}
      {!isMobile && (
        <div className="mt-2 sm:mt-4 text-center">
          <span className="text-xs sm:text-sm text-slate-400">
            Karten: {hand.length}
          </span>
        </div>
      )}
    </div>
  );
}