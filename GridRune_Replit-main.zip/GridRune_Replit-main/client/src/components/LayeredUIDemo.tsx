import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ModalBackdrop, 
  LayeredContainer, 
  NotificationContainer, 
  ToastContainer, 
  GameOverlay 
} from './ui/LayeredContainer';
import { SystemNotification, NotificationManager } from './ui/SystemNotification';
import { LoadingOverlay, ErrorOverlay } from './ui/LoadingOverlay';
import { DebugPanel } from './ui/DebugPanel';
import { useNotifications } from '../hooks/useNotifications';
import { useLayerManagerContext } from '../contexts/LayerManagerContext';
import { Button } from './ui/button';
import { cn } from '../lib/utils';

interface LayeredUIDemoProps {
  onClose: () => void;
}

export function LayeredUIDemo({ onClose }: LayeredUIDemoProps) {
  const [showModal, setShowModal] = useState(false);
  const [showNestedModal, setShowNestedModal] = useState(false);
  const [showLoading, setShowLoading] = useState(false);
  const [showError, setShowError] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [showGameEffects, setShowGameEffects] = useState(false);
  const [showDebugPanel, setShowDebugPanel] = useState(false);

  const notifications = useNotifications();
  const layerManager = useLayerManagerContext();

  const handleShowLoading = () => {
    setShowLoading(true);
    setLoadingProgress(0);
    
    // Simulate loading progress
    const interval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setShowLoading(false);
          notifications.success('Laden abgeschlossen!', 'Das System wurde erfolgreich geladen.');
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  const testNotifications = () => {
    notifications.info('Info-Nachricht', 'Dies ist eine informative Nachricht');
    setTimeout(() => {
      notifications.warning('Warnung', 'Dies ist eine Warnung');
    }, 1000);
    setTimeout(() => {
      notifications.success('Erfolg!', 'Aktion erfolgreich abgeschlossen');
    }, 2000);
  };

  const showBattleEffects = () => {
    setShowGameEffects(true);
    setTimeout(() => setShowGameEffects(false), 3000);
  };

  return (
    <ModalBackdrop onClose={onClose}>
      <div className="bg-slate-900 rounded-xl border border-slate-600 w-full max-w-4xl h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 to-indigo-900 p-6 border-b border-slate-600">
          <h2 className="text-2xl font-bold text-white">Layered UI System Demo</h2>
          <p className="text-purple-200 mt-2">
            Teste die verschiedenen UI-Layer und Z-Index-Management-Features
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Modal Tests */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Modal-System</h3>
            <div className="flex gap-3 flex-wrap">
              <Button onClick={() => setShowModal(true)}>
                Einfaches Modal
              </Button>
              <Button 
                onClick={() => {
                  setShowModal(true);
                  setTimeout(() => setShowNestedModal(true), 500);
                }}
                variant="outline"
              >
                Verschachtelte Modals
              </Button>
            </div>
          </div>

          {/* Notification Tests */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Benachrichtigungssystem</h3>
            <div className="flex gap-3 flex-wrap">
              <Button onClick={testNotifications}>
                Test-Benachrichtigungen
              </Button>
              <Button 
                onClick={() => notifications.error('Fehler!', 'Dies ist eine Fehlermeldung')}
                variant="outline"
              >
                Fehler-Nachricht
              </Button>
              <Button 
                onClick={() => notifications.clearNotifications()}
                variant="outline"
              >
                Alle löschen
              </Button>
            </div>
          </div>

          {/* Loading/Error Overlays */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-4">System-Overlays</h3>
            <div className="flex gap-3 flex-wrap">
              <Button onClick={handleShowLoading}>
                Lade-Overlay
              </Button>
              <Button 
                onClick={() => setShowError(true)}
                variant="outline"
              >
                Fehler-Overlay
              </Button>
            </div>
          </div>

          {/* Game Layer Tests */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Spiel-Layer</h3>
            <div className="flex gap-3 flex-wrap">
              <Button onClick={showBattleEffects}>
                Kampf-Effekte
              </Button>
              <Button 
                onClick={() => setShowDebugPanel(!showDebugPanel)}
                variant="outline"
              >
                Debug-Panel
              </Button>
            </div>
          </div>

          {/* Layer Manager Status */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Layer-Manager Status</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-400">Aktive Modals:</span>
                <span className="text-blue-400 ml-2">{layerManager.layerState.activeModals.length}</span>
              </div>
              <div>
                <span className="text-slate-400">Game Overlays:</span>
                <span className="text-green-400 ml-2">{layerManager.layerState.gameOverlays.length}</span>
              </div>
              <div>
                <span className="text-slate-400">Benachrichtigungen:</span>
                <span className="text-yellow-400 ml-2">{layerManager.layerState.notifications.length}</span>
              </div>
              <div>
                <span className="text-slate-400">Max Z-Index:</span>
                <span className="text-purple-400 ml-2">{layerManager.layerState.currentMaxZIndex}</span>
              </div>
            </div>
          </div>

          {/* Clear All Button */}
          <div className="flex justify-center">
            <Button 
              onClick={() => layerManager.clearLayers('all')}
              variant="outline"
              className="border-red-500 text-red-400 hover:bg-red-500/10"
            >
              Alle Layer zurücksetzen
            </Button>
          </div>
        </div>
      </div>

      {/* Demo Modals */}
      <AnimatePresence>
        {showModal && (
          <ModalBackdrop onClose={() => setShowModal(false)}>
            <div className="bg-slate-800 rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-bold text-white mb-4">Test Modal</h3>
              <p className="text-slate-300 mb-6">
                Dies ist ein Test-Modal mit korrekter Z-Index-Verwaltung.
              </p>
              <div className="flex gap-3">
                <Button onClick={() => setShowNestedModal(true)}>
                  Öffne Nested Modal
                </Button>
                <Button 
                  onClick={() => setShowModal(false)}
                  variant="outline"
                >
                  Schließen
                </Button>
              </div>
            </div>
          </ModalBackdrop>
        )}

        {showNestedModal && (
          <ModalBackdrop onClose={() => setShowNestedModal(false)}>
            <div className="bg-slate-700 rounded-lg p-6 max-w-sm w-full border-2 border-purple-500">
              <h3 className="text-lg font-bold text-white mb-4">Nested Modal</h3>
              <p className="text-slate-300 mb-6">
                Dieses Modal hat einen höheren Z-Index als das vorherige.
              </p>
              <Button 
                onClick={() => setShowNestedModal(false)}
                className="w-full"
              >
                Schließen
              </Button>
            </div>
          </ModalBackdrop>
        )}
      </AnimatePresence>

      {/* Game Effects Overlay */}
      <AnimatePresence>
        {showGameEffects && (
          <GameOverlay>
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="text-6xl">💥</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-2xl font-bold"
            >
              KRITISCHER TREFFER!
            </motion.div>
          </GameOverlay>
        )}
      </AnimatePresence>

      {/* Loading Overlay */}
      <LoadingOverlay 
        isVisible={showLoading}
        message="Demo wird geladen..."
        progress={loadingProgress}
      />

      {/* Error Overlay */}
      <ErrorOverlay
        isVisible={showError}
        title="Demo-Fehler"
        message="Dies ist ein Test-Fehler für das Overlay-System. In einem echten Szenario würde hier eine echte Fehlermeldung stehen."
        onRetry={() => {
          setShowError(false);
          notifications.info('Neustart', 'Fehler wurde behoben!');
        }}
        onDismiss={() => setShowError(false)}
      />

      {/* Notification Manager */}
      <NotificationManager 
        notifications={notifications.notifications}
        onClose={notifications.removeNotification}
      />

      {/* Debug Panel */}
      {showDebugPanel && <DebugPanel isVisible={showDebugPanel} />}
    </ModalBackdrop>
  );
}