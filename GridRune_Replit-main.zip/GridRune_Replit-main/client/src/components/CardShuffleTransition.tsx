import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface CardShuffleTransitionProps {
  isVisible: boolean;
  onComplete?: () => void;
  duration?: number;
}

const CARD_COUNT = 8;

export function CardShuffleTransition({ 
  isVisible, 
  onComplete, 
  duration = 800 
}: CardShuffleTransitionProps) {
  const [animationPhase, setAnimationPhase] = useState<'gather' | 'shuffle' | 'scatter'>('gather');

  useEffect(() => {
    if (isVisible) {
      setAnimationPhase('gather');
      
      // Sequence the animation phases
      const gatherTimer = setTimeout(() => {
        setAnimationPhase('shuffle');
      }, duration * 0.3);

      const shuffleTimer = setTimeout(() => {
        setAnimationPhase('scatter');
      }, duration * 0.6);

      const completeTimer = setTimeout(() => {
        onComplete?.();
      }, duration);

      return () => {
        clearTimeout(gatherTimer);
        clearTimeout(shuffleTimer);
        clearTimeout(completeTimer);
      };
    }
  }, [isVisible, duration, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none overflow-hidden">
      <AnimatePresence>
        {Array.from({ length: CARD_COUNT }).map((_, index) => {
          const cardDelay = index * 0.05;
          const isEven = index % 2 === 0;
          
          // Different starting positions for variety
          const startX = (index % 4) * 25 + 10; // Spread across screen width
          const startY = Math.floor(index / 4) * 30 + 20; // Multiple rows
          
          // Center gathering point
          const gatherX = 50;
          const gatherY = 50;
          
          // Random scatter positions
          const scatterX = Math.random() * 100;
          const scatterY = Math.random() * 100;
          const scatterRotation = (Math.random() - 0.5) * 720; // Random spin

          return (
            <motion.div
              key={index}
              className="absolute w-16 h-24 rounded-lg shadow-xl border-2"
              style={{
                background: isEven 
                  ? 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)'
                  : 'linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%)',
                borderColor: isEven ? '#d97706' : '#1d4ed8',
                left: `${startX}%`,
                top: `${startY}%`,
              }}
              initial={{
                x: 0,
                y: 0,
                scale: 0.3,
                rotate: (Math.random() - 0.5) * 30,
                opacity: 0,
              }}
              animate={{
                x: animationPhase === 'gather' 
                  ? `${gatherX - startX}%`
                  : animationPhase === 'shuffle'
                  ? `${gatherX - startX + (Math.random() - 0.5) * 10}%`
                  : `${scatterX - startX}%`,
                y: animationPhase === 'gather'
                  ? `${gatherY - startY}%`
                  : animationPhase === 'shuffle'
                  ? `${gatherY - startY + (Math.random() - 0.5) * 10}%`
                  : `${scatterY - startY}%`,
                scale: animationPhase === 'gather' 
                  ? 0.8
                  : animationPhase === 'shuffle'
                  ? 0.9
                  : 0.1,
                rotate: animationPhase === 'gather'
                  ? 0
                  : animationPhase === 'shuffle'
                  ? (Math.random() - 0.5) * 180
                  : scatterRotation,
                opacity: animationPhase === 'scatter' ? 0 : 1,
                zIndex: animationPhase === 'shuffle' ? 60 - index : 50 + index,
              }}
              transition={{
                duration: animationPhase === 'gather' 
                  ? duration * 0.003
                  : animationPhase === 'shuffle'
                  ? duration * 0.002
                  : duration * 0.004,
                delay: cardDelay,
                ease: animationPhase === 'gather'
                  ? "easeOut"
                  : animationPhase === 'shuffle'
                  ? "easeInOut"
                  : "easeIn",
              }}
            >
              {/* Card design elements */}
              <div className="absolute inset-2 rounded border border-opacity-30"
                style={{
                  borderColor: isEven ? '#d97706' : '#1d4ed8',
                }}
              >
                <div className="w-full h-full flex items-center justify-center">
                  <div 
                    className="w-8 h-8 rounded-full border-2"
                    style={{
                      borderColor: isEven ? '#d97706' : '#1d4ed8',
                      background: isEven 
                        ? 'radial-gradient(circle, #fbbf24 0%, #d97706 100%)'
                        : 'radial-gradient(circle, #60a5fa 0%, #1d4ed8 100%)',
                    }}
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>

      {/* Background overlay during shuffle */}
      <motion.div
        className="absolute inset-0 bg-black"
        initial={{ opacity: 0 }}
        animate={{ 
          opacity: animationPhase === 'shuffle' ? 0.3 : 0 
        }}
        transition={{ duration: 0.2 }}
      />
    </div>
  );
}