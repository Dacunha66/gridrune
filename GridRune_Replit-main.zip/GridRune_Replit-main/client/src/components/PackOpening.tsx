import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';
import { Button } from './ui/button';
import { Card as CardComponent } from './Card';
import { GameCard, RARITY_CONFIG } from '../lib/cardData';
import { useAudio } from '../lib/stores/useAudio';
import SocialShareButton from './SocialShareButton';

interface ShopPack {
  id: string;
  name: string;
  description: string | React.ReactNode;
  goldPrice?: number;
  diamondPrice?: number;
  cardCount: number;
  image: string;
  limited?: boolean;
  featured?: boolean;
}

interface PackOpeningProps {
  pack: ShopPack;
  cards: GameCard[];
  onComplete: (cards: GameCard[]) => void;
}

type OpeningPhase = 'opening' | 'revealing' | 'suspense' | 'big-reveal' | 'complete';

export function PackOpening({ pack, cards, onComplete }: PackOpeningProps) {
  const [phase, setPhase] = useState<OpeningPhase>('opening');
  const [revealedCards, setRevealedCards] = useState<GameCard[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [sortedCards, setSortedCards] = useState<GameCard[]>([]);
  const [isSpecialCard, setIsSpecialCard] = useState(false);
  const [showingSuspense, setShowingSuspense] = useState(false);
  const [bigRevealCard, setBigRevealCard] = useState<GameCard | null>(null);
  const { hitSound, successSound } = useAudio();
  
  // Sort cards by rarity - best card comes last
  useEffect(() => {
    const getRarityValue = (card: GameCard) => {
      const rarity = card.rarity || 'common';
      const values = { 'common': 1, 'uncommon': 2, 'rare': 3, 'epic': 4, 'legendary': 5 };
      return values[rarity] || 1;
    };
    
    const sorted = [...cards].sort((a, b) => getRarityValue(a) - getRarityValue(b));
    setSortedCards(sorted);
  }, [cards]);
  
  const playHitSound = () => {
    if (hitSound && !hitSound.muted) {
      hitSound.currentTime = 0;
      hitSound.play().catch(() => {});
    }
  };
  
  const playSuccessSound = () => {
    if (successSound && !successSound.muted) {
      successSound.currentTime = 0;
      successSound.play().catch(() => {});
    }
  };

  useEffect(() => {
    // Start pack opening animation
    const timer = setTimeout(() => {
      setPhase('revealing');
      playSuccessSound();
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Main card revealing logic
  useEffect(() => {
    if (phase === 'revealing' && currentCardIndex < sortedCards.length && sortedCards.length > 0 && !showingSuspense) {
      const currentCard = sortedCards[currentCardIndex];
      const isLastCard = currentCardIndex === sortedCards.length - 1;
      const cardRarity = currentCard.rarity || 'common';
      const isSpecial = cardRarity === 'epic' || cardRarity === 'legendary';
      
      // For special cards, show suspense first
      if (isSpecial) {
        setIsSpecialCard(true);
        setShowingSuspense(true);
        setPhase('suspense');
        return;
      }
      
      // For normal cards, reveal immediately
      const timer = setTimeout(() => {
        setRevealedCards(prev => [...prev, currentCard]);
        playHitSound();
        
        if (isLastCard) {
          setTimeout(() => setPhase('complete'), 1000);
        } else {
          setCurrentCardIndex(prev => prev + 1);
        }
      }, 800);

      return () => clearTimeout(timer);
    }
  }, [phase, currentCardIndex, sortedCards, showingSuspense]);

  // Suspense phase logic
  useEffect(() => {
    if (phase === 'suspense' && showingSuspense && currentCardIndex < sortedCards.length) {
      const currentCard = sortedCards[currentCardIndex];
      const isLastCard = currentCardIndex === sortedCards.length - 1;
      const cardRarity = currentCard.rarity || 'common';
      
      const suspenseTimer = setTimeout(() => {
        // Add vibration effect for mobile devices
        if ('vibrate' in navigator) {
          if (cardRarity === 'legendary') {
            navigator.vibrate([100, 50, 100, 50, 200]);
          } else if (cardRarity === 'epic') {
            navigator.vibrate([100, 50, 100]);
          }
        }
        
        // Show big reveal for special card
        setBigRevealCard(currentCard);
        setPhase('big-reveal');
        playSuccessSound();
        setIsSpecialCard(false);
        setShowingSuspense(false);
        
        // After big reveal, add to revealed cards and continue
        setTimeout(() => {
          setRevealedCards(prev => [...prev, currentCard]);
          setBigRevealCard(null);
          
          setTimeout(() => {
            if (isLastCard) {
              setPhase('complete');
            } else {
              setCurrentCardIndex(prev => prev + 1);
              setPhase('revealing');
            }
          }, 1000);
        }, 2500);
      }, 1500);
      
      return () => clearTimeout(suspenseTimer);
    }
  }, [phase, showingSuspense, currentCardIndex, sortedCards]);

  const handleComplete = () => {
    onComplete(cards);
  };

  const getCardRarityEffect = (card: GameCard) => {
    const rarity = card.rarity || 'common';
    const config = RARITY_CONFIG[rarity];
    
    return {
      glow: config.color.replace('text-', 'shadow-'),
      particles: rarity === 'legendary' ? '✨' : rarity === 'epic' ? '⭐' : '✦'
    };
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="w-full max-w-6xl mx-auto">
        {/* Opening Animation */}
        <AnimatePresence>
          {phase === 'opening' && (
            <motion.div
              className="text-center"
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                className="relative mx-auto mb-8"
                animate={{ 
                  rotateY: [0, 180, 360],
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <div className="w-40 h-56 bg-gradient-to-br from-purple-500 via-blue-500 to-cyan-500 rounded-xl relative overflow-hidden shadow-2xl">
                  {/* Pack Design */}
                  <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 to-transparent" />
                  <div className="absolute inset-4 border-2 border-white/30 rounded-lg" />
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-6xl">
                    📦
                  </div>
                  
                  {/* Sparkle effects */}
                  <div className="absolute inset-0">
                    {[...Array(8)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                        }}
                        animate={{
                          opacity: [0, 1, 0],
                          scale: [0, 1, 0],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
              
              <h2 className="text-4xl font-bold text-white mb-2">{pack.name} öffnen...</h2>
              <p className="text-gray-300">Deine Karten werden enthüllt...</p>
              
              {/* Loading bar */}
              <motion.div
                className="w-64 h-2 bg-gray-700 rounded-full mx-auto mt-6 overflow-hidden"
                initial={{ width: 0 }}
                animate={{ width: 256 }}
                transition={{ duration: 2 }}
              >
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-cyan-500"
                  initial={{ x: '-100%' }}
                  animate={{ x: '0%' }}
                  transition={{ duration: 2 }}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Suspense Animation for Special Cards */}
        <AnimatePresence>
          {phase === 'suspense' && (
            <motion.div
              className="text-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.2 }}
              transition={{ duration: 0.5 }}
            >
              <motion.div
                className="relative mx-auto mb-8 w-48 h-64"
                animate={{
                  scale: [1, 1.1, 1.2, 1.1, 1],
                  rotateY: [0, 10, -10, 0]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-yellow-500 to-red-500 rounded-xl shadow-2xl">
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-yellow-400/30 to-transparent rounded-xl"
                    animate={{ opacity: [0.3, 0.8, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                  
                  <div className="absolute inset-4 border-4 border-white/50 rounded-lg">
                    <motion.div
                      className="w-full h-full flex items-center justify-center"
                      animate={{ rotate: [0, 360] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    >
                      <span className="text-8xl">✨</span>
                    </motion.div>
                  </div>
                  
                  {/* Intense sparkle effects */}
                  <div className="absolute inset-0">
                    {[...Array(20)].map((_, i) => (
                      <motion.div
                        key={`suspense-sparkle-${i}`}
                        className="absolute w-2 h-2 bg-white rounded-full"
                        style={{
                          left: `${(i * 17 + 5) % 95}%`,
                          top: `${(i * 23 + 10) % 95}%`,
                        }}
                        animate={{
                          opacity: [0, 1, 0],
                          scale: [0, 2, 0],
                          rotate: [0, 360]
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          delay: i * 0.1,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
              
              <motion.h2 
                className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-red-500 to-purple-600 mb-4"
                animate={{ 
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                Etwas Besonderes!
              </motion.h2>
              
              <motion.p 
                className="text-white text-xl"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                Eine seltene Karte wird enthüllt...
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Big Reveal Animation for Special Cards */}
        <AnimatePresence>
          {phase === 'big-reveal' && bigRevealCard && (
            <motion.div
              className="fixed inset-0 z-60 bg-gradient-to-br from-purple-900/95 via-black/90 to-yellow-900/95 backdrop-blur-lg flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-center">
                <motion.h1 
                  className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-red-500 to-purple-600 mb-8"
                  initial={{ scale: 0, y: -50 }}
                  animate={{ scale: 1, y: 0 }}
                  transition={{ duration: 0.8, type: "spring", stiffness: 150 }}
                >
                  {bigRevealCard.rarity === 'legendary' ? '✨ LEGENDÄR! ✨' : '⭐ EPISCH! ⭐'}
                </motion.h1>

                <motion.div
                  className="relative"
                  initial={{ scale: 0, rotateY: 180 }}
                  animate={{ 
                    scale: [0, 1.2, 1],
                    rotateY: [180, 0, 0],
                    y: [0, -20, 0]
                  }}
                  transition={{ 
                    duration: 1.5,
                    type: "spring",
                    stiffness: 100,
                    times: [0, 0.6, 1]
                  }}
                >
                  {/* Background glow effect around the entire container */}
                  <motion.div
                    className={cn(
                      "absolute inset-0 rounded-3xl blur-3xl",
                      bigRevealCard.rarity === 'legendary' 
                        ? "shadow-yellow-400 bg-yellow-400/30" 
                        : "shadow-purple-500 bg-purple-500/30"
                    )}
                    animate={{
                      opacity: [0.2, 0.8, 0.2],
                      scale: [1, 1.3, 1]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />



                  {/* Massive particle explosion around the card area */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden">
                    {[...Array(bigRevealCard.rarity === 'legendary' ? 16 : 12)].map((_, i) => {
                      const angle = (i / (bigRevealCard.rarity === 'legendary' ? 16 : 12)) * Math.PI * 2;
                      const radius = 180;
                      return (
                        <motion.div
                          key={`big-reveal-particle-${i}`}
                          className="absolute text-3xl"
                          style={{
                            left: '50%',
                            top: '50%',
                            transform: 'translate(-50%, -50%)',
                          }}
                          animate={{
                            opacity: [0, 1, 0],
                            scale: [0, 1.5, 0],
                            x: [0, Math.cos(angle) * radius],
                            y: [0, Math.sin(angle) * radius],
                            rotate: [0, 360],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            delay: i * 0.1,
                            ease: "easeOut"
                          }}
                        >
                          {bigRevealCard.rarity === 'legendary' ? '✨' : '⭐'}
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* The actual large card - properly centered */}
                  <div className="relative flex items-center justify-center w-96 h-96">
                    <div className="relative scale-[2.5] origin-center">
                      <CardComponent 
                        card={bigRevealCard}
                        size="medium"
                        isClickable={false}
                      />
                    </div>
                  </div>
                </motion.div>

                <motion.p 
                  className="text-white text-2xl mt-8 font-semibold"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1 }}
                >
                  {bigRevealCard.name}
                </motion.p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Card Revealing Animation */}
        <AnimatePresence>
          {(phase === 'revealing' || phase === 'complete') && (
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold text-white mb-8">Deine Karten!</h2>
              
              <div className="flex justify-center gap-4 flex-wrap">
                {revealedCards.map((card, index) => {
                  const effect = getCardRarityEffect(card);
                  const cardRarity = card.rarity || 'common';
                  const isSpecialCard = cardRarity === 'epic' || cardRarity === 'legendary';
                  
                  return (
                    <motion.div
                      key={card.id}
                      initial={{ 
                        scale: 0,
                        rotateY: 180,
                        opacity: 0
                      }}
                      animate={{ 
                        scale: isSpecialCard ? [1, 1.1, 1] : 1,
                        rotateY: 0,
                        opacity: 1,
                        y: isSpecialCard ? [0, -10, 0] : 0
                      }}
                      transition={{ 
                        duration: isSpecialCard ? 1.2 : 0.8,
                        delay: index * 0.1,
                        type: "spring",
                        stiffness: isSpecialCard ? 150 : 100,
                        y: {
                          duration: 2,
                          repeat: isSpecialCard ? Infinity : 0,
                          ease: "easeInOut"
                        },
                        scale: {
                          duration: 2,
                          repeat: isSpecialCard ? Infinity : 0,
                          ease: "easeInOut"
                        }
                      }}
                      className="relative"
                    >
                      {/* Enhanced glow effect for special cards */}
                      <motion.div
                        className={cn(
                          "absolute inset-0 rounded-lg blur-lg",
                          effect.glow
                        )}
                        animate={{
                          opacity: isSpecialCard ? [0.3, 1, 0.3] : [0.5, 0.8, 0.5],
                          scale: isSpecialCard ? [1, 1.3, 1] : [1, 1.1, 1]
                        }}
                        transition={{
                          duration: isSpecialCard ? 1.5 : 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                      
                      {/* Enhanced particle effects for special cards */}
                      {isSpecialCard && (
                        <div className="absolute inset-0 pointer-events-none">
                          {[...Array(cardRarity === 'legendary' ? 12 : 8)].map((_, i) => {
                            const particleId = `${card.id}-particle-${i}`;
                            return (
                              <motion.div
                                key={particleId}
                                className="absolute text-2xl"
                                style={{
                                  left: `${(i * 23 + 10) % 90}%`,
                                  top: `${(i * 17 + 5) % 90}%`,
                                }}
                                animate={{
                                  opacity: [0, 1, 0],
                                  y: [0, -30, -60],
                                  x: [0, (i % 2 === 0 ? 1 : -1) * 20],
                                  scale: [0.5, 1.2, 0.5],
                                  rotate: [0, 360],
                                }}
                                transition={{
                                  duration: cardRarity === 'legendary' ? 2.5 : 2,
                                  repeat: Infinity,
                                  delay: i * 0.3,
                                  ease: "easeOut"
                                }}
                              >
                                {effect.particles}
                              </motion.div>
                            );
                          })}
                        </div>
                      )}
                      
                      {/* Legendary special ring effect */}
                      {cardRarity === 'legendary' && (
                        <motion.div
                          className="absolute inset-0 border-4 border-yellow-400 rounded-lg"
                          animate={{
                            borderColor: ['#facc15', '#f59e0b', '#eab308', '#facc15'],
                            boxShadow: [
                              '0 0 20px #facc15',
                              '0 0 40px #f59e0b',
                              '0 0 60px #eab308',
                              '0 0 20px #facc15'
                            ]
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        />
                      )}
                      
                      <div className="relative">
                        <CardComponent 
                          card={card}
                          size="medium"
                          isClickable={false}
                        />
                      </div>
                    </motion.div>
                  );
                })}
                
                {/* Enhanced placeholder cards with suspense animation */}
                {Array.from({ length: sortedCards.length - revealedCards.length }).map((_, index) => {
                  const isNextSpecial = sortedCards.length > 0 && 
                    revealedCards.length + index < sortedCards.length &&
                    (sortedCards[revealedCards.length + index]?.rarity === 'epic' || 
                     sortedCards[revealedCards.length + index]?.rarity === 'legendary');
                  
                  return (
                    <motion.div
                      key={`placeholder-${index}`}
                      className={cn(
                        "w-20 h-28 rounded-lg border-2 flex items-center justify-center",
                        isNextSpecial && isSpecialCard 
                          ? "bg-gradient-to-br from-purple-700 to-yellow-600 border-yellow-400 shadow-lg" 
                          : "bg-gray-700 border-gray-600"
                      )}
                      animate={{ 
                        opacity: isNextSpecial && isSpecialCard ? [0.4, 1, 0.4] : [0.3, 0.6, 0.3],
                        scale: isNextSpecial && isSpecialCard ? [1, 1.15, 1] : [1, 1.05, 1],
                        rotateY: isNextSpecial && isSpecialCard ? [0, 10, -10, 0] : 0
                      }}
                      transition={{ 
                        duration: isNextSpecial && isSpecialCard ? 0.8 : 1.5,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      {isNextSpecial && isSpecialCard ? (
                        <motion.span 
                          className="text-3xl"
                          animate={{ 
                            scale: [1, 1.2, 1],
                            rotate: [0, 360]
                          }}
                          transition={{
                            duration: 1,
                            repeat: Infinity
                          }}
                        >
                          ✨
                        </motion.span>
                      ) : (
                        <span className="text-2xl text-gray-500">?</span>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Complete Button and Social Share */}
        <AnimatePresence>
          {phase === 'complete' && (
            <motion.div
              className="text-center mt-8 space-y-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              {/* Social Share Button for Epic/Legendary pulls */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 }}
              >
                <SocialShareButton cards={cards} packType={pack.name} />
              </motion.div>
              
              <Button
                onClick={handleComplete}
                className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-bold px-8 py-3 text-lg"
              >
                Karten zur Sammlung hinzufügen
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}