import React, { useState } from 'react';
import { Button } from './ui/button';
import { Trophy } from 'lucide-react';
import PlayfulCelebration from './PlayfulCelebration';

// Test component for achievement celebrations
export const AchievementTestButton: React.FC = () => {
  const [showCelebration, setShowCelebration] = useState(false);
  const [currentAchievement, setCurrentAchievement] = useState<any>(null);

  const testAchievements = [
    {
      title: 'First Victory',
      description: 'Win your first game in GridRune',
      rarity: 'common' as const,
      reward: { xp: 100, gold: 200 }
    },
    {
      title: 'Card Master',
      description: 'Collect 50 different cards',
      rarity: 'rare' as const,
      reward: { xp: 500, diamonds: 25, title: 'Collector' }
    },
    {
      title: 'Legend Hunter',
      description: 'Obtain your first legendary card',
      rarity: 'legendary' as const,
      reward: { xp: 1000, diamonds: 100, gold: 1000, title: 'Legend Hunter' }
    }
  ];

  const triggerTestCelebration = (achievement: any) => {
    setCurrentAchievement(achievement);
    setShowCelebration(true);
  };

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <div className="space-y-2">
        <p className="text-white text-sm">Test Celebrations:</p>
        {testAchievements.map((achievement, index) => (
          <Button
            key={index}
            onClick={() => triggerTestCelebration(achievement)}
            variant="outline"
            size="sm"
            className="bg-purple-600 text-white border-purple-400 hover:bg-purple-500"
          >
            <Trophy className="w-4 h-4 mr-2" />
            {achievement.rarity}
          </Button>
        ))}
      </div>

      <PlayfulCelebration
        achievement={currentAchievement}
        isVisible={showCelebration}
        onComplete={() => {
          setShowCelebration(false);
          setCurrentAchievement(null);
        }}
      />
    </div>
  );
};

export default AchievementTestButton;