import { useState } from "react";
import { useCardGame } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { ArrowLeft, Palette, Save, Tag, Sparkles } from "lucide-react";
import { 
  DECK_THEMES, 
  DeckTheme, 
  getUnlockedThemes, 
  getThemesByCategory,
  generateThemeCSS,
  getThemeGradientClass,
  getThemeBorderClass 
} from "../lib/deckThemes";
import { ThemePreviewCard } from "./ThemePreviewCard";
import { allCards } from "../lib/cardData";

export function DeckThemeCustomizer() {
  const { setGamePhase, savedDecks, saveDeck, currentEditingDeck } = useCardGame();
  const [selectedTheme, setSelectedTheme] = useState<DeckTheme>(DECK_THEMES[0]);
  const [deckName, setDeckName] = useState("");
  const [deckDescription, setDeckDescription] = useState("");
  const [deckTags, setDeckTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // If editing existing deck, load its data
  const currentDeck = currentEditingDeck !== null ? savedDecks[currentEditingDeck] : null;

  const categories = [
    { id: "all", name: "Alle Themes", icon: "🎨" },
    { id: "elemental", name: "Elemental", icon: "🔥" },
    { id: "nature", name: "Natur", icon: "🌿" },
    { id: "mystical", name: "Mystisch", icon: "🌙" },
    { id: "cosmic", name: "Kosmisch", icon: "⭐" },
    { id: "premium", name: "Premium", icon: "👑" }
  ];

  const getFilteredThemes = () => {
    const unlockedThemes = getUnlockedThemes();
    if (selectedCategory === "all") return unlockedThemes;
    return getThemesByCategory(selectedCategory as DeckTheme['category']).filter(theme => theme.unlocked);
  };

  const addTag = () => {
    if (newTag.trim() && !deckTags.includes(newTag.trim()) && deckTags.length < 5) {
      setDeckTags([...deckTags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tag: string) => {
    setDeckTags(deckTags.filter(t => t !== tag));
  };

  const handleSave = () => {
    if (!deckName.trim()) {
      alert("Bitte gib einen Deck-Namen ein!");
      return;
    }

    // Here you would integrate with the existing deck saving logic
    // For now, we'll just navigate back to deck management
    alert("Theme-Anpassung gespeichert! (Demo-Funktion)");
    setGamePhase("deck-management");
  };

  const ThemePreview = ({ theme, isSelected = false }: { theme: DeckTheme, isSelected?: boolean }) => (
    <div 
      className={`relative p-4 rounded-lg border-2 transition-all duration-300 hover:scale-105 ${
        isSelected ? 'theme-glow ring-4 ring-purple-500 ring-opacity-50' : ''
      } ${getThemeBorderClass(theme)} ${getThemeGradientClass(theme)}`}
    >
      {/* Theme Icon with sparkle effect when selected */}
      <div className={`absolute top-2 right-2 text-2xl ${isSelected ? 'theme-sparkle' : ''}`}>
        {theme.icon}
      </div>
      
      {/* Selection indicator */}
      {isSelected && (
        <div className="absolute top-2 left-2 bg-purple-600 text-white rounded-full p-1">
          ✓
        </div>
      )}
      
      <div className="space-y-2">
        <div className="font-bold text-lg" style={{ color: theme.textColor }}>
          {theme.name}
        </div>
        <div className="text-sm opacity-90 line-clamp-2" style={{ color: theme.textColor }}>
          {theme.description}
        </div>
        
        {/* Theme colors preview */}
        <div className="flex space-x-2 mt-3">
          <div 
            className="w-4 h-4 rounded-full border border-white/20 shadow-sm" 
            style={{ backgroundColor: theme.primaryColor }}
            title="Primary Color"
          />
          <div 
            className="w-4 h-4 rounded-full border border-white/20 shadow-sm" 
            style={{ backgroundColor: theme.secondaryColor }}
            title="Secondary Color"
          />
          <div 
            className="w-4 h-4 rounded-full border border-white/20 shadow-sm" 
            style={{ backgroundColor: theme.accentColor }}
            title="Accent Color"
          />
        </div>
        
        {/* Category badge */}
        <div className="absolute bottom-2 left-2">
          <span className="px-2 py-1 text-xs rounded-full bg-black/30 text-white/90 capitalize">
            {theme.category}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={() => setGamePhase("deck-management")}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zur Verwaltung
          </Button>
          
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Palette className="w-8 h-8 text-purple-400" />
            Deck-Theme anpassen
          </h1>
          
          <Button 
            onClick={handleSave}
            disabled={!deckName.trim()}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600"
          >
            <Save className="w-4 h-4 mr-2" />
            Speichern
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Theme Selection */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-yellow-400" />
                  Theme auswählen
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Category Filter */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {categories.map((category) => (
                    <Badge
                      key={category.id}
                      variant={selectedCategory === category.id ? "default" : "secondary"}
                      className={`cursor-pointer transition-colors ${
                        selectedCategory === category.id
                          ? "bg-purple-600 hover:bg-purple-700"
                          : "bg-slate-700 hover:bg-slate-600"
                      }`}
                      onClick={() => setSelectedCategory(category.id)}
                    >
                      {category.icon} {category.name}
                    </Badge>
                  ))}
                </div>

                {/* Theme Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {getFilteredThemes().map((theme) => (
                    <div
                      key={theme.id}
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => setSelectedTheme(theme)}
                    >
                      <ThemePreview theme={theme} isSelected={selectedTheme.id === theme.id} />
                    </div>
                  ))}
                </div>

                {/* Locked Themes Preview */}
                {selectedCategory === "all" && (
                  <div className="mt-8">
                    <h3 className="text-lg font-semibold mb-4 text-slate-300">
                      Freischaltbare Themes
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 opacity-60">
                      {DECK_THEMES.filter(theme => !theme.unlocked).slice(0, 4).map((theme) => (
                        <div key={theme.id} className="relative">
                          <ThemePreview theme={theme} />
                          <div className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center">
                            <div className="text-center">
                              <div className="text-2xl mb-2">🔒</div>
                              <div className="text-sm font-medium">Gesperrt</div>
                              <div className="text-xs text-slate-300 mt-1 px-2">
                                {theme.unlockCondition}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Customization Panel */}
          <div className="space-y-6">
            {/* Selected Theme Preview */}
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: selectedTheme.primaryColor }}></div>
                  Aktuelle Auswahl
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ThemePreview theme={selectedTheme} isSelected={true} />
                
                {/* Theme Cards Preview */}
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-slate-300 mb-2">Karten mit diesem Theme:</h4>
                  <div className="flex justify-center gap-2">
                    {allCards.slice(0, 3).map((card, index) => (
                      <ThemePreviewCard 
                        key={index}
                        theme={selectedTheme}
                        card={card}
                        size="small"
                      />
                    ))}
                  </div>
                </div>
                
                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between text-slate-300">
                    <span>Primärfarbe:</span>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedTheme.primaryColor }}></div>
                      <span className="font-mono text-xs">{selectedTheme.primaryColor}</span>
                    </div>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Sekundärfarbe:</span>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedTheme.secondaryColor }}></div>
                      <span className="font-mono text-xs">{selectedTheme.secondaryColor}</span>
                    </div>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Akzentfarbe:</span>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedTheme.accentColor }}></div>
                      <span className="font-mono text-xs">{selectedTheme.accentColor}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Deck Details */}
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white">Deck-Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Deck-Name
                  </label>
                  <Input
                    value={deckName}
                    onChange={(e) => setDeckName(e.target.value)}
                    placeholder="Gib deinem Deck einen Namen..."
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                    maxLength={30}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Beschreibung
                  </label>
                  <Textarea
                    value={deckDescription}
                    onChange={(e) => setDeckDescription(e.target.value)}
                    placeholder="Beschreibe deine Deck-Strategie..."
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                    rows={3}
                    maxLength={200}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    Tags ({deckTags.length}/5)
                  </label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      placeholder="Neuer Tag..."
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 flex-1"
                      maxLength={15}
                      onKeyPress={(e) => e.key === "Enter" && addTag()}
                    />
                    <Button
                      onClick={addTag}
                      size="sm"
                      disabled={!newTag.trim() || deckTags.length >= 5}
                      className="bg-slate-600 hover:bg-slate-500"
                    >
                      +
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {deckTags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="bg-slate-600 text-white cursor-pointer"
                        onClick={() => removeTag(tag)}
                      >
                        {tag} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Theme Stats */}
            <Card className="bg-slate-800 border-slate-600">
              <CardHeader>
                <CardTitle className="text-white text-sm">Theme-Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between text-slate-300">
                  <span>Kategorie:</span>
                  <span className="capitalize">{selectedTheme.category}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Freigeschaltet:</span>
                  <span className={selectedTheme.unlocked ? "text-green-400" : "text-red-400"}>
                    {selectedTheme.unlocked ? "Ja" : "Nein"}
                  </span>
                </div>
                {!selectedTheme.unlocked && selectedTheme.unlockCondition && (
                  <div className="text-xs text-slate-400 mt-2 p-2 bg-slate-700 rounded">
                    Freischaltung: {selectedTheme.unlockCondition}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}