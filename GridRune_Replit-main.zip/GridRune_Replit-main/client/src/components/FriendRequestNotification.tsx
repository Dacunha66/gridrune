import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserPlus, Check, X, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { useFriends } from '../lib/stores/useFriends';
import { cn } from '../lib/utils';

export function FriendRequestNotifications() {
  const { friendRequests, acceptFriendRequest, declineFriendRequest } = useFriends();

  if (friendRequests.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      <AnimatePresence>
        {friendRequests.slice(0, 3).map((request, index) => (
          <motion.div
            key={request.id}
            initial={{ opacity: 0, x: 300, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 300, scale: 0.8 }}
            transition={{ 
              type: "spring", 
              stiffness: 300, 
              damping: 20,
              delay: index * 0.1 
            }}
          >
            <Card className="w-80 bg-gradient-to-r from-blue-900/95 to-purple-900/95 border-blue-500/50 backdrop-blur-sm shadow-xl">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center border-2 border-blue-400">
                      <span className="text-2xl">{request.fromAvatar}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <UserPlus className="w-4 h-4 text-blue-400" />
                        <Badge variant="secondary" className="text-xs bg-blue-600/30 text-blue-200">
                          Freundschaftsanfrage
                        </Badge>
                      </div>
                      <p className="text-white font-medium">
                        <span className="font-bold">{request.fromUsername}</span> möchte dein Freund werden!
                      </p>
                      <p className="text-xs text-slate-300 mt-1">
                        vor {Math.floor((Date.now() - request.sentAt.getTime()) / 60000)} Min.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button
                    onClick={() => acceptFriendRequest(request.id)}
                    size="sm"
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Check className="w-4 h-4 mr-1" />
                    Annehmen
                  </Button>
                  <Button
                    onClick={() => declineFriendRequest(request.id)}
                    variant="outline"
                    size="sm"
                    className="flex-1 border-red-500 text-red-400 hover:bg-red-500/20"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Ablehnen
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
        
        {friendRequests.length > 3 && (
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
          >
            <Card className="w-80 bg-gradient-to-r from-slate-800/95 to-slate-900/95 border-slate-600/50 backdrop-blur-sm">
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center gap-2 text-slate-300">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">
                    +{friendRequests.length - 3} weitere Anfragen
                  </span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}