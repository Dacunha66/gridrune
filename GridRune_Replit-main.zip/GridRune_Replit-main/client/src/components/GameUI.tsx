import { useCardGame } from "../lib/stores/useCardGame";
import { useAudio } from "../lib/stores/useAudio";
import { useTheme } from "../lib/stores/useTheme";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { EffectMessages } from "./EffectMessages";
import { Volume2, VolumeX, RotateCcw, Settings, Target, HelpCircle, Brain, Layers } from "lucide-react";
import { LayeredUIDemo } from './LayeredUIDemo';
import { cn } from "../lib/utils";
import { AvatarDisplay } from './AvatarSelector';
import { DynamicArrangementToggle } from './DynamicArrangementToggle';
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Slider } from "./ui/slider";


interface GameUIProps {
  onShowMobileTutorial?: () => void;
}

export function GameUI({ onShowMobileTutorial }: GameUIProps = {}) {
  const { 
    gamePhase, 
    currentPlayer, 
    winner, 
    player1Score, 
    player2Score, 
    resetToMenu,
    oCardOwner,
    gameMode,
    player1Name,
    player2Name,
    player1Avatar,
    player2Avatar,
    showAvatarCustomizationDialog,
    showPlacementGuide,
    setShowPlacementGuide,
    showStrategicHints,
    setShowStrategicHints
  } = useCardGame();
  
  // Turn indicator state
  const [isBlinking, setIsBlinking] = useState(true);
  
  // Settings panel state
  const [showSettings, setShowSettings] = useState(false);
  
  // Layered UI demo state
  const [showLayerDemo, setShowLayerDemo] = useState(false);

  // Stop blinking after 2 seconds when turn changes
  useEffect(() => {
    setIsBlinking(true);
    const timer = setTimeout(() => {
      setIsBlinking(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, [currentPlayer, gamePhase]);

  // Close settings panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showSettings && !event.target) return;
      
      const settingsElement = document.querySelector('[data-settings-panel]');
      const settingsButton = document.querySelector('[data-settings-button]');
      
      if (showSettings && 
          settingsElement && 
          settingsButton &&
          !settingsElement.contains(event.target as Node) &&
          !settingsButton.contains(event.target as Node)) {
        setShowSettings(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showSettings]);
  
  const { isMuted, toggleMute, backgroundMusic, masterVolume, setMasterVolume } = useAudio();
  const { currentTheme, getThemeConfig } = useTheme();
  const themeConfig = getThemeConfig();

  const handleMuteToggle = () => {
    toggleMute();
    if (backgroundMusic) {
      if (isMuted) {
        backgroundMusic.play().catch(console.log);
      } else {
        backgroundMusic.pause();
      }
    }
  };

  const getGameStatus = () => {
    switch (gamePhase) {
      case "ready":
        return "Game Ready - Click to Start";
      case "playing":
        if (gameMode === "ai") {
          return currentPlayer === 1 ? `${player1Name} ist dran` : "Computer denkt...";
        }
        return currentPlayer === 1 ? `${player1Name} ist dran` : `${player2Name} ist dran`;
      case "ended":
        if (winner === "tie") return "Unentschieden!";
        if (gameMode === "ai") {
          return winner === "player1" ? `${player1Name} hat gewonnen!` : "Computer hat gewonnen!";
        }
        return winner === "player1" ? `${player1Name} hat gewonnen!` : `${player2Name} hat gewonnen!`;
      default:
        return "Loading...";
    }
  };

  const isMobile = window.innerWidth < 1024;



  return (
    <Card className="bg-slate-800 border-slate-600 p-3 mb-4 overflow-visible relative z-50">
      <div className="grid grid-cols-3 items-center">
        {/* Left Side - GridRune Logo (extra large) */}
        <div className="flex items-center">
          <img 
            src="/gridrune-logo-transparent.png" 
            alt="GridRune Logo" 
            className={cn(
              "object-contain",
              isMobile ? "h-14" : "h-20 sm:h-24"
            )}
            style={{
              filter: 'drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.7))'
            }}
          />
        </div>

        {/* Center - Turn Indicator */}
        <div className="flex justify-center">
          {(gamePhase === "playing" || gamePhase === "blitzschlag-target" || gamePhase === "clone-target") && (
            <div className={cn(
              "relative rounded-full shadow-2xl transition-all duration-500 border-2",
              isMobile ? "w-10 h-10" : "w-12 h-12 sm:w-16 sm:h-16 sm:border-4",
              isBlinking ? "animate-pulse" : "",
              currentPlayer === 1 
                ? "bg-blue-600/90 border-blue-300" 
                : "bg-red-600/90 border-red-300"
            )}>
              {/* Player Avatar */}
              <div className={cn(
                "absolute rounded-full overflow-hidden flex items-center justify-center bg-white/10 backdrop-blur-sm",
                isMobile ? "inset-1 text-sm" : "inset-1 sm:inset-2 text-lg sm:text-2xl"
              )}>
                {(currentPlayer === 1 ? player1Avatar : player2Avatar).emoji}
              </div>
              
              {/* Status indicator dot for special effects */}
              {(gamePhase === "blitzschlag-target" || gamePhase === "clone-target") && (
                <div className={cn(
                  "absolute bg-yellow-400 rounded-full border border-white flex items-center justify-center animate-bounce",
                  isMobile ? "-top-0.5 -right-0.5 w-3 h-3" : "-top-0.5 -right-0.5 sm:-top-1 sm:-right-1 w-4 h-4 sm:w-5 sm:h-5 sm:border-2"
                )}>
                  <div className="text-xs">
                    {gamePhase === "blitzschlag-target" ? "⚡" : "👥"}
                  </div>
                </div>
              )}

              {/* Glowing effect - only when blinking */}
              {isBlinking && (
                <div className={cn(
                  "absolute inset-0 rounded-full opacity-30 animate-ping",
                  currentPlayer === 1 
                    ? "bg-blue-400" 
                    : "bg-red-400"
                )} />
              )}
            </div>
          )}
        </div>

        {/* Right Side - Help and Settings */}
        <div className="flex items-center gap-2 justify-end">
          {/* Help Button */}
          {onShowMobileTutorial && (
            <Button
              variant="outline"
              size="sm"
              onClick={onShowMobileTutorial}
              className={cn(
                "rounded-full text-white border-slate-600 hover:bg-slate-700 z-50",
                isMobile ? "w-8 h-8" : "w-10 h-10"
              )}
              title="Hilfe"
            >
              <HelpCircle className={isMobile ? "w-3 h-3" : "w-4 h-4"} />
            </Button>
          )}
          
          {/* Settings Button */}
          <div className="relative">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
              className={cn(
                "rounded-full text-white border-slate-600 hover:bg-slate-700 z-50",
                isMobile ? "w-8 h-8" : "w-10 h-10"
              )}
              title="Einstellungen"
              data-settings-button
            >
              <Settings className={isMobile ? "w-3 h-3" : "w-4 h-4"} />
            </Button>
            
            {/* Settings Panel */}
            <AnimatePresence>
              {showSettings && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-12 right-0 bg-slate-900/95 backdrop-blur-lg border border-slate-600 rounded-lg p-4 shadow-2xl z-60 min-w-64"
                  data-settings-panel
                >
                  {/* Header */}
                  <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-700">
                    <Settings className="w-4 h-4 text-slate-400" />
                    <h3 className="text-sm font-semibold text-white">Einstellungen</h3>
                  </div>

                  {/* Volume Control */}
                  <div className="space-y-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Volume2 className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-300">Lautstärke</span>
                        <span className="text-xs text-slate-500 ml-auto">{Math.round(masterVolume * 100)}%</span>
                      </div>
                      <Slider
                        value={[masterVolume]}
                        onValueChange={(value) => setMasterVolume(value[0])}
                        max={1}
                        step={0.1}
                        className="w-full"
                      />
                    </div>

                    {/* Quick Actions */}
                    <div className="flex gap-2">
                      <Button
                        onClick={toggleMute}
                        variant={isMuted ? "destructive" : "outline"}
                        size="sm"
                        className="flex-1"
                      >
                        {isMuted ? <VolumeX className="w-3 h-3 mr-1" /> : <Volume2 className="w-3 h-3 mr-1" />}
                        {isMuted ? 'Stumm' : 'Ton an'}
                      </Button>
                    </div>
                  </div>



                  {/* Dynamic Card Arrangement */}
                  <div className="border-t border-slate-700 pt-4 mb-4">
                    <DynamicArrangementToggle />
                  </div>

                  {/* UI Demo */}
                  <div className="border-t border-slate-700 pt-4 mb-4">
                    <Button
                      onClick={() => setShowLayerDemo(true)}
                      variant="outline"
                      size="sm"
                      className="w-full text-purple-300 border-purple-500/30 hover:bg-purple-500/10"
                    >
                      <Layers className="w-3 h-3 mr-2" />
                      Layered UI Demo
                    </Button>
                  </div>

                  {/* Game Actions */}
                  <div className="border-t border-slate-700 pt-4">
                    <Button
                      onClick={() => {
                        setShowSettings(false);
                        resetToMenu();
                      }}
                      variant="destructive"
                      size="sm"
                      className="w-full"
                    >
                      <RotateCcw className="w-3 h-3 mr-2" />
                      Spiel beenden
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Layered UI Demo Modal */}
      {showLayerDemo && (
        <LayeredUIDemo onClose={() => setShowLayerDemo(false)} />
      )}
    </Card>
  );
}
