import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Gift, Star, Crown, Diamond, Gem } from 'lucide-react';
import { RANK_TIERS, type RankTier, type SeasonReward } from '../../../shared/ranking';

interface SeasonRewardsProps {
  onBack: () => void;
  currentRank: string;
  seasonEndsIn?: number; // days
}

export function SeasonRewards({ onBack, currentRank, seasonEndsIn = 15 }: SeasonRewardsProps) {
  const [selectedRank, setSelectedRank] = useState<RankTier | null>(null);

  const getRankIcon = (rank: RankTier) => {
    const baseClasses = "w-6 h-6";
    switch (true) {
      case rank.minPoints >= 3000: return <Crown className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 2500: return <Star className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 2000: return <Diamond className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 1000: return <Trophy className={baseClasses} style={{ color: rank.color }} />;
      default: return <span className={baseClasses} style={{ color: rank.color }}>⚔️</span>;
    }
  };

  const formatReward = (reward: SeasonReward) => {
    const items: string[] = [];
    
    if (reward.basicPacks) items.push(`${reward.basicPacks}x Basis-Pack`);
    if (reward.premiumPacks) items.push(`${reward.premiumPacks}x Premium-Pack`);
    if (reward.legendaryPacks) items.push(`${reward.legendaryPacks}x Legendäres Pack`);
    if (reward.eventPacks) items.push(`${reward.eventPacks}x Event-Pack`);
    if (reward.gold) items.push(`${reward.gold} Gold`);
    if (reward.diamonds) items.push(`${reward.diamonds} Diamanten`);
    if (reward.specialItems) items.push(...reward.specialItems);
    
    return items;
  };

  const getRewardIcon = (item: string) => {
    if (item.includes('Diamanten')) return <Diamond className="w-4 h-4 text-blue-400" />;
    if (item.includes('Gold')) return <span className="text-yellow-500">🪙</span>;
    if (item.includes('Pack')) return <Gift className="w-4 h-4 text-purple-500" />;
    if (item.includes('Emblem') || item.includes('Avatar')) return <Star className="w-4 h-4 text-orange-500" />;
    if (item.includes('Titel') || item.includes('Karte')) return <Crown className="w-4 h-4 text-red-500" />;
    return <Gem className="w-4 h-4 text-green-500" />;
  };

  const groupedRanks = {
    'Bronze': RANK_TIERS.slice(0, 3),
    'Silber': RANK_TIERS.slice(3, 6),
    'Gold': RANK_TIERS.slice(6, 9),
    'Platin': RANK_TIERS.slice(9, 12),
    'Diamant': RANK_TIERS.slice(12, 15),
    'Mythisch': RANK_TIERS.slice(15, 18),
    'Legende': RANK_TIERS.slice(18, 21)
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-800 to-pink-700 bg-clip-text text-transparent">
            🏆 Saison-Belohnungen
          </h1>
          <p className="text-purple-700 text-lg mb-4">
            Erreiche höhere Ränge und sichere dir exklusive Belohnungen!
          </p>
          <div className="bg-orange-100 border border-orange-300 rounded-lg p-4 max-w-md mx-auto">
            <p className="text-orange-800 font-semibold">
              ⏰ Saison endet in: <span className="text-xl">{seasonEndsIn} Tagen</span>
            </p>
          </div>
        </motion.div>

        {/* Rank Groups */}
        <div className="space-y-8">
          {Object.entries(groupedRanks).map(([groupName, ranks], groupIndex) => (
            <motion.div
              key={groupName}
              className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border-2 border-purple-200 shadow-xl"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: groupIndex * 0.1 }}
            >
              <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: ranks[0].color }}>
                {ranks[0].emoji} {groupName}
              </h2>
              
              <div className="grid md:grid-cols-3 gap-4">
                {ranks.map((rank, index) => (
                  <motion.div
                    key={rank.id}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                      rank.id === currentRank 
                        ? 'border-yellow-400 bg-yellow-50 shadow-lg transform scale-105' 
                        : 'border-gray-200 bg-gray-50 hover:border-purple-300 hover:bg-purple-50'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedRank(rank)}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center mb-2">
                        {getRankIcon(rank)}
                        <span className="text-2xl ml-2">{rank.emoji}</span>
                      </div>
                      <h3 className="font-bold text-lg mb-1" style={{ color: rank.color }}>
                        {rank.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {rank.minPoints} - {rank.maxPoints === 999999 ? '∞' : rank.maxPoints} Punkte
                      </p>
                      {rank.id === currentRank && (
                        <div className="mt-2 bg-yellow-200 text-yellow-800 text-xs font-bold py-1 px-2 rounded-full">
                          Dein aktueller Rang
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-800 text-sm mb-2">Belohnungen:</h4>
                      {formatReward(rank.seasonReward).map((item, itemIndex) => (
                        <div key={itemIndex} className="flex items-center text-sm text-gray-700">
                          {getRewardIcon(item)}
                          <span className="ml-2">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Reward Detail Modal */}
        <AnimatePresence>
          {selectedRank && (
            <motion.div
              className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedRank(null)}
            >
              <motion.div
                className="bg-white rounded-2xl p-6 max-w-md w-full"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center mb-4">
                    {getRankIcon(selectedRank)}
                    <span className="text-4xl ml-3">{selectedRank.emoji}</span>
                  </div>
                  <h3 className="text-2xl font-bold mb-2" style={{ color: selectedRank.color }}>
                    {selectedRank.name}
                  </h3>
                  <p className="text-gray-600">
                    {selectedRank.minPoints} - {selectedRank.maxPoints === 999999 ? '∞' : selectedRank.maxPoints} Punkte
                  </p>
                </div>

                <div className="mb-6">
                  <h4 className="font-bold text-lg mb-4 text-gray-800">🎁 Saison-Belohnungen:</h4>
                  <div className="space-y-3">
                    {formatReward(selectedRank.seasonReward).map((item, index) => (
                      <motion.div
                        key={index}
                        className="flex items-center p-3 bg-gray-50 rounded-lg"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        {getRewardIcon(item)}
                        <span className="ml-3 text-gray-700 font-medium">{item}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setSelectedRank(null)}
                  className="w-full bg-purple-600 text-white font-bold py-3 px-6 rounded-xl hover:bg-purple-700 transition-colors"
                >
                  Schließen
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Info Section */}
        <motion.div
          className="bg-blue-100 border border-blue-300 rounded-2xl p-6 mt-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <h3 className="text-xl font-bold text-blue-800 mb-4">ℹ️ Wichtige Informationen</h3>
          <div className="grid md:grid-cols-2 gap-4 text-blue-700">
            <div>
              <h4 className="font-semibold mb-2">📅 Saison-System:</h4>
              <ul className="space-y-1 text-sm">
                <li>• Eine Saison dauert 1 Monat</li>
                <li>• Belohnungen werden automatisch vergeben</li>
                <li>• Rangpunkte werden am Saisonende zurückgesetzt</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">🎯 Tipps:</h4>
              <ul className="space-y-1 text-sm">
                <li>• Spiele täglich für bessere Belohnungen</li>
                <li>• Höhere Ränge = Bessere Belohnungen</li>
                <li>• Verliere keine Rangpunkte kurz vor Saisonende</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Back Button */}
        <motion.div
          className="text-center mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <button
            onClick={onBack}
            className="bg-gray-600 text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:bg-gray-700 transition-all duration-200"
          >
            Zurück zum Hauptmenü
          </button>
        </motion.div>
      </div>
    </div>
  );
}