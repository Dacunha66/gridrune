import { useCardGame } from "../lib/stores/useCardGame";

export function DynamicArrangementToggle() {
  const { dynamicArrangementEnabled, toggleDynamicArrangement } = useCardGame();

  return (
    <div className="flex items-center gap-2 text-sm">
      <button
        onClick={toggleDynamicArrangement}
        className={`
          flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all duration-200
          ${dynamicArrangementEnabled
            ? 'bg-green-600 text-white shadow-lg'
            : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
          }
        `}
      >
        <span className="text-xs">🔄</span>
        <span className="font-medium">Smart Order</span>
      </button>
      
      {dynamicArrangementEnabled && (
        <div className="text-xs text-green-400 animate-pulse">
          Karten werden strategisch angeordnet
        </div>
      )}
    </div>
  );
}