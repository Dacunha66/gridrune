import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from './Card';
import { GameCard } from '../lib/cardData';
import { cn } from '../lib/utils';

interface DragDropOverlayProps {
  draggedCard: GameCard | null;
  dragPosition: { x: number; y: number } | null;
  isDragging: boolean;
  snapTarget: {
    slotIndex: number;
    position: { x: number; y: number; width: number; height: number };
    isValid: boolean;
  } | null;
}

export function DragDropOverlay({ 
  draggedCard, 
  dragPosition, 
  isDragging, 
  snapTarget 
}: DragDropOverlayProps) {
  if (!isDragging || !draggedCard || !dragPosition) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {/* Dragged Card */}
      <motion.div
        className="absolute"
        style={{
          left: dragPosition.x - 40, // Center the card on cursor
          top: dragPosition.y - 56,
          transform: 'translate(-50%, -50%)'
        }}
        initial={{ scale: 1 }}
        animate={{ 
          scale: isDragging ? 1.1 : 1,
          rotate: isDragging ? 5 : 0
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <div className="opacity-90 shadow-2xl">
          <Card 
            card={draggedCard}
            size="small"
            owner="neutral"
            isOnBoard={false}
            showEffectBonuses={false}
          />
        </div>
      </motion.div>

      {/* Snap Target Indicator */}
      <AnimatePresence>
        {snapTarget && (
          <motion.div
            className={cn(
              "absolute border-4 rounded-lg",
              snapTarget.isValid 
                ? "border-green-400 bg-green-400/20" 
                : "border-red-400 bg-red-400/20"
            )}
            style={{
              left: snapTarget.position.x,
              top: snapTarget.position.y,
              width: snapTarget.position.width,
              height: snapTarget.position.height,
            }}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: 1,
              boxShadow: snapTarget.isValid 
                ? "0 0 20px rgba(34, 197, 94, 0.5)" 
                : "0 0 20px rgba(239, 68, 68, 0.5)"
            }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
          >
            {/* Pulse effect for valid targets */}
            {snapTarget.isValid && (
              <motion.div
                className="absolute inset-0 border-4 border-green-400 rounded-lg"
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.6, 0.2, 0.6]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
            
            {/* Target icon */}
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-white font-bold",
                  snapTarget.isValid ? "bg-green-500" : "bg-red-500"
                )}
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 0.6,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                {snapTarget.isValid ? "✓" : "✕"}
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Drop zone highlight */}
      <motion.div
        className="absolute inset-0 bg-blue-500/10 border-2 border-dashed border-blue-400"
        initial={{ opacity: 0 }}
        animate={{ opacity: isDragging ? 0.3 : 0 }}
        transition={{ duration: 0.2 }}
        style={{
          margin: '10px',
          borderRadius: '12px'
        }}
      />
    </div>
  );
}