import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { 
  Target, 
  X, 
  Clock, 
  Calendar, 
  Star,
  Trophy,
  Gift,
  ChevronRight,
  Zap,
  Sword,
  Shield,
  Crown
} from 'lucide-react';
import { useAudio } from '@/lib/stores/useAudio';
import { useAchievementUnlock } from './AchievementUnlockAnimation';
import { useWeeklyChallenges } from '@/lib/stores/useWeeklyChallenges';
import { useSeasonalRewards } from '@/lib/stores/useSeasonalRewards';
import { usePlayerProgress } from '@/lib/stores/usePlayerProgress';
import { WeeklyChallenges } from './WeeklyChallenges';
import { SeasonalRewards } from './SeasonalRewards';
import { AchievementsPanel } from './AchievementsPanel';
import { RewardNotification } from './RewardNotification';

interface QuestHubProps {
  isOpen: boolean;
  onClose: () => void;
}

type QuestTab = 'daily' | 'weekly' | 'seasonal' | 'achievements';

const DAILY_QUESTS = [
  {
    id: 'daily-cards',
    title: 'Kartenspieler',
    description: 'Spiele 3 Kartenspiele',
    progress: 2,
    target: 3,
    completed: true,
    reward: { xp: 100, gold: 50 }
  },
  {
    id: 'daily-wins',
    title: 'Siegesserie',
    description: 'Gewinne 2 Spiele in Folge',
    progress: 1,
    target: 2,
    completed: false,
    reward: { xp: 150, gold: 75, diamonds: 5 }
  },
  {
    id: 'daily-effects',
    title: 'Perfekter Sieg',
    description: 'Gewinne ein Spiel ohne Kartenverlust',
    progress: 1,
    target: 1,
    completed: true,
    reward: { xp: 200, gold: 100, diamonds: 10, packs: 2 }
  }
];

export function QuestHub({ isOpen, onClose }: QuestHubProps) {
  const [selectedTab, setSelectedTab] = useState<QuestTab>('daily');
  const [showRewardNotification, setShowRewardNotification] = useState(false);
  const [currentReward, setCurrentReward] = useState<{ xp?: number; gold?: number; diamonds?: number; packs?: number }>({});
  const [claimedQuests, setClaimedQuests] = useState<string[]>([]);
  const { playHit, playSuccess } = useAudio();
  const achievementUnlock = useAchievementUnlock();
  const { getCompletedTasksCount } = useWeeklyChallenges();
  const seasonalRewards = useSeasonalRewards();
  const playerProgress = usePlayerProgress();

  const handleTabChange = (tab: QuestTab) => {
    setSelectedTab(tab);
    playHit();
  };

  const handleClaimReward = (questId: string) => {
    const quest = DAILY_QUESTS.find(q => q.id === questId);
    if (!quest || !quest.completed || claimedQuests.includes(questId)) return;

    // Set up reward notification
    setCurrentReward(quest.reward);
    setShowRewardNotification(true);
    playSuccess();

    // Mark quest as claimed
    setClaimedQuests(prev => [...prev, questId]);
  };

  const handleRewardComplete = () => {
    // Add rewards to player progress
    if (currentReward.xp) playerProgress.addXp(currentReward.xp);
    if (currentReward.gold) playerProgress.addGold(currentReward.gold);
    if (currentReward.diamonds) playerProgress.addDiamonds(currentReward.diamonds);
    if (currentReward.packs) playerProgress.addPacks(currentReward.packs);

    // Clean up
    setShowRewardNotification(false);
    setCurrentReward({});
  };

  // Count pending rewards for each tab
  const safeClaimedQuests = claimedQuests || [];
  const dailyCompletedCount = DAILY_QUESTS.filter(q => q.completed && !safeClaimedQuests.includes(q.id)).length;
  const weeklyCompletedCount = getCompletedTasksCount();
  const seasonalCompletedCount = seasonalRewards.unclaimedRewards || 0;

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-slate-800 rounded-xl border border-slate-600 w-full max-w-6xl max-h-[90vh] overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-slate-600 bg-gradient-to-r from-slate-800 to-slate-700">
            <div className="flex items-center gap-3">
              <Target className="w-8 h-8 text-yellow-400" />
              <div>
                <h1 className="text-3xl font-bold text-white">Quest-Zentrale</h1>
                <p className="text-slate-400">Tägliche, wöchentliche und saisonale Herausforderungen</p>
              </div>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </Button>
          </div>

          {/* Tab Navigation */}
          <div className="border-b border-slate-600">
            <div className="flex">
              <button
                onClick={() => handleTabChange('daily')}
                className={cn(
                  'flex-1 px-6 py-4 text-center font-medium transition-colors relative',
                  selectedTab === 'daily'
                    ? 'text-blue-400 bg-blue-500/10 border-b-2 border-blue-400'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                )}
              >
                <div className="flex items-center justify-center gap-2">
                  <Clock className="w-5 h-5" />
                  <span>Tägliche Quests</span>
                </div>
                {dailyCompletedCount > 0 && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                    {dailyCompletedCount}
                  </div>
                )}
              </button>
              
              <button
                onClick={() => handleTabChange('weekly')}
                className={cn(
                  'flex-1 px-6 py-4 text-center font-medium transition-colors relative',
                  selectedTab === 'weekly'
                    ? 'text-purple-400 bg-purple-500/10 border-b-2 border-purple-400'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                )}
              >
                <div className="flex items-center justify-center gap-2">
                  <Calendar className="w-5 h-5" />
                  <span>Wöchentliche Herausforderungen</span>
                </div>
                {weeklyCompletedCount > 0 && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                    {weeklyCompletedCount}
                  </div>
                )}
              </button>
              
              <button
                onClick={() => handleTabChange('seasonal')}
                className={cn(
                  'flex-1 px-6 py-4 text-center font-medium transition-colors relative',
                  selectedTab === 'seasonal'
                    ? 'text-green-400 bg-green-500/10 border-b-2 border-green-400'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                )}
              >
                <div className="flex items-center justify-center gap-2">
                  <Crown className="w-5 h-5" />
                  <span>Saisonale Belohnungen</span>
                </div>
                {seasonalCompletedCount > 0 && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                    {seasonalCompletedCount}
                  </div>
                )}
              </button>
              
              <button
                onClick={() => handleTabChange('achievements')}
                className={cn(
                  'flex-1 px-6 py-4 text-center font-medium transition-colors',
                  selectedTab === 'achievements'
                    ? 'text-yellow-400 bg-yellow-500/10 border-b-2 border-yellow-400'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                )}
              >
                <div className="flex items-center justify-center gap-2">
                  <Trophy className="w-5 h-5" />
                  <span>Erfolge</span>
                </div>
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="overflow-y-auto max-h-[60vh]">
            <AnimatePresence mode="wait">
              {selectedTab === 'daily' && (
                <motion.div
                  key="daily"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-6"
                >
                  <DailyQuestsContent 
                    claimedQuests={claimedQuests}
                    onClaimReward={handleClaimReward}
                  />
                </motion.div>
              )}
              
              {selectedTab === 'weekly' && (
                <motion.div
                  key="weekly"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-6"
                >
                  <WeeklyChallenges 
                    onBack={() => {}} 
                    onShowReward={(reward) => {
                      setCurrentReward(reward);
                      setShowRewardNotification(true);
                    }}
                  />
                </motion.div>
              )}
              
              {selectedTab === 'seasonal' && (
                <motion.div
                  key="seasonal"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-6"
                >
                  <SeasonalRewards 
                    onBack={() => {}} 
                    onShowReward={(reward) => {
                      setCurrentReward(reward);
                      setShowRewardNotification(true);
                    }}
                  />
                </motion.div>
              )}
              
              {selectedTab === 'achievements' && (
                <motion.div
                  key="achievements"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-6"
                >
                  <AchievementsPanel onBack={() => {}} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
      
      {/* Reward Notification */}
      <RewardNotification
        show={showRewardNotification}
        rewards={currentReward}
        onComplete={handleRewardComplete}
      />
      
      {achievementUnlock.AchievementUnlockAnimation && <achievementUnlock.AchievementUnlockAnimation />}
    </>
  );
}

// Daily Quests Content Component
function DailyQuestsContent({ claimedQuests, onClaimReward }: {
  claimedQuests: string[];
  onClaimReward: (questId: string) => void;
}) {
  const safeClaimedQuests = claimedQuests || [];

  return (
    <div className="space-y-6">
      <div className="grid gap-4">
        {DAILY_QUESTS.map((quest) => (
          <Card key={quest.id} className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                      <Sword className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">{quest.title}</h3>
                      <p className="text-slate-400">{quest.description}</p>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-slate-400">Fortschritt</span>
                      <span className="text-white font-medium">
                        {quest.progress}/{quest.target}
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div 
                        className={cn(
                          'h-2 rounded-full transition-all',
                          quest.completed 
                            ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                            : 'bg-gradient-to-r from-blue-500 to-cyan-500'
                        )}
                        style={{ width: `${(quest.progress / quest.target) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  {/* Rewards */}
                  <div className="flex items-center gap-2 md:gap-4 text-xs md:text-sm flex-wrap">
                    <div className="flex items-center gap-1 text-blue-400">
                      <Star className="w-4 h-4" />
                      <span>{quest.reward.xp} XP</span>
                    </div>
                    {quest.reward.gold && (
                      <div className="flex items-center gap-1 text-yellow-500">
                        <span>🪙</span>
                        <span>{quest.reward.gold} Gold</span>
                      </div>
                    )}
                    {quest.reward.diamonds && (
                      <div className="flex items-center gap-1 text-cyan-400">
                        <span>💎</span>
                        <span>{quest.reward.diamonds} Diamanten</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="ml-2 md:ml-6 flex-shrink-0">
                  {quest.completed ? (
                    safeClaimedQuests.includes(quest.id) ? (
                      <Button
                        disabled
                        className="bg-gray-600 text-gray-400 cursor-not-allowed"
                        size="sm"
                      >
                        <Trophy className="w-4 h-4 md:mr-2" />
                        <span className="hidden md:inline">Erhalten</span>
                        <span className="md:hidden">✓</span>
                      </Button>
                    ) : (
                      <Button
                        onClick={() => onClaimReward(quest.id)}
                        className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 animate-pulse"
                        size="sm"
                      >
                        <Gift className="w-4 h-4 md:mr-2" />
                        <span className="hidden md:inline">Abholen</span>
                        <span className="md:hidden">💰</span>
                      </Button>
                    )
                  ) : (
                    <div className="text-center">
                      <div className="text-slate-400 text-sm mb-2">In Bearbeitung</div>
                      <ChevronRight className="w-6 h-6 text-slate-600 mx-auto" />
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Daily Bonus */}
      <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-500/30">
        <CardContent className="p-6 text-center">
          <Star className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-white mb-2">Täglicher Bonus</h3>
          <p className="text-slate-400 mb-4">
            Schließe alle täglichen Quests ab für einen Extrabonus!
          </p>
          <div className="flex items-center justify-center gap-4 text-lg">
            <div className="flex items-center gap-2 text-blue-400">
              <Star className="w-5 h-5" />
              <span className="font-semibold">+100 XP</span>
            </div>
            <div className="flex items-center gap-2 text-yellow-500">
              <span>🪙</span>
              <span className="font-semibold">+200 Gold</span>
            </div>
            <div className="flex items-center gap-2 text-cyan-400">
              <span>💎</span>
              <span className="font-semibold">+10 Diamanten</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default QuestHub;