import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft } from 'lucide-react';

interface MobileTutorialProps {
  isVisible: boolean;
  onClose: () => void;
}

const tutorialSteps = [
  {
    id: 1,
    title: "Touch-Steuerung",
    icon: "👆",
    description: "Tippe kurz auf ein Feld, um deine Karte zu platzieren",
    highlight: "Kurzes Antippen = Karte platzieren"
  },
  {
    id: 2,
    title: "Karten-Details",
    icon: "🔍",
    description: "Halte eine Karte 0.5 Sekunden gedrückt, um alle Details zu sehen",
    highlight: "Langes Drücken = Karten-Details anzeigen"
  },
  {
    id: 3,
    title: "Platzierungshilfe",
    icon: "✨",
    description: "Grüne Felder zeigen dir, wo du deine Karten platzieren kannst",
    highlight: "Grüne Markierung = Gültiger Platz"
  },
  {
    id: 4,
    title: "Handkarten wischen",
    icon: "↔️",
    description: "Wische nach links oder rechts, um durch deine Handkarten zu navigieren",
    highlight: "Wischen = Durch Karten blättern"
  }
];

export function MobileTutorial({ isVisible, onClose }: MobileTutorialProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [touchStartX, setTouchStartX] = useState(0);

  // Handle swipe gestures for navigation
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const touchEndX = e.changedTouches[0].clientX;
    const diffX = touchStartX - touchEndX;

    // Swipe threshold
    if (Math.abs(diffX) > 50) {
      if (diffX > 0 && currentStep < tutorialSteps.length - 1) {
        // Swipe left - next step
        setCurrentStep(prev => prev + 1);
      } else if (diffX < 0 && currentStep > 0) {
        // Swipe right - previous step
        setCurrentStep(prev => prev - 1);
      }
    }
  };

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleClose = () => {
    // Mark tutorial as completed in localStorage
    localStorage.setItem('mobileTutorialCompleted', 'true');
    onClose();
  };

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
        onClick={handleClose}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          className="bg-slate-800 rounded-xl max-w-sm w-full mx-4 overflow-hidden border border-white/20"
          onClick={(e) => e.stopPropagation()}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-white relative">
            <button
              onClick={handleClose}
              className="absolute top-3 right-3 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X size={18} />
            </button>
            <div className="text-center">
              <h3 className="text-lg font-bold">Mobile Tutorial</h3>
              <p className="text-sm opacity-90 mt-1">
                Schritt {currentStep + 1} von {tutorialSteps.length}
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="text-center"
              >
                <div className="text-4xl mb-4">
                  {tutorialSteps[currentStep].icon}
                </div>
                <h4 className="text-xl font-bold text-white mb-3">
                  {tutorialSteps[currentStep].title}
                </h4>
                <p className="text-slate-300 text-sm leading-relaxed mb-4">
                  {tutorialSteps[currentStep].description}
                </p>
                <div className="bg-slate-700 rounded-lg p-3">
                  <p className="text-blue-400 font-semibold text-sm">
                    💡 {tutorialSteps[currentStep].highlight}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Progress indicators */}
          <div className="px-6 pb-4">
            <div className="flex justify-center space-x-2 mb-4">
              {tutorialSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentStep ? 'bg-blue-500' : 'bg-slate-600'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="bg-slate-700 px-6 py-4 flex justify-between items-center">
            <button
              onClick={prevStep}
              disabled={currentStep === 0}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                currentStep === 0
                  ? 'text-slate-500 cursor-not-allowed'
                  : 'text-white hover:bg-slate-600'
              }`}
            >
              <ChevronLeft size={16} />
              <span className="text-sm">Zurück</span>
            </button>

            {currentStep === tutorialSteps.length - 1 ? (
              <button
                onClick={handleClose}
                className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all"
              >
                <span className="text-sm font-semibold">Verstanden!</span>
              </button>
            ) : (
              <button
                onClick={nextStep}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <span className="text-sm">Weiter</span>
                <ChevronRight size={16} />
              </button>
            )}
          </div>

          {/* Swipe hint */}
          <div className="bg-slate-900 px-4 py-2 text-center">
            <p className="text-xs text-slate-400">
              💬 Wische nach links/rechts zum Navigieren
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}