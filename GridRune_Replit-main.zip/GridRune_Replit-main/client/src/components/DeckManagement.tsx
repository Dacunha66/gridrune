import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCardGame } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ArrowLeft, Plus, Edit, Trash2, Eye, Play, Palette, Crown, Sparkles, CheckCircle, Share2, Download } from "lucide-react";
import { useAudio } from "../lib/stores/useAudio";
import DeckSharingModal from "./DeckSharingModal";
import { useDeckSharing, type SharedDeck } from "../lib/stores/useDeckSharing";

export function DeckManagement() {
  const { 
    savedDecks, 
    selectedDeckForGame, 
    setGamePhase, 
    deleteDeck, 
    selectDeckForGame, 
    setCurrentEditingDeck 
  } = useCardGame();
  const { playHit, playSuccess } = useAudio();
  const [hoveredDeck, setHoveredDeck] = useState<number>(-1);
  const [sharingModal, setSharingModal] = useState<{
    isOpen: boolean;
    mode: 'share' | 'import';
    deckIndex?: number;
  }>({ isOpen: false, mode: 'share' });
  
  const deckSharingStore = useDeckSharing();

  const handleEditDeck = (index: number) => {
    setCurrentEditingDeck(index);
    setGamePhase("deck-editor");
  };

  const handleCreateNewDeck = () => {
    setCurrentEditingDeck(null); // null means creating new deck
    setGamePhase("deck-creator");
  };

  const handleViewAllCards = () => {
    setGamePhase("card-collection");
  };

  const handleShareDeck = (deckIndex: number) => {
    setSharingModal({ isOpen: true, mode: 'share', deckIndex });
  };

  const handleImportDeck = () => {
    setSharingModal({ isOpen: true, mode: 'import' });
  };

  const handleDeckImported = (deck: SharedDeck) => {
    // Use the importDeck function from useCardGame
    const { importDeck } = useCardGame.getState();
    importDeck(deck.name, deck.cards, deck.boardSize);
    
    playSuccess();
    setSharingModal({ isOpen: false, mode: 'import' });
  };

  const getDeckSizeLabel = (deckSize: string) => {
    switch (deckSize) {
      case "3x3": return "10 Karten (3x3)";
      case "4x4": return "15 Karten (4x4)";
      case "5x5": return "25 Karten (5x5)";
      default: return "Unbekannt";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-2 sm:p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header - Mobile optimized */}
        <div className="flex items-center justify-between mb-4 sm:mb-8">
          <Button 
            onClick={() => setGamePhase("menu")}
            variant="outline"
            size="sm"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Zurück zum Menü</span>
            <span className="sm:hidden">Zurück</span>
          </Button>
          
          <h1 className="text-xl sm:text-3xl font-bold">Deck-Verwaltung</h1>
          
          <div className="w-16 sm:w-32" /> {/* Spacer for alignment */}
        </div>

        {/* Menu Options - Mobile optimized */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-6 mb-4 sm:mb-8">
          {/* Edit Current Deck */}
          <Card className="bg-slate-800 border-slate-600 hover:bg-slate-750 transition-colors cursor-pointer" 
                onClick={() => setGamePhase("deck-editor")}>
            <CardHeader className="text-center p-3 sm:p-6">
              <Edit className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-1 sm:mb-2 text-blue-400" />
              <CardTitle className="text-white text-sm sm:text-base">Deck bearbeiten</CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-6 pt-0">
              <p className="text-slate-300 text-center text-xs sm:text-sm">
                Bearbeite dein aktuelles Deck für das Spiel
              </p>
            </CardContent>
          </Card>

          {/* Create New Deck */}
          <Card className="bg-slate-800 border-slate-600 hover:bg-slate-750 transition-colors cursor-pointer" 
                onClick={handleCreateNewDeck}>
            <CardHeader className="text-center p-3 sm:p-6">
              <Plus className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-1 sm:mb-2 text-green-400" />
              <CardTitle className="text-white text-sm sm:text-base">Deck erstellen</CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-6 pt-0">
              <p className="text-slate-300 text-center text-xs sm:text-sm">
                Erstelle ein neues Deck (max. 5 Decks)
              </p>
              <p className="text-slate-400 text-xs sm:text-sm text-center mt-1 sm:mt-2">
                {savedDecks.length}/5 Decks erstellt
              </p>
            </CardContent>
          </Card>

          {/* Theme Customization */}
          <Card className="bg-slate-800 border-slate-600 hover:bg-slate-750 transition-colors cursor-pointer" 
                onClick={() => setGamePhase("deck-theme-customizer")}>
            <CardHeader className="text-center p-3 sm:p-6">
              <Palette className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-1 sm:mb-2 text-pink-400" />
              <CardTitle className="text-white text-sm sm:text-base">Themes anpassen</CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-6 pt-0">
              <p className="text-slate-300 text-center text-xs sm:text-sm">
                Personalisiere das Aussehen deiner Decks
              </p>
            </CardContent>
          </Card>

          {/* Import Deck */}
          <Card className="bg-slate-800 border-slate-600 hover:bg-slate-750 transition-colors cursor-pointer" 
                onClick={handleImportDeck}>
            <CardHeader className="text-center p-3 sm:p-6">
              <Download className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-1 sm:mb-2 text-cyan-400" />
              <CardTitle className="text-white text-sm sm:text-base">Deck Importieren</CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-6 pt-0">
              <p className="text-slate-300 text-center text-xs sm:text-sm">
                Importiere geteilte Decks von anderen Spielern
              </p>
            </CardContent>
          </Card>

          {/* View All Cards */}
          <Card className="bg-slate-800 border-slate-600 hover:bg-slate-750 transition-colors cursor-pointer" 
                onClick={handleViewAllCards}>
            <CardHeader className="text-center p-3 sm:p-6">
              <Eye className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-1 sm:mb-2 text-purple-400" />
              <CardTitle className="text-white text-sm sm:text-base">Alle Karten ansehen</CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-6 pt-0">
              <p className="text-slate-300 text-center text-xs sm:text-sm">
                Betrachte alle verfügbaren Karten in deiner Sammlung
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Saved Decks */}
        <div className="mb-4 sm:mb-8">
          <h2 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4">Gespeicherte Decks</h2>
          
          {savedDecks.length === 0 ? (
            <Card className="bg-slate-800 border-slate-600">
              <CardContent className="text-center py-8">
                <p className="text-slate-400">Noch keine Decks erstellt</p>
                <Button 
                  onClick={handleCreateNewDeck}
                  className="mt-4 bg-green-600 hover:bg-green-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Erstes Deck erstellen
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {savedDecks.map((deck, index) => (
                <Card 
                  key={index} 
                  className={`bg-slate-800 border-slate-600 ${
                    selectedDeckForGame === index 
                      ? 'ring-2 ring-blue-400 bg-blue-900/20' 
                      : ''
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span>{deck.name}</span>
                      {selectedDeckForGame === index && (
                        <Play className="w-4 h-4 text-blue-400" />
                      )}
                    </CardTitle>
                    <div className="flex justify-between items-center text-sm">
                      <p className="text-slate-400">
                        {getDeckSizeLabel(deck.boardSize)}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">{deck.cards.length} Karten</span>
                        {deck.boardSize === "4x4" && (
                          <span className="text-xs bg-purple-600 px-2 py-0.5 rounded">Hauptspiel</span>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => selectDeckForGame(index)}
                        variant="outline"
                        size="sm"
                        className={`flex-1 ${
                          selectedDeckForGame === index 
                            ? 'bg-blue-600 border-blue-500 text-white' 
                            : 'text-white border-slate-600 hover:bg-slate-700'
                        }`}
                      >
                        {selectedDeckForGame === index ? 'Ausgewählt' : 'Auswählen'}
                      </Button>
                      <Button
                        onClick={() => handleEditDeck(index)}
                        variant="outline"
                        size="sm"
                        className="text-white border-slate-600 hover:bg-slate-700"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => handleShareDeck(index)}
                        variant="outline"
                        size="sm"
                        className="text-green-400 border-green-600 hover:bg-green-900"
                      >
                        <Share2 className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => deleteDeck(index)}
                        variant="outline"
                        size="sm"
                        className="text-red-400 border-red-600 hover:bg-red-900"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Deck Size Requirements */}
        <Card className="bg-slate-800 border-slate-600">
          <CardHeader>
            <CardTitle className="text-white">Deck-Anforderungen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div>
                <h3 className="text-lg font-semibold text-blue-400">3x3 Modus</h3>
                <p className="text-slate-300">10 Karten im Deck</p>
                <p className="text-slate-400 text-sm">5 Handkarten</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-green-400">4x4 Modus</h3>
                <p className="text-slate-300">15 Karten im Deck</p>
                <p className="text-slate-400 text-sm">5 Handkarten</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-purple-400">5x5 Modus</h3>
                <p className="text-slate-300">25 Karten im Deck</p>
                <p className="text-slate-400 text-sm">5 Handkarten</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Deck Sharing Modal */}
      <DeckSharingModal
        isOpen={sharingModal.isOpen}
        onClose={() => setSharingModal({ isOpen: false, mode: 'share' })}
        mode={sharingModal.mode}
        deckToShare={
          sharingModal.mode === 'share' && sharingModal.deckIndex !== undefined
            ? savedDecks[sharingModal.deckIndex]
            : undefined
        }
        onDeckImported={handleDeckImported}
      />
    </div>
  );
}