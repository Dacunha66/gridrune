import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { PackOpening } from './PackOpening';
import { useCardGame } from '../lib/stores/useCardGame';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { GameCard, allCards, Rarity, RARITY_CONFIG } from '../lib/cardData';
import { ArrowLeft, Info } from 'lucide-react';
import PayPalButton from './PayPalButton';
import { DynamicBackground } from './DynamicBackground';

interface ShopPack {
  id: string;
  name: string;
  description: string | React.ReactNode;
  goldPrice?: number;
  diamondPrice?: number;
  cardCount: number;
  rarity: {
    common: number;
    uncommon: number;
    rare: number;
    epic: number;
    legendary: number;
  };
  image: string;
  limited?: boolean;
  featured?: boolean;
}

interface PackDrawRates {
  guaranteed: (string | React.ReactNode)[];
  chances: { rarity: string; color: string; rate: string; }[];
}

interface Currency {
  gold: number;
  diamonds: number;
  packs: number;
}

const SHOP_PACKS: ShopPack[] = [
  {
    id: 'basic',
    name: 'Basis-Pack',
    description: (
      <>
        4 <span className="text-gray-400 font-bold">gewöhnliche</span> oder{' '}
        <span className="text-green-400 font-bold">ungewöhnliche</span> und 1 Karte mind.{' '}
        <span className="text-blue-400 font-bold">selten</span>
      </>
    ),
    goldPrice: 100,
    diamondPrice: 10,
    cardCount: 5,
    rarity: {
      common: 3,
      uncommon: 1,
      rare: 0.8,
      epic: 0.15,
      legendary: 0.05
    },
    image: '/images/basic-pack.png'
  },
  {
    id: 'premium',
    name: 'Premium-Pack',
    description: (
      <>
        3 <span className="text-gray-400 font-bold">gewöhnliche</span> oder{' '}
        <span className="text-green-400 font-bold">ungewöhnliche</span>, 1{' '}
        <span className="text-blue-400 font-bold">seltene</span> und 1{' '}
        <span className="text-purple-400 font-bold">epische</span> oder{' '}
        <span className="text-yellow-400 font-bold">legendäre</span>
      </>
    ),
    diamondPrice: 25,
    cardCount: 5,
    rarity: {
      common: 2,
      uncommon: 1,
      rare: 1,
      epic: 0.8,
      legendary: 0.2
    },
    image: '/images/premium-pack.png',
    featured: true
  },
  {
    id: 'legendary',
    name: 'Legendäres Pack',
    description: (
      <>
        8 Karten: 5 <span className="text-gray-400 font-bold">gewöhnliche</span> oder{' '}
        <span className="text-green-400 font-bold">ungewöhnliche</span>, 1{' '}
        <span className="text-blue-400 font-bold">seltene</span> und 2{' '}
        <span className="text-purple-400 font-bold">EPISCHE</span> oder{' '}
        <span className="text-yellow-400 font-bold">LEGENDÄRE</span> Karten!
      </>
    ),
    diamondPrice: 50,
    cardCount: 8,
    rarity: {
      common: 3,
      uncommon: 2,
      rare: 1,
      epic: 1.4,
      legendary: 0.6
    },
    image: '/images/legendary-pack.png',
    limited: true
  }
];

export function Shop() {
  const { stats, addPacks } = usePlayerProgress();
  const [currency, setCurrency] = useState<Currency>({ 
    gold: stats.gold, 
    diamonds: stats.diamonds,
    packs: stats.packs 
  });
  
  // Sync with PlayerProgress when stats change
  useEffect(() => {
    setCurrency({
      gold: stats.gold,
      diamonds: stats.diamonds,
      packs: stats.packs
    });
  }, [stats]);
  const [selectedPack, setSelectedPack] = useState<ShopPack | null>(null);
  const [isOpening, setIsOpening] = useState(false);
  const [openedCards, setOpenedCards] = useState<GameCard[]>([]);
  const [purchaseHistory, setPurchaseHistory] = useState<string[]>([]);
  const [paypalAvailable, setPaypalAvailable] = useState<boolean>(false);
  
  const { setGamePhase } = useCardGame();

  // Calculate draw rates for pack information
  const getPackDrawRates = (pack: ShopPack) => {
    if (pack.id === 'basic') {
      return {
        guaranteed: [
          <>4 <span className="text-gray-400">Gewöhnliche</span> oder <span className="text-green-400">Ungewöhnliche</span></>,
          <>1 <span className="text-blue-400">Seltene</span> (mindestens)</>
        ],
        chances: [
          { rarity: 'Gewöhnliche', color: 'text-gray-400', rate: '100%' },
          { rarity: 'Ungewöhnliche', color: 'text-green-400', rate: '100%' },
          { rarity: 'Seltene', color: 'text-blue-400', rate: '80%' },
          { rarity: 'Epische', color: 'text-purple-400', rate: '15%' },
          { rarity: 'Legendäre', color: 'text-yellow-400', rate: '5%' }
        ]
      };
    } else if (pack.id === 'premium') {
      return {
        guaranteed: [
          <>3 <span className="text-gray-400">Gewöhnliche</span> oder <span className="text-green-400">Ungewöhnliche</span></>,
          <>1 <span className="text-blue-400">Seltene</span></>,
          <>1 <span className="text-purple-400">Epische</span> oder <span className="text-yellow-400">Legendäre</span></>
        ],
        chances: [
          { rarity: 'Gewöhnliche', color: 'text-gray-400', rate: '100%' },
          { rarity: 'Ungewöhnliche', color: 'text-green-400', rate: '100%' },
          { rarity: 'Seltene', color: 'text-blue-400', rate: '100%' },
          { rarity: 'Epische', color: 'text-purple-400', rate: '80%' },
          { rarity: 'Legendäre', color: 'text-yellow-400', rate: '20%' }
        ]
      };
    } else if (pack.id === 'legendary') {
      return {
        guaranteed: [
          <>5 <span className="text-gray-400">Gewöhnliche</span> oder <span className="text-green-400">Ungewöhnliche</span></>,
          <>1 <span className="text-blue-400">Seltene</span></>,
          <>2 <span className="text-purple-400">Epische</span> oder <span className="text-yellow-400">Legendäre</span></>
        ],
        chances: [
          { rarity: 'Gewöhnliche', color: 'text-gray-400', rate: '100%' },
          { rarity: 'Ungewöhnliche', color: 'text-green-400', rate: '100%' },
          { rarity: 'Seltene', color: 'text-blue-400', rate: '100%' },
          { rarity: 'Epische', color: 'text-purple-400', rate: '70% je Slot' },
          { rarity: 'Legendäre', color: 'text-yellow-400', rate: '30% je Slot' }
        ]
      };
    }
    return { guaranteed: [], chances: [] };
  };
  
  // Check PayPal availability on mount
  useEffect(() => {
    const checkPaypalAvailability = async () => {
      try {
        const response = await fetch('/paypal/setup');
        setPaypalAvailable(response.ok);
      } catch {
        setPaypalAvailable(false);
      }
    };
    
    checkPaypalAvailability();
  }, []);

  const generatePackCards = (pack: ShopPack): GameCard[] => {
    const cards: GameCard[] = [];
    const availableCards = allCards.filter(card => card.id !== 'O');
    
    // Calculate guaranteed rarities based on pack type
    const rarities: Rarity[] = [];
    
    if (pack.id === 'legendary') {
      // 8 Karten: 5 gewöhnliche oder ungewöhnliche, 1 seltene und 2 EPISCHE oder LEGENDÄRE
      rarities.push('common', 'common', 'uncommon', 'uncommon', 'uncommon', 'rare', 'epic', 'epic');
      
      // Chance for legendary in epic slots
      if (Math.random() < 0.3) rarities[6] = 'legendary';
      if (Math.random() < 0.3) rarities[7] = 'legendary';
      
    } else if (pack.id === 'premium') {
      // 3 gewöhnliche oder ungewöhnliche, 1 seltene und 1 epische oder legendäre
      rarities.push('common', 'uncommon', 'uncommon', 'rare', 'epic');
      
      // Chance for legendary in epic slot
      if (Math.random() < 0.2) rarities[4] = 'legendary';
      
    } else {
      // Basic pack - 4 gewöhnliche oder ungewöhnliche und 1 Karte mind. selten
      rarities.push('common', 'common', 'uncommon', 'uncommon', 'rare');
      
      // Small chance for higher rarity in the rare slot
      if (Math.random() < 0.15) rarities[4] = 'epic';
      if (Math.random() < 0.05) rarities[4] = 'legendary';
    }
    
    // Generate cards for each rarity
    rarities.forEach(targetRarity => {
      const cardsOfRarity = availableCards.filter(card => 
        card.rarity === targetRarity || (!card.rarity && targetRarity === 'common')
      );
      
      if (cardsOfRarity.length > 0) {
        const randomCard = cardsOfRarity[Math.floor(Math.random() * cardsOfRarity.length)];
        cards.push({
          ...randomCard,
          id: `${randomCard.id}-${Date.now()}-${Math.random()}`
        });
      }
    });
    
    return cards.slice(0, pack.cardCount);
  };

  const handlePurchase = (pack: ShopPack) => {
    const canAffordGold = pack.goldPrice && currency.gold >= pack.goldPrice;
    const canAffordDiamonds = pack.diamondPrice && currency.diamonds >= pack.diamondPrice;
    
    if (!canAffordGold && !canAffordDiamonds) {
      return;
    }
    
    // Prefer gold if both are available and affordable
    let usedCurrency: 'gold' | 'diamonds' = 'diamonds';
    if (canAffordGold && pack.goldPrice) {
      usedCurrency = 'gold';
      setCurrency(prev => ({ ...prev, gold: prev.gold - pack.goldPrice! }));
    } else if (canAffordDiamonds && pack.diamondPrice) {
      setCurrency(prev => ({ ...prev, diamonds: prev.diamonds - pack.diamondPrice! }));
    }
    
    // Also add 1 pack to player's pack inventory
    setCurrency(prev => ({ ...prev, packs: prev.packs + 1 }));
    
    // Generate cards and start opening animation
    const newCards = generatePackCards(pack);
    setOpenedCards(newCards);
    setSelectedPack(pack);
    setIsOpening(true);
    
    // Add to purchase history
    setPurchaseHistory(prev => [...prev, `${pack.name} (${usedCurrency === 'gold' ? pack.goldPrice + ' Gold' : pack.diamondPrice + ' Diamanten'})`]);
  };

  const handlePackOpeningComplete = (cards: GameCard[]) => {
    // Add cards to player's collection (for now just close the modal)
    // TODO: Implement proper card collection system
    setIsOpening(false);
    setSelectedPack(null);
    setOpenedCards([]);
  };

  const handleFreePack = () => {
    // Create a free reward pack with guaranteed rare card
    const freePackData = {
      id: 'free-reward',
      name: 'Belohnungs-Pack',
      cardCount: 5,
      rarity: {
        common: 2,
        uncommon: 2, 
        rare: 1,
        epic: 0,
        legendary: 0
      }
    };
    
    // Generate cards with at least 1 rare guaranteed
    const newCards = generatePackCards(freePackData as ShopPack);
    setOpenedCards(newCards);
    setSelectedPack(freePackData as ShopPack);
    setIsOpening(true);
    
    // Remove one pack from inventory - sync with PlayerProgress
    setCurrency(prev => ({ ...prev, packs: prev.packs - 1 }));
    addPacks(-1); // Remove 1 pack from PlayerProgress store
  };

  const canAfford = (pack: ShopPack) => {
    const goldAffordable = pack.goldPrice ? currency.gold >= pack.goldPrice : false;
    const diamondsAffordable = pack.diamondPrice ? currency.diamonds >= pack.diamondPrice : false;
    return goldAffordable || diamondsAffordable;
  };

  return (
    <DynamicBackground dominantRarity="epic" intensity={1.2}>
      <div className="min-h-screen p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-between mb-4">
            <Button
              onClick={() => setGamePhase("menu")}
              variant="outline"
              className="text-white border-gray-600 hover:bg-gray-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Zurück zum Menü
            </Button>
            <div></div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">🛍️ Karten-Shop</h1>
          <p className="text-gray-300">Sammle mächtige Karten für deine Decks</p>
        </div>

        {/* Currency Display */}
        <div className="flex justify-center gap-6 mb-8">
          <div className="flex items-center gap-2 bg-yellow-600/20 px-4 py-2 rounded-lg border border-yellow-500/30">
            <span className="text-yellow-400 text-xl">🪙</span>
            <span className="text-white font-bold">{currency.gold.toLocaleString()}</span>
            <span className="text-yellow-400 text-sm">Gold</span>
          </div>
          <div className="flex items-center gap-2 bg-cyan-600/20 px-4 py-2 rounded-lg border border-cyan-500/30">
            <span className="text-cyan-400 text-xl">💎</span>
            <span className="text-white font-bold">{currency.diamonds}</span>
            <span className="text-cyan-400 text-sm">Diamanten</span>
          </div>
          {currency.packs > 0 && (
            <div className="flex items-center gap-2 bg-purple-600/20 px-4 py-2 rounded-lg border border-purple-500/30">
              <span className="text-purple-400 text-xl">📦</span>
              <span className="text-white font-bold">{currency.packs}</span>
              <span className="text-purple-400 text-sm">Packs bereit</span>
            </div>
          )}
        </div>

        {/* Free Packs Section */}
        {currency.packs > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white text-center mb-6 flex items-center justify-center gap-3">
              <span className="text-purple-400 text-3xl">🎁</span>
              Kostenlose Packs
              <span className="text-purple-400 text-3xl">🎁</span>
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[...Array(currency.packs)].map((_, index) => (
                <motion.div
                  key={`free-pack-${index}`}
                  className="relative bg-gradient-to-br from-purple-800/50 via-purple-700/30 to-purple-900/50 backdrop-blur-sm rounded-xl p-6 border-2 border-purple-400 shadow-purple-400/30 shadow-lg cursor-pointer hover:scale-105 transition-all duration-300"
                  whileHover={{ scale: 1.02 }}
                  onClick={() => handleFreePack()}
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-500 text-white font-bold animate-pulse">KOSTENLOS</Badge>
                  </div>

                  <div className="text-center">
                    <motion.div 
                      className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center"
                      animate={{ 
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0]
                      }}
                      transition={{ 
                        duration: 2, 
                        repeat: Infinity,
                        ease: "easeInOut" 
                      }}
                    >
                      <span className="text-3xl">🎁</span>
                    </motion.div>
                    
                    <h3 className="text-xl font-bold text-white mb-2">Belohnungs-Pack</h3>
                    <p className="text-purple-200 text-sm mb-4">
                      Erhalten durch Quest-Belohnungen
                    </p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="text-sm text-purple-200">
                        <span className="font-medium">5 Zufallskarten</span>
                      </div>
                      <div className="text-xs text-purple-300">
                        Mindestens 1 seltene Karte garantiert
                      </div>
                    </div>
                    
                    <motion.div
                      className="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-lg transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Pack öffnen
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Shop Packs */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white text-center mb-6">🛍️ Shop Packs</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {SHOP_PACKS.map(pack => (
            <motion.div
              key={pack.id}
              className={cn(
                "relative bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border-2 transition-all duration-300",
                pack.featured && "border-yellow-500 shadow-yellow-500/20 shadow-lg",
                pack.limited && "border-purple-500 shadow-purple-500/20 shadow-lg",
                !pack.featured && !pack.limited && "border-gray-600 hover:border-gray-500",
                canAfford(pack) ? "cursor-pointer hover:scale-105" : "opacity-60"
              )}
              whileHover={canAfford(pack) ? { scale: 1.02 } : {}}
              onClick={() => canAfford(pack) && handlePurchase(pack)}
            >
              {pack.featured && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-500 text-black font-bold">EMPFOHLEN</Badge>
                </div>
              )}
              
              {pack.limited && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-purple-500 text-white font-bold">LIMITIERT</Badge>
                </div>
              )}

              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-3xl">📦</span>
                </div>
                
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-bold text-white">{pack.name}</h3>
                  <Dialog>
                    <DialogTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-gray-400 hover:text-white p-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Info className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent 
                      className="bg-gray-900 border-gray-700 max-w-md"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <DialogHeader>
                        <DialogTitle className="text-white flex items-center gap-2">
                          <Info className="w-5 h-5" />
                          {pack.name} - Ziehraten
                        </DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4" onClick={(e) => e.stopPropagation()}>
                        <div>
                          <h4 className="text-white font-semibold mb-2">Garantierte Karten:</h4>
                          <ul className="space-y-1">
                            {getPackDrawRates(pack).guaranteed.map((item, index) => (
                              <li key={index} className="text-gray-300 text-sm flex items-center gap-2">
                                <span className="w-2 h-2 bg-green-400 rounded-full" />
                                <div>{item}</div>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        {getPackDrawRates(pack).chances.length > 0 && (
                          <div>
                            <h4 className="text-white font-semibold mb-2">Wahrscheinlichkeiten:</h4>
                            <ul className="space-y-1">
                              {getPackDrawRates(pack).chances.map((chance, index) => (
                                <li key={index} className="text-sm flex items-center justify-between">
                                  <span className={chance.color}>{chance.rarity}</span>
                                  <span className="text-gray-300 font-mono">{chance.rate}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        <div className="bg-gray-800 rounded-lg p-3">
                          <p className="text-gray-400 text-xs">
                            Wahrscheinlichkeiten gelten für die jeweiligen Bonus-Slots. 
                            Gewöhnliche und ungewöhnliche Karten haben gleiche Verteilung.
                          </p>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <div className="text-gray-300 text-sm mb-4">{pack.description}</div>
                
                <div className="mb-4">
                  <div className="text-xs text-gray-400 mb-2">{pack.cardCount} Karten enthalten</div>
                </div>

                <Separator className="my-4 bg-gray-600" />

                <div className="space-y-2">
                  {pack.goldPrice && (
                    <div className={cn(
                      "flex items-center justify-center gap-2 p-2 rounded",
                      currency.gold >= pack.goldPrice ? "bg-yellow-600/20 text-yellow-400" : "bg-gray-600/20 text-gray-500"
                    )}>
                      <span>🪙</span>
                      <span className="font-bold">{pack.goldPrice}</span>
                      <span className="text-xs">Gold</span>
                    </div>
                  )}
                  
                  {pack.diamondPrice && (
                    <div className={cn(
                      "flex items-center justify-center gap-2 p-2 rounded",
                      currency.diamonds >= pack.diamondPrice ? "bg-cyan-600/20 text-cyan-400" : "bg-gray-600/20 text-gray-500"
                    )}>
                      <span>💎</span>
                      <span className="font-bold">{pack.diamondPrice}</span>
                      <span className="text-xs">Diamanten</span>
                    </div>
                  )}
                </div>

                {!canAfford(pack) && (
                  <div className="mt-4 text-red-400 text-xs">
                    Nicht genug Währung
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          </div>
        </div>

        {/* Purchase History */}
        {purchaseHistory.length > 0 && (
          <div className="bg-gray-800/30 rounded-lg p-4">
            <h3 className="text-white font-bold mb-2">Letzte Käufe</h3>
            <div className="space-y-1">
              {purchaseHistory.slice(-5).map((purchase, index) => (
                <div key={index} className="text-sm text-gray-300">
                  {purchase}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Buy Diamonds Section */}
        <div className="text-center mt-8">
          <h3 className="text-white font-bold mb-4">💎 Diamanten kaufen</h3>
          {paypalAvailable ? (
            <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              <div className="bg-gray-800/50 rounded-lg p-4 border border-cyan-500/30">
                <div className="text-cyan-400 text-lg font-bold mb-2">10 Diamanten</div>
                <div className="text-white text-2xl font-bold mb-4">€0.99</div>
                <PayPalButton amount="0.99" currency="EUR" intent="CAPTURE" />
              </div>
              <div className="bg-gray-800/50 rounded-lg p-4 border border-cyan-500/30">
                <div className="text-cyan-400 text-lg font-bold mb-2">50 Diamanten</div>
                <div className="text-white text-2xl font-bold mb-4">€4.99</div>
                <PayPalButton amount="4.99" currency="EUR" intent="CAPTURE" />
              </div>
              <div className="bg-gray-800/50 rounded-lg p-4 border border-cyan-500/30">
                <div className="text-cyan-400 text-lg font-bold mb-2">100 Diamanten</div>
                <div className="text-white text-2xl font-bold mb-4">€9.99</div>
                <PayPalButton amount="9.99" currency="EUR" intent="CAPTURE" />
              </div>
            </div>
          ) : (
            <div className="bg-gray-800/50 rounded-lg p-6 border border-orange-500/30 max-w-md mx-auto">
              <div className="text-orange-400 font-bold mb-2">Zahlungen derzeit nicht verfügbar</div>
              <div className="text-gray-300 text-sm">
                Der Zahlungsservice ist momentan nicht konfiguriert. Diamanten können später erworben werden.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Pack Opening Modal */}
      <AnimatePresence>
        {isOpening && selectedPack && (
          <PackOpening
            pack={selectedPack}
            cards={openedCards}
            onComplete={handlePackOpeningComplete}
          />
        )}
      </AnimatePresence>
      </div>
    </DynamicBackground>
  );
}