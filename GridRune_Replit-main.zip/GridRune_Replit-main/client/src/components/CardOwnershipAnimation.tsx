import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCardGame } from '../lib/stores/useCardGame';

interface CardOwnershipAnimationProps {
  cardPosition: { row: number; col: number };
  newOwner: number;
  oldOwner: number;
  onAnimationComplete?: () => void;
}

export function CardOwnershipAnimation({ 
  cardPosition, 
  newOwner, 
  oldOwner, 
  onAnimationComplete 
}: CardOwnershipAnimationProps) {
  const [isAnimating, setIsAnimating] = useState(true);

  const getOwnerColors = (owner: number) => {
    if (owner === 1) {
      return {
        primary: '#3b82f6', // blue-500
        secondary: '#1d4ed8', // blue-700
        glow: '#60a5fa' // blue-400
      };
    } else {
      return {
        primary: '#ef4444', // red-500
        secondary: '#dc2626', // red-600
        glow: '#f87171' // red-400
      };
    }
  };

  const oldColors = getOwnerColors(oldOwner);
  const newColors = getOwnerColors(newOwner);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimating(false);
      onAnimationComplete?.();
    }, 2000);

    return () => clearTimeout(timer);
  }, [onAnimationComplete]);

  if (!isAnimating) return null;

  return (
    <motion.div
      className="absolute inset-0 pointer-events-none rounded-lg overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        background: `linear-gradient(45deg, ${oldColors.primary}, ${oldColors.secondary})`
      }}
    >
      {/* Color Wave Transition */}
      <motion.div
        className="absolute inset-0"
        initial={{ 
          background: `linear-gradient(45deg, ${oldColors.primary}, ${oldColors.secondary})`,
          transform: 'translateX(-100%)'
        }}
        animate={{ 
          background: `linear-gradient(45deg, ${newColors.primary}, ${newColors.secondary})`,
          transform: 'translateX(0%)'
        }}
        transition={{ 
          duration: 1.5, 
          ease: [0.25, 0.46, 0.45, 0.94] // easeOutQuad
        }}
      />
      
      {/* Pulsing Glow Effect */}
      <motion.div
        className="absolute inset-0 rounded-lg"
        initial={{ 
          boxShadow: `0 0 20px ${oldColors.glow}40`,
          opacity: 0.8
        }}
        animate={{ 
          boxShadow: [
            `0 0 20px ${oldColors.glow}40`,
            `0 0 40px ${newColors.glow}80`,
            `0 0 20px ${newColors.glow}40`
          ],
          opacity: [0.8, 1, 0.6]
        }}
        transition={{ 
          duration: 2, 
          times: [0, 0.5, 1],
          ease: "easeInOut" 
        }}
      />

      {/* Sparkle Effects */}
      <AnimatePresence>
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full"
            initial={{ 
              opacity: 0,
              scale: 0,
              x: Math.random() * 100 + '%',
              y: Math.random() * 100 + '%'
            }}
            animate={{ 
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
              x: Math.random() * 100 + '%',
              y: Math.random() * 100 + '%'
            }}
            transition={{ 
              duration: 1.5,
              delay: i * 0.1,
              ease: "easeOut"
            }}
          />
        ))}
      </AnimatePresence>

      {/* Ownership Change Text */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        initial={{ opacity: 0, scale: 0.5, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.5, y: -20 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <div className="bg-black/60 backdrop-blur-sm rounded-lg px-3 py-1 text-white text-xs font-bold">
          {newOwner === 1 ? 'EROBERT!' : 'VERLOREN!'}
        </div>
      </motion.div>
    </motion.div>
  );
}

/**
 * Hook to manage card ownership animations
 */
export function useCardOwnershipAnimation() {
  const [animations, setAnimations] = useState<Map<string, CardOwnershipAnimationProps>>(new Map());

  const triggerOwnershipAnimation = (
    position: { row: number; col: number },
    newOwner: number,
    oldOwner: number
  ) => {
    const key = `${position.row}-${position.col}`;
    
    setAnimations(prev => new Map(prev.set(key, {
      cardPosition: position,
      newOwner,
      oldOwner,
      onAnimationComplete: () => {
        setAnimations(current => {
          const updated = new Map(current);
          updated.delete(key);
          return updated;
        });
      }
    })));
  };

  const getAnimationForPosition = (row: number, col: number) => {
    return animations.get(`${row}-${col}`);
  };

  const clearAllAnimations = () => {
    setAnimations(new Map());
  };

  return {
    triggerOwnershipAnimation,
    getAnimationForPosition,
    clearAllAnimations,
    activeAnimations: animations
  };
}