import React, { useState } from 'react';
import { Share2, Twitter, Facebook, Copy, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { GameCard, RARITY_CONFIG } from '../lib/cardData';

interface SocialShareButtonProps {
  cards: GameCard[];
  packType: string;
}

const SocialShareButton: React.FC<SocialShareButtonProps> = ({ cards, packType }) => {
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [copiedToClipboard, setCopiedToClipboard] = useState(false);

  // Filter for epic and legendary cards
  const epicCards = cards.filter(card => card.rarity === 'epic' || card.rarity === 'legendary');
  
  if (epicCards.length === 0) return null;

  const generateShareText = () => {
    const epicCount = cards.filter(card => card.rarity === 'epic').length;
    const legendaryCount = cards.filter(card => card.rarity === 'legendary').length;
    
    let shareText = `🎉 Unglaublicher ${packType} Pull! `;
    
    if (legendaryCount > 0) {
      shareText += `${legendaryCount} LEGENDÄRE${legendaryCount > 1 ? '' : ''} Karte${legendaryCount > 1 ? 'n' : ''}! `;
      const legendaryNames = cards
        .filter(card => card.rarity === 'legendary')
        .map(card => card.name)
        .join(', ');
      shareText += `✨ ${legendaryNames} ✨ `;
    }
    
    if (epicCount > 0) {
      shareText += `${epicCount} EPISCHE Karte${epicCount > 1 ? 'n' : ''}! `;
      const epicNames = cards
        .filter(card => card.rarity === 'epic')
        .map(card => card.name)
        .join(', ');
      shareText += `🔥 ${epicNames} 🔥 `;
    }
    
    shareText += `\n\n#GridRune #CardGame #EpicPull #Gaming`;
    return shareText;
  };

  const shareText = generateShareText();
  const encodedText = encodeURIComponent(shareText);
  const gameUrl = encodeURIComponent(window.location.origin);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareText + `\n\nSpiele auch: ${window.location.origin}`);
      setCopiedToClipboard(true);
      setTimeout(() => setCopiedToClipboard(false), 2000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const shareOnTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodedText}&url=${gameUrl}`;
    window.open(twitterUrl, '_blank');
  };

  const shareOnFacebook = () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${gameUrl}&quote=${encodedText}`;
    window.open(facebookUrl, '_blank');
  };

  const shareViaWebShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'GridRune - Epischer Pull!',
          text: shareText,
          url: window.location.origin,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    }
  };

  return (
    <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
      <DialogTrigger asChild>
        <Button
          className="bg-gradient-to-r from-purple-600 to-yellow-600 hover:from-purple-700 hover:to-yellow-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 hover:scale-105"
        >
          <Share2 className="w-5 h-5 mr-2" />
          Epischen Pull teilen!
        </Button>
      </DialogTrigger>
      
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">
            🎉 Teile deinen epischen Pull!
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Preview of cards */}
          <div className="flex flex-wrap gap-2 justify-center">
            {epicCards.map((card, index) => (
              <div
                key={index}
                className={`px-3 py-1 rounded-full text-sm font-bold ${
                  card.rarity === 'legendary'
                    ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-black'
                    : 'bg-gradient-to-r from-purple-400 to-purple-600 text-white'
                }`}
              >
                {card.name}
              </div>
            ))}
          </div>
          
          {/* Share text preview */}
          <div className="bg-gray-800 p-3 rounded-lg max-h-32 overflow-y-auto">
            <p className="text-sm text-gray-300 whitespace-pre-line">{shareText}</p>
          </div>
          
          {/* Share buttons */}
          <div className="space-y-3">
            {/* Native Web Share API (mobile) */}
            {typeof window !== 'undefined' && typeof navigator !== 'undefined' && navigator.share && (
              <Button
                onClick={shareViaWebShare}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Teilen
              </Button>
            )}
            
            {/* Social media buttons */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={shareOnTwitter}
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                <Twitter className="w-4 h-4 mr-2" />
                Twitter
              </Button>
              
              <Button
                onClick={shareOnFacebook}
                className="bg-blue-700 hover:bg-blue-800 text-white"
              >
                <Facebook className="w-4 h-4 mr-2" />
                Facebook
              </Button>
            </div>
            
            {/* Copy to clipboard */}
            <Button
              onClick={copyToClipboard}
              className={`w-full transition-colors ${
                copiedToClipboard
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-gray-600 hover:bg-gray-700'
              } text-white`}
            >
              {copiedToClipboard ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Kopiert!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Text kopieren
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SocialShareButton;