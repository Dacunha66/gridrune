import React, { useEffect, useState } from 'react';
import { useAudio } from '../lib/stores/useAudio';
import { audioSynthesizer } from '../lib/audioSynthesizer';

export const AudioInitializer: React.FC = () => {
  const [isInitialized, setIsInitialized] = useState(false);
  const { 
    setAttackSound, 
    setDefenseSound, 
    setCaptureSound, 
    setBlitzschlagSound, 
    setShieldBreakSound, 
    setClashSound, 
    setPlacementSound,
    setMagicalSelectionSound
  } = useAudio();

  useEffect(() => {
    const initializeBattleSounds = async () => {
      try {
        console.log("🔊 Initializing battle sound effects...");
        
        // Generate all battle sounds
        const [
          attackSound,
          defenseSound,
          captureSound,
          blitzschlagSound,
          shieldBreakSound,
          clashSound,
          placementSound,
          magicalSelectionSound
        ] = await Promise.all([
          audioSynthesizer.createAttackSound(),
          audioSynthesizer.createDefenseSound(),
          audioSynthesizer.createCaptureSound(),
          audioSynthesizer.createBlitzschlagSound(),
          audioSynthesizer.createShieldBreakSound(),
          audioSynthesizer.createClashSound(),
          audioSynthesizer.createPlacementSound(),
          audioSynthesizer.createMagicalSelectionSound()
        ]);

        // Set sounds in audio store
        if (attackSound) setAttackSound(attackSound);
        if (defenseSound) setDefenseSound(defenseSound);
        if (captureSound) setCaptureSound(captureSound);
        if (blitzschlagSound) setBlitzschlagSound(blitzschlagSound);
        if (shieldBreakSound) setShieldBreakSound(shieldBreakSound);
        if (clashSound) setClashSound(clashSound);
        if (placementSound) setPlacementSound(placementSound);
        if (magicalSelectionSound) setMagicalSelectionSound(magicalSelectionSound);

        setIsInitialized(true);
        console.log("✅ Battle sound effects initialized successfully");
      } catch (error) {
        console.warn("⚠️ Failed to initialize battle sounds:", error);
        setIsInitialized(true); // Continue without sounds
      }
    };

    // Initialize sounds when component mounts
    initializeBattleSounds();
  }, [setAttackSound, setDefenseSound, setCaptureSound, setBlitzschlagSound, setShieldBreakSound, setClashSound, setPlacementSound]);

  // This component doesn't render anything visible
  return null;
};