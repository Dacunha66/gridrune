import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trophy, Star, Crown, Shield, Flame, Zap, Target, Calendar, Clock, Medal, Award, ChevronLeft, ChevronRight, Filter, Search, Grid, List } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { cn } from '../lib/utils';
import { useAudio } from '../lib/stores/useAudio';
import { useAchievements } from '../lib/stores/useAchievements';
import { useWeeklyChallenges } from '../lib/stores/useWeeklyChallenges';

interface QuestAchievementShowcaseProps {
  isOpen: boolean;
  onClose: () => void;
}

type ShowcaseCategory = 'all' | 'achievements' | 'quests' | 'seasonal' | 'rare';
type ViewMode = 'grid' | 'list';
type SortMode = 'recent' | 'rarity' | 'progress';

interface ShowcaseItem {
  id: string;
  title: string;
  description: string;
  category: 'achievement' | 'quest' | 'seasonal';
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  completed: boolean;
  completedAt?: Date;
  progress?: { current: number; total: number };
  reward: {
    xp?: number;
    gold?: number;
    diamonds?: number;
    title?: string;
  };
  icon: React.ReactNode;
  unlockCondition: string;
  stats?: {
    timesCompleted?: number;
    bestTime?: string;
    difficulty?: string;
  };
}

const SHOWCASE_ITEMS: ShowcaseItem[] = [
  {
    id: 'first-victory',
    title: 'Erster Sieg',
    description: 'Gewinne dein erstes Spiel in GridRune',
    category: 'achievement',
    rarity: 'common',
    completed: true,
    completedAt: new Date('2025-01-01'),
    reward: { xp: 100, gold: 200 },
    icon: <Trophy className="w-8 h-8" />,
    unlockCondition: 'Gewinne 1 Spiel',
    stats: { timesCompleted: 1, bestTime: '5m 32s' }
  },
  {
    id: 'card-master',
    title: 'Kartenmeister',
    description: 'Sammle 50 verschiedene Karten',
    category: 'achievement',
    rarity: 'rare',
    completed: true,
    completedAt: new Date('2025-01-05'),
    reward: { xp: 500, diamonds: 25, title: 'Kartensammler' },
    icon: <Star className="w-8 h-8" />,
    unlockCondition: 'Sammle 50 Karten',
    stats: { timesCompleted: 1 }
  },
  {
    id: 'legendary-hunter',
    title: 'Legendenjäger',
    description: 'Erhalte deine erste legendäre Karte',
    category: 'achievement',
    rarity: 'epic',
    completed: true,
    completedAt: new Date('2025-01-07'),
    reward: { xp: 750, diamonds: 50, title: 'Legendenjäger' },
    icon: <Crown className="w-8 h-8" />,
    unlockCondition: 'Erhalte 1 legendäre Karte',
    stats: { timesCompleted: 1 }
  },
  {
    id: 'weekly-warrior',
    title: 'Wöchentlicher Krieger',
    description: 'Schließe alle wöchentlichen Quests ab',
    category: 'quest',
    rarity: 'uncommon',
    completed: false,
    progress: { current: 3, total: 5 },
    reward: { xp: 300, gold: 500 },
    icon: <Shield className="w-8 h-8" />,
    unlockCondition: 'Schließe 5 wöchentliche Quests ab',
    stats: { difficulty: 'Mittel' }
  },
  {
    id: 'winter-champion',
    title: 'Wintermeister',
    description: 'Erreiche Rang 1 in der Wintersaison',
    category: 'seasonal',
    rarity: 'legendary',
    completed: false,
    progress: { current: 75, total: 100 },
    reward: { xp: 1000, diamonds: 100, title: 'Wintermeister' },
    icon: <Medal className="w-8 h-8" />,
    unlockCondition: 'Erreiche 100 Saisonpunkte',
    stats: { difficulty: 'Legendär' }
  },
  {
    id: 'speed-demon',
    title: 'Blitzkrieger',
    description: 'Gewinne ein Spiel in unter 3 Minuten',
    category: 'achievement',
    rarity: 'epic',
    completed: true,
    completedAt: new Date('2025-01-10'),
    reward: { xp: 400, gold: 300, title: 'Blitzkrieger' },
    icon: <Zap className="w-8 h-8" />,
    unlockCondition: 'Gewinne in unter 3 Minuten',
    stats: { timesCompleted: 2, bestTime: '2m 47s' }
  }
];

const getRarityColors = (rarity: string) => {
  switch (rarity) {
    case 'common': return 'from-gray-500 to-gray-600 border-gray-400';
    case 'uncommon': return 'from-green-500 to-green-600 border-green-400';
    case 'rare': return 'from-blue-500 to-blue-600 border-blue-400';
    case 'epic': return 'from-purple-500 to-purple-600 border-purple-400';
    case 'legendary': return 'from-yellow-500 to-yellow-600 border-yellow-400';
    default: return 'from-gray-500 to-gray-600 border-gray-400';
  }
};

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'achievement': return <Trophy className="w-5 h-5" />;
    case 'quest': return <Target className="w-5 h-5" />;
    case 'seasonal': return <Crown className="w-5 h-5" />;
    default: return <Star className="w-5 h-5" />;
  }
};

export function QuestAchievementShowcase({ isOpen, onClose }: QuestAchievementShowcaseProps) {
  const [selectedCategory, setSelectedCategory] = useState<ShowcaseCategory>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortMode, setSortMode] = useState<SortMode>('recent');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<ShowcaseItem | null>(null);
  const [filteredItems, setFilteredItems] = useState<ShowcaseItem[]>(SHOWCASE_ITEMS);

  const { playSuccess, playHit } = useAudio();

  useEffect(() => {
    let items = [...SHOWCASE_ITEMS];

    // Filter by category
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'rare') {
        items = items.filter(item => ['epic', 'legendary'].includes(item.rarity));
      } else {
        items = items.filter(item => {
          if (selectedCategory === 'achievements') return item.category === 'achievement';
          if (selectedCategory === 'quests') return item.category === 'quest';
          if (selectedCategory === 'seasonal') return item.category === 'seasonal';
          return true;
        });
      }
    }

    // Filter by search
    if (searchQuery) {
      items = items.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort items
    items.sort((a, b) => {
      switch (sortMode) {
        case 'recent':
          if (a.completed && b.completed) {
            return new Date(b.completedAt || 0).getTime() - new Date(a.completedAt || 0).getTime();
          }
          return a.completed === b.completed ? 0 : a.completed ? -1 : 1;
        
        case 'rarity':
          const rarityOrder = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
          return rarityOrder.indexOf(b.rarity) - rarityOrder.indexOf(a.rarity);
        
        case 'progress':
          const getProgress = (item: ShowcaseItem) => {
            if (item.completed) return 100;
            if (item.progress) return (item.progress.current / item.progress.total) * 100;
            return 0;
          };
          return getProgress(b) - getProgress(a);
        
        default:
          return 0;
      }
    });

    setFilteredItems(items);
  }, [selectedCategory, searchQuery, sortMode]);

  const handleItemClick = (item: ShowcaseItem) => {
    setSelectedItem(item);
    playHit();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-slate-800 rounded-xl border border-slate-600 w-full max-w-7xl max-h-[95vh] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-600 bg-gradient-to-r from-slate-800 to-slate-700">
          <div className="flex items-center gap-3">
            <Award className="w-8 h-8 text-yellow-400" />
            <div>
              <h1 className="text-3xl font-bold text-white">Erfolgs-Galerie</h1>
              <p className="text-slate-400">Deine Errungenschaften und Quest-Fortschritte</p>
            </div>
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-slate-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>

        {/* Controls */}
        <div className="p-6 border-b border-slate-600 bg-slate-750">
          <div className="flex flex-wrap items-center justify-between gap-4">
            {/* Category Filters */}
            <div className="flex gap-2">
              {[
                { key: 'all', label: 'Alle', icon: <Star className="w-4 h-4" /> },
                { key: 'achievements', label: 'Erfolge', icon: <Trophy className="w-4 h-4" /> },
                { key: 'quests', label: 'Quests', icon: <Target className="w-4 h-4" /> },
                { key: 'seasonal', label: 'Saison', icon: <Crown className="w-4 h-4" /> },
                { key: 'rare', label: 'Selten', icon: <Medal className="w-4 h-4" /> }
              ].map(({ key, label, icon }) => (
                <Button
                  key={key}
                  onClick={() => setSelectedCategory(key as ShowcaseCategory)}
                  variant={selectedCategory === key ? 'default' : 'outline'}
                  size="sm"
                  className={cn(
                    'flex items-center gap-2',
                    selectedCategory === key
                      ? 'bg-blue-600 text-white'
                      : 'border-slate-600 text-slate-300 hover:bg-slate-700'
                  )}
                >
                  {icon}
                  {label}
                </Button>
              ))}
            </div>

            {/* Search and Controls */}
            <div className="flex items-center gap-4">
              <Input
                placeholder="Erfolge suchen..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 bg-slate-700 border-slate-600 text-white"
              />
              
              <select
                value={sortMode}
                onChange={(e) => setSortMode(e.target.value as SortMode)}
                className="bg-slate-700 border border-slate-600 rounded-md px-3 py-2 text-white text-sm"
              >
                <option value="recent">Neueste</option>
                <option value="rarity">Seltenheit</option>
                <option value="progress">Fortschritt</option>
              </select>

              <div className="flex border border-slate-600 rounded-md overflow-hidden">
                <Button
                  onClick={() => setViewMode('grid')}
                  variant="ghost"
                  size="sm"
                  className={cn(
                    'rounded-none',
                    viewMode === 'grid' ? 'bg-slate-600' : 'hover:bg-slate-700'
                  )}
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  onClick={() => setViewMode('list')}
                  variant="ghost"
                  size="sm"
                  className={cn(
                    'rounded-none',
                    viewMode === 'list' ? 'bg-slate-600' : 'hover:bg-slate-700'
                  )}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(95vh-240px)] p-6">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <ShowcaseCard
                  key={item.id}
                  item={item}
                  onClick={() => handleItemClick(item)}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredItems.map((item) => (
                <ShowcaseListItem
                  key={item.id}
                  item={item}
                  onClick={() => handleItemClick(item)}
                />
              ))}
            </div>
          )}

          {filteredItems.length === 0 && (
            <div className="text-center py-12">
              <Award className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Keine Erfolge gefunden</h3>
              <p className="text-slate-400">Versuche andere Filter oder Suchbegriffe</p>
            </div>
          )}
        </div>

        {/* Detail Modal */}
        <AnimatePresence>
          {selectedItem && (
            <ShowcaseDetailModal
              item={selectedItem}
              onClose={() => setSelectedItem(null)}
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

// Showcase Card Component
function ShowcaseCard({ item, onClick }: { item: ShowcaseItem; onClick: () => void }) {
  const rarityColors = getRarityColors(item.rarity);
  
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className={cn(
        'relative overflow-hidden transition-all duration-300',
        item.completed 
          ? `bg-gradient-to-br ${rarityColors} shadow-lg`
          : 'bg-slate-700 border-slate-600 opacity-75'
      )}>
        {/* Rarity Border Effect */}
        {item.completed && (
          <div className={cn(
            'absolute inset-0 bg-gradient-to-br opacity-20',
            rarityColors
          )} />
        )}
        
        {/* Completion Badge */}
        {item.completed && (
          <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1">
            <Trophy className="w-4 h-4 text-white" />
          </div>
        )}

        <CardContent className="p-6 relative z-10">
          <div className="text-center">
            {/* Icon */}
            <div className={cn(
              'w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center',
              item.completed 
                ? 'bg-white/20 text-white'
                : 'bg-slate-600 text-slate-400'
            )}>
              {item.icon}
            </div>

            {/* Title */}
            <h3 className={cn(
              'font-semibold mb-2',
              item.completed ? 'text-white' : 'text-slate-300'
            )}>
              {item.title}
            </h3>

            {/* Progress or Completion Date */}
            {item.completed ? (
              <p className="text-xs text-white/70">
                Abgeschlossen: {item.completedAt?.toLocaleDateString('de-DE')}
              </p>
            ) : item.progress ? (
              <div className="w-full bg-slate-600 rounded-full h-2 mb-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all"
                  style={{ width: `${(item.progress.current / item.progress.total) * 100}%` }}
                />
              </div>
            ) : null}

            {/* Category Badge */}
            <div className="flex items-center justify-center gap-1 mt-3">
              {getCategoryIcon(item.category)}
              <span className="text-xs capitalize text-white/70">
                {item.category}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Showcase List Item Component
function ShowcaseListItem({ item, onClick }: { item: ShowcaseItem; onClick: () => void }) {
  const rarityColors = getRarityColors(item.rarity);
  
  return (
    <motion.div
      whileHover={{ x: 5 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className={cn(
        'transition-all duration-300',
        item.completed 
          ? 'bg-slate-700 border-l-4 hover:bg-slate-600'
          : 'bg-slate-800 border-slate-600 opacity-75 hover:bg-slate-700'
      )}
      style={{
        borderLeftColor: item.completed ? getRarityColors(item.rarity).split(' ')[2].replace('border-', '#') : undefined
      }}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Icon */}
              <div className={cn(
                'w-12 h-12 rounded-full flex items-center justify-center',
                item.completed 
                  ? `bg-gradient-to-br ${rarityColors}`
                  : 'bg-slate-600'
              )}>
                {React.cloneElement(item.icon as React.ReactElement, {
                  className: 'w-6 h-6 text-white'
                })}
              </div>

              {/* Content */}
              <div>
                <h3 className="font-semibold text-white">{item.title}</h3>
                <p className="text-sm text-slate-400">{item.description}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className={cn(
                    'text-xs px-2 py-1 rounded-full',
                    `bg-gradient-to-r ${rarityColors} text-white`
                  )}>
                    {item.rarity}
                  </span>
                  <span className="text-xs text-slate-400">
                    {getCategoryIcon(item.category)}
                    <span className="ml-1 capitalize">{item.category}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="text-right">
              {item.completed ? (
                <div className="text-green-400 text-sm font-medium">
                  ✓ Abgeschlossen
                </div>
              ) : item.progress ? (
                <div className="text-blue-400 text-sm">
                  {item.progress.current}/{item.progress.total}
                </div>
              ) : (
                <div className="text-slate-400 text-sm">
                  Gesperrt
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Showcase Detail Modal Component
function ShowcaseDetailModal({ item, onClose }: { item: ShowcaseItem; onClose: () => void }) {
  const rarityColors = getRarityColors(item.rarity);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 bg-black/50 flex items-center justify-center p-4 z-10"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-slate-800 rounded-xl border border-slate-600 max-w-2xl w-full overflow-hidden"
      >
        {/* Header */}
        <div className={cn(
          'p-6 bg-gradient-to-r text-white',
          rarityColors.replace('border-', '')
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                {React.cloneElement(item.icon as React.ReactElement, {
                  className: 'w-8 h-8 text-white'
                })}
              </div>
              <div>
                <h2 className="text-2xl font-bold">{item.title}</h2>
                <p className="text-white/80">{item.description}</p>
              </div>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-white/70 hover:text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Status and Progress */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-slate-400 mb-2">Status</h3>
              <div className={cn(
                'px-3 py-2 rounded-lg text-center font-medium',
                item.completed 
                  ? 'bg-green-500/20 text-green-400'
                  : 'bg-yellow-500/20 text-yellow-400'
              )}>
                {item.completed ? 'Abgeschlossen' : 'In Bearbeitung'}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium text-slate-400 mb-2">Seltenheit</h3>
              <div className={cn(
                'px-3 py-2 rounded-lg text-center font-medium capitalize',
                `bg-gradient-to-r ${rarityColors} text-white`
              )}>
                {item.rarity}
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          {item.progress && !item.completed && (
            <div>
              <h3 className="text-sm font-medium text-slate-400 mb-2">Fortschritt</h3>
              <div className="bg-slate-700 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full transition-all"
                  style={{ width: `${(item.progress.current / item.progress.total) * 100}%` }}
                />
              </div>
              <p className="text-sm text-slate-400 mt-1">
                {item.progress.current} von {item.progress.total}
              </p>
            </div>
          )}

          {/* Unlock Condition */}
          <div>
            <h3 className="text-sm font-medium text-slate-400 mb-2">Freischaltbedingung</h3>
            <p className="text-white">{item.unlockCondition}</p>
          </div>

          {/* Rewards */}
          <div>
            <h3 className="text-sm font-medium text-slate-400 mb-2">Belohnungen</h3>
            <div className="flex gap-4">
              {item.reward.xp && (
                <div className="flex items-center gap-2 text-blue-400">
                  <Star className="w-4 h-4" />
                  <span>{item.reward.xp} XP</span>
                </div>
              )}
              {item.reward.gold && (
                <div className="flex items-center gap-2 text-yellow-500">
                  <span>🪙</span>
                  <span>{item.reward.gold} Gold</span>
                </div>
              )}
              {item.reward.diamonds && (
                <div className="flex items-center gap-2 text-cyan-400">
                  <span>💎</span>
                  <span>{item.reward.diamonds} Diamanten</span>
                </div>
              )}
              {item.reward.title && (
                <div className="flex items-center gap-2 text-purple-400">
                  <Crown className="w-4 h-4" />
                  <span>Titel: {item.reward.title}</span>
                </div>
              )}
            </div>
          </div>

          {/* Stats */}
          {item.stats && (
            <div>
              <h3 className="text-sm font-medium text-slate-400 mb-2">Statistiken</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                {item.stats.timesCompleted && (
                  <div>
                    <span className="text-slate-400">Mal abgeschlossen:</span>
                    <span className="text-white ml-2">{item.stats.timesCompleted}</span>
                  </div>
                )}
                {item.stats.bestTime && (
                  <div>
                    <span className="text-slate-400">Beste Zeit:</span>
                    <span className="text-white ml-2">{item.stats.bestTime}</span>
                  </div>
                )}
                {item.stats.difficulty && (
                  <div>
                    <span className="text-slate-400">Schwierigkeit:</span>
                    <span className="text-white ml-2">{item.stats.difficulty}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Completion Date */}
          {item.completed && item.completedAt && (
            <div>
              <h3 className="text-sm font-medium text-slate-400 mb-2">Abgeschlossen am</h3>
              <p className="text-white">
                {item.completedAt.toLocaleDateString('de-DE', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

export default QuestAchievementShowcase;