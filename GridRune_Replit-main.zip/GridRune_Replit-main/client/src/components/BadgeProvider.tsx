import React, { createContext, useContext, useEffect } from 'react';
import { useBadges } from '../lib/stores/useBadges';
import { BadgeNotificationManager } from './BadgeNotification';

const BadgeContext = createContext<{
  initializeBadges: () => void;
} | null>(null);

export const useBadgeContext = () => {
  const context = useContext(BadgeContext);
  if (!context) {
    throw new Error('useBadgeContext must be used within BadgeProvider');
  }
  return context;
};

interface BadgeProviderProps {
  children: React.ReactNode;
}

export function BadgeProvider({ children }: BadgeProviderProps) {
  const { initializeBadges, badges, getUnlockedBadges } = useBadges();
  
  useEffect(() => {
    initializeBadges();
  }, [initializeBadges]);

  const handleBadgeViewed = (badgeId: string) => {
    // Mark badge as viewed - could extend badge interface to track this
    console.log(`Badge ${badgeId} viewed`);
  };

  return (
    <BadgeContext.Provider value={{ initializeBadges }}>
      {children}
      
      {/* Badge Notification System */}
      <BadgeNotificationManager
        badges={getUnlockedBadges()}
        onBadgeViewed={handleBadgeViewed}
      />
    </BadgeContext.Provider>
  );
}