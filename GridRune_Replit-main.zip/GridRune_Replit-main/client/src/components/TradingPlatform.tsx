import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Send, ArrowLeftRight, ArrowLeft, Plus, X } from 'lucide-react';
import { Card as CardComponent } from './Card';
import { GameCard, createExtendedDeck } from '../lib/cardData';
import { useCardGame } from '../lib/stores/useCardGame';

export default function TradingPlatform() {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [mySelectedCards, setMySelectedCards] = useState<GameCard[]>([]);
  const [requestedCards, setRequestedCards] = useState<GameCard[]>([]);
  const [tradeMessage, setTradeMessage] = useState('');
  const [selectedRarityFilter, setSelectedRarityFilter] = useState<string>('');
  
  // Create collection for trading
  const collection = useMemo(() => {
    const deck1 = createExtendedDeck(1);
    const deck2 = createExtendedDeck(2);
    return [...deck1, ...deck2.slice(0, 10)];
  }, []);

  // Get available rarities based on selected cards
  const getAvailableRarities = () => {
    if (mySelectedCards.length === 0) return ['common', 'uncommon', 'rare', 'epic', 'legendary'];
    const rarities = mySelectedCards.map(c => c.rarity).filter(r => r !== undefined) as string[];
    return Array.from(new Set(rarities));
  };

  // Check if rarity matches between offered and requested cards
  const checkRarityMatch = () => {
    if (mySelectedCards.length === 0 || requestedCards.length === 0) return true;
    const myRarities = mySelectedCards.map(c => c.rarity).filter(r => r !== undefined);
    const requestedRarities = requestedCards.map(c => c.rarity).filter(r => r !== undefined);
    const uniqueMyRarities = Array.from(new Set(myRarities));
    const uniqueRequestedRarities = Array.from(new Set(requestedRarities));
    return uniqueMyRarities.length === 1 && uniqueRequestedRarities.length === 1 && 
           uniqueMyRarities[0] === uniqueRequestedRarities[0];
  };

  // Filter cards by allowed rarities for requesting
  const getSelectableCards = () => {
    const allowedRarities = getAvailableRarities();
    if (mySelectedCards.length === 0) return collection;
    return collection.filter(card => card.rarity && allowedRarities.includes(card.rarity));
  };

  const renderBrowseOffers = () => (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold text-purple-600">Angebote durchsuchen</h3>
        <Button
          onClick={() => setActiveSection(null)}
          variant="outline"
          className="bg-gray-600 text-white hover:bg-gray-700"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Zurück
        </Button>
      </div>
      <div className="text-center py-20 text-gray-600">
        <Search className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p className="text-lg">Hier kannst du Angebote von anderen Spielern durchsuchen.</p>
        <p className="text-sm mt-2">Funktionalität wird bald verfügbar sein.</p>
      </div>
    </div>
  );

  const renderCreateTrade = () => {
    
    const rarityColors = {
      'common': 'text-gray-600 bg-gray-100',
      'uncommon': 'text-green-600 bg-green-100', 
      'rare': 'text-blue-600 bg-blue-100',
      'epic': 'text-purple-600 bg-purple-100',
      'legendary': 'text-yellow-600 bg-yellow-100'
    };

    const filteredCards = selectedRarityFilter 
      ? collection.filter(card => card.rarity === selectedRarityFilter)
      : collection;

    return (
      <div className="p-3 max-w-md mx-auto">
        <style>{`
          .hide-scrollbar {
            -webkit-overflow-scrolling: touch;
          }
          .hide-scrollbar::-webkit-scrollbar {
            display: none;
          }
        `}</style>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-green-600">Tausch erstellen</h3>
          <Button
            onClick={() => {
              setActiveSection(null);
              setMySelectedCards([]);
              setRequestedCards([]);
              setTradeMessage('');
              setSelectedRarityFilter('');
            }}
            variant="outline"
            size="sm"
            className="bg-gray-600 text-white hover:bg-gray-700"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Zurück
          </Button>
        </div>

        {/* Step 1: Rarity Selection */}
        <div className="space-y-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 mb-3">1. Seltenheit auswählen</h4>
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: 'common', label: 'Gewöhnlich' },
                { value: 'uncommon', label: 'Ungewöhnlich' },
                { value: 'rare', label: 'Selten' },
                { value: 'epic', label: 'Episch' },
                { value: 'legendary', label: 'Legendär' }
              ].map((rarity) => (
                <Button
                  key={rarity.value}
                  onClick={() => {
                    setSelectedRarityFilter(rarity.value);
                    setMySelectedCards([]);
                    setRequestedCards([]);
                  }}
                  variant={selectedRarityFilter === rarity.value ? "default" : "outline"}
                  className={`h-12 ${selectedRarityFilter === rarity.value ? 'ring-2 ring-blue-500' : ''} ${rarityColors[rarity.value as keyof typeof rarityColors]}`}
                >
                  {rarity.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Step 2: Card Selection (only if rarity selected) */}
          {selectedRarityFilter && (
            <>


              {/* My Cards Section */}
              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800">2. Meine Karten auswählen</h4>
                
                {/* Selected Cards Display */}
                {mySelectedCards.length > 0 && (
                  <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar">
                    {mySelectedCards.map((card, index) => (
                      <div key={index} className="relative flex-shrink-0">
                        <div className="scale-90 transform-gpu">
                          <CardComponent card={card} size="small" isClickable={false} />
                        </div>
                        <button
                          onClick={() => setMySelectedCards(prev => prev.filter((_, i) => i !== index))}
                          className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Available Cards - Horizontal Scroll */}
                <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar">
                  {filteredCards.slice(0, 15).map((card, index) => {
                    const isSelected = mySelectedCards.some(c => c.id === card.id);
                    return (
                      <motion.div
                        key={index}
                        whileTap={{ scale: 0.95 }}
                        className={`relative cursor-pointer flex-shrink-0 ${isSelected ? 'ring-2 ring-green-500 rounded' : ''}`}
                        onClick={() => {
                          if (isSelected) {
                            setMySelectedCards(prev => prev.filter(c => c.id !== card.id));
                          } else {
                            setMySelectedCards(prev => [...prev, card]);
                          }
                        }}
                      >
                        <div className="scale-90 transform-gpu">
                          <CardComponent card={card} size="small" isClickable={false} />
                        </div>
                        {isSelected && (
                          <div className="absolute top-0 right-0 w-5 h-5 bg-green-500 text-white rounded-full flex items-center justify-center text-xs">
                            ✓
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Requested Cards Section */}
              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800">3. Gewünschte Karten auswählen</h4>
                
                {/* Selected Requested Cards */}
                {requestedCards.length > 0 && (
                  <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar">
                    {requestedCards.map((card, index) => (
                      <div key={index} className="relative flex-shrink-0">
                        <div className="scale-90 transform-gpu">
                          <CardComponent card={card} size="small" isClickable={false} />
                        </div>
                        <button
                          onClick={() => setRequestedCards(prev => prev.filter((_, i) => i !== index))}
                          className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Available Cards for Request - Horizontal Scroll */}
                <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar">
                  {filteredCards.slice(0, 15).map((card, index) => {
                    const isSelected = requestedCards.some(c => c.id === card.id);
                    return (
                      <motion.div
                        key={index}
                        whileTap={{ scale: 0.95 }}
                        className={`relative cursor-pointer flex-shrink-0 ${isSelected ? 'ring-2 ring-purple-500 rounded' : ''}`}
                        onClick={() => {
                          if (isSelected) {
                            setRequestedCards(prev => prev.filter(c => c.id !== card.id));
                          } else {
                            setRequestedCards(prev => [...prev, card]);
                          }
                        }}
                      >
                        <div className="scale-90 transform-gpu">
                          <CardComponent card={card} size="small" isClickable={false} />
                        </div>
                        {isSelected && (
                          <div className="absolute top-0 right-0 w-5 h-5 bg-purple-500 text-white rounded-full flex items-center justify-center text-xs">
                            ✓
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Message */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Nachricht (optional):</label>
                <Input
                  placeholder="Beschreibe dein Tausch-Angebot..."
                  value={tradeMessage}
                  onChange={(e) => setTradeMessage(e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Create Button */}
              <Button
                onClick={() => {
                  alert('Tausch-Angebot erstellt! (Demo)');
                  setMySelectedCards([]);
                  setRequestedCards([]);
                  setTradeMessage('');
                }}
                disabled={mySelectedCards.length === 0 || requestedCards.length === 0 || mySelectedCards.length !== requestedCards.length}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-bold py-3"
              >
                <Send className="w-5 h-5 mr-2" />
                {mySelectedCards.length === 0 ? 'Wähle deine Karten aus' :
                 requestedCards.length === 0 ? 'Wähle gewünschte Karten aus' :
                 mySelectedCards.length !== requestedCards.length ? 'Gleiche Anzahl wählen' :
                 'Tausch erstellen'}
              </Button>
            </>
          )}
        </div>
      </div>
    );
  };

  const renderMyOffers = () => (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold text-blue-600">Meine Angebote</h3>
        <Button
          onClick={() => setActiveSection(null)}
          variant="outline"
          className="bg-gray-600 text-white hover:bg-gray-700"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Zurück
        </Button>
      </div>
      <div className="text-center py-20 text-gray-600">
        <ArrowLeftRight className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p className="text-lg">Hier siehst du deine eigenen Tausch-Angebote.</p>
        <p className="text-sm mt-2">Du hast noch keine Angebote erstellt.</p>
      </div>
    </div>
  );

  if (activeSection === 'browse') {
    return renderBrowseOffers();
  }

  if (activeSection === 'create') {
    return renderCreateTrade();
  }

  if (activeSection === 'offers') {
    return renderMyOffers();
  }

  // Main menu with three buttons
  return (
    <div className="p-6">
      <div className="grid gap-6 max-w-2xl mx-auto">
        {/* Browse Offers Button */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={() => setActiveSection('browse')}
            className="w-full h-20 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white text-xl font-bold"
          >
            <Search className="w-8 h-8 mr-4" />
            Angebote durchsuchen
          </Button>
        </motion.div>

        {/* Create Trade Button */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={() => setActiveSection('create')}
            className="w-full h-20 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white text-xl font-bold"
          >
            <Send className="w-8 h-8 mr-4" />
            Tausch erstellen
          </Button>
        </motion.div>

        {/* My Offers Button */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={() => setActiveSection('offers')}
            className="w-full h-20 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-xl font-bold"
          >
            <ArrowLeftRight className="w-8 h-8 mr-4" />
            Meine Angebote
          </Button>
        </motion.div>
      </div>
    </div>
  );
}