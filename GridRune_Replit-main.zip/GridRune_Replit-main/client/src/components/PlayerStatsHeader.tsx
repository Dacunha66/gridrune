import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Trophy, Coins, Gem, Crown, Package, Info, X } from 'lucide-react';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { cn } from '../lib/utils';
import { ModalBackdrop } from './ui/LayeredContainer';
import { Z_CATEGORIES } from '../lib/constants/zIndex';

interface PlayerStatsHeaderProps {
  className?: string;
  showLevel?: boolean;
  showGold?: boolean;
  showDiamonds?: boolean;
  showXp?: boolean;
  showPacks?: boolean;
}

export function PlayerStatsHeader({ 
  className = '', 
  showLevel = true, 
  showGold = true, 
  showDiamonds = true, 
  showXp = true,
  showPacks = true
}: PlayerStatsHeaderProps) {
  const { stats, getXpForNextLevel, getLevelProgress } = usePlayerProgress();
  const [showInfoPopup, setShowInfoPopup] = useState(false);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
    return num.toString();
  };

  return (
    <>
    <div 
      className={cn('flex items-center gap-1 sm:gap-2 md:gap-4 bg-slate-800/50 rounded-lg p-1.5 sm:p-2 md:p-3 border border-slate-600 cursor-pointer hover:bg-slate-800/70 transition-colors', className)}
      onClick={() => setShowInfoPopup(true)}
    >
      {/* Level Display - Compact on mobile */}
      {showLevel && (
        <div className="flex items-center gap-1 sm:gap-2">
          <div className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 bg-gradient-to-br from-purple-600 to-indigo-700 rounded-full flex items-center justify-center border border-purple-400 sm:border-2">
            <Crown className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-white" />
          </div>
          <div className="hidden sm:block">
            <div className="text-xs sm:text-sm font-bold text-white">Level {stats.level}</div>
            {showXp && (
              <div className="text-xs text-slate-400 hidden md:block">
                {stats.xp}/{getXpForNextLevel()} XP
              </div>
            )}
          </div>
          {/* Mobile-only level text */}
          <div className="sm:hidden">
            <div className="text-xs font-bold text-white">Lvl {stats.level}</div>
          </div>
        </div>
      )}

      {/* XP Progress Bar - Hidden on mobile */}
      {showXp && showLevel && (
        <div className="hidden md:flex flex-1 max-w-32">
          <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
            <motion.div
              className="bg-gradient-to-r from-purple-500 to-indigo-500 h-full rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${getLevelProgress()}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            />
          </div>
        </div>
      )}

      {/* Gold - Compact design */}
      {showGold && (
        <div className="flex items-center gap-1 bg-yellow-600/20 px-1.5 sm:px-2 md:px-3 py-0.5 sm:py-1 rounded-full border border-yellow-500/30">
          <Coins className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400" />
          <span className="text-yellow-100 font-semibold text-xs sm:text-sm">
            {formatNumber(stats.gold)}
          </span>
        </div>
      )}

      {/* Diamonds - Compact design */}
      {showDiamonds && (
        <div className="flex items-center gap-1 bg-cyan-600/20 px-1.5 sm:px-2 md:px-3 py-0.5 sm:py-1 rounded-full border border-cyan-500/30">
          <Gem className="w-3 h-3 sm:w-4 sm:h-4 text-cyan-400" />
          <span className="text-cyan-100 font-semibold text-xs sm:text-sm">
            {formatNumber(stats.diamonds)}
          </span>
        </div>
      )}

      {/* Packs - Compact design with priority display */}
      {showPacks && stats.packs > 0 && (
        <div className="flex items-center gap-1 bg-purple-600/20 px-1.5 sm:px-2 md:px-3 py-0.5 sm:py-1 rounded-full border border-purple-500/30 animate-pulse">
          <Package className="w-3 h-3 sm:w-4 sm:h-4 text-purple-400" />
          <span className="text-purple-100 font-semibold text-xs sm:text-sm">
            {formatNumber(stats.packs)}
          </span>
        </div>
      )}

      {/* Additional Stats - Hidden on mobile */}
      {showLevel && (
        <div className="hidden lg:flex items-center gap-1 text-slate-400 text-xs">
          <Trophy className="w-3 h-3" />
          <span>{stats.gamesWon}/{stats.gamesPlayed}</span>
        </div>
      )}

      {/* Info Icon - Always visible */}
      <div className="flex items-center">
        <Info className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 hover:text-white transition-colors" />
      </div>
    </div>

    {/* Info Popup Modal */}
    <AnimatePresence>
      {showInfoPopup && (
        <ModalBackdrop onClose={() => setShowInfoPopup(false)}>
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg max-w-sm w-full max-h-[80vh] overflow-y-auto p-4 border border-slate-600 shadow-2xl">
            {/* Header */}
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Crown className="w-5 h-5 text-purple-400" />
                Statistiken
              </h3>
              <button
                onClick={() => setShowInfoPopup(false)}
                className="text-slate-400 hover:text-white transition-colors p-1 hover:bg-slate-700 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Stats Info */}
            <div className="space-y-3">
              {/* Level */}
              <div className="flex items-center gap-2 p-2 bg-purple-600/20 rounded border border-purple-500/30">
                <Crown className="w-4 h-4 text-purple-400" />
                <div className="flex-1">
                  <h4 className="font-semibold text-white text-sm">Level {stats.level}</h4>
                  <p className="text-xs text-slate-300">
                    XP sammeln für neue Features
                  </p>
                </div>
              </div>

              {/* Gold */}
              <div className="flex items-center gap-2 p-2 bg-yellow-600/20 rounded border border-yellow-500/30">
                <Coins className="w-4 h-4 text-yellow-400" />
                <div className="flex-1">
                  <h4 className="font-semibold text-white text-sm">Gold: {formatNumber(stats.gold)}</h4>
                  <p className="text-xs text-slate-300">
                    Hauptwährung für Kartenpacks
                  </p>
                </div>
              </div>

              {/* Diamonds */}
              <div className="flex items-center gap-2 p-2 bg-cyan-600/20 rounded border border-cyan-500/30">
                <Gem className="w-4 h-4 text-cyan-400" />
                <div className="flex-1">
                  <h4 className="font-semibold text-white text-sm">Diamanten: {formatNumber(stats.diamonds)}</h4>
                  <p className="text-xs text-slate-300">
                    Premium-Währung für Extras
                  </p>
                </div>
              </div>

              {/* Packs */}
              {stats.packs > 0 && (
                <div className="flex items-center gap-2 p-2 bg-purple-600/20 rounded border border-purple-500/30">
                  <Package className="w-4 h-4 text-purple-400" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-white text-sm">Packs: {formatNumber(stats.packs)}</h4>
                    <p className="text-xs text-slate-300">
                      Gehe zum Shop zum Öffnen
                    </p>
                  </div>
                </div>
              )}

              {/* Win Rate */}
              <div className="flex items-center gap-2 p-2 bg-green-600/20 rounded border border-green-500/30">
                <Trophy className="w-4 h-4 text-green-400" />
                <div className="flex-1">
                  <h4 className="font-semibold text-white text-sm">Siege: {stats.gamesWon}/{stats.gamesPlayed}</h4>
                  {stats.gamesPlayed > 0 && (
                    <p className="text-xs text-green-300">
                      {((stats.gamesWon / stats.gamesPlayed) * 100).toFixed(1)}% Siegesrate
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Close Button */}
            <div className="mt-4 flex justify-center">
              <button
                onClick={() => setShowInfoPopup(false)}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded hover:from-purple-500 hover:to-blue-500 transition-colors text-sm font-semibold"
              >
                OK
              </button>
            </div>
          </div>
        </ModalBackdrop>
      )}
    </AnimatePresence>
    </>
  );
}

export default PlayerStatsHeader;