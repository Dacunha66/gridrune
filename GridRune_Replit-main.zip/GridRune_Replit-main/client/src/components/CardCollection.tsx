import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCardGame } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card as UICard, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { ArrowLeft, Search, Filter, Eye, Sparkles } from "lucide-react";
import { Card as GameCard } from "./Card";
import { allCards } from "../lib/cardData";
import { GameCard as GameCardType } from "../lib/cardData";
import { CardDetailModal } from "./CardDetailModal";
import { useAudio } from "../lib/stores/useAudio";
import { DynamicBackground, useDominantRarity } from './DynamicBackground';

export function CardCollection() {
  const { setGamePhase } = useCardGame();
  const { playHit } = useAudio();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedElement, setSelectedElement] = useState<string>("all");
  const [selectedRarity, setSelectedRarity] = useState<string>("all");
  const [selectedEffect, setSelectedEffect] = useState<string>("all");
  const [selectedCard, setSelectedCard] = useState<GameCardType | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<string>("");

  const elements = ["all", "fire", "water", "earth", "lightning", "wind", "ice", "nature", "shadow", "desert", "crystal"];
  const rarities = ["all", "common", "uncommon", "rare", "epic", "legendary", "ultimate"];
  const effects = [
    "all", "blitzschlag", "schild", "verstärkung", "schwächung",
    "drehung", "clone", "sniper", "heilung", "infektion",
    "regeneration", "gift", "frost", "brennen"
  ];

  const filteredCards = allCards.filter(card => {
    const matchesSearch = (card.name || card.id).toLowerCase().includes(searchTerm.toLowerCase()) ||
                         card.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesElement = selectedElement === "all" || card.element === selectedElement;
    const matchesRarity = selectedRarity === "all" || card.rarity === selectedRarity;
    const matchesEffect = selectedEffect === "all" || card.effect === selectedEffect;

    return matchesSearch && matchesElement && matchesRarity && matchesEffect;
  });

  // Calculate dominant rarity for dynamic background
  const dominantRarity = useDominantRarity(filteredCards);

  const getElementColor = (element: string) => {
    const colors: { [key: string]: string } = {
      fire: "text-red-400",
      water: "text-blue-400",
      earth: "text-yellow-600",
      lightning: "text-yellow-400",
      wind: "text-green-400",
      ice: "text-cyan-400",
      nature: "text-emerald-400",
      shadow: "text-purple-400",
      desert: "text-orange-400",
      crystal: "text-pink-400"
    };
    return colors[element] || "text-gray-400";
  };

  const getRarityColor = (rarity: string) => {
    const colors: { [key: string]: string } = {
      common: "text-gray-400",
      uncommon: "text-green-400",
      rare: "text-blue-400",
      epic: "text-purple-400",
      legendary: "text-yellow-400",
      ultimate: "text-pink-400"
    };
    return colors[rarity] || "text-gray-400";
  };

  const getRarityDisplayName = (rarity: string) => {
    const names: { [key: string]: string } = {
      common: "Gewöhnlich",
      uncommon: "Ungewöhnlich", 
      rare: "Selten",
      epic: "Episch",
      legendary: "Legendär",
      ultimate: "Ultimativ"
    };
    return names[rarity] || "Unbekannt";
  };

  return (
    <DynamicBackground dominantRarity={dominantRarity} intensity={0.8}>
      <div className="min-h-screen text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={() => setGamePhase("deck-management")}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zur Verwaltung
          </Button>

          <h1 className="text-3xl font-bold">Kartensammlung</h1>

          <div className="text-slate-300">
            {filteredCards.length} von {allCards.length} Karten
          </div>
        </div>

        {/* Filters */}
        <UICard className="bg-slate-800 border-slate-600 mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Filter className="w-5 h-5 mr-2" />
              Filter & Suche
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Search */}
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Suche</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Kartenname suchen..."
                    className="pl-10 bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>

              {/* Element Filter */}
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Element</label>
                <select
                  value={selectedElement}
                  onChange={(e) => setSelectedElement(e.target.value)}
                  className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-white"
                >
                  {elements.map(element => (
                    <option key={element} value={element}>
                      {element === "all" ? "Alle Elemente" : element.charAt(0).toUpperCase() + element.slice(1)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Rarity Filter */}
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Seltenheit</label>
                <select
                  value={selectedRarity}
                  onChange={(e) => setSelectedRarity(e.target.value)}
                  className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-white"
                >
                  {rarities.map(rarity => (
                    <option key={rarity} value={rarity}>
                      {rarity === "all" ? "Alle Seltenheiten" : getRarityDisplayName(rarity)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Effect Filter */}
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Effekt</label>
                <select
                  value={selectedEffect}
                  onChange={(e) => setSelectedEffect(e.target.value)}
                  className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-white"
                >
                  {effects.map(effect => (
                    <option key={effect} value={effect}>
                      {effect === "all" ? "Alle Effekte" : effect.charAt(0).toUpperCase() + effect.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Clear Filters */}
            <div className="mt-4 flex justify-end">
              <Button
                onClick={() => {
                  setSearchTerm("");
                  setSelectedElement("all");
                  setSelectedRarity("all");
                  setSelectedEffect("all");
                }}
                variant="outline"
                className="text-white border-slate-600 hover:bg-slate-700"
              >
                Filter zurücksetzen
              </Button>
            </div>
          </CardContent>
        </UICard>

        {/* Enhanced Card Grid with Staggered Animation */}
        <motion.div
          className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 2xl:grid-cols-8 gap-6 sm:gap-8 place-items-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <AnimatePresence mode="popLayout">
            {filteredCards.map((card, index) => (
              <motion.div
                key={card.id}
                className="group relative flex items-center justify-center w-full h-full"
                initial={{ opacity: 0, scale: 0.8, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: -20 }}
                transition={{
                  delay: index * 0.02,
                  type: "spring",
                  stiffness: 200,
                  damping: 20
                }}
                layout
                onHoverStart={() => setHoveredCard(card.id)}
                onHoverEnd={() => setHoveredCard("")}
              >
                <motion.div
                  className="relative cursor-pointer"
                  whileHover={{
                    scale: 1.08,
                    y: -8,
                    rotateY: 3,
                    z: 20
                  }}
                  whileTap={{
                    scale: 0.95,
                    rotateX: 5,
                    transition: { duration: 0.1 }
                  }}
                  onClick={() => {
                    setSelectedCard(card);
                    setIsDetailModalOpen(true);
                    playHit();
                  }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                >
                  <motion.div
                    className="relative flex items-center justify-center w-full h-full"
                    style={{
                      transform: 'scale(0.95)',
                      transformOrigin: 'center',
                      maxWidth: '100%',
                      maxHeight: '100%'
                    }}
                    whileHover={{
                      filter: [
                        "drop-shadow(0 4px 8px rgba(0,0,0,0.3))",
                        `drop-shadow(0 8px 25px ${
                          card.rarity === 'legendary' ? 'rgba(251,191,36,0.4)' :
                          card.rarity === 'epic' ? 'rgba(168,85,247,0.4)' :
                          card.rarity === 'rare' ? 'rgba(59,130,246,0.4)' :
                          card.rarity === 'uncommon' ? 'rgba(16,185,129,0.4)' :
                          'rgba(107,114,128,0.4)'
                        })`
                      ]
                    }}
                  >
                    <GameCard
                      card={card}
                      isSelected={false}
                      isInCollection={true}
                      onClick={() => {
                        setSelectedCard(card);
                        setIsDetailModalOpen(true);
                        playHit();
                      }}
                      isClickable={true}
                      isDisabled={false}
                    />
                  </motion.div>

                  {/* Animated Hover Glow Effect */}
                  <motion.div
                    className="absolute inset-0 rounded-lg pointer-events-none"
                    style={{
                      background: `radial-gradient(circle, ${
                        card.rarity === 'legendary' ? 'rgba(251,191,36,0.3)' :
                        card.rarity === 'epic' ? 'rgba(168,85,247,0.3)' :
                        card.rarity === 'rare' ? 'rgba(59,130,246,0.3)' :
                        card.rarity === 'uncommon' ? 'rgba(16,185,129,0.3)' :
                        'rgba(107,114,128,0.3)'
                      } 0%, transparent 70%)`
                    }}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{
                      opacity: hoveredCard === card.id ? 1 : 0,
                      scale: hoveredCard === card.id ? 1.1 : 0.8
                    }}
                    transition={{ duration: 0.3 }}
                  />

                  {/* Enhanced Card Info Overlay with Animation */}
                  <motion.div
                    className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-2 pointer-events-none"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{
                      opacity: hoveredCard === card.id ? 1 : 0,
                      y: hoveredCard === card.id ? 0 : 10
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="text-xs text-center">
                      <motion.p
                        className="text-white font-semibold truncate drop-shadow-lg"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.1 }}
                      >
                        {card.name || card.id}
                      </motion.p>
                      <motion.div
                        className="flex justify-between items-center mt-1"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.15 }}
                      >
                        <span className={`text-xs font-medium ${getRarityColor(card.rarity || "common")} drop-shadow-md`}>
                          {getRarityDisplayName(card.rarity || "common")}
                        </span>
                        {card.element && (
                          <span className={`text-xs ${getElementColor(card.element)} drop-shadow-md`}>
                            {card.element}
                          </span>
                        )}
                      </motion.div>
                      {card.effect && (
                        <motion.p
                          className="text-xs text-blue-300 mt-1 truncate drop-shadow-md"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.2 }}
                        >
                          {card.effect}
                        </motion.p>
                      )}
                    </div>
                  </motion.div>

                  {/* Floating inspection button */}
                  <motion.div
                    className="absolute -top-2 -right-2"
                    initial={{ opacity: 0, scale: 0, rotate: -90 }}
                    animate={{
                      opacity: hoveredCard === card.id ? 1 : 0,
                      scale: hoveredCard === card.id ? 1 : 0,
                      rotate: hoveredCard === card.id ? 0 : -90
                    }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  >
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedCard(card);
                        setIsDetailModalOpen(true);
                        playHit();
                      }}
                      size="sm"
                      className="w-6 h-6 p-0 bg-blue-600 hover:bg-blue-500 text-white rounded-full shadow-lg"
                    >
                      <Eye className="w-3 h-3" />
                    </Button>
                  </motion.div>

                  {/* Legendary sparkle effect */}
                  {card.rarity === 'legendary' && (
                    <motion.div
                      className="absolute inset-0 pointer-events-none"
                      animate={{
                        opacity: [0, 0.6, 0],
                        scale: [1, 1.05, 1]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        repeatType: "loop",
                        delay: Math.random() * 2
                      }}
                    >
                      <Sparkles className="absolute top-1 right-1 w-4 h-4 text-yellow-400" />
                      <Sparkles className="absolute bottom-1 left-1 w-3 h-3 text-amber-300" />
                    </motion.div>
                  )}
                </motion.div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredCards.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-400 text-lg">Keine Karten gefunden</p>
            <p className="text-slate-500 text-sm mt-2">Versuche andere Filtereinstellungen</p>
          </div>
        )}

        {/* Card Detail Modal */}
        <CardDetailModal
          card={selectedCard}
          isOpen={isDetailModalOpen}
          onClose={() => {
            setIsDetailModalOpen(false);
            setSelectedCard(null);
          }}
        />
      </div>
      </div>
    </DynamicBackground>
  );
}