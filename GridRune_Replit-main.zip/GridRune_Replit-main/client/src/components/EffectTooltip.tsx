import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { CARD_EFFECTS, CardEffect } from '../lib/cardEffects';
import { cn } from '../lib/utils';

interface EffectTooltipProps {
  effect: CardEffect;
  children: React.ReactNode;
}

export function EffectTooltip({ effect, children }: EffectTooltipProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  const triggerRef = useRef<HTMLDivElement>(null);
  const effectData = CARD_EFFECTS[effect];

  useEffect(() => {
    if (isVisible && triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      const viewport = {
        width: window.innerWidth,
        height: window.innerHeight
      };
      
      // Calculate best position
      let x = rect.left + rect.width / 2;
      let y = rect.top - 10; // Default above
      
      // Check if there's enough space above
      if (rect.top < 120) {
        // Not enough space above, try right
        if (rect.right + 250 < viewport.width) {
          x = rect.right + 10;
          y = rect.top + rect.height / 2;
        }
        // Try left
        else if (rect.left - 250 > 0) {
          x = rect.left - 10;
          y = rect.top + rect.height / 2;
        }
        // Fall back to below
        else {
          x = rect.left + rect.width / 2;
          y = rect.bottom + 10;
        }
      }
      
      setTooltipPosition({ x, y });
    }
  }, [isVisible]);

  if (!effectData) return <>{children}</>;

  const tooltip = isVisible ? createPortal(
    <div 
      className="fixed pointer-events-none"
      style={{ 
        left: tooltipPosition.x,
        top: tooltipPosition.y,
        zIndex: 99999,
        transform: 'translate(-50%, -100%)'
      }}
    >
      <div className="bg-slate-900 text-white px-3 py-2 rounded-lg shadow-2xl border border-slate-600 max-w-64 text-sm backdrop-blur-sm bg-opacity-95">
        <div className="font-bold text-yellow-400 mb-1">
          {effectData.symbol} {effectData.name}
        </div>
        <div className="text-gray-300">
          {effectData.description}
        </div>
      </div>
    </div>,
    document.body
  ) : null;

  return (
    <>
      <div className="relative inline-block">
        <div
          ref={triggerRef}
          onMouseEnter={() => setIsVisible(true)}
          onMouseLeave={() => setIsVisible(false)}
          onClick={() => setIsVisible(!isVisible)}
          className="cursor-help"
        >
          {children}
        </div>
      </div>
      {tooltip}
    </>
  );
}