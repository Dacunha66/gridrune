import { DeckTheme } from "../lib/deckThemes";
import { GameCard } from "../lib/cardData";

interface ThemePreviewCardProps {
  theme: DeckTheme;
  card: GameCard;
  size?: 'small' | 'medium' | 'large';
}

export function ThemePreviewCard({ theme, card, size = 'medium' }: ThemePreviewCardProps) {
  const sizeClasses = {
    small: 'w-16 h-20 text-xs',
    medium: 'w-20 h-28 text-sm',
    large: 'w-24 h-32 text-base'
  };

  const valueSize = {
    small: 'text-xs',
    medium: 'text-sm',
    large: 'text-base'
  };

  return (
    <div
      className={`relative rounded-lg border-2 transition-all duration-300 hover:scale-105 ${sizeClasses[size]}`}
      style={{
        backgroundColor: theme.cardBackColor,
        borderColor: theme.accentColor,
        background: `linear-gradient(135deg, ${theme.primaryColor}20, ${theme.secondaryColor}40)`
      }}
    >
      {/* Card back pattern overlay */}
      <div 
        className={`absolute inset-0 rounded-lg opacity-20`}
        style={{
          backgroundImage: getPatternBackground(theme.cardBackPattern)
        }}
      />
      
      {/* Card content */}
      <div className="absolute inset-0 p-1 flex flex-col justify-between">
        {/* Top value */}
        <div 
          className={`${valueSize[size]} font-bold text-center`}
          style={{ color: theme.textColor }}
        >
          {card.top}
        </div>
        
        {/* Center with element symbol */}
        <div className="flex justify-between items-center">
          <div 
            className={`${valueSize[size]} font-bold`}
            style={{ color: theme.textColor }}
          >
            {card.left}
          </div>
          <div className="text-xs">{getElementEmoji(card.element)}</div>
          <div 
            className={`${valueSize[size]} font-bold`}
            style={{ color: theme.textColor }}
          >
            {card.right}
          </div>
        </div>
        
        {/* Bottom value */}
        <div 
          className={`${valueSize[size]} font-bold text-center`}
          style={{ color: theme.textColor }}
        >
          {card.bottom}
        </div>
      </div>
      
      {/* Effect indicator */}
      {card.effect && (
        <div className="absolute top-0 right-0 text-xs bg-black/50 rounded-bl-md px-1">
          {getEffectSymbol(card.effect)}
        </div>
      )}
      
      {/* Theme accent glow */}
      <div 
        className="absolute inset-0 rounded-lg opacity-30 pointer-events-none"
        style={{
          boxShadow: `inset 0 0 10px ${theme.accentColor}40`
        }}
      />
    </div>
  );
}

function getElementEmoji(element: string): string {
  const emojis: { [key: string]: string } = {
    fire: "🔥",
    water: "💧", 
    earth: "🌍",
    lightning: "⚡",
    wind: "🌪️",
    ice: "❄️",
    nature: "🌿",
    shadow: "🌙",
    desert: "🏜️",
    crystal: "💎"
  };
  return emojis[element] || "⚫";
}

function getEffectSymbol(effect: string): string {
  const symbols: { [key: string]: string } = {
    blitzschlag: "⚡",
    schild: "🛡️",
    verstärkung: "💪",
    schwächung: "💔",
    drehung: "🔄",
    clone: "👥",
    sniper: "🎯",
    heilung: "❤️",
    infektion: "🦠",
    regeneration: "🔋",
    gift: "☠️",
    frost: "🧊",
    brennen: "🔥",
    anker: "⚓"
  };
  return symbols[effect] || "✨";
}

function getPatternBackground(pattern: string): string {
  const patterns: { [key: string]: string } = {
    flame: "radial-gradient(circle at 20% 50%, rgba(251, 191, 36, 0.3) 0%, transparent 50%), radial-gradient(circle at 80% 50%, rgba(220, 38, 38, 0.3) 0%, transparent 50%)",
    wave: "repeating-linear-gradient(45deg, rgba(6, 182, 212, 0.1) 0px, rgba(6, 182, 212, 0.1) 1px, transparent 1px, transparent 15px)",
    stone: "radial-gradient(circle at 30% 70%, rgba(163, 163, 163, 0.2) 0%, transparent 50%), radial-gradient(circle at 70% 30%, rgba(234, 179, 8, 0.2) 0%, transparent 50%)",
    lightning: "linear-gradient(135deg, transparent 30%, rgba(234, 179, 8, 0.3) 50%, transparent 70%)",
    leaf: "repeating-linear-gradient(60deg, rgba(5, 150, 105, 0.1) 0px, rgba(5, 150, 105, 0.1) 2px, transparent 2px, transparent 12px)",
    snowflake: "radial-gradient(circle at 25% 25%, rgba(240, 249, 255, 0.3) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(8, 145, 178, 0.2) 0%, transparent 50%)",
    shadow: "linear-gradient(45deg, rgba(124, 58, 237, 0.2) 25%, transparent 25%, transparent 75%, rgba(91, 33, 182, 0.2) 75%)",
    crystal: "conic-gradient(from 0deg, rgba(236, 72, 153, 0.2) 0deg, transparent 60deg, rgba(168, 85, 247, 0.2) 120deg, transparent 180deg, rgba(236, 72, 153, 0.2) 240deg, transparent 300deg)",
    stars: "radial-gradient(2px 2px at 20px 30px, rgba(251, 191, 36, 0.5), transparent), radial-gradient(2px 2px at 40px 70px, rgba(251, 191, 36, 0.4), transparent), radial-gradient(1px 1px at 90px 40px, rgba(251, 191, 36, 0.6), transparent)",
    "gold-ornament": "repeating-conic-gradient(from 0deg at 50% 50%, rgba(217, 119, 6, 0.3) 0deg, transparent 45deg, rgba(146, 64, 14, 0.2) 90deg, transparent 135deg)"
  };
  return patterns[pattern] || "none";
}