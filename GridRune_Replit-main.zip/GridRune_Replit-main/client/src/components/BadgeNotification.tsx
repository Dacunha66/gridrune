import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AchievementBadge, type Badge } from './AchievementBadge';
import { useAudio } from '../lib/stores/useAudio';
import { cn } from '../lib/utils';

interface BadgeNotificationProps {
  badge: Badge;
  onClose: () => void;
}

export function BadgeNotification({ badge, onClose }: BadgeNotificationProps) {
  const { playSuccess } = useAudio();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    playSuccess();
    
    // Auto close after 5 seconds
    const timer = setTimeout(() => {
      handleClose();
    }, 5000);

    return () => clearTimeout(timer);
  }, [playSuccess]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          className="fixed top-4 right-4 z-50 pointer-events-auto"
        >
          <div className="bg-slate-900 border-2 border-amber-400 rounded-xl shadow-2xl p-4 max-w-sm">
            <div className="flex items-center space-x-3">
              <AchievementBadge
                badge={badge}
                size="medium"
                showTooltip={false}
              />
              
              <div className="flex-1">
                <div className="text-amber-400 font-bold text-sm mb-1">
                  Abzeichen freigeschaltet!
                </div>
                <div className="text-white font-semibold">
                  {badge.title}
                </div>
                <div className="text-gray-300 text-xs">
                  {badge.description}
                </div>
              </div>

              <button
                onClick={handleClose}
                className="text-gray-400 hover:text-white transition-colors ml-2"
              >
                ✕
              </button>
            </div>

            {/* Sparkle Animation */}
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-1 h-1 bg-yellow-400 rounded-full"
                  initial={{ 
                    x: '50%', 
                    y: '50%',
                    scale: 0,
                    opacity: 1
                  }}
                  animate={{ 
                    x: `${50 + (Math.random() - 0.5) * 200}%`,
                    y: `${50 + (Math.random() - 0.5) * 200}%`,
                    scale: [0, 1, 0],
                    opacity: [1, 1, 0]
                  }}
                  transition={{ 
                    duration: 2,
                    delay: i * 0.1,
                    ease: "easeOut"
                  }}
                />
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Badge Notification Manager
interface BadgeNotificationManagerProps {
  badges: Badge[];
  onBadgeViewed: (badgeId: string) => void;
}

export function BadgeNotificationManager({ badges, onBadgeViewed }: BadgeNotificationManagerProps) {
  const [currentBadge, setCurrentBadge] = useState<Badge | null>(null);
  const [queue, setQueue] = useState<Badge[]>([]);

  useEffect(() => {
    // Add new badges to queue
    const newBadges = badges.filter(badge => {
      if (!badge.unlockedAt) return false;
      
      const unlockedDate = badge.unlockedAt instanceof Date 
        ? badge.unlockedAt 
        : new Date(badge.unlockedAt);
      
      if (isNaN(unlockedDate.getTime())) return false;
      
      return new Date().getTime() - unlockedDate.getTime() < 10000 && // Within last 10 seconds
        !queue.some(qb => qb.id === badge.id) &&
        currentBadge?.id !== badge.id;
    });
    
    if (newBadges.length > 0) {
      setQueue(prev => [...prev, ...newBadges]);
    }
  }, [badges, queue, currentBadge]);

  useEffect(() => {
    // Show next badge if not currently showing one
    if (!currentBadge && queue.length > 0) {
      setCurrentBadge(queue[0]);
      setQueue(prev => prev.slice(1));
    }
  }, [currentBadge, queue]);

  const handleClose = () => {
    if (currentBadge) {
      onBadgeViewed(currentBadge.id);
      setCurrentBadge(null);
    }
  };

  if (!currentBadge) return null;

  return (
    <BadgeNotification
      badge={currentBadge}
      onClose={handleClose}
    />
  );
}