import React from 'react';
import { cn } from '../lib/utils';

export interface Avatar {
  id: string;
  name: string;
  emoji: string;
  background: string;
  borderColor: string;
}

export const AVAILABLE_AVATARS: Avatar[] = [
  {
    id: 'warrior',
    name: 'Krieger',
    emoji: '⚔️',
    background: 'bg-gradient-to-br from-red-600 to-red-800',
    borderColor: 'border-red-400'
  },
  {
    id: 'mage',
    name: 'Magier',
    emoji: '🔮',
    background: 'bg-gradient-to-br from-purple-600 to-purple-800',
    borderColor: 'border-purple-400'
  },
  {
    id: 'archer',
    name: 'Bogenschütze',
    emoji: '🏹',
    background: 'bg-gradient-to-br from-green-600 to-green-800',
    borderColor: 'border-green-400'
  },
  {
    id: 'knight',
    name: 'Ritter',
    emoji: '🛡️',
    background: 'bg-gradient-to-br from-blue-600 to-blue-800',
    borderColor: 'border-blue-400'
  },
  {
    id: 'dragon',
    name: 'Drache',
    emoji: '🐉',
    background: 'bg-gradient-to-br from-orange-600 to-orange-800',
    borderColor: 'border-orange-400'
  },
  {
    id: 'phoenix',
    name: 'Phönix',
    emoji: '🔥',
    background: 'bg-gradient-to-br from-yellow-600 to-yellow-800',
    borderColor: 'border-yellow-400'
  },
  {
    id: 'wolf',
    name: 'Wolf',
    emoji: '🐺',
    background: 'bg-gradient-to-br from-gray-600 to-gray-800',
    borderColor: 'border-gray-400'
  },
  {
    id: 'eagle',
    name: 'Adler',
    emoji: '🦅',
    background: 'bg-gradient-to-br from-cyan-600 to-cyan-800',
    borderColor: 'border-cyan-400'
  },
  {
    id: 'tiger',
    name: 'Tiger',
    emoji: '🐅',
    background: 'bg-gradient-to-br from-amber-600 to-amber-800',
    borderColor: 'border-amber-400'
  },
  {
    id: 'bear',
    name: 'Bär',
    emoji: '🐻',
    background: 'bg-gradient-to-br from-stone-600 to-stone-800',
    borderColor: 'border-stone-400'
  },
  {
    id: 'cat',
    name: 'Katze',
    emoji: '🐱',
    background: 'bg-gradient-to-br from-pink-600 to-pink-800',
    borderColor: 'border-pink-400'
  },
  {
    id: 'wizard',
    name: 'Zauberer',
    emoji: '🧙',
    background: 'bg-gradient-to-br from-indigo-600 to-indigo-800',
    borderColor: 'border-indigo-400'
  }
];

interface AvatarSelectorProps {
  selectedAvatar?: Avatar;
  onSelect: (avatar: Avatar) => void;
  size?: 'small' | 'medium' | 'large';
  showNames?: boolean;
  className?: string;
}

export function AvatarSelector({ 
  selectedAvatar, 
  onSelect, 
  size = 'medium',
  showNames = true,
  className 
}: AvatarSelectorProps) {
  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return 'w-12 h-12 text-xl';
      case 'large':
        return 'w-20 h-20 text-3xl';
      default:
        return 'w-16 h-16 text-2xl';
    }
  };

  return (
    <div className={cn("grid grid-cols-4 gap-3", className)}>
      {AVAILABLE_AVATARS.map((avatar) => (
        <div
          key={avatar.id}
          className={cn(
            "flex flex-col items-center space-y-2 cursor-pointer transition-all duration-200 hover:scale-105",
            selectedAvatar?.id === avatar.id && "scale-110"
          )}
          onClick={() => onSelect(avatar)}
        >
          <div
            className={cn(
              "rounded-full border-2 flex items-center justify-center transition-all duration-200",
              getSizeClasses(),
              avatar.background,
              avatar.borderColor,
              selectedAvatar?.id === avatar.id 
                ? "ring-4 ring-white ring-opacity-75 shadow-lg" 
                : "hover:shadow-md"
            )}
          >
            <span className="drop-shadow-lg">{avatar.emoji}</span>
          </div>
          {showNames && (
            <span className={cn(
              "text-xs text-slate-300 text-center font-medium",
              selectedAvatar?.id === avatar.id && "text-white font-bold"
            )}>
              {avatar.name}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

interface AvatarDisplayProps {
  avatar: Avatar;
  size?: 'small' | 'medium' | 'large';
  showName?: boolean;
  className?: string;
}

export function AvatarDisplay({ 
  avatar, 
  size = 'medium', 
  showName = false,
  className 
}: AvatarDisplayProps) {
  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return 'w-8 h-8 text-sm';
      case 'large':
        return 'w-16 h-16 text-2xl';
      default:
        return 'w-12 h-12 text-xl';
    }
  };

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      <div
        className={cn(
          "rounded-full border-2 flex items-center justify-center",
          getSizeClasses(),
          avatar.background,
          avatar.borderColor
        )}
      >
        <span className="drop-shadow-lg">{avatar.emoji}</span>
      </div>
      {showName && (
        <span className="text-sm font-medium text-slate-200">
          {avatar.name}
        </span>
      )}
    </div>
  );
}