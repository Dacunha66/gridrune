import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Target, Zap, Shield } from 'lucide-react';

interface PlacementIndicatorProps {
  strategy?: 'optimal' | 'aggressive' | 'defensive' | 'neutral';
  isHighlighted?: boolean;
  isEmpty?: boolean;
  showStrategicHints?: boolean;
}

export function PlacementIndicator({ 
  strategy, 
  isHighlighted = false, 
  isEmpty = true,
  showStrategicHints = false 
}: PlacementIndicatorProps) {
  if (!isEmpty) return null;

  const getStrategyInfo = (strategy: string) => {
    switch (strategy) {
      case 'optimal':
        return {
          icon: <Target className="w-4 h-4" />,
          color: 'text-purple-300',
          bg: 'bg-purple-500/30',
          border: 'border-purple-400',
          label: '⭐ Optimal'
        };
      case 'aggressive':
        return {
          icon: <Zap className="w-4 h-4" />,
          color: 'text-red-300',
          bg: 'bg-red-500/30',
          border: 'border-red-400',
          label: '⚔️ Angriff'
        };
      case 'defensive':
        return {
          icon: <Shield className="w-4 h-4" />,
          color: 'text-blue-300',
          bg: 'bg-blue-500/30',
          border: 'border-blue-400',
          label: '🛡️ Verteidigung'
        };
      default:
        return {
          icon: <CheckCircle className="w-4 h-4" />,
          color: 'text-gray-300',
          bg: 'bg-gray-500/30',
          border: 'border-gray-400',
          label: '🎯 Neutral'
        };
    }
  };

  const strategyInfo = strategy ? getStrategyInfo(strategy) : null;

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      {/* Base placement indicator - always shown for valid slots */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ 
          scale: isHighlighted ? 1.2 : 1, 
          opacity: 1,
        }}
        transition={{ 
          type: "spring", 
          stiffness: 300, 
          damping: 20 
        }}
        className="relative flex items-center justify-center"
      >
        {/* Pulsing ring animation */}
        <motion.div
          animate={{ 
            scale: [1, 1.4, 1],
            opacity: [0.3, 0.1, 0.3]
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute w-8 h-8 rounded-full border-2 border-emerald-400"
        />
        
        {/* Center dot */}
        <motion.div
          animate={{
            scale: isHighlighted ? [1, 1.3, 1] : 1,
          }}
          transition={{
            duration: 0.6,
            repeat: isHighlighted ? Infinity : 0,
          }}
          className={`w-3 h-3 rounded-full ${
            isHighlighted 
              ? 'bg-emerald-300 shadow-lg shadow-emerald-300/50' 
              : 'bg-emerald-400'
          }`}
        />

        {/* Strategic hint overlay - removed text labels per user request */}
      </motion.div>
    </div>
  );
}