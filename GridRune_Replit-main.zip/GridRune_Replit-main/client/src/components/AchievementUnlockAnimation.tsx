import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Star, Crown, Medal, Zap, Sparkles, X, Gift } from 'lucide-react';
import { Button } from './ui/button';
import { useAudio } from '../lib/stores/useAudio';
import confetti from 'canvas-confetti';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  reward: {
    xp?: number;
    gold?: number;
    diamonds?: number;
    title?: string;
  };
  icon?: React.ReactNode;
}

interface AchievementUnlockAnimationProps {
  achievement: Achievement | null;
  isVisible: boolean;
  onComplete: () => void;
  onSkip?: () => void;
}

const RARITY_CONFIGS = {
  common: {
    colors: 'from-gray-400 to-gray-600',
    borderColor: 'border-gray-400',
    particles: 15,
    glowColor: 'rgba(156, 163, 175, 0.3)',
    title: 'Erfolg freigeschaltet!',
    duration: 2000
  },
  uncommon: {
    colors: 'from-green-400 to-green-600',
    borderColor: 'border-green-400',
    particles: 25,
    glowColor: 'rgba(34, 197, 94, 0.4)',
    title: 'Ungewöhnlicher Erfolg!',
    duration: 2500
  },
  rare: {
    colors: 'from-blue-400 to-blue-600',
    borderColor: 'border-blue-400',
    particles: 35,
    glowColor: 'rgba(59, 130, 246, 0.5)',
    title: 'Seltener Erfolg!',
    duration: 3000
  },
  epic: {
    colors: 'from-purple-400 to-purple-600',
    borderColor: 'border-purple-400',
    particles: 45,
    glowColor: 'rgba(147, 51, 234, 0.6)',
    title: 'Epischer Erfolg!',
    duration: 3500
  },
  legendary: {
    colors: 'from-yellow-400 to-yellow-600',
    borderColor: 'border-yellow-400',
    particles: 60,
    glowColor: 'rgba(251, 191, 36, 0.8)',
    title: 'LEGENDÄRER ERFOLG!',
    duration: 4000
  }
};

// Particle component for special effects
const Particle = ({ delay, rarity }: { delay: number; rarity: string }) => {
  const config = RARITY_CONFIGS[rarity as keyof typeof RARITY_CONFIGS];
  
  return (
    <motion.div
      className={`absolute w-2 h-2 bg-gradient-to-r ${config.colors} rounded-full`}
      initial={{ 
        x: 0, 
        y: 0, 
        scale: 0, 
        opacity: 0 
      }}
      animate={{
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 400,
        scale: [0, 1, 0],
        opacity: [0, 1, 0]
      }}
      transition={{
        duration: 2,
        delay: delay,
        ease: "easeOut"
      }}
      style={{
        left: '50%',
        top: '50%'
      }}
    />
  );
};

// Star burst effect
const StarBurst = ({ rarity }: { rarity: string }) => {
  const config = RARITY_CONFIGS[rarity as keyof typeof RARITY_CONFIGS];
  const starCount = rarity === 'legendary' ? 12 : rarity === 'epic' ? 8 : 6;
  
  return (
    <div className="absolute inset-0 pointer-events-none">
      {Array.from({ length: starCount }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute"
          initial={{ scale: 0, rotate: 0 }}
          animate={{ 
            scale: [0, 1.5, 0],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 1.5,
            delay: i * 0.1,
            ease: "easeOut"
          }}
          style={{
            left: '50%',
            top: '50%',
            transform: `translate(-50%, -50%) rotate(${i * (360 / starCount)}deg) translateY(-80px)`
          }}
        >
          <Star className={`w-6 h-6 text-${config.colors.split('-')[1]}-400`} />
        </motion.div>
      ))}
    </div>
  );
};

// Lightning effects for epic/legendary
const LightningEffect = () => {
  return (
    <motion.div
      className="absolute inset-0 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 0, 1, 0] }}
      transition={{ duration: 0.5, repeat: 3 }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-300/20 to-transparent transform rotate-12" />
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-purple-300/20 to-transparent transform -rotate-12" />
    </motion.div>
  );
};

export function AchievementUnlockAnimation({ 
  achievement, 
  isVisible, 
  onComplete, 
  onSkip 
}: AchievementUnlockAnimationProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [animationPhase, setAnimationPhase] = useState<'entry' | 'main' | 'exit'>('entry');
  const { playSuccess } = useAudio();

  useEffect(() => {
    if (!isVisible || !achievement) return;

    playSuccess();
    
    // Trigger confetti celebration based on rarity
    const triggerConfetti = () => {
      const config = RARITY_CONFIGS[achievement.rarity];
      const colors = achievement.rarity === 'legendary' 
        ? ['#FFD700', '#FFA500', '#FFFF00'] 
        : achievement.rarity === 'epic'
        ? ['#8B5CF6', '#A78BFA']
        : achievement.rarity === 'rare'
        ? ['#3B82F6', '#60A5FA']
        : ['#10B981', '#34D399'];
      
      // Multiple confetti bursts
      confetti({
        particleCount: config.particles * 2,
        spread: 70,
        origin: { y: 0.6 },
        colors
      });
      
      setTimeout(() => {
        confetti({
          particleCount: config.particles,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.8 },
          colors
        });
      }, 200);
      
      setTimeout(() => {
        confetti({
          particleCount: config.particles,
          angle: 120,
          spread: 55,
          origin: { x: 1, y: 0.8 },
          colors
        });
      }, 400);
      
      // Extra celebration for legendary achievements
      if (achievement.rarity === 'legendary') {
        setTimeout(() => {
          confetti({
            particleCount: 150,
            spread: 90,
            origin: { y: 0.4 },
            colors,
            gravity: 0.5,
            drift: 0.1
          });
        }, 600);
      }
    };

    // Trigger confetti after a short delay
    setTimeout(triggerConfetti, 500);
    
    const config = RARITY_CONFIGS[achievement.rarity];
    
    // Phase timing
    const phaseTimer = setTimeout(() => setAnimationPhase('main'), 500);
    const detailsTimer = setTimeout(() => setShowDetails(true), 1500);
    const completeTimer = setTimeout(() => {
      setAnimationPhase('exit');
      setTimeout(onComplete, 500);
    }, config.duration);

    return () => {
      clearTimeout(phaseTimer);
      clearTimeout(detailsTimer);
      clearTimeout(completeTimer);
    };
  }, [isVisible, achievement, onComplete, playSuccess]);

  if (!isVisible || !achievement) return null;

  const config = RARITY_CONFIGS[achievement.rarity];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] overflow-hidden"
      >
        {/* Background Effects */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(circle at center, ${config.glowColor} 0%, transparent 70%)`
          }}
          animate={{
            scale: [0.5, 1.2, 1],
            opacity: [0, 0.8, 0.6]
          }}
          transition={{ duration: 2, ease: "easeOut" }}
        />

        {/* Particle Effects */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: config.particles }).map((_, i) => (
            <Particle 
              key={i} 
              delay={i * 0.05} 
              rarity={achievement.rarity}
            />
          ))}
        </div>

        {/* Star Burst */}
        <StarBurst rarity={achievement.rarity} />

        {/* Lightning for Epic/Legendary */}
        {(achievement.rarity === 'epic' || achievement.rarity === 'legendary') && (
          <LightningEffect />
        )}

        {/* Main Achievement Container */}
        <motion.div
          className="relative text-center max-w-lg mx-auto p-8"
          initial={{ scale: 0, y: 50 }}
          animate={{ 
            scale: animationPhase === 'exit' ? 0 : 1,
            y: animationPhase === 'exit' ? -50 : 0
          }}
          transition={{ 
            type: "spring", 
            stiffness: 200, 
            damping: 20 
          }}
        >
          {/* Achievement Icon */}
          <motion.div
            className={`w-32 h-32 mx-auto mb-6 rounded-full flex items-center justify-center bg-gradient-to-br ${config.colors} border-4 ${config.borderColor} relative overflow-hidden`}
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ 
              type: "spring", 
              stiffness: 150, 
              damping: 15,
              delay: 0.3
            }}
            style={{
              boxShadow: `0 0 40px ${config.glowColor}`
            }}
          >
            {/* Rotating glow effect */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: `conic-gradient(from 0deg, transparent, ${config.glowColor}, transparent)`
              }}
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Icon */}
            <div className="relative z-10 text-white">
              {achievement.icon || <Trophy className="w-16 h-16" />}
            </div>

            {/* Sparkle overlay for legendary */}
            {achievement.rarity === 'legendary' && (
              <motion.div
                className="absolute inset-0 rounded-full"
                animate={{
                  background: [
                    'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8) 2px, transparent 2px)',
                    'radial-gradient(circle at 70% 70%, rgba(255,255,255,0.8) 2px, transparent 2px)',
                    'radial-gradient(circle at 50% 20%, rgba(255,255,255,0.8) 2px, transparent 2px)'
                  ]
                }}
                transition={{ duration: 1, repeat: Infinity }}
              />
            )}
          </motion.div>

          {/* Achievement Title */}
          <motion.h1
            className={`text-4xl font-bold mb-4 bg-gradient-to-r ${config.colors} bg-clip-text text-transparent`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            style={{
              filter: `drop-shadow(0 0 10px ${config.glowColor})`,
              fontFamily: achievement.rarity === 'legendary' ? 'serif' : 'inherit'
            }}
          >
            {config.title}
          </motion.h1>

          {/* Achievement Name */}
          <motion.h2
            className="text-2xl font-semibold text-white mb-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            {achievement.title}
          </motion.h2>

          {/* Achievement Description */}
          <motion.p
            className="text-slate-300 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
          >
            {achievement.description}
          </motion.p>

          {/* Rewards Display */}
          <AnimatePresence>
            {showDetails && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`bg-black/40 rounded-lg p-4 border ${config.borderColor} backdrop-blur-sm`}
              >
                <h3 className="text-lg font-semibold text-white mb-3">Belohnungen:</h3>
                <div className="flex justify-center gap-4 flex-wrap">
                  {achievement.reward.xp && (
                    <div className="flex items-center gap-2 text-blue-400">
                      <Star className="w-5 h-5" />
                      <span className="font-semibold">+{achievement.reward.xp} XP</span>
                    </div>
                  )}
                  {achievement.reward.gold && (
                    <div className="flex items-center gap-2 text-yellow-500">
                      <span>🪙</span>
                      <span className="font-semibold">+{achievement.reward.gold} Gold</span>
                    </div>
                  )}
                  {achievement.reward.diamonds && (
                    <div className="flex items-center gap-2 text-cyan-400">
                      <span>💎</span>
                      <span className="font-semibold">+{achievement.reward.diamonds} Diamanten</span>
                    </div>
                  )}
                  {achievement.reward.title && (
                    <div className="flex items-center gap-2 text-purple-400">
                      <Crown className="w-5 h-5" />
                      <span className="font-semibold">Titel: {achievement.reward.title}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Skip Button */}
          {onSkip && (
            <motion.div
              className="absolute top-4 right-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <Button
                onClick={onSkip}
                variant="ghost"
                size="sm"
                className="text-white/70 hover:text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </motion.div>
          )}
        </motion.div>

        {/* Screen Flash Effect for Legendary */}
        {achievement.rarity === 'legendary' && (
          <motion.div
            className="absolute inset-0 bg-yellow-400/20"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0] }}
            transition={{ duration: 0.2, delay: 0.5 }}
          />
        )}

        {/* Ripple Effect */}
        <motion.div
          className={`absolute w-32 h-32 rounded-full border-4 ${config.borderColor}`}
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)'
          }}
          animate={{
            scale: [1, 8],
            opacity: [0.8, 0]
          }}
          transition={{ duration: 2, ease: "easeOut" }}
        />
      </motion.div>
    </AnimatePresence>
  );
}

// Hook for triggering achievement unlocks
export function useAchievementUnlock() {
  const [currentAchievement, setCurrentAchievement] = useState<Achievement | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [queue, setQueue] = useState<Achievement[]>([]);

  const triggerAchievement = (achievement: Achievement) => {
    if (isVisible) {
      // Add to queue if animation is already playing
      setQueue(prev => [...prev, achievement]);
    } else {
      // Show immediately
      setCurrentAchievement(achievement);
      setIsVisible(true);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    setCurrentAchievement(null);
    
    // Process queue
    setTimeout(() => {
      if (queue.length > 0) {
        const [next, ...rest] = queue;
        setQueue(rest);
        setCurrentAchievement(next);
        setIsVisible(true);
      }
    }, 100);
  };

  const skip = () => {
    handleComplete();
  };

  return {
    currentAchievement,
    isVisible,
    triggerAchievement,
    handleComplete,
    skip,
    AchievementUnlockAnimation: () => (
      <AchievementUnlockAnimation
        achievement={currentAchievement}
        isVisible={isVisible}
        onComplete={handleComplete}
        onSkip={skip}
      />
    )
  };
}

export default AchievementUnlockAnimation;