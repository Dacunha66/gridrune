import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Star, Crown, Sparkles, Gift, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PlayfulCelebrationProps {
  achievement: {
    title: string;
    description: string;
    rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
    reward: {
      gold?: number;
      diamonds?: number;
      xp?: number;
      title?: string;
    };
  } | null;
  isVisible: boolean;
  onComplete: () => void;
}

const rarityEffects = {
  common: {
    colors: ['#9CA3AF', '#D1D5DB'],
    gradient: 'from-gray-400 to-gray-600',
    glow: 'shadow-gray-400/50',
    particles: 30
  },
  uncommon: {
    colors: ['#10B981', '#34D399'],
    gradient: 'from-green-400 to-green-600', 
    glow: 'shadow-green-400/50',
    particles: 50
  },
  rare: {
    colors: ['#3B82F6', '#60A5FA'],
    gradient: 'from-blue-400 to-blue-600',
    glow: 'shadow-blue-400/50', 
    particles: 70
  },
  epic: {
    colors: ['#8B5CF6', '#A78BFA'],
    gradient: 'from-purple-400 to-purple-600',
    glow: 'shadow-purple-400/50',
    particles: 100
  },
  legendary: {
    colors: ['#FFD700', '#FFA500', '#FFFF00'],
    gradient: 'from-yellow-400 to-orange-500',
    glow: 'shadow-yellow-400/50',
    particles: 150
  }
};

export const PlayfulCelebration: React.FC<PlayfulCelebrationProps> = ({ 
  achievement, 
  isVisible, 
  onComplete 
}) => {
  useEffect(() => {
    if (!isVisible || !achievement) return;

    const effects = rarityEffects[achievement.rarity];
    
    // Create multiple confetti bursts
    const celebrateWithConfetti = () => {
      // Initial burst
      confetti({
        particleCount: effects.particles,
        spread: 70,
        origin: { y: 0.6 },
        colors: effects.colors
      });

      // Side bursts
      setTimeout(() => {
        confetti({
          particleCount: effects.particles / 2,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.8 },
          colors: effects.colors
        });
      }, 200);

      setTimeout(() => {
        confetti({
          particleCount: effects.particles / 2,
          angle: 120, 
          spread: 55,
          origin: { x: 1, y: 0.8 },
          colors: effects.colors
        });
      }, 400);

      // Epic finale for legendary
      if (achievement.rarity === 'legendary') {
        setTimeout(() => {
          confetti({
            particleCount: 200,
            spread: 100,
            origin: { y: 0.4 },
            colors: effects.colors,
            gravity: 0.4,
            drift: 0.1,
            shapes: ['star']
          });
        }, 800);
      }
    };

    setTimeout(celebrateWithConfetti, 300);
    
    // Auto-complete after animation
    const timer = setTimeout(onComplete, 4000);
    return () => clearTimeout(timer);
  }, [isVisible, achievement, onComplete]);

  if (!isVisible || !achievement) return null;

  const effects = rarityEffects[achievement.rarity];

  return (
    <motion.div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Animated background */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            'radial-gradient(circle, transparent 20%, rgba(0,0,0,0.8) 100%)',
            `radial-gradient(circle, ${effects.colors[0]}20 20%, rgba(0,0,0,0.8) 100%)`,
            'radial-gradient(circle, transparent 20%, rgba(0,0,0,0.8) 100%)'
          ]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />

      <motion.div
        className="relative bg-gradient-to-br from-slate-800/90 to-slate-900/90 rounded-2xl p-8 max-w-md mx-4 backdrop-blur-sm border border-white/10"
        initial={{ scale: 0, rotate: -10 }}
        animate={{ 
          scale: [0, 1.1, 1],
          rotate: [0, 5, 0]
        }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 20
        }}
      >
        {/* Floating particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-yellow-400 rounded-full"
              initial={{
                x: Math.random() * 400,
                y: Math.random() * 400,
                opacity: 0
              }}
              animate={{
                y: [400, -50],
                opacity: [0, 1, 0],
                scale: [0, 1, 0]
              }}
              transition={{
                duration: 3,
                delay: i * 0.1,
                repeat: Infinity,
                ease: "easeOut"
              }}
            />
          ))}
        </div>

        {/* Header with celebration emoji */}
        <motion.div
          className="text-center mb-6"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <h1 className="text-3xl font-bold text-white mb-2">
            🎉 Achievement Unlocked! 🎉
          </h1>
          <div className={`inline-block px-4 py-2 rounded-full bg-gradient-to-r ${effects.gradient} text-white font-bold text-sm uppercase tracking-wider`}>
            {achievement.rarity}
          </div>
        </motion.div>

        {/* Achievement icon with pulse */}
        <motion.div
          className={`mx-auto mb-6 w-24 h-24 bg-gradient-to-br ${effects.gradient} rounded-full flex items-center justify-center ${effects.glow} shadow-2xl`}
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 360]
          }}
          transition={{
            scale: { duration: 2, repeat: Infinity },
            rotate: { duration: 8, repeat: Infinity, ease: "linear" }
          }}
        >
          <Trophy className="w-12 h-12 text-white" />
          
          {/* Rotating ring for legendary */}
          {achievement.rarity === 'legendary' && (
            <motion.div
              className="absolute inset-0 border-4 border-yellow-300/50 rounded-full"
              animate={{ rotate: -360 }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />
          )}
        </motion.div>

        {/* Achievement details */}
        <motion.div
          className="text-center mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h2 className="text-2xl font-bold text-white mb-2">
            {achievement.title}
          </h2>
          <p className="text-gray-300">
            {achievement.description}
          </p>
        </motion.div>

        {/* Rewards showcase */}
        <motion.div
          className="bg-black/30 rounded-lg p-4 backdrop-blur-sm"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, type: "spring" }}
        >
          <motion.h3 
            className="text-lg font-bold text-white mb-3 flex items-center justify-center"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Gift className="w-5 h-5 mr-2 text-yellow-400" />
            Rewards Earned!
          </motion.h3>
          
          <div className="flex flex-wrap justify-center gap-2">
            {achievement.reward.xp && (
              <motion.div
                className="flex items-center bg-blue-500/20 px-3 py-1 rounded-full border border-blue-400/30"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.2, type: "spring" }}
              >
                <Zap className="w-4 h-4 mr-1 text-blue-300" />
                <span className="text-blue-300 font-bold">+{achievement.reward.xp} XP</span>
              </motion.div>
            )}
            
            {achievement.reward.gold && (
              <motion.div
                className="flex items-center bg-yellow-500/20 px-3 py-1 rounded-full border border-yellow-400/30"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.4, type: "spring" }}
              >
                <span className="text-yellow-300 font-bold text-lg">💰 +{achievement.reward.gold}</span>
              </motion.div>
            )}
            
            {achievement.reward.diamonds && (
              <motion.div
                className="flex items-center bg-cyan-500/20 px-3 py-1 rounded-full border border-cyan-400/30"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.6, type: "spring" }}
              >
                <span className="text-cyan-300 font-bold text-lg">💎 +{achievement.reward.diamonds}</span>
              </motion.div>
            )}
            
            {achievement.reward.title && (
              <motion.div
                className="flex items-center bg-purple-500/20 px-3 py-1 rounded-full border border-purple-400/30"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.8, type: "spring" }}
              >
                <Crown className="w-4 h-4 mr-1 text-purple-300" />
                <span className="text-purple-300 font-bold">{achievement.reward.title}</span>
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* Sparkle effects */}
        <div className="absolute top-4 right-4">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <Star className="w-6 h-6 text-yellow-400" />
          </motion.div>
        </div>
        
        <div className="absolute bottom-4 left-4">
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="w-5 h-5 text-blue-400" />
          </motion.div>
        </div>

        {/* Continue button */}
        <motion.button
          onClick={onComplete}
          className={`w-full mt-6 bg-gradient-to-r ${effects.gradient} hover:opacity-90 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-opacity`}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 2 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Awesome! Continue
        </motion.button>
      </motion.div>
    </motion.div>
  );
};

export default PlayfulCelebration;