import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GameCard, RARITY_CONFIG, Rarity } from "../lib/cardData";
import { cn } from "../lib/utils";
import { CARD_EFFECTS } from "../lib/cardEffects";
import { EffectTooltip } from "./EffectTooltip";
import { ValueTooltip } from "./ValueTooltip";
import { getRarityVisualEffects, generateDynamicGradientCSS, getRarityAnimationKeyframes } from "../lib/rarityGradients";
import { hapticFeedback } from "../lib/hapticFeedback";
import { CardOwnershipAnimation } from "./CardOwnershipAnimation";


// Assuming Player type is defined elsewhere, e.g.:
// type Player = "player1" | "player2" | "neutral";

interface CardProps {
  card: GameCard;
  owner?: "player1" | "player2" | "neutral";
  size?: "tiny" | "small" | "medium" | "large";
  isSelected?: boolean;
  isOnBoard?: boolean;
  originalCard?: GameCard; // For showing O-card effects
  onClick?: () => void;
  onPointerDown?: (event: React.PointerEvent) => void;
  onPointerMove?: (event: React.PointerEvent) => void;
  onPointerUp?: () => void;
  onPointerCancel?: () => void;
  elementBonus?: boolean; // New prop to indicate element bonus
  showEffectBonuses?: boolean; // Show active effect bonuses like shield +1
  shieldBroken?: boolean; // Indicate if shield is broken
  isHovered?: boolean; // Track hover state
  isClickable?: boolean; // Can the card be clicked
  isDisabled?: boolean; // Is the card disabled
  adjacentOwnCards?: number; // Count of adjacent cards of same owner
  adjacentSameElementCards?: number; // Count of adjacent cards of same element
  isOCardOwner?: boolean; // Is this card's owner the O-card owner
  adjacentToOCard?: boolean; // Is this card adjacent to the O-card
  highlightedValue?: string | null; // Which value to highlight for tutorials
  showTooltip?: boolean; // Whether to show tooltips
  isInCollection?: boolean; // Special mode for collection display
  animation?: {
    type: 'attacking' | 'defending' | 'captured' | 'blitzschlag' | 'shield-break' | 'clash' | 'glow' | 'placed' | 'rarity-upgrade' | 'rarity-sparkle' | 'ownership-change';
    startTime: number;
    duration: number;
    damageNumbers?: { value: number; type: 'damage' | 'heal' }[];
    fromRarity?: Rarity;
    toRarity?: Rarity;
    fromOwner?: number;
    toOwner?: number;
    position?: { row: number; col: number };
  };

}

export function Card({
  card,
  owner = "neutral",
  originalCard,
  size = "medium",
  isSelected = false,
  onClick,
  onPointerDown,
  onPointerMove,
  onPointerUp,
  onPointerCancel,
  isOnBoard = false,
  elementBonus = false, // Default value for the new prop
  showEffectBonuses = false,
  shieldBroken = false,
  isHovered = false,
  isClickable = true,
  isDisabled = false,
  adjacentOwnCards = 0,
  adjacentSameElementCards = 0,
  isOCardOwner = false,
  adjacentToOCard = false,
  highlightedValue = null,
  showTooltip = true,
  isInCollection = false,
  animation,

}: CardProps) {
  
  // Early return if card is null/undefined
  if (!card) {
    return <div className="w-20 h-28 bg-slate-800 rounded border border-slate-600 flex items-center justify-center text-slate-400">No Card</div>;
  }
  const [localHovered, setLocalHovered] = useState(false);
  const [localShowTooltip, setLocalShowTooltip] = useState(false);
  
  const isHoveringCard = isHovered || localHovered;
  
  // Helper function to get rarity styling and info
  const getRarityInfo = () => {
    if (!card.rarity) return { 
      name: "Gewöhnlich",
      color: "text-gray-200", 
      emoji: "⚪", 
      borderColor: "border-gray-400",
      bgColor: "bg-gray-600"
    };
    return RARITY_CONFIG[card.rarity];
  };

  const rarityInfo = getRarityInfo();

  const getOwnerColor = () => {
    // Light background tint, main color comes from rarity border
    switch (owner) {
      case "player1":
        return "bg-gradient-to-br from-slate-700/90 to-slate-800/90";
      case "player2":
        return "bg-gradient-to-br from-slate-700/90 to-slate-800/90";
      case "neutral":
        return "bg-gradient-to-br from-slate-700/90 to-slate-800/90";
      default:
        return "bg-gradient-to-br from-slate-700/90 to-slate-800/90";
    }
  };

  const getRarityBorderColor = () => {
    if (!card.rarity) return "#9ca3af"; // gray-400
    
    switch (card.rarity) {
      case "common":
        return "#9ca3af"; // grau - Gewöhnlich
      case "uncommon":
        return "#4ade80"; // grün - Ungewöhnlich  
      case "rare":
        return "#60a5fa"; // blau - Selten
      case "epic":
        return "#a855f7"; // lila - Episch
      case "legendary":
        return "#fbbf24"; // gold - Legendär
      case "ultimate":
        return "#dc2626"; // leuchtend rot - Ultimativ
      default:
        return "#9ca3af"; // grau - default
    }
  };

  // Get dynamic rarity visual effects (disabled during gameplay and for epic cards)
  const showRarityEffects = !isOnBoard; // Only show effects when not on the game board
  const rarityEffects = showRarityEffects && card.rarity && card.rarity !== "epic" ? getRarityVisualEffects(card.rarity) : null;
  
  // Generate dynamic CSS for rarity effects (disabled during gameplay and for epic cards)
  const dynamicCardStyle = showRarityEffects && card.rarity && card.rarity !== "epic" ? generateDynamicGradientCSS(card.rarity, isHoveringCard, isSelected) : '';



  // Get animation class based on animation state
  const getAnimationClass = () => {
    if (!animation) return "";
    
    switch (animation.type) {
      case 'attacking':
        return "card-attacking";
      case 'defending':
        return "card-defending";
      case 'captured':
        return "card-captured";
      case 'blitzschlag':
        return "card-blitzschlag";
      case 'shield-break':
        return "card-shield-break";
      case 'clash':
        return "card-clash";
      case 'glow':
        return "card-glow";
      case 'placed':
        return "card-placed";
      case 'rarity-upgrade':
        return "card-rarity-upgrade";
      case 'rarity-sparkle':
        return "card-rarity-sparkle";
      default:
        return "";
    }
  };

  // Helper function to get element emoji
  const getElementEmoji = (element?: string) => {
    switch (element) {
      case "fire":
        return "🔥";
      case "water":
        return "💧";
      case "earth":
        return "🌍";
      case "lightning":
        return "⚡";
      default:
        return "";
    }
  };



  // Helper function to get effect bonuses for display
  const getEffectBonuses = () => {
    if (!showEffectBonuses || !card.effect) return null;
    
    switch (card.effect) {
      case "schild":
        // Only show shield symbol if not broken (no +1 bonus anymore)
        return !shieldBroken ? { type: "shield" } : null;
      case "anker":
        return { type: "anchor", text: "Nicht angreifbar" };
      case "tarnung":
        return { type: "stealth", text: "Unsichtbar" };
      default:
        return null;
    }
  };

  // Helper function to check if card has damage (values reduced from original)
  const getDamageIndicator = () => {
    if (!originalCard || !showEffectBonuses || !card) return null;
    
    // Check if all required properties exist
    if (typeof card.top !== 'number' || typeof card.right !== 'number' || 
        typeof card.bottom !== 'number' || typeof card.left !== 'number' ||
        typeof originalCard.top !== 'number' || typeof originalCard.right !== 'number' || 
        typeof originalCard.bottom !== 'number' || typeof originalCard.left !== 'number') {
      return null;
    }
    
    const totalDamage = 
      (originalCard.top - card.top) +
      (originalCard.right - card.right) + 
      (originalCard.bottom - card.bottom) +
      (originalCard.left - card.left);
    
    if (totalDamage > 0) {
      return { type: "damage" }; // Only return type, no damage number
    }
    
    return null;
  };

  // Card dimensions in pixels for precise center calculation
  const getCardDimensions = () => {
    if (size === "tiny") return { width: 60, height: 80 }; // extra small for mobile compact layout
    if (size === "small") return { width: 72, height: 100 }; // mobile sizing for 85×110px slots
    if (size === "large" && isOnBoard) {
      // Mobile board cards fill most of the 75px × 108px slot
      return { width: 70, height: 100 }; // almost slot size with small margins
    }
    if (size === "large") return { width: 112, height: 160 }; // w-28 h-40 base size
    return { width: 96, height: 144 }; // medium default
  };
  
  const cardDimensions = getCardDimensions();
  const centerX = cardDimensions.width / 2;  // True mathematical center
  const centerY = cardDimensions.height / 2; // True mathematical center
  
  // Board cards use slot size, hand cards optimized for mobile
  const cardSize = size === "tiny" ? "w-[60px] h-[80px]" :
    size === "small" ? "w-[72px] h-[100px]" : 
    size === "large" && isOnBoard ? "w-[70px] h-[100px] sm:w-28 sm:h-40 md:w-32 md:h-44" : 
    size === "large" ? "w-28 h-40 sm:w-32 sm:h-44 md:w-36 md:h-56" : 
    "w-24 h-36 sm:w-28 sm:h-40 md:w-32 md:h-44";
  

  const textSize = size === "tiny" ? "text-xs" :
    (size === "small" && isOnBoard) ? "text-xs" :
    size === "large" && isOnBoard ? "text-xs" : 
    size === "large" ? "text-sm sm:text-base md:text-lg" : "text-sm sm:text-base";
  
  // Special handling for mobile sizes - all small cards get tiny text for 70x100px fit
  const valueTextSize = size === "tiny" ? "text-[10px]" : // Extra small for tiny cards
    size === "small" ? "text-xs" : 
    size === "large" && isOnBoard ? "text-xs" : "text-sm"; // Small cards get smaller text for compact fit

  // Check if card has O-card effects (values different from original)
  const hasOCardEffects = originalCard && card && 
    typeof card.top === 'number' && typeof card.right === 'number' && 
    typeof card.bottom === 'number' && typeof card.left === 'number' &&
    typeof originalCard.top === 'number' && typeof originalCard.right === 'number' && 
    typeof originalCard.bottom === 'number' && typeof originalCard.left === 'number' && (
    card.top !== originalCard.top ||
    card.right !== originalCard.right ||
    card.bottom !== originalCard.bottom ||
    card.left !== originalCard.left
  );

  // Helper function to get value color and display
  const getValueDisplay = (currentValue: number, originalValue?: number, isShieldBroken?: boolean) => {
    if (!originalValue || currentValue === originalValue) {
      // For shield cards, show green if shield is intact (original has +1 bonus)
      if (showEffectBonuses && card.effect === "schild" && !isShieldBroken) {
        return { value: currentValue, color: "text-green-400", showEffect: false };
      }
      return { value: currentValue, color: "text-white", showEffect: false };
    }

    const difference = currentValue - originalValue;
    if (difference > 0) {
      return {
        value: currentValue,
        color: "text-green-400",
        showEffect: true,
        effectText: `+${difference}`
      };
    } else if (difference < 0) {
      return {
        value: currentValue,
        color: "text-red-400",
        showEffect: true,
        effectText: `${difference}`
      };
    }

    return { value: currentValue, color: "text-white", showEffect: false };
  };

  const effectBonuses = getEffectBonuses();
  const damageIndicator = getDamageIndicator();

  // Safe value display with null checks
  const topDisplay = card && typeof card.top === 'number' ? getValueDisplay(card.top, originalCard?.top, shieldBroken) : { value: 0, color: "text-white", showEffect: false };
  const rightDisplay = card && typeof card.right === 'number' ? getValueDisplay(card.right, originalCard?.right, shieldBroken) : { value: 0, color: "text-white", showEffect: false };
  const bottomDisplay = card && typeof card.bottom === 'number' ? getValueDisplay(card.bottom, originalCard?.bottom, shieldBroken) : { value: 0, color: "text-white", showEffect: false };
  const leftDisplay = card && typeof card.left === 'number' ? getValueDisplay(card.left, originalCard?.left, shieldBroken) : { value: 0, color: "text-white", showEffect: false };




  
  return (
    <div className={cn(
      "relative", 
      "overflow-visible",
      // Add extra padding for collection to accommodate outer values
      size === "small" ? "p-0" : size === "large" && isOnBoard ? "p-1" : isInCollection ? "p-4" : "p-1"
    )}>
      {/* Top Value - Hidden for Rune cards */}
      {!card.isRune && (
        <div 
          className={cn(
            "absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 font-bold z-20 bg-slate-800 rounded transition-all duration-300",
            // Position centered on card border
            isInCollection 
              ? "top-0 px-1 py-0.5 border-2 border-solid" 
              : (size === "tiny" ? "top-0 px-0.5 py-0 border border-solid" :
                 size === "small" ? "top-0 px-1 py-0.5 border-2 border-solid" : "top-0 px-1 py-0.5 border-2 border-solid"),
            valueTextSize,
            topDisplay.color,
            highlightedValue === 'top' && "ring-4 ring-yellow-400 ring-opacity-75 scale-125 bg-yellow-900"
          )}
          style={{ 
            borderColor: getRarityBorderColor()
          }}
        >
        <ValueTooltip
          currentValue={card.top}
          originalValue={originalCard?.top || card.top}
          card={card}
          position="top"
          shieldBroken={shieldBroken}
          elementBonus={elementBonus}
          adjacentOwnCards={adjacentOwnCards}
          adjacentSameElementCards={adjacentSameElementCards}
          isOCardOwner={isOCardOwner}
          adjacentToOCard={adjacentToOCard}
        >
          <span>{topDisplay.value}</span>
        </ValueTooltip>


        </div>
      )}

      {/* Right Value - Hidden for Rune cards */}
      {!card.isRune && (
        <div 
          className={cn(
          "absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-1/2 font-bold z-20 bg-slate-800 rounded transition-all duration-300",
          // Position centered on card border
          isInCollection 
            ? "px-1 py-0.5 border-2 border-solid" 
            : (size === "tiny" ? "px-0.5 py-0 border border-solid" :
               size === "small" ? "px-1 py-0.5 border-2 border-solid" : "px-1 py-0.5 border-2 border-solid"),
          valueTextSize,
          rightDisplay.color,
          highlightedValue === 'right' && "ring-4 ring-yellow-400 ring-opacity-75 scale-125 bg-yellow-900"
        )}
        style={{ 
          borderColor: getRarityBorderColor()
        }}
      >
        <ValueTooltip
          currentValue={card.right}
          originalValue={originalCard?.right || card.right}
          card={card}
          position="right"
          shieldBroken={shieldBroken}
          elementBonus={elementBonus}
          adjacentOwnCards={adjacentOwnCards}
          adjacentSameElementCards={adjacentSameElementCards}
          isOCardOwner={isOCardOwner}
          adjacentToOCard={adjacentToOCard}
        >
          <span>{rightDisplay.value}</span>
        </ValueTooltip>


        </div>
      )}

      {/* Bottom Value - Hidden for Rune cards */}
      {!card.isRune && (
        <div 
          className={cn(
          "absolute left-1/2 bottom-0 transform -translate-x-1/2 translate-y-1/2 font-bold z-20 bg-slate-800 rounded transition-all duration-300",
          // Position centered on card border
          isInCollection 
            ? "px-1 py-0.5 border-2 border-solid" 
            : (size === "tiny" ? "px-0.5 py-0 border border-solid" :
               size === "small" ? "px-1 py-0.5 border-2 border-solid" : "px-1 py-0.5 border-2 border-solid"),
          valueTextSize,
          bottomDisplay.color,
          highlightedValue === 'bottom' && "ring-4 ring-yellow-400 ring-opacity-75 scale-125 bg-yellow-900"
        )}
        style={{ 
          borderColor: getRarityBorderColor()
        }}
      >
        <ValueTooltip
          currentValue={card.bottom}
          originalValue={originalCard?.bottom || card.bottom}
          card={card}
          position="bottom"
          shieldBroken={shieldBroken}
          elementBonus={elementBonus}
          adjacentOwnCards={adjacentOwnCards}
          adjacentSameElementCards={adjacentSameElementCards}
          isOCardOwner={isOCardOwner}
          adjacentToOCard={adjacentToOCard}
        >
          <span>{bottomDisplay.value}</span>
        </ValueTooltip>
        {/* Show shield symbol - positioned left of bottom value - only if shield not broken */}
        {effectBonuses?.type === "shield" && !shieldBroken && (
          <span className="absolute bottom-0 -left-8 text-xs text-green-400 font-bold bg-green-900/90 px-1 rounded border border-green-600 z-10">
            🛡️
          </span>
        )}


        </div>
      )}

      {/* Left Value - Hidden for Rune cards */}
      {!card.isRune && (
        <div 
          className={cn(
          "absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-1/2 font-bold z-20 bg-slate-800 rounded transition-all duration-300",
          // Position centered on card border
          isInCollection 
            ? "px-1 py-0.5 border-2 border-solid" 
            : (size === "tiny" ? "px-0.5 py-0 border border-solid" :
               size === "small" ? "px-1 py-0.5 border-2 border-solid" : "px-1 py-0.5 border-2 border-solid"),
          valueTextSize,
          leftDisplay.color,
          highlightedValue === 'left' && "ring-4 ring-yellow-400 ring-opacity-75 scale-125 bg-yellow-900"
        )}
        style={{ 
          borderColor: getRarityBorderColor()
        }}
      >
        <ValueTooltip
          currentValue={card.left}
          originalValue={originalCard?.left || card.left}
          card={card}
          position="left"
          shieldBroken={shieldBroken}
          elementBonus={elementBonus}
          adjacentOwnCards={adjacentOwnCards}
          adjacentSameElementCards={adjacentSameElementCards}
          isOCardOwner={isOCardOwner}
          adjacentToOCard={adjacentToOCard}
        >
          <span>{leftDisplay.value}</span>
        </ValueTooltip>


        </div>
      )}

      {/* Main Card */}
      <motion.div
        className={cn(
          "game-card relative rounded-lg transition-all duration-200 ease-in-out",
          // Thin borders that fit the exact card size - O-card gets thinner border
          size === "tiny" ? "border-1" :
          size === "small" ? "border-2" : 
          (card.id === "O" && isOnBoard ? "border-1" : 
          (card.rarity === "ultimate" ? "border-8" : "border-4")),
          cardSize,
          owner,
          size,
          getAnimationClass(),
          getOwnerColor(),
          isSelected && "selected ring-4 ring-blue-400 ring-opacity-75",
          isClickable && "clickable",
          isDisabled && "disabled opacity-50",
          !isOnBoard && onClick && "hover:cursor-pointer",
          isOnBoard && "cursor-default on-board",
          card.rarity && !isOnBoard && `rarity-${card.rarity}`,
          rarityEffects && `rarity-${rarityEffects.animation.type}`,
          // Add specific class for small legendary cards
          size === "small" && card.rarity === "legendary" && "small-legendary-card"
        )}
        data-rarity={card.rarity}
        ref={undefined}
        style={{ 
          borderColor: isSelected ? "#3b82f6" : (card.id === "O" && isOnBoard ? "#6b7280" : getRarityBorderColor()), // blue for selected, gray-500 for O-card on board
          background: rarityEffects ? rarityEffects.backgroundGradient.replace('bg-gradient-to-br', 'linear-gradient(135deg,') + ')' : undefined,
          filter: showRarityEffects && card.rarity && card.rarity !== "epic" ? `brightness(${1 + (RARITY_CONFIG[card.rarity].intensity - 1) * 0.1})` : undefined,
          boxShadow: card.rarity === "ultimate" 
            ? (size === "small" 
              ? `0 0 6px ${getRarityBorderColor()}90, 0 0 12px ${getRarityBorderColor()}60, inset 0 0 4px ${getRarityBorderColor()}30`
              : `0 0 20px ${getRarityBorderColor()}80, 0 0 40px ${getRarityBorderColor()}40, inset 0 0 20px ${getRarityBorderColor()}20`)
            : rarityEffects ? (size === "small" 
              ? `0 0 4px ${getRarityBorderColor()}80, 0 0 8px ${getRarityBorderColor()}50`
              : `${rarityEffects.glowEffect}, ${rarityEffects.shadowEffect}`) : 
            (size === "small" ? `0 1px 3px rgba(0, 0, 0, 0.3)` : undefined),
          // Add dynamic pulsing animation for ultimate and legendary cards
          animation: card.rarity === "ultimate" ? "ultimate-pulse 2s ease-in-out infinite" 
            : card.rarity === "legendary" ? "legendary-pulse 2s ease-in-out infinite" 
            : undefined,
          // Force exact dimensions - larger mobile sizing for expanded slots
          ...(size === "small" ? { 
            width: '78px', 
            height: '110px',
            maxWidth: '78px',
            maxHeight: '110px',
            minWidth: '78px',
            minHeight: '110px',
            boxSizing: 'border-box' // Border included in dimensions
          } : {})
        }}
        onClick={!isOnBoard && isClickable && !isDisabled ? () => {
          hapticFeedback.cardHover();
          onClick?.();
        } : undefined}
        onPointerDown={!isOnBoard ? onPointerDown : undefined}
        onPointerMove={!isOnBoard ? onPointerMove : undefined}
        onPointerUp={!isOnBoard ? onPointerUp : undefined}
        onPointerCancel={!isOnBoard ? onPointerCancel : undefined}
        onMouseEnter={() => {
          setLocalHovered(true);
          setLocalShowTooltip(true);
        }}
        onMouseLeave={() => {
          setLocalHovered(false);
          setLocalShowTooltip(false);
        }}
        initial={{ scale: 1, y: 0, rotateY: 0 }}
        animate={{
          scale: isSelected ? (size === "small" ? 1.08 : 1.12) : isHoveringCard ? (size === "small" ? 1.01 : 1.02) : 1,
          y: isSelected ? (size === "small" ? -3 : -5) : isHoveringCard ? (size === "small" ? -0.5 : -1) : 0,
          rotateY: isSelected ? [0, 5, -5, 0] : 0,
          boxShadow: isSelected 
            ? (size === "small" 
              ? `0 6px 20px rgba(59, 130, 246, 0.6), 0 0 15px ${getRarityBorderColor()}60, 0 0 30px rgba(255, 215, 0, 0.3)`
              : `0 12px 40px rgba(59, 130, 246, 0.6), 0 0 25px ${getRarityBorderColor()}60, 0 0 50px rgba(255, 215, 0, 0.3)`)
            : isHoveringCard 
            ? (size === "small"
              ? `0 2px 8px rgba(0, 0, 0, 0.3), 0 0 5px ${getRarityBorderColor()}30`
              : `0 4px 15px rgba(0, 0, 0, 0.3), 0 0 10px ${getRarityBorderColor()}30`)
            : (size === "small" ? `0 1px 4px rgba(0, 0, 0, 0.2)` : `0 2px 8px rgba(0, 0, 0, 0.2)`),
        }}
        whileHover={!isOnBoard ? {
          scale: 1.03,
          y: -3,
          transition: { duration: 0.2 }
        } : {}}
        whileTap={!isOnBoard && isClickable ? {
          scale: 0.98,
          transition: { duration: 0.1 }
        } : {}}
        transition={{
          scale: { duration: 0.3, ease: "easeOut" },
          y: { duration: 0.3, ease: "easeOut" },
          rotateY: isSelected ? { 
            duration: 1.5, 
            ease: "easeInOut",
            repeat: Infinity,
            repeatType: "reverse" as const,
            repeatDelay: 0.5
          } : { duration: 0.3 },
          boxShadow: { duration: 0.3 },
          type: "spring",
          stiffness: 400,
          damping: 25
        }}
      >
        {/* Rarity Particle Effects */}
        {rarityEffects?.particleEffect && (
          <>
            {Array.from({ length: rarityEffects.particleEffect.count }, (_, i) => (
              <div
                key={`particle-${i}`}
                className={`rarity-particle rarity-particle-${(i % 4) + 1}`}
                style={{
                  backgroundColor: rarityEffects.particleEffect!.colors[i % rarityEffects.particleEffect!.colors.length],
                  left: `${20 + (i * 15) % 60}%`,
                  top: `${80 - (i * 10) % 40}%`,
                  animationDuration: `${2 + (i * 0.3)}s`,
                  animationDelay: `${i * 0.5}s`
                }}
              />
            ))}
          </>
        )}

        {/* Damage Numbers */}
        {animation?.damageNumbers?.map((damage, index) => (
          <div 
            key={index}
            className={cn(
              "damage-number",
              damage.type === 'heal' ? "text-green-400" : "text-red-400"
            )}
          >
            {damage.type === 'heal' ? '+' : '-'}{Math.abs(damage.value)}
          </div>
        ))}
        
        {/* Shield Break Particles */}
        {animation?.type === 'shield-break' && (
          <>
            <div className="shield-particle shield-particle-1" style={{ 
              top: '30%', 
              left: '20%', 
              animationDelay: '0ms' 
            }} />
            <div className="shield-particle shield-particle-2" style={{ 
              top: '25%', 
              left: '70%', 
              animationDelay: '100ms' 
            }} />
            <div className="shield-particle shield-particle-3" style={{ 
              top: '60%', 
              left: '15%', 
              animationDelay: '200ms' 
            }} />
            <div className="shield-particle shield-particle-4" style={{ 
              top: '65%', 
              left: '75%', 
              animationDelay: '150ms' 
            }} />
            <div className="shield-particle shield-particle-1" style={{ 
              top: '45%', 
              left: '50%', 
              animationDelay: '250ms' 
            }} />
            <div className="shield-particle shield-particle-2" style={{ 
              top: '80%', 
              left: '40%', 
              animationDelay: '300ms' 
            }} />
          </>
        )}

        {/* Rarity Upgrade Animation */}
        {animation?.type === 'rarity-upgrade' && (
          <>
            {/* Central burst effect */}
            <div className="rarity-upgrade-burst" style={{
              background: `radial-gradient(circle, ${getRarityBorderColor()}, transparent 70%)`
            }} />
            
            {/* Transformation ring */}
            <div className="rarity-upgrade-ring" style={{
              borderColor: getRarityBorderColor()
            }} />
            
            {/* Sparkle particles */}
            {Array.from({ length: 12 }).map((_, i) => (
              <div
                key={i}
                className="rarity-sparkle-particle"
                style={{
                  top: `${20 + Math.sin(i * Math.PI / 6) * 30 + 30}%`,
                  left: `${20 + Math.cos(i * Math.PI / 6) * 30 + 30}%`,
                  animationDelay: `${i * 100}ms`,
                  background: getRarityBorderColor()
                }}
              />
            ))}
            
            {/* Rarity text display */}
            <div className="rarity-upgrade-text">
              <div className="text-white font-bold text-lg drop-shadow-lg">
                {rarityInfo.emoji} {rarityInfo.name}!
              </div>
            </div>
          </>
        )}

        {/* Rarity Sparkle Effect */}
        {animation?.type === 'rarity-sparkle' && (
          <>
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="rarity-ambient-sparkle"
                style={{
                  top: `${10 + Math.random() * 80}%`,
                  left: `${10 + Math.random() * 80}%`,
                  animationDelay: `${i * 200}ms`,
                  background: getRarityBorderColor()
                }}
              />
            ))}
          </>
        )}

        {/* Ownership Change Animation */}
        {animation?.type === 'ownership-change' && animation.fromOwner !== undefined && animation.toOwner !== undefined && (
          <CardOwnershipAnimation
            cardPosition={animation.position || { row: 0, col: 0 }}
            newOwner={animation.toOwner}
            oldOwner={animation.fromOwner}
            onAnimationComplete={() => {
              // Animation completed - handled by parent component
            }}
          />
        )}

        {/* Magical Selection Sparkles */}
        {isSelected && (
          <>
            {Array.from({ length: 12 }).map((_, i) => (
              <motion.div
                key={`sparkle-${i}`}
                className="absolute w-1 h-1 bg-yellow-300 rounded-full pointer-events-none z-30"
                style={{
                  top: `${15 + Math.sin(i * Math.PI / 6) * 35 + 30}%`,
                  left: `${15 + Math.cos(i * Math.PI / 6) * 35 + 30}%`,
                  boxShadow: '0 0 6px currentColor',
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                  scale: [0, 1.5, 0],
                  opacity: [0, 1, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.1,
                  ease: "easeInOut"
                }}
              />
            ))}
            
            {/* Magical energy waves */}
            {Array.from({ length: 3 }).map((_, i) => (
              <motion.div
                key={`wave-${i}`}
                className="absolute inset-0 border-2 border-blue-400 rounded-lg pointer-events-none opacity-30"
                style={{
                  borderColor: getRarityBorderColor(),
                }}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{
                  scale: [0.8, 1.3, 0.8],
                  opacity: [0, 0.6, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.7,
                  ease: "easeInOut"
                }}
              />
            ))}

            {/* Central magical glow */}
            <motion.div
              className="absolute inset-0 rounded-lg pointer-events-none"
              style={{
                background: `radial-gradient(circle at center, ${getRarityBorderColor()}20, transparent 70%)`,
              }}
              initial={{ opacity: 0 }}
              animate={{
                opacity: [0, 0.8, 0],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </>
        )}


        {/* Element icon */}
        {card.element && (
          <div className={cn(
            "absolute top-1 right-1 z-20 drop-shadow-lg",
            size === "tiny" ? "text-sm" : "text-lg"
          )}>
            {getElementEmoji(card.element)}
          </div>
        )}

        {/* Effect icon - hide for Rune cards since they have their own effect display */}
        {card.effect && !card.isRune && (
          <div className="absolute top-1 left-1 z-30 overflow-visible pointer-events-auto">
            <EffectTooltip effect={card.effect}>
              <div className={cn(
                size === "tiny" ? "text-sm" : "text-lg",
                "drop-shadow-lg cursor-help hover:scale-110 transition-transform",
                CARD_EFFECTS[card.effect].color
              )}>
                {CARD_EFFECTS[card.effect].symbol}
              </div>
            </EffectTooltip>
          </div>
        )}

        {/* Rarity glow effect - disabled for Rune cards to show background image */}
        {card.rarity && !card.isRune && (
          <div className={cn(
            "absolute inset-0 rounded-lg opacity-30 pointer-events-none",
            rarityInfo.bgColor
          )} />
        )}

        {/* Background image or gradient - moved to z-10 to be visible but below overlays */}
        {card.image ? (
          card.isRune ? (
            // Use actual img element for Rune cards
            <img
              src={card.image}
              alt={card.name}
              className="absolute inset-0 w-full h-full object-cover rounded-lg z-10"
              style={{
                // Ensure proper scaling for small mobile cards
                objectFit: 'cover'
              }}
            />
          ) : (
            // Keep background-image for regular cards
            <div
              className="absolute inset-0 rounded-lg z-10 opacity-60"
              style={{ 
                backgroundImage: `url(${card.image})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
                // Force full container size for mobile cards
                ...(size === "small" ? { 
                  width: '100%', 
                  height: '100%'
                } : {})
              }}
            />
          )
        ) : (
          <div className={cn(
            "absolute inset-0 rounded-lg opacity-60 z-10",
            // Themed backgrounds based on card name
            card.name?.includes("Storm") && "bg-gradient-to-br from-purple-600 via-blue-700 to-gray-800",
            card.name?.includes("Mountain") && "bg-gradient-to-br from-amber-700 via-orange-800 to-red-900",
            card.name?.includes("Ocean") && "bg-gradient-to-br from-blue-400 via-cyan-600 to-blue-900",
            card.name?.includes("Desert") && "bg-gradient-to-br from-yellow-600 via-orange-700 to-red-800",
            card.name?.includes("Sky") && "bg-gradient-to-br from-blue-300 via-purple-500 to-indigo-800",
            card.name?.includes("Flame") && "bg-gradient-to-br from-red-500 via-orange-600 to-yellow-700",
            // Default fallback
            (!card.name || (!card.name.includes("Storm") && !card.name.includes("Mountain") &&
             !card.name.includes("Ocean") && !card.name.includes("Desert") &&
             !card.name.includes("Sky") && !card.name.includes("Flame"))) && "bg-gradient-to-br from-slate-700 to-slate-900"
          )} />
        )}

        {/* Rune Card Overlays - positioned on the card itself */}
        {card.isRune && (
          <>
            {/* Effect symbol - top left with tooltip */}
            <div className="absolute top-1 left-1 z-30 overflow-visible pointer-events-auto">
              <EffectTooltip effect={card.effect!}>
                <div className={cn(
                  "text-sm drop-shadow-lg cursor-help hover:scale-110 transition-transform bg-slate-900/90 px-1.5 py-1 rounded border border-purple-400",
                  CARD_EFFECTS[card.effect!].color
                )}>
                  {CARD_EFFECTS[card.effect!]?.symbol || "🎭"}
                </div>
              </EffectTooltip>
            </div>
            
            {/* Card name - bottom center */}
            <div className="absolute bottom-1 left-1 right-1 z-20">
              <div className="text-[10px] sm:text-xs font-bold text-white text-center bg-slate-900 px-2 py-1 rounded border border-purple-400 drop-shadow-lg shadow-lg">
                {card.name}
              </div>
            </div>
          </>
        )}

        {/* Regular Card Name/ID positioned above bottom value - only for non-Rune cards */}
        {!card.isRune && (
          <div className={cn(
            "absolute inset-x-0 flex items-center justify-center p-1 z-5",
            // Position with small gap from bottom value
            size === "tiny" ? "bottom-2" :
            size === "small" ? "bottom-3" : "bottom-4",
            // Special positioning for O-card on mobile - move to center
            card.id === "O" && isOnBoard && "bottom-0 top-0"
          )}>
            <div className="text-center">
              {card.name && (
                <div className={cn(
                  "font-bold rounded border-2 shadow-lg bg-slate-900 text-white",
                  // Smaller text for mobile cards
                  size === "tiny" ? "text-[7px] px-0.5 py-0" :
                  size === "small" ? "text-[8px] px-1 py-0.5" : "text-[10px] sm:text-xs px-2 py-1",
                  rarityInfo.borderColor
                )}
                style={{ textShadow: '2px 2px 4px rgba(0,0,0,1)' }}>
                  {card.name}
                </div>
              )}
              {!card.name && !card.image && (
                <span className={cn(
                  "text-white font-semibold bg-slate-900 rounded",
                  // Special sizing for O-card on mobile board - much smaller
                  card.id === "O" && isOnBoard 
                    ? "text-xs px-0.5 py-0 w-4 h-4 flex items-center justify-center" 
                    : "text-[10px] sm:text-xs px-2 py-1"
                )}>
                  {card.id}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Damage indicator for cards hit by effects like Blitzschlag */}
        {damageIndicator && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-30">
            <div className="bg-red-600 text-white font-bold px-2 py-1 rounded-full text-xs border-2 border-red-800 shadow-lg animate-pulse">
              🗲
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}