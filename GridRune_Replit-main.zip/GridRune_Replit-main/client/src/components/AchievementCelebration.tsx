import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Star, Crown, Zap, Award, Sparkles, Gift } from 'lucide-react';
import { Button } from './ui/button';
import confetti from 'canvas-confetti';

interface Achievement {
  id: string;
  title: string;
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  icon: React.ReactNode;
  reward: {
    gold?: number;
    diamonds?: number;
    cards?: number;
    title?: string;
  };
}

interface AchievementCelebrationProps {
  achievement: Achievement | null;
  isVisible: boolean;
  onClose: () => void;
}

const rarityConfig = {
  common: {
    color: 'from-gray-400 to-gray-600',
    glow: 'shadow-gray-400/50',
    particles: '#9CA3AF',
    confettiColors: ['#9CA3AF', '#D1D5DB']
  },
  uncommon: {
    color: 'from-green-400 to-green-600',
    glow: 'shadow-green-400/50',
    particles: '#10B981',
    confettiColors: ['#10B981', '#34D399']
  },
  rare: {
    color: 'from-blue-400 to-blue-600',
    glow: 'shadow-blue-400/50',
    particles: '#3B82F6',
    confettiColors: ['#3B82F6', '#60A5FA']
  },
  epic: {
    color: 'from-purple-400 to-purple-600',
    glow: 'shadow-purple-400/50',
    particles: '#8B5CF6',
    confettiColors: ['#8B5CF6', '#A78BFA']
  },
  legendary: {
    color: 'from-yellow-400 to-orange-500',
    glow: 'shadow-yellow-400/50',
    particles: '#F59E0B',
    confettiColors: ['#F59E0B', '#FBBF24', '#FCD34D']
  }
};

const FloatingParticle: React.FC<{ color: string; delay: number; duration: number }> = ({ color, delay, duration }) => (
  <motion.div
    className="absolute w-2 h-2 rounded-full"
    style={{ backgroundColor: color }}
    initial={{ 
      x: Math.random() * 400 - 200, 
      y: Math.random() * 400 - 200, 
      opacity: 0,
      scale: 0
    }}
    animate={{ 
      x: Math.random() * 600 - 300,
      y: Math.random() * 600 - 300,
      opacity: [0, 1, 0],
      scale: [0, 1.5, 0],
      rotate: 360
    }}
    transition={{
      duration,
      delay,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  />
);

const SparkleEffect: React.FC<{ rarity: string }> = ({ rarity }) => {
  const config = rarityConfig[rarity as keyof typeof rarityConfig];
  
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {[...Array(20)].map((_, i) => (
        <FloatingParticle
          key={i}
          color={config.particles}
          delay={i * 0.1}
          duration={3 + Math.random() * 2}
        />
      ))}
      
      {/* Sparkle bursts */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`sparkle-${i}`}
          className="absolute"
          style={{
            left: `${20 + (i * 10)}%`,
            top: `${30 + Math.sin(i) * 20}%`
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ 
            scale: [0, 1.5, 0],
            opacity: [0, 1, 0],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 2,
            delay: i * 0.2,
            repeat: Infinity,
            repeatDelay: 1
          }}
        >
          <Sparkles className="w-4 h-4 text-white" />
        </motion.div>
      ))}
    </div>
  );
};

const RewardDisplay: React.FC<{ reward: Achievement['reward'] }> = ({ reward }) => (
  <motion.div
    className="bg-black/30 rounded-lg p-4 backdrop-blur-sm"
    initial={{ y: 20, opacity: 0 }}
    animate={{ y: 0, opacity: 1 }}
    transition={{ delay: 1.5, duration: 0.5 }}
  >
    <h4 className="text-lg font-bold text-white mb-2 flex items-center">
      <Gift className="w-5 h-5 mr-2 text-yellow-400" />
      Belohnungen erhalten:
    </h4>
    <div className="flex flex-wrap gap-3">
      {reward.gold && (
        <motion.div
          className="flex items-center bg-yellow-500/20 px-3 py-1 rounded-full"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 1.8, type: "spring" }}
        >
          <span className="text-yellow-400 font-bold">+{reward.gold} Gold</span>
        </motion.div>
      )}
      {reward.diamonds && (
        <motion.div
          className="flex items-center bg-blue-500/20 px-3 py-1 rounded-full"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 2.0, type: "spring" }}
        >
          <span className="text-blue-400 font-bold">+{reward.diamonds} Diamanten</span>
        </motion.div>
      )}
      {reward.cards && (
        <motion.div
          className="flex items-center bg-purple-500/20 px-3 py-1 rounded-full"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 2.2, type: "spring" }}
        >
          <span className="text-purple-400 font-bold">+{reward.cards} Karten</span>
        </motion.div>
      )}
      {reward.title && (
        <motion.div
          className="flex items-center bg-orange-500/20 px-3 py-1 rounded-full"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 2.4, type: "spring" }}
        >
          <Crown className="w-4 h-4 mr-1 text-orange-400" />
          <span className="text-orange-400 font-bold">Titel: {reward.title}</span>
        </motion.div>
      )}
    </div>
  </motion.div>
);

export const AchievementCelebration: React.FC<AchievementCelebrationProps> = ({
  achievement,
  isVisible,
  onClose
}) => {
  const [showRewards, setShowRewards] = useState(false);

  useEffect(() => {
    if (isVisible && achievement) {
      // Trigger confetti based on rarity
      const config = rarityConfig[achievement.rarity];
      
      // Multiple confetti bursts
      const burst1 = () => confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: config.confettiColors
      });
      
      const burst2 = () => confetti({
        particleCount: 50,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.8 },
        colors: config.confettiColors
      });
      
      const burst3 = () => confetti({
        particleCount: 50,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.8 },
        colors: config.confettiColors
      });

      // Staggered confetti bursts
      burst1();
      setTimeout(burst2, 200);
      setTimeout(burst3, 400);
      
      // For legendary achievements, add extra celebration
      if (achievement.rarity === 'legendary') {
        setTimeout(() => {
          confetti({
            particleCount: 200,
            spread: 90,
            origin: { y: 0.4 },
            colors: config.confettiColors,
            gravity: 0.5,
            drift: 0.1
          });
        }, 600);
      }

      // Show rewards after initial animation
      setTimeout(() => setShowRewards(true), 1500);
    }
  }, [isVisible, achievement]);

  if (!achievement) return null;

  const config = rarityConfig[achievement.rarity];

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-8 max-w-md w-full border-4"
            style={{ borderImage: `linear-gradient(135deg, ${config.color.split(' ')[1]}, ${config.color.split(' ')[3]}) 1` }}
            initial={{ scale: 0, rotate: -10 }}
            animate={{ 
              scale: [0, 1.1, 1],
              rotate: [0, 5, 0]
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ 
              type: "spring",
              stiffness: 200,
              damping: 20
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Background glow effect */}
            <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${config.color} opacity-20 blur-xl`} />
            
            {/* Particle effects */}
            <SparkleEffect rarity={achievement.rarity} />
            
            {/* Achievement content */}
            <div className="relative z-10 text-center">
              {/* Header */}
              <motion.div
                initial={{ y: -20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-yellow-400 mb-2">
                  🎉 Erfolg Freigeschaltet! 🎉
                </h2>
                <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4 bg-gradient-to-r ${config.color} text-white`}>
                  {achievement.rarity}
                </div>
              </motion.div>

              {/* Achievement icon */}
              <motion.div
                className={`mx-auto mb-4 w-20 h-20 bg-gradient-to-br ${config.color} rounded-full flex items-center justify-center text-4xl shadow-2xl ${config.glow}`}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ 
                  scale: [0, 1.3, 1],
                  rotate: [0, 360, 0]
                }}
                transition={{ 
                  delay: 0.5,
                  duration: 1,
                  type: "spring"
                }}
              >
                {achievement.icon || <Trophy className="w-10 h-10 text-white" />}
              </motion.div>

              {/* Achievement details */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                <h3 className="text-xl font-bold text-white mb-2">
                  {achievement.title}
                </h3>
                <p className="text-gray-300 mb-6">
                  {achievement.description}
                </p>
              </motion.div>

              {/* Rewards */}
              <AnimatePresence>
                {showRewards && (
                  <RewardDisplay reward={achievement.reward} />
                )}
              </AnimatePresence>

              {/* Close button */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 2.5 }}
                className="mt-6"
              >
                <Button
                  onClick={onClose}
                  className={`bg-gradient-to-r ${config.color} hover:opacity-90 text-white font-bold px-8 py-2 shadow-lg`}
                >
                  Fantastisch!
                </Button>
              </motion.div>
            </div>

            {/* Corner decorations */}
            <div className="absolute top-2 right-2">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              >
                <Star className="w-6 h-6 text-yellow-400" />
              </motion.div>
            </div>
            <div className="absolute bottom-2 left-2">
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              >
                <Zap className="w-5 h-5 text-blue-400" />
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AchievementCelebration;