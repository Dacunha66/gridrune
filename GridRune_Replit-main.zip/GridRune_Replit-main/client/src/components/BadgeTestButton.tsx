import React from 'react';
import { useBadges } from '../lib/stores/useBadges';
import { dispatchBadgeEvent } from './BadgeIntegrationHelper';

/**
 * Development component to test badge functionality
 */
export function BadgeTestButton() {
  const { updatePlayerStats, playerStats, unlockBadge } = useBadges();

  const testBadgeUnlock = () => {
    // Test unlocking first victory badge
    unlockBadge('first-victory');
    console.log('Badge unlocked: first-victory');
  };

  const testStatUpdate = () => {
    // Simulate a game win
    updatePlayerStats({
      totalGames: playerStats.totalGames + 1,
      totalWins: playerStats.totalWins + 1,
      currentWinStreak: playerStats.currentWinStreak + 1,
      longestWinStreak: Math.max(playerStats.longestWinStreak, playerStats.currentWinStreak + 1)
    });
    console.log('Stats updated - triggering badge checks');
  };

  const testCardCollection = () => {
    // Simulate collecting a legendary card
    dispatchBadgeEvent.cardCollected('legendary');
    console.log('Legendary card collected event dispatched');
  };

  const testDeckCreation = () => {
    // Simulate deck creation
    dispatchBadgeEvent.deckCreated();
    console.log('Deck created event dispatched');
  };

  if (process.env.NODE_ENV !== 'development') {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 bg-slate-800 p-4 rounded-lg border border-slate-600 z-50">
      <h3 className="text-white font-bold mb-2">Badge Testing</h3>
      <div className="space-y-2">
        <button
          onClick={testBadgeUnlock}
          className="block w-full px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
        >
          Unlock First Victory
        </button>
        <button
          onClick={testStatUpdate}
          className="block w-full px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
        >
          Simulate Game Win
        </button>
        <button
          onClick={testCardCollection}
          className="block w-full px-3 py-1 bg-purple-600 text-white rounded text-sm hover:bg-purple-700"
        >
          Collect Legendary Card
        </button>
        <button
          onClick={testDeckCreation}
          className="block w-full px-3 py-1 bg-orange-600 text-white rounded text-sm hover:bg-orange-700"
        >
          Create Deck
        </button>
      </div>
      <div className="mt-2 text-xs text-gray-400">
        <div>Games: {playerStats.totalGames}</div>
        <div>Wins: {playerStats.totalWins}</div>
        <div>Streak: {playerStats.currentWinStreak}</div>
      </div>
    </div>
  );
}