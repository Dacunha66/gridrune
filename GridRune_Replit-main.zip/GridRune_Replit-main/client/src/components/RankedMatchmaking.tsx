import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, Trophy, Star, Crown, Clock, Users, Zap } from 'lucide-react';
import { RANK_TIERS, getRankByPoints, type RankTier } from '../../../shared/ranking';

interface RankedMatchmakingProps {
  onStartMatch: (matchData: any) => void;
  onBack: () => void;
  currentUser: {
    id: string;
    username: string;
    rankedPoints: number;
    currentRank: string;
    seasonWins: number;
    seasonLosses: number;
    winStreak: number;
  };
}

export function RankedMatchmaking({ onStartMatch, onBack, currentUser }: RankedMatchmakingProps) {
  const [isSearching, setIsSearching] = useState(false);
  const [searchTime, setSearchTime] = useState(0);
  const [estimatedWaitTime, setEstimatedWaitTime] = useState(30);
  const [matchFound, setMatchFound] = useState(false);

  const currentRankData = getRankByPoints(currentUser.rankedPoints);
  const winRate = currentUser.seasonWins + currentUser.seasonLosses > 0 
    ? Math.round((currentUser.seasonWins / (currentUser.seasonWins + currentUser.seasonLosses)) * 100)
    : 0;

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSearching && !matchFound) {
      interval = setInterval(() => {
        setSearchTime(prev => prev + 1);
        // Simulate dynamic wait time estimation
        if (searchTime > 60) {
          setEstimatedWaitTime(prev => Math.max(10, prev - 5));
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isSearching, matchFound, searchTime]);

  const startMatchmaking = async () => {
    setIsSearching(true);
    setSearchTime(0);
    
    // Simulate matchmaking process
    setTimeout(() => {
      setMatchFound(true);
      setTimeout(() => {
        onStartMatch({
          gameMode: 'ranked',
          boardSize: '4x4',
          opponent: {
            id: 'ai_ranked',
            username: 'Herausforderer',
            rankedPoints: currentUser.rankedPoints + Math.floor(Math.random() * 200 - 100)
          }
        });
      }, 2000);
    }, Math.random() * 20000 + 10000); // 10-30 seconds
  };

  const cancelMatchmaking = () => {
    setIsSearching(false);
    setMatchFound(false);
    setSearchTime(0);
    setEstimatedWaitTime(30);
    // Return to main menu
    onBack();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getRankIcon = (rank: RankTier) => {
    const baseClasses = "w-8 h-8";
    switch (true) {
      case rank.minPoints >= 3000: return <Crown className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 2500: return <Star className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 2000: return <Trophy className={baseClasses} style={{ color: rank.color }} />;
      case rank.minPoints >= 1000: return <Swords className={baseClasses} style={{ color: rank.color }} />;
      default: return <span className={baseClasses} style={{ color: rank.color }}>⚔️</span>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <motion.h1 
            className="text-5xl font-bold mb-4 bg-gradient-to-r from-amber-800 to-orange-700 bg-clip-text text-transparent"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            🏆 Ranglistenspiel
          </motion.h1>
          <p className="text-amber-700 text-lg">
            Kämpfe um Rangpunkte und steige in den Rängen auf!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Player Rank Card */}
          <motion.div
            className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border-2 shadow-xl"
            style={{ borderColor: currentRankData.color }}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="text-center mb-6">
              <div className="flex items-center justify-center mb-4">
                {getRankIcon(currentRankData)}
                <span className="text-3xl ml-3">{currentRankData.emoji}</span>
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: currentRankData.color }}>
                {currentRankData.name}
              </h2>
              <div className="text-lg font-semibold text-gray-700">
                {currentUser.rankedPoints} Punkte
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>{currentRankData.minPoints}</span>
                <span>{currentRankData.maxPoints === 999999 ? '∞' : currentRankData.maxPoints}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <motion.div
                  className="h-3 rounded-full"
                  style={{ backgroundColor: currentRankData.color }}
                  initial={{ width: 0 }}
                  animate={{ 
                    width: currentRankData.maxPoints === 999999 ? '100%' : 
                          `${Math.min(100, ((currentUser.rankedPoints - currentRankData.minPoints) / 
                          (currentRankData.maxPoints - currentRankData.minPoints)) * 100)}%`
                  }}
                  transition={{ duration: 1, ease: "easeOut" }}
                />
              </div>
            </div>

            {/* Season Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-green-100 rounded-lg">
                <div className="text-2xl font-bold text-green-700">{currentUser.seasonWins}</div>
                <div className="text-sm text-green-600">Siege</div>
              </div>
              <div className="text-center p-3 bg-red-100 rounded-lg">
                <div className="text-2xl font-bold text-red-700">{currentUser.seasonLosses}</div>
                <div className="text-sm text-red-600">Niederlagen</div>
              </div>
              <div className="text-center p-3 bg-blue-100 rounded-lg">
                <div className="text-2xl font-bold text-blue-700">{winRate}%</div>
                <div className="text-sm text-blue-600">Siegesrate</div>
              </div>
              <div className="text-center p-3 bg-orange-100 rounded-lg">
                <div className="text-2xl font-bold text-orange-700">{currentUser.winStreak}</div>
                <div className="text-sm text-orange-600">Serie</div>
              </div>
            </div>
          </motion.div>

          {/* Matchmaking Control */}
          <motion.div
            className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border-2 border-amber-300 shadow-xl"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h3 className="text-2xl font-bold text-amber-800 mb-6 text-center">
              🎯 Gegner suchen
            </h3>

            <AnimatePresence mode="wait">
              {!isSearching && !matchFound && (
                <motion.div
                  key="ready"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center"
                >
                  <div className="mb-6">
                    <div className="flex items-center justify-center mb-4">
                      <Users className="w-8 h-8 text-amber-600 mr-3" />
                      <span className="text-lg text-gray-700">Bereit für das Ranglistenspiel?</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">
                      Spiele auf dem 4x4 Spielfeld gegen Gegner deines Rangs
                    </p>
                    <div className="bg-amber-100 p-4 rounded-lg mb-6">
                      <h4 className="font-semibold text-amber-800 mb-2">Belohnungen:</h4>
                      <div className="text-sm text-amber-700">
                        <p>🏆 Sieg: +{25} Rangpunkte</p>
                        <p>💔 Niederlage: -{20} Rangpunkte</p>
                        <p>⭐ Bonus gegen höhere Ränge!</p>
                      </div>
                    </div>
                  </div>

                  <motion.button
                    onClick={startMatchmaking}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:from-green-600 hover:to-emerald-700 transition-all duration-200 flex items-center justify-center"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Swords className="w-6 h-6 mr-3" />
                    Match suchen
                  </motion.button>
                </motion.div>
              )}

              {isSearching && !matchFound && (
                <motion.div
                  key="searching"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center"
                >
                  <div className="mb-6">
                    <motion.div
                      className="w-16 h-16 border-4 border-blue-300 border-t-blue-600 rounded-full mx-auto mb-4"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    <h4 className="text-xl font-bold text-blue-700 mb-2">Gegner wird gesucht...</h4>
                    <div className="flex items-center justify-center text-gray-600 mb-4">
                      <Clock className="w-5 h-5 mr-2" />
                      <span>Zeit: {formatTime(searchTime)}</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      Geschätzte Wartezeit: ~{estimatedWaitTime}s
                    </div>
                  </div>

                  <motion.button
                    onClick={cancelMatchmaking}
                    className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:from-red-600 hover:to-red-700 transition-all duration-200"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Suche abbrechen
                  </motion.button>
                </motion.div>
              )}

              {matchFound && (
                <motion.div
                  key="found"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center"
                >
                  <motion.div
                    className="text-6xl mb-4"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  >
                    ⚔️
                  </motion.div>
                  <h4 className="text-2xl font-bold text-green-700 mb-2">Match gefunden!</h4>
                  <div className="bg-green-100 p-4 rounded-lg mb-4">
                    <p className="text-green-800 font-semibold">Gegner gefunden</p>
                    <p className="text-sm text-green-700">Das Spiel startet gleich...</p>
                  </div>
                  <motion.div
                    className="w-full bg-green-200 rounded-full h-2"
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 2 }}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Rank Ladder Preview */}
        <motion.div
          className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border-2 border-amber-300 shadow-xl"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-2xl font-bold text-amber-800 mb-6 text-center">
            🏆 Rangübersicht
          </h3>
          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-96 overflow-y-auto">
            {RANK_TIERS.slice().reverse().map((rank, index) => (
              <motion.div
                key={rank.id}
                className={`p-3 rounded-lg border-2 ${
                  rank.id === currentRankData.id 
                    ? 'border-yellow-400 bg-yellow-50 shadow-lg' 
                    : 'border-gray-200 bg-gray-50'
                }`}
                whileHover={{ scale: 1.05, y: -2 }}
                transition={{ duration: 0.2 }}
              >
                <div className="text-center">
                  <div className="text-2xl mb-1">{rank.emoji}</div>
                  <h4 className="font-bold text-sm mb-1" style={{ color: rank.color }}>
                    {rank.name}
                  </h4>
                  <p className="text-xs text-gray-600">
                    {rank.minPoints} - {rank.maxPoints === 999999 ? '∞' : rank.maxPoints}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Back Button */}
        <motion.div
          className="text-center mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <button
            onClick={onBack}
            className="bg-gray-600 text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:bg-gray-700 transition-all duration-200"
          >
            Zurück zum Hauptmenü
          </button>
        </motion.div>
      </div>
    </div>
  );
}