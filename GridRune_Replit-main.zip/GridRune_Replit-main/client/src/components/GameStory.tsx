import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { useCardGame } from '../lib/stores/useCardGame';
import { ArrowLeft, ArrowRight, BookOpen, Sparkles } from 'lucide-react';

interface StoryChapter {
  id: string;
  title: string;
  content: string[];
  image?: string;
}

const STORY_CHAPTERS: StoryChapter[] = [
  {
    id: 'prologue',
    title: 'Der Beginn',
    content: [
      'In den mystischen Landen von GridRune existieren mächtige Karten, die die Essenz der Elemente in sich tragen.',
      'Jede Karte besitzt einzigartige Kräfte - Feuer brennt mit unbändiger Macht, Wasser fließt mit heilender Energie, und die Erde steht fest wie ein unerschütterlicher Fels.',
      'Legendäre Kartenmeister kämpfen um die Kontrolle über diese magischen Artefakte, denn wer sie beherrscht, kontrolliert das Schicksal der Welt.'
    ]
  },
  {
    id: 'elements',
    title: 'Die Vier Elemente',
    content: [
      'Das Feuer-Element 🔥 verleiht Karten explosive Angriffskraft. Feuerkarten sind bekannt für ihre aggressive Natur und können gegnerische Verteidigungen durchbrechen.',
      'Das Wasser-Element 🌊 bringt Heilung und Schutz. Wasserkarten können Schäden absorbieren und verbündete Karten stärken.',
      'Das Erd-Element 🌍 steht für Stabilität und Ausdauer. Erdkarten haben hohe Verteidigungswerte und können lange im Kampf bestehen.',
      'Das Luft-Element 💨 symbolisiert Geschwindigkeit und Wendigkeit. Luftkarten können schnell ihre Position ändern und überraschende Angriffe ausführen.'
    ]
  },
  {
    id: 'rarities',
    title: 'Die Seltenheit der Macht',
    content: [
      'Gewöhnliche Karten (Grau) sind die Grundlage jeder Sammlung. Sie mögen einfach erscheinen, aber in den richtigen Händen können sie den Unterschied ausmachen.',
      'Ungewöhnliche Karten (Grün) besitzen bereits merkbare magische Energie und bieten taktische Vorteile.',
      'Seltene Karten (Blau) sind mit starker Magie durchdrungen und können das Schlachtenblatt wenden.',
      'Epische Karten (Lila) pulsieren vor magischer Kraft und besitzen mächtige Spezialfähigkeiten.',
      'Legendäre Karten (Gold) sind die seltensten Artefakte - jede einzelne kann ganze Armeen besiegen und Königreiche erschüttern.'
    ]
  },
  {
    id: 'battle',
    title: 'Die Kunst des Kampfes',
    content: [
      'Auf dem heiligen Schlachtfeld von GridRune treffen die Kartenmeister aufeinander. Das mystische 3x3 oder 4x4 Gitter erwacht zum Leben.',
      'Jede Karte kämpft mit vier Richtungswerten - Nord, Süd, Ost und West. Die Kunst liegt darin, die Schwächen des Gegners zu erkennen und auszunutzen.',
      'Wenn eine Karte mit höherem Wert eine gegnerische Karte angreift, wechselt diese die Seiten - ein Zeichen der Unterwerfung vor der überlegenen Macht.',
      'In der Mitte des Schlachtfeldes liegt die mächtige O-Karte - wer sie kontrolliert, erhält einen entscheidenden Vorteil für alle benachbarten Karten.'
    ]
  },
  {
    id: 'effects',
    title: 'Magische Kräfte',
    content: [
      'Einige Karten besitzen mystische Fähigkeiten, die über den normalen Kampf hinausgehen:',
      'Schild 🛡️ - Ein schimmernder Schutz, der den ersten Angriff vollständig abwehrt.',
      'Blitzschlag ⚡ - Eine verheerende Kraft, die Schilde durchbricht und pure Zerstörung bringt.',
      'Drehung 🔄 - Eine wirbelnde Energie, die alle Karten am Ende jedes Zuges im Uhrzeigersinn rotiert.',
      'Diese Kräfte können das Schicksal einer Schlacht in einem einzigen Moment wenden.'
    ]
  },
  {
    id: 'destiny',
    title: 'Dein Schicksal',
    content: [
      'Nun, junger Kartenmeister, liegt es an dir, dein eigenes Vermächtnis zu schmieden.',
      'Sammle die mächtigsten Karten, meistere ihre Geheimnisse und stelle dich anderen Meistern im Kampf.',
      'Tausche mit anderen Sammlern, um die perfekte Sammlung zu erschaffen.',
      'Das Schicksal von GridRune liegt in deinen Händen. Wirst du zum legendären Kartenmeister aufsteigen?'
    ]
  }
];

export function GameStory() {
  const [currentChapter, setCurrentChapter] = useState(0);
  const { setGamePhase } = useCardGame();

  const nextChapter = () => {
    if (currentChapter < STORY_CHAPTERS.length - 1) {
      setCurrentChapter(currentChapter + 1);
    }
  };

  const prevChapter = () => {
    if (currentChapter > 0) {
      setCurrentChapter(currentChapter - 1);
    }
  };

  const currentStory = STORY_CHAPTERS[currentChapter];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-between mb-4">
            <Button
              onClick={() => setGamePhase("menu")}
              variant="outline"
              className="text-white border-gray-600 hover:bg-gray-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Zurück zum Menü
            </Button>
            <div className="flex items-center gap-2 text-purple-300">
              <BookOpen className="w-5 h-5" />
              <span>{currentChapter + 1} / {STORY_CHAPTERS.length}</span>
            </div>
          </div>
          <motion.h1 
            className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 bg-clip-text text-transparent"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
Die Geschichte von GridRune
          </motion.h1>
        </div>

        {/* Story Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentChapter}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-gray-900/80 backdrop-blur-sm border-purple-500/30 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-2xl text-center text-purple-300 flex items-center justify-center gap-2">
                  <Sparkles className="w-6 h-6" />
                  {currentStory.title}
                  <Sparkles className="w-6 h-6" />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {currentStory.content.map((paragraph, index) => (
                  <motion.p
                    key={index}
                    className="text-gray-200 text-lg leading-relaxed text-center"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.2 }}
                  >
                    {paragraph}
                  </motion.p>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            onClick={prevChapter}
            disabled={currentChapter === 0}
            variant="outline"
            className="text-white border-purple-500 hover:bg-purple-700 disabled:opacity-50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vorheriges Kapitel
          </Button>

          {/* Chapter indicators */}
          <div className="flex gap-2">
            {STORY_CHAPTERS.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentChapter(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentChapter
                    ? 'bg-purple-400'
                    : index < currentChapter
                    ? 'bg-purple-600'
                    : 'bg-gray-600'
                }`}
              />
            ))}
          </div>

          <Button
            onClick={nextChapter}
            disabled={currentChapter === STORY_CHAPTERS.length - 1}
            variant="outline"
            className="text-white border-purple-500 hover:bg-purple-700 disabled:opacity-50"
          >
            Nächstes Kapitel
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Final chapter call to action */}
        {currentChapter === STORY_CHAPTERS.length - 1 && (
          <motion.div
            className="text-center mt-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <Button
              onClick={() => setGamePhase("menu")}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold px-8 py-3 text-lg"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Beginne dein Abenteuer!
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}