import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Gem, Trophy, Sparkles, Package } from 'lucide-react';
import { cn } from '../lib/utils';

interface RewardNotificationProps {
  show: boolean;
  rewards: {
    xp?: number;
    gold?: number;
    diamonds?: number;
    packs?: number;
  };
  onComplete: () => void;
}

export function RewardNotification({ show, rewards, onComplete }: RewardNotificationProps) {
  const [animationPhase, setAnimationPhase] = useState<'appearing' | 'counting' | 'completing'>('appearing');
  const [currentValues, setCurrentValues] = useState({ xp: 0, gold: 0, diamonds: 0, packs: 0 });

  useEffect(() => {
    if (!show) return;

    const timer1 = setTimeout(() => {
      setAnimationPhase('counting');
      
      // Animate counting up
      const duration = 2000; // 2 seconds
      const interval = 50; // Update every 50ms
      const steps = duration / interval;
      
      let step = 0;
      const countingInterval = setInterval(() => {
        step++;
        const progress = step / steps;
        const easeOut = 1 - Math.pow(1 - progress, 3); // Ease out animation
        
        setCurrentValues({
          xp: Math.floor((rewards.xp || 0) * easeOut),
          gold: Math.floor((rewards.gold || 0) * easeOut),
          diamonds: Math.floor((rewards.diamonds || 0) * easeOut),
          packs: Math.floor((rewards.packs || 0) * easeOut)
        });
        
        if (step >= steps) {
          clearInterval(countingInterval);
          setCurrentValues({
            xp: rewards.xp || 0,
            gold: rewards.gold || 0,
            diamonds: rewards.diamonds || 0,
            packs: rewards.packs || 0
          });
          
          setTimeout(() => {
            setAnimationPhase('completing');
            setTimeout(() => {
              onComplete();
              setAnimationPhase('appearing');
              setCurrentValues({ xp: 0, gold: 0, diamonds: 0, packs: 0 });
            }, 500);
          }, 1000);
        }
      }, interval);
      
      return () => clearInterval(countingInterval);
    }, 500);

    return () => clearTimeout(timer1);
  }, [show, rewards, onComplete]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: -50 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ 
              scale: animationPhase === 'counting' ? [1, 1.05, 1] : 1,
              rotate: animationPhase === 'counting' ? [0, 1, -1, 0] : 0 
            }}
            transition={{ 
              scale: { duration: 0.6, repeat: animationPhase === 'counting' ? Infinity : 0 },
              rotate: { duration: 0.8, repeat: animationPhase === 'counting' ? Infinity : 0 }
            }}
            className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl border-2 border-yellow-500/50 shadow-2xl shadow-yellow-500/20 max-w-md w-full"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-yellow-600 to-orange-600 p-4 rounded-t-xl text-center">
              <motion.div
                animate={{ 
                  rotate: animationPhase === 'counting' ? 360 : 0,
                  scale: animationPhase === 'counting' ? [1, 1.2, 1] : 1
                }}
                transition={{ 
                  rotate: { duration: 2, repeat: animationPhase === 'counting' ? Infinity : 0 },
                  scale: { duration: 1, repeat: animationPhase === 'counting' ? Infinity : 0 }
                }}
                className="inline-block"
              >
                <Trophy className="w-8 h-8 text-white mb-2" />
              </motion.div>
              <h2 className="text-xl font-bold text-white">Belohnung erhalten!</h2>
            </div>

            {/* Rewards Display */}
            <div className="p-6 space-y-4">
              {rewards.xp && (
                <motion.div
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="flex items-center justify-between bg-blue-900/30 rounded-lg p-4 border border-blue-500/30"
                >
                  <div className="flex items-center gap-3">
                    <motion.div
                      animate={{ 
                        scale: animationPhase === 'counting' ? [1, 1.3, 1] : 1,
                        rotate: animationPhase === 'counting' ? [0, 180, 360] : 0
                      }}
                      transition={{ duration: 1, repeat: animationPhase === 'counting' ? Infinity : 0 }}
                    >
                      <Star className="w-6 h-6 text-blue-400" />
                    </motion.div>
                    <span className="text-white font-medium">Erfahrungspunkte</span>
                  </div>
                  <motion.div
                    key={currentValues.xp}
                    initial={{ scale: 1.2, color: '#60a5fa' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    +{currentValues.xp.toLocaleString()}
                  </motion.div>
                </motion.div>
              )}

              {rewards.gold && (
                <motion.div
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="flex items-center justify-between bg-yellow-900/30 rounded-lg p-4 border border-yellow-500/30"
                >
                  <div className="flex items-center gap-3">
                    <motion.div
                      animate={{ 
                        scale: animationPhase === 'counting' ? [1, 1.3, 1] : 1,
                        rotate: animationPhase === 'counting' ? [0, -180, -360] : 0
                      }}
                      transition={{ duration: 1.2, repeat: animationPhase === 'counting' ? Infinity : 0 }}
                      className="text-2xl"
                    >
                      🪙
                    </motion.div>
                    <span className="text-white font-medium">Gold</span>
                  </div>
                  <motion.div
                    key={currentValues.gold}
                    initial={{ scale: 1.2, color: '#eab308' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    +{currentValues.gold.toLocaleString()}
                  </motion.div>
                </motion.div>
              )}

              {rewards.diamonds && (
                <motion.div
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="flex items-center justify-between bg-cyan-900/30 rounded-lg p-4 border border-cyan-500/30"
                >
                  <div className="flex items-center gap-3">
                    <motion.div
                      animate={{ 
                        scale: animationPhase === 'counting' ? [1, 1.3, 1] : 1,
                        rotate: animationPhase === 'counting' ? [0, 120, 240, 360] : 0
                      }}
                      transition={{ duration: 1.5, repeat: animationPhase === 'counting' ? Infinity : 0 }}
                    >
                      <Gem className="w-6 h-6 text-cyan-400" />
                    </motion.div>
                    <span className="text-white font-medium">Diamanten</span>
                  </div>
                  <motion.div
                    key={currentValues.diamonds}
                    initial={{ scale: 1.2, color: '#22d3ee' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    +{currentValues.diamonds.toLocaleString()}
                  </motion.div>
                </motion.div>
              )}

              {rewards.packs && (
                <motion.div
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className="flex items-center justify-between bg-purple-900/30 rounded-lg p-4 border border-purple-500/30"
                >
                  <div className="flex items-center gap-3">
                    <motion.div
                      animate={{ 
                        scale: animationPhase === 'counting' ? [1, 1.5, 1] : 1,
                        rotate: animationPhase === 'counting' ? [0, -45, 45, 0] : 0
                      }}
                      transition={{ duration: 1.8, repeat: animationPhase === 'counting' ? Infinity : 0 }}
                    >
                      <Package className="w-6 h-6 text-purple-400" />
                    </motion.div>
                    <span className="text-white font-medium">Kartenpacks</span>
                  </div>
                  <motion.div
                    key={currentValues.packs}
                    initial={{ scale: 1.2, color: '#a855f7' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    +{currentValues.packs.toLocaleString()}
                  </motion.div>
                </motion.div>
              )}

              {/* Sparkle Effects */}
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ 
                      opacity: animationPhase === 'counting' ? [0, 1, 0] : 0,
                      scale: animationPhase === 'counting' ? [0, 1, 0] : 0,
                      x: animationPhase === 'counting' ? [0, Math.random() * 200 - 100] : 0,
                      y: animationPhase === 'counting' ? [0, Math.random() * 200 - 100] : 0
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: animationPhase === 'counting' ? Infinity : 0,
                      delay: i * 0.3 
                    }}
                    className="absolute"
                    style={{
                      left: `${20 + i * 15}%`,
                      top: `${30 + (i % 2) * 30}%`
                    }}
                  >
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-800/50 p-4 rounded-b-xl text-center">
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-slate-300 text-sm"
              >
                {animationPhase === 'appearing' && "Belohnung wird verarbeitet..."}
                {animationPhase === 'counting' && "Belohnungen werden hinzugefügt..."}
                {animationPhase === 'completing' && "Abgeschlossen!"}
              </motion.p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}