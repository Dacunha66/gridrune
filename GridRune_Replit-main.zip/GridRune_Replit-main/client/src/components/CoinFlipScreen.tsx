import { useState, useRef, useEffect } from "react";
import { useCardGame } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

// 3D Coin Component
function AnimatedCoin({ isFlipping, result }: { isFlipping: boolean; result: "heads" | "tails" | null }) {
  const coinRef = useRef<THREE.Group>(null);
  const [animationTime, setAnimationTime] = useState(0);
  const [hasLanded, setHasLanded] = useState(false);

  useFrame((state, delta) => {
    if (coinRef.current && isFlipping && !hasLanded) {
      setAnimationTime(prev => prev + delta);
      
      // Parabolic trajectory - coin flies up and comes down
      const height = Math.sin(animationTime * 2) * 3 + 0.5;
      const rotationSpeed = 15; // Fast rotation during flight
      
      coinRef.current.position.y = height;
      coinRef.current.rotation.x += delta * rotationSpeed;
      coinRef.current.rotation.z += delta * rotationSpeed * 0.7;
      
      // After 2 seconds, start landing sequence
      if (animationTime > 2 && height < 0.1) {
        setHasLanded(true);
        coinRef.current.position.y = 0;
        
        // Set final rotation based on result
        if (result === "heads") {
          coinRef.current.rotation.x = 0;
        } else {
          coinRef.current.rotation.x = Math.PI; // Flip to show tails
        }
        coinRef.current.rotation.z = 0;
      }
    }
  });

  // Reset animation when new flip starts
  useEffect(() => {
    if (isFlipping) {
      setAnimationTime(0);
      setHasLanded(false);
      if (coinRef.current) {
        coinRef.current.position.y = 0;
        coinRef.current.rotation.x = 0;
        coinRef.current.rotation.z = 0;
      }
    }
  }, [isFlipping]);

  return (
    <group ref={coinRef} position={[0, 0, 0]}>
      {/* Main coin body */}
      <mesh>
        <cylinderGeometry args={[1, 1, 0.2, 32]} />
        <meshStandardMaterial color="#FFD700" metalness={0.8} roughness={0.2} />
      </mesh>
      
      {/* Heads side background */}
      <mesh position={[0, 0.11, 0]} rotation={[-Math.PI/2, 0, 0]}>
        <circleGeometry args={[0.85, 32]} />
        <meshStandardMaterial color="#1a1a1a" />
      </mesh>
      
      {/* "K" text on heads side - using multiple rectangles to form the letter */}
      <group position={[0, 0.12, 0]} rotation={[-Math.PI/2, 0, 0]}>
        {/* Left vertical line of K */}
        <mesh position={[-0.3, 0, 0]}>
          <planeGeometry args={[0.1, 0.6]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
        {/* Top diagonal of K */}
        <mesh position={[-0.1, 0.15, 0]} rotation={[0, 0, -0.7]}>
          <planeGeometry args={[0.08, 0.3]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
        {/* Bottom diagonal of K */}
        <mesh position={[-0.1, -0.15, 0]} rotation={[0, 0, 0.7]}>
          <planeGeometry args={[0.08, 0.3]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
      </group>
      
      {/* Tails side background */}
      <mesh position={[0, -0.11, 0]} rotation={[Math.PI/2, 0, 0]}>
        <circleGeometry args={[0.85, 32]} />
        <meshStandardMaterial color="#2a2a2a" />
      </mesh>
      
      {/* "Z" text on tails side - using rectangles to form the letter */}
      <group position={[0, -0.12, 0]} rotation={[Math.PI/2, 0, 0]}>
        {/* Top horizontal line of Z */}
        <mesh position={[0, 0.2, 0]}>
          <planeGeometry args={[0.5, 0.08]} />
          <meshBasicMaterial color="#CD853F" />
        </mesh>
        {/* Diagonal line of Z */}
        <mesh position={[0, 0, 0]} rotation={[0, 0, -0.7]}>
          <planeGeometry args={[0.08, 0.45]} />
          <meshBasicMaterial color="#CD853F" />
        </mesh>
        {/* Bottom horizontal line of Z */}
        <mesh position={[0, -0.2, 0]}>
          <planeGeometry args={[0.5, 0.08]} />
          <meshBasicMaterial color="#CD853F" />
        </mesh>
      </group>
    </group>
  );
}

export function CoinFlipScreen() {
  const { flipCoin, coinFlipResult, coinFlipWinner, boardSize } = useCardGame();
  const [playerChoice, setPlayerChoice] = useState<"heads" | "tails" | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const handleCoinFlip = (choice: "heads" | "tails") => {
    setPlayerChoice(choice);
    setIsFlipping(true);
    setShowResult(false);
    
    // Simulate coin flip result
    const result = Math.random() < 0.5 ? "heads" : "tails";
    
    // Show result after coin animation
    setTimeout(() => {
      flipCoin(choice);
      setIsFlipping(false);
      setShowResult(true);
    }, 3000); // 3 seconds for full animation
  };

  if (coinFlipResult && coinFlipWinner && showResult) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <Card className="bg-slate-800 border-slate-600 max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-white">Münzwurf Ergebnis</CardTitle>
          </CardHeader>
          <CardContent className="text-center pb-8">
            {/* 3D Result Coin */}
            <div className="h-40 mb-6">
              <Canvas camera={{ position: [0, 0, 4], fov: 50 }}>
                <ambientLight intensity={0.6} />
                <pointLight position={[5, 5, 5]} intensity={1} />
                <AnimatedCoin isFlipping={false} result={coinFlipResult} />
              </Canvas>
            </div>
            
            <div className="mb-6">
              <div className="bg-slate-700 rounded-lg p-4 mb-4">
                <p className="text-xl text-slate-200 mb-3 text-center">
                  <span className="text-3xl mr-3">
                    {coinFlipResult === "heads" ? "🪙" : "🪙"}
                  </span>
                  Ergebnis: <span className="font-bold text-yellow-400 text-2xl">
                    {coinFlipResult === "heads" ? "KOPF (K)" : "ZAHL (Z)"}
                  </span>
                </p>
                <p className="text-lg text-slate-300 text-center">
                  Deine Wahl: <span className="font-bold text-white">
                    {playerChoice === "heads" ? "Kopf (K)" : "Zahl (Z)"}
                  </span>
                </p>
              </div>
            </div>
            
            {coinFlipWinner === 1 ? (
              <div className="bg-green-600 text-white p-4 rounded-lg mb-4">
                <p className="font-bold text-lg">Du hast gewonnen!</p>
                <p className="text-sm">Du darfst die O-Karte platzieren.</p>
              </div>
            ) : (
              <div className="bg-red-600 text-white p-4 rounded-lg mb-4">
                <p className="font-bold text-lg">Spieler 2 hat gewonnen!</p>
                <p className="text-sm">Spieler 2 darf die O-Karte platzieren.</p>
              </div>
            )}
            
            <p className="text-slate-400 text-sm">
              Der Gewinner platziert die O-Karte irgendwo auf dem {boardSize} Spielfeld...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <Card className="bg-slate-800 border-slate-600 max-w-md w-full">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-white">Münzwurf</CardTitle>
          <p className="text-slate-300 mt-2">
            Der Gewinner darf die O-Karte frei platzieren
          </p>
        </CardHeader>
        <CardContent className="text-center pb-8">
          {isFlipping ? (
            <div className="mb-6">
              {/* 3D Animated Coin */}
              <div className="h-40 mb-4">
                <Canvas camera={{ position: [0, 0, 4], fov: 50 }}>
                  <ambientLight intensity={0.6} />
                  <pointLight position={[5, 5, 5]} intensity={1} />
                  <AnimatedCoin isFlipping={true} result={coinFlipResult} />
                </Canvas>
              </div>
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-xl text-white font-bold text-center mb-2">🪙 Die Münze fliegt durch die Luft...</p>
                <p className="text-lg text-yellow-400 text-center">
                  Deine Wahl: <span className="font-bold">{playerChoice === "heads" ? "KOPF (K)" : "ZAHL (Z)"}</span>
                </p>
              </div>
            </div>
          ) : (
            <>
              <div className="mb-6">
                {/* Static 3D Coin */}
                <div className="h-32 mb-4">
                  <Canvas camera={{ position: [0, 0, 4], fov: 50 }}>
                    <ambientLight intensity={0.6} />
                    <pointLight position={[5, 5, 5]} intensity={1} />
                    <AnimatedCoin isFlipping={false} result={null} />
                  </Canvas>
                </div>
                <p className="text-lg text-white mb-4">Wähle Kopf oder Zahl:</p>
                <p className="text-sm text-slate-400 mb-4">
                  Münzwurf bestimmt wer die O-Karte frei platzieren darf ({boardSize} Modus)
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => handleCoinFlip("heads")}
                  className="bg-gradient-to-b from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-6 px-8 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
                  disabled={isFlipping}
                >
                  <div className="text-center">
                    <div className="text-4xl mb-2">🪙</div>
                    <div className="text-3xl font-bold mb-1">K</div>
                    <div className="text-lg">KOPF</div>
                  </div>
                </Button>
                <Button
                  onClick={() => handleCoinFlip("tails")}
                  className="bg-gradient-to-b from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-bold py-6 px-8 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
                  disabled={isFlipping}
                >
                  <div className="text-center">
                    <div className="text-4xl mb-2">🪙</div>
                    <div className="text-3xl font-bold mb-1">Z</div>
                    <div className="text-lg">ZAHL</div>
                  </div>
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}