import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Trophy, Users, UserPlus, UserCheck, MessageCircle, Crown, Sword, Shield, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar } from './ui/avatar';
import { cn } from '../lib/utils';
import { useFriends } from '../lib/stores/useFriends';

interface Player {
  id: string;
  username: string;
  rank: number;
  rating: number;
  wins: number;
  losses: number;
  winRate: number;
  level: number;
  avatar: string;
  title: string;
  isFriend: boolean;
  isOnline: boolean;
  lastSeen: Date;
  achievements: number;
  favoriteCard: string;
}

interface CommunityLeaderboardProps {
  onBack: () => void;
}

// Mock data for demonstration
const mockPlayers: Player[] = [
  {
    id: "1",
    username: "GridMeister",
    rank: 1,
    rating: 2850,
    wins: 247,
    losses: 53,
    winRate: 82.3,
    level: 45,
    avatar: "🦅",
    title: "Legendärer Champion",
    isFriend: false,
    isOnline: true,
    lastSeen: new Date(),
    achievements: 89,
    favoriteCard: "Drache des Feuers"
  },
  {
    id: "2", 
    username: "RuneKrieger",
    rank: 2,
    rating: 2720,
    wins: 189,
    losses: 41,
    winRate: 82.2,
    level: 42,
    avatar: "⚔️",
    title: "Großmeister",
    isFriend: true,
    isOnline: true,
    lastSeen: new Date(),
    achievements: 76,
    favoriteCard: "Erd-Golem"
  },
  {
    id: "3",
    username: "Kartenmagier",
    rank: 3,
    rating: 2650,
    wins: 156,
    losses: 44,
    winRate: 78.0,
    level: 38,
    avatar: "🧙",
    title: "Arkaner Meister",
    isFriend: false,
    isOnline: false,
    lastSeen: new Date(Date.now() - 3600000), // 1 hour ago
    achievements: 63,
    favoriteCard: "Blitzschlag"
  },
  {
    id: "4",
    username: "Strategix",
    rank: 4,
    rating: 2580,
    wins: 134,
    losses: 38,
    winRate: 77.9,
    level: 35,
    avatar: "🎯",
    title: "Taktischer Experte",
    isFriend: true,
    isOnline: true,
    lastSeen: new Date(),
    achievements: 58,
    favoriteCard: "Wasserwächter"
  },
  {
    id: "5",
    username: "ElementForce",
    rank: 5,
    rating: 2510,
    wins: 112,
    losses: 31,
    winRate: 78.3,
    level: 33,
    avatar: "🌊",
    title: "Elementarmeister",
    isFriend: false,
    isOnline: false,
    lastSeen: new Date(Date.now() - 7200000), // 2 hours ago
    achievements: 52,
    favoriteCard: "Feuerball"
  }
];

export function CommunityLeaderboard({ onBack }: CommunityLeaderboardProps) {
  const [selectedTab, setSelectedTab] = useState<string>("global");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { 
    friends, 
    isFriend, 
    hasSentRequest, 
    sendFriendRequest, 
    cancelFriendRequest,
    getOnlineFriends 
  } = useFriends();

  const filteredPlayers = useMemo(() => {
    let players = mockPlayers.map(player => ({
      ...player,
      isFriend: isFriend(player.id)
    }));
    
    if (selectedTab === "friends") {
      players = players.filter(p => p.isFriend);
    }
    
    if (searchQuery.trim()) {
      players = players.filter(p => 
        p.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return players;
  }, [selectedTab, searchQuery, friends]);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-5 h-5 text-yellow-500" />;
      case 2: return <Trophy className="w-5 h-5 text-gray-400" />;
      case 3: return <Trophy className="w-5 h-5 text-amber-600" />;
      default: return <span className="text-lg font-bold">#{rank}</span>;
    }
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return "from-yellow-400 via-yellow-500 to-yellow-600";
    if (rank === 2) return "from-gray-300 via-gray-400 to-gray-500";
    if (rank === 3) return "from-amber-400 via-amber-500 to-amber-600";
    return "from-slate-600 via-slate-700 to-slate-800";
  };

  const handleFriendRequest = (player: Player) => {
    if (hasSentRequest(player.id)) {
      cancelFriendRequest(player.id);
    } else {
      sendFriendRequest(player.id, player.username, player.avatar);
    }
  };

  const PlayerCard = ({ player, index }: { player: Player; index: number }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, type: "spring", stiffness: 200, damping: 20 }}
      whileHover={{ scale: 1.01, y: -2 }}
    >
      <Card className={cn(
        "relative overflow-hidden transition-all duration-300 border-2",
        player.rank <= 3 ? "bg-gradient-to-r " + getRankColor(player.rank) + " border-yellow-500/30" : "bg-slate-800/50 border-slate-600",
        player.isOnline && "ring-2 ring-green-500/20"
      )}>
        {/* Rank badge */}
        <div className="absolute top-3 left-3 z-10">
          <motion.div
            className={cn(
              "flex items-center justify-center w-12 h-12 rounded-full font-bold",
              player.rank <= 3 
                ? "bg-gradient-to-br " + getRankColor(player.rank) + " text-white shadow-lg"
                : "bg-slate-700 text-slate-300"
            )}
            whileHover={{ scale: 1.1 }}
          >
            {getRankIcon(player.rank)}
          </motion.div>
        </div>

        {/* Online indicator */}
        {player.isOnline && (
          <div className="absolute top-3 right-3 z-10">
            <motion.div
              className="w-3 h-3 bg-green-500 rounded-full shadow-lg"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        )}

        <CardHeader className="pt-16 pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-3xl">{player.avatar}</div>
              <div>
                <CardTitle className="text-white flex items-center gap-2">
                  {player.username}
                  {player.isFriend && <UserCheck className="w-4 h-4 text-green-400" />}
                </CardTitle>
                <p className="text-sm text-slate-400">{player.title}</p>
              </div>
            </div>
            
            {!player.isFriend && (
              <Button
                onClick={() => handleFriendRequest(player)}
                variant={hasSentRequest(player.id) ? "secondary" : "outline"}
                size="sm"
                className={cn(
                  "transition-all duration-200",
                  hasSentRequest(player.id)
                    ? "bg-green-600 hover:bg-green-700 text-white"
                    : "border-blue-500 text-blue-400 hover:bg-blue-500/20"
                )}
              >
                {hasSentRequest(player.id) ? (
                  <>
                    <UserCheck className="w-4 h-4 mr-2" />
                    Angefragt
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Freund hinzufügen
                  </>
                )}
              </Button>
            )}
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          <div className="grid grid-cols-3 gap-4 text-center mb-4">
            <div>
              <p className="text-2xl font-bold text-cyan-400">{player.rating}</p>
              <p className="text-xs text-slate-500">Rating</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-400">{player.wins}</p>
              <p className="text-xs text-slate-500">Siege</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-400">{player.winRate}%</p>
              <p className="text-xs text-slate-500">Siegrate</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="secondary" className="text-xs">
              <Star className="w-3 h-3 mr-1" />
              Level {player.level}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              <Trophy className="w-3 h-3 mr-1" />
              {player.achievements} Erfolge
            </Badge>
          </div>

          <div className="text-xs text-slate-400 mb-3">
            <strong>Lieblingskarte:</strong> {player.favoriteCard}
          </div>

          {!player.isOnline && (
            <div className="text-xs text-slate-500">
              Zuletzt online: {player.lastSeen.toLocaleString('de-DE')}
            </div>
          )}

          {player.isFriend && (
            <div className="flex gap-2 mt-4">
              <Button variant="outline" size="sm" className="flex-1 text-blue-400 border-blue-500 hover:bg-blue-500/20">
                <MessageCircle className="w-4 h-4 mr-2" />
                Nachricht
              </Button>
              <Button variant="outline" size="sm" className="flex-1 text-red-400 border-red-500 hover:bg-red-500/20">
                <Sword className="w-4 h-4 mr-2" />
                Herausfordern
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto">
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4 w-full">
        <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={onBack}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück
          </Button>
          
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Users className="w-8 h-8 text-yellow-400" />
            Community-Rangliste
          </h1>
          
          <div className="w-32" /> {/* Spacer for center alignment */}
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-yellow-900/50 to-yellow-800/50 border-yellow-600/50">
            <CardContent className="p-4 text-center">
              <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-300">
                {filteredPlayers.filter(p => p.rank <= 10).length}
              </p>
              <p className="text-xs text-yellow-500">Top 10 Spieler</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-900/50 to-green-800/50 border-green-600/50">
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-300">
                {friends.filter(f => f.isOnline).length}
              </p>
              <p className="text-xs text-green-500">Online Freunde</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/50 border-blue-600/50">
            <CardContent className="p-4 text-center">
              <UserPlus className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-300">
                {friends.length}
              </p>
              <p className="text-xs text-blue-500">Meine Freunde</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/50 border-purple-600/50">
            <CardContent className="p-4 text-center">
              <Trophy className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-300">
                {filteredPlayers.length}
              </p>
              <p className="text-xs text-purple-500">Aktive Spieler</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Tabs */}
        <div className="mb-6 space-y-4">
          <Input
            placeholder="Spieler suchen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-md mx-auto bg-slate-800 border-slate-600 text-white placeholder-slate-400"
          />

          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 bg-slate-800">
              <TabsTrigger value="global" className="data-[state=active]:bg-yellow-600 data-[state=active]:text-slate-900">
                <Trophy className="w-4 h-4 mr-2" />
                Globale Rangliste
              </TabsTrigger>
              <TabsTrigger value="friends" className="data-[state=active]:bg-yellow-600 data-[state=active]:text-slate-900">
                <Users className="w-4 h-4 mr-2" />
                Meine Freunde
              </TabsTrigger>
            </TabsList>

            <TabsContent value="global" className="space-y-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                <AnimatePresence>
                  {filteredPlayers.map((player, index) => (
                    <PlayerCard key={player.id} player={player} index={index} />
                  ))}
                </AnimatePresence>
              </motion.div>

              {filteredPlayers.length === 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-12"
                >
                  <Users className="w-16 h-16 text-slate-500 mx-auto mb-4" />
                  <p className="text-xl text-slate-400">Keine Spieler gefunden</p>
                  <p className="text-slate-500 mt-2">Versuche eine andere Suche oder warte auf neue Spieler</p>
                </motion.div>
              )}
            </TabsContent>

            <TabsContent value="friends" className="space-y-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                <AnimatePresence>
                  {filteredPlayers.map((player, index) => (
                    <PlayerCard key={player.id} player={player} index={index} />
                  ))}
                </AnimatePresence>
              </motion.div>

              {filteredPlayers.length === 0 && selectedTab === "friends" && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-12"
                >
                  <UserPlus className="w-16 h-16 text-slate-500 mx-auto mb-4" />
                  <p className="text-xl text-slate-400">
                    {searchQuery.trim() ? "Keine Freunde gefunden" : "Noch keine Freunde"}
                  </p>
                  <p className="text-slate-500 mt-2">
                    {searchQuery.trim() 
                      ? "Versuche eine andere Suche" 
                      : "Füge Spieler aus der globalen Rangliste hinzu"
                    }
                  </p>
                </motion.div>
              )}
            </TabsContent>
          </Tabs>
        </div>
        </div>
      </div>
    </div>
  );
}