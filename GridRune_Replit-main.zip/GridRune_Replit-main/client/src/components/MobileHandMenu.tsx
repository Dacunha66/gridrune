
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCardGame } from '../lib/stores/useCardGame';
import { Card } from './Card';
import { ChevronUp, ChevronDown, Hand, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { hapticFeedback } from '../lib/hapticFeedback';

interface MobileHandMenuProps {
  player: 1 | 2;
}

export function MobileHandMenu({ player }: MobileHandMenuProps) {
  const {
    player1Hand,
    player2Hand,
    selectedCard,
    selectCard,
    currentPlayer,
    gamePhase,
    gameMode,
    updateValidPlacementSlots
  } = useCardGame();

  const [isOpen, setIsOpen] = useState(false);
  const [selectedCardIndex, setSelectedCardIndex] = useState<number | null>(null);
  
  const hand = player === 1 ? player1Hand : player2Hand;
  const isCurrentPlayer = currentPlayer === player;
  const isAIPlayer = gameMode === 'ai' && player === 2;
  const playerColor = player === 1 ? "blue" : "red";

  // Don't show for AI player or when not current player's turn
  if (isAIPlayer || !isCurrentPlayer || gamePhase !== "playing") {
    return null;
  }

  const handleCardSelect = (cardIndex: number) => {
    hapticFeedback.cardSelect();
    selectCard(player, cardIndex);
    setSelectedCardIndex(cardIndex);
    setIsOpen(false); // Close menu after selection
    setTimeout(() => updateValidPlacementSlots(), 50);
  };

  const handleToggleMenu = () => {
    hapticFeedback.light();
    setIsOpen(!isOpen);
  };

  return (
    <>
      {/* Mobile Hand Menu Toggle Button */}
      <motion.div
        className={cn(
          "fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50",
          "bg-slate-800 border-2 rounded-full shadow-2xl",
          playerColor === "blue" ? "border-blue-400" : "border-red-400"
        )}
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <button
          onClick={handleToggleMenu}
          className={cn(
            "flex items-center justify-center gap-2 px-4 py-3 rounded-full transition-all",
            "text-white font-semibold text-sm",
            playerColor === "blue" 
              ? "bg-blue-600 hover:bg-blue-700 active:bg-blue-800" 
              : "bg-red-600 hover:bg-red-700 active:bg-red-800"
          )}
        >
          <Hand className="w-4 h-4" />
          <span>Handkarten ({hand.length})</span>
          {isOpen ? (
            <ChevronDown className="w-4 h-4" />
          ) : (
            <ChevronUp className="w-4 h-4" />
          )}
        </button>
      </motion.div>

      {/* Mobile Hand Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
            />

            {/* Hand Menu Container */}
            <motion.div
              className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t-4 border-blue-400 rounded-t-2xl shadow-2xl z-50 max-h-[70vh] overflow-hidden"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-slate-700">
                <div className="flex items-center gap-2">
                  <Hand className={cn(
                    "w-5 h-5",
                    playerColor === "blue" ? "text-blue-400" : "text-red-400"
                  )} />
                  <h3 className="text-white font-bold text-lg">
                    Deine Handkarten ({hand.length})
                  </h3>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
                >
                  <X className="w-5 h-5 text-white" />
                </button>
              </div>

              {/* Cards Horizontal Scroll */}
              <div className="p-4 overflow-y-auto max-h-[50vh]">
                {hand.length === 0 ? (
                  <div className="text-center py-8 text-slate-400">
                    <Hand className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Keine Karten mehr auf der Hand</p>
                  </div>
                ) : (
                  <>
                    {/* Horizontal scrolling cards for quick access */}
                    <div className="mb-4">
                      <h4 className="text-white text-sm font-medium mb-2 px-1">
                        Handkarten (wischen für mehr)
                      </h4>
                      <div 
                        className="flex gap-2 overflow-x-auto pb-3 px-2 scrollbar-hide"
                        style={{ 
                          scrollSnapType: 'x mandatory',
                          WebkitOverflowScrolling: 'touch',
                          scrollBehavior: 'smooth',
                          touchAction: 'pan-x',
                          overscrollBehaviorX: 'contain'
                        }}
                      >
                        {hand.map((card, index) => (
                          card && (
                            <motion.div
                              key={`scroll-${card.id}-${index}`}
                              className={cn(
                                "relative cursor-pointer transition-all duration-200 flex-shrink-0",
                                "hover:scale-105 active:scale-95",
                                selectedCard?.player === player && selectedCard?.cardIndex === index
                                  ? "ring-2 ring-yellow-400 ring-offset-1 ring-offset-slate-900"
                                  : ""
                              )}
                              style={{ 
                                scrollSnapAlign: 'start',
                                width: '85px',
                                height: '105px',
                                minWidth: '85px'
                              }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => handleCardSelect(index)}
                            >
                              {/* Selection Indicator */}
                              {selectedCard?.player === player && selectedCard?.cardIndex === index && (
                                <motion.div
                                  className="absolute -top-1 -right-1 w-5 h-5 bg-yellow-400 rounded-full flex items-center justify-center z-10"
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ type: "spring", stiffness: 400 }}
                                >
                                  <span className="text-slate-900 text-xs font-bold">✓</span>
                                </motion.div>
                              )}

                              <div className="transform-gpu w-full h-full">
                                <Card
                                  card={card}
                                  owner={player === 1 ? "player1" : "player2"}
                                  isSelected={selectedCard?.player === player && selectedCard?.cardIndex === index}
                                  onClick={() => {}} // Handled by parent div
                                  isClickable={true}
                                  isDisabled={false}
                                  size="medium"
                                />
                              </div>
                            </motion.div>
                          )
                        ))}
                      </div>
                      
                      {/* Swipe hint with scroll indicators */}
                      <div className="flex items-center justify-center gap-2 mt-3">
                        <div className="w-3 h-1 bg-blue-400 rounded animate-pulse"></div>
                        <p className="text-blue-300 text-xs font-medium">
                          ← Wische horizontal für alle {hand.length} Karten →
                        </p>
                        <div className="w-3 h-1 bg-blue-400 rounded animate-pulse"></div>
                      </div>
                      
                      {/* Scroll Progress Indicator */}
                      {hand.length > 4 && (
                        <div className="flex justify-center mt-2">
                          <div className="flex space-x-1">
                            {Array.from({ length: Math.ceil(hand.length / 4) }).map((_, idx) => (
                              <div 
                                key={idx}
                                className="w-2 h-2 rounded-full bg-slate-600 opacity-50"
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Full Grid View */}
                    <div>
                      <h4 className="text-white text-sm font-medium mb-2 px-1">
                        Alle Karten
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                    {hand.map((card, index) => (
                      card && (
                        <motion.div
                          key={`${card.id}-${index}`}
                          className={cn(
                            "relative cursor-pointer transition-all duration-200",
                            selectedCard?.player === player && selectedCard?.cardIndex === index
                              ? "ring-2 ring-yellow-400 ring-offset-2 ring-offset-slate-900 scale-105"
                              : "hover:scale-102"
                          )}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleCardSelect(index)}
                          layout
                        >
                          {/* Selection Indicator */}
                          {selectedCard?.player === player && selectedCard?.cardIndex === index && (
                            <motion.div
                              className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center z-10"
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 400 }}
                            >
                              <span className="text-slate-900 text-xs font-bold">✓</span>
                            </motion.div>
                          )}

                          <div className="transform-gpu">
                            <Card
                              card={card}
                              owner={player === 1 ? "player1" : "player2"}
                              isSelected={selectedCard?.player === player && selectedCard?.cardIndex === index}
                              onClick={() => {}} // Handled by parent div
                              isClickable={true}
                              isDisabled={false}
                              size="medium"
                            />
                          </div>

                          {/* Card Info Overlay */}
                          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 rounded-b-lg">
                            <p className="text-white text-xs font-medium truncate">
                              {card.name}
                            </p>
                            <p className="text-slate-300 text-xs opacity-75">
                              {card.rarity}
                            </p>
                          </div>
                        </motion.div>
                      )
                    ))}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Footer with Instructions */}
              <div className="p-4 bg-slate-800 border-t border-slate-700">
                <p className="text-slate-400 text-sm text-center">
                  {selectedCard?.player === player 
                    ? "Karte ausgewählt! Tippe auf ein freies Feld auf dem Spielbrett." 
                    : "Wähle eine Karte zum Spielen aus."
                  }
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
