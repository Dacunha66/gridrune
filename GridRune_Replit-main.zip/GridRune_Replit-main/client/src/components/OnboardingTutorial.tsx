import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft, X, Play, RotateCcw, Zap, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Card as CardComponent } from './Card';
import { GameCard, allCards } from '../lib/cardData';
import { useAchievements } from '../lib/stores/useAchievements';
import { useSeasonalRewards } from '../lib/stores/useSeasonalRewards';
import { useWeeklyChallenges } from '../lib/stores/useWeeklyChallenges';

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  component: React.ReactNode;
  animation?: string;
}

interface OnboardingTutorialProps {
  onComplete: () => void;
  onClose: () => void;
}

export default function OnboardingTutorial({ onComplete, onClose }: OnboardingTutorialProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const { onTutorialCompleted } = useAchievements();
  const seasonalRewards = useSeasonalRewards();
  const weeklyChallenges = useWeeklyChallenges();
  
  // Sample cards for demonstrations
  const fireCard = allCards.find(c => c.element === 'fire') || allCards[0];
  const waterCard = allCards.find(c => c.element === 'water') || allCards[1];
  const earthCard = allCards.find(c => c.element === 'earth') || allCards[2];
  const blitzCard = allCards.find(c => c.effect === 'blitzschlag') || allCards[3];
  const shieldCard = allCards.find(c => c.effect === 'schild') || allCards[4];

  const WelcomeStep = () => (
    <div className="text-center space-y-6">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", bounce: 0.5 }}
        className="text-6xl"
      >
        🎴
      </motion.div>
      <motion.h2
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-3xl font-bold text-yellow-300"
      >
        Willkommen bei GridRune!
      </motion.h2>
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-lg text-gray-300"
      >
        Lerne die Grundlagen des strategischen Kartenkampfs in einer interaktiven Tour durch die Welt von GridRune.
      </motion.p>
    </div>
  );

  const CardBasicsStep = () => {
    const [highlightedValue, setHighlightedValue] = useState<string | null>(null);
    
    useEffect(() => {
      const sequence = ['top', 'right', 'bottom', 'left'];
      let index = 0;
      
      const interval = setInterval(() => {
        setHighlightedValue(sequence[index]);
        index = (index + 1) % sequence.length;
      }, 1000);
      
      return () => clearInterval(interval);
    }, []);

    return (
      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-yellow-300 text-center">Kartengrundlagen</h3>
        <div className="flex justify-center">
          <motion.div
            className="relative"
            initial={{ rotateY: 0 }}
            animate={{ rotateY: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <CardComponent
              card={fireCard}
              size="large"
              isClickable={false}
              highlightedValue={highlightedValue}
              showTooltip={false}
            />
          </motion.div>
        </div>
        <div className="space-y-3 text-center">
          <p className="text-gray-300">Jede Karte hat vier Werte (oben, rechts, unten, links)</p>
          <motion.div
            className="inline-flex items-center gap-2 text-yellow-300"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            <span>↑ ➡ ↓ ⬅</span>
          </motion.div>
          <p className="text-sm text-gray-400">Diese Werte entscheiden über Sieg oder Niederlage im Kampf!</p>
        </div>
      </div>
    );
  };

  const BattleStep = () => {
    const [battlePhase, setBattlePhase] = useState(0);
    
    useEffect(() => {
      const timer = setInterval(() => {
        setBattlePhase(prev => (prev + 1) % 4);
      }, 2000);
      
      return () => clearInterval(timer);
    }, []);

    return (
      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-yellow-300 text-center">Kartenkampf</h3>
        <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
          <div />
          <motion.div
            animate={{ 
              scale: battlePhase === 1 ? 1.1 : 1,
              boxShadow: battlePhase === 1 ? '0 0 20px #ef4444' : '0 0 0px #ef4444'
            }}
          >
            <CardComponent card={fireCard} size="small" isClickable={false} />
          </motion.div>
          <div />
          
          <motion.div
            animate={{ 
              scale: battlePhase === 2 ? 1.1 : 1,
              boxShadow: battlePhase === 2 ? '0 0 20px #3b82f6' : '0 0 0px #3b82f6'
            }}
          >
            <CardComponent card={waterCard} size="small" isClickable={false} />
          </motion.div>
          
          <motion.div
            className="relative"
            animate={{ 
              scale: battlePhase === 0 ? 1.2 : 1,
              rotate: battlePhase === 3 ? 360 : 0
            }}
          >
            <CardComponent card={earthCard} size="small" isClickable={false} />
            {battlePhase === 3 && (
              <motion.div
                className="absolute inset-0 border-4 border-yellow-400 rounded-lg"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              />
            )}
          </motion.div>
          
          <div />
          <div />
          <div />
          <div />
        </div>
        
        <div className="text-center space-y-2">
          {battlePhase === 0 && <p className="text-yellow-300">Neue Karte wird platziert...</p>}
          {battlePhase === 1 && <p className="text-red-300">Vergleich mit oberer Karte: Feuer vs Erde</p>}
          {battlePhase === 2 && <p className="text-blue-300">Vergleich mit linker Karte: Wasser vs Erde</p>}
          {battlePhase === 3 && <p className="text-yellow-300">Karte erobert! Spieler erhält Punkte</p>}
        </div>
      </div>
    );
  };

  const EffectsStep = () => {
    const [activeEffect, setActiveEffect] = useState<string | null>(null);
    
    useEffect(() => {
      const effects = ['blitzschlag', 'schild', 'rotation'];
      let index = 0;
      
      const timer = setInterval(() => {
        setActiveEffect(effects[index]);
        index = (index + 1) % effects.length;
      }, 2500);
      
      return () => clearInterval(timer);
    }, []);

    return (
      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-yellow-300 text-center">Spezielle Karteneffekte</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            className="text-center space-y-3"
            animate={{ 
              scale: activeEffect === 'blitzschlag' ? 1.05 : 1,
              backgroundColor: activeEffect === 'blitzschlag' ? '#7c2d1244' : 'transparent'
            }}
            transition={{ duration: 0.3 }}
          >
            <div className="relative">
              <CardComponent card={blitzCard} size="medium" isClickable={false} />
              {activeEffect === 'blitzschlag' && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1.5, opacity: [1, 0] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Zap className="w-8 h-8 text-yellow-400" />
                </motion.div>
              )}
            </div>
            <div className="flex items-center justify-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-300 font-bold">Blitzschlag</span>
            </div>
            <p className="text-sm text-gray-400">Verursacht 2 Schadenspunkte</p>
          </motion.div>

          <motion.div
            className="text-center space-y-3"
            animate={{ 
              scale: activeEffect === 'schild' ? 1.05 : 1,
              backgroundColor: activeEffect === 'schild' ? '#1e40af44' : 'transparent'
            }}
            transition={{ duration: 0.3 }}
          >
            <div className="relative">
              <CardComponent card={shieldCard} size="medium" isClickable={false} />
              {activeEffect === 'schild' && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1.3, opacity: [0, 1, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <Shield className="w-8 h-8 text-blue-400" />
                </motion.div>
              )}
            </div>
            <div className="flex items-center justify-center gap-2">
              <Shield className="w-5 h-5 text-blue-400" />
              <span className="text-blue-300 font-bold">Schild</span>
            </div>
            <p className="text-sm text-gray-400">Blockiert den ersten Angriff</p>
          </motion.div>

          <motion.div
            className="text-center space-y-3"
            animate={{ 
              scale: activeEffect === 'rotation' ? 1.05 : 1,
              backgroundColor: activeEffect === 'rotation' ? '#16a34a44' : 'transparent'
            }}
            transition={{ duration: 0.3 }}
          >
            <div className="relative">
              <motion.div
                animate={{ rotate: activeEffect === 'rotation' ? 360 : 0 }}
                transition={{ duration: 2, ease: "easeInOut" }}
              >
                <CardComponent card={earthCard} size="medium" isClickable={false} />
              </motion.div>
              {activeEffect === 'rotation' && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1.2, rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <RotateCcw className="w-6 h-6 text-green-400" />
                </motion.div>
              )}
            </div>
            <div className="flex items-center justify-center gap-2">
              <RotateCcw className="w-5 h-5 text-green-400" />
              <span className="text-green-300 font-bold">Drehung</span>
            </div>
            <p className="text-sm text-gray-400">Rotiert am Rundenende</p>
          </motion.div>
        </div>
      </div>
    );
  };

  const GameModesStep = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-yellow-300 text-center">Spielmodi</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div
          className="bg-gray-800/50 rounded-lg p-6 border border-gray-600"
          whileHover={{ scale: 1.02, borderColor: '#facc15' }}
        >
          <div className="text-center space-y-4">
            <div className="text-4xl">🎯</div>
            <h4 className="text-xl font-bold text-yellow-300">Lokales Spiel</h4>
            <p className="text-sm text-gray-300">3x3 Feld, 10 Karten pro Deck</p>
            <p className="text-xs text-gray-400">Perfekt für schnelle Runden und zum Üben</p>
          </div>
        </motion.div>

        <motion.div
          className="bg-gray-800/50 rounded-lg p-6 border border-gray-600"
          whileHover={{ scale: 1.02, borderColor: '#3b82f6' }}
        >
          <div className="text-center space-y-4">
            <div className="text-4xl">🤖</div>
            <h4 className="text-xl font-bold text-blue-300">KI-Gegner</h4>
            <p className="text-sm text-gray-300">4x4 Feld, 15 Karten pro Deck</p>
            <p className="text-xs text-gray-400">Herausfordernde KI mit strategischen Zügen</p>
          </div>
        </motion.div>

        <motion.div
          className="bg-gray-800/50 rounded-lg p-6 border border-gray-600"
          whileHover={{ scale: 1.02, borderColor: '#22c55e' }}
        >
          <div className="text-center space-y-4">
            <div className="text-4xl">🌐</div>
            <h4 className="text-xl font-bold text-green-300">Online Multiplayer</h4>
            <p className="text-sm text-gray-300">4x4 Feld, Echtzeitkämpfe</p>
            <p className="text-xs text-gray-400">Spiele gegen andere Spieler weltweit</p>
          </div>
        </motion.div>

        <motion.div
          className="bg-gray-800/50 rounded-lg p-6 border border-gray-600"
          whileHover={{ scale: 1.02, borderColor: '#8b5cf6' }}
        >
          <div className="text-center space-y-4">
            <div className="text-4xl">🏆</div>
            <h4 className="text-xl font-bold text-purple-300">Rangliste</h4>
            <p className="text-sm text-gray-300">Kompetitive Matches</p>
            <p className="text-xs text-gray-400">Kämpfe um die Spitzenposition</p>
          </div>
        </motion.div>
      </div>
    </div>
  );

  const CompletionStep = () => (
    <div className="text-center space-y-6">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", bounce: 0.6, delay: 0.2 }}
        className="text-6xl"
      >
        🎉
      </motion.div>
      
      <motion.h2
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="text-3xl font-bold text-yellow-300"
      >
        Tutorial abgeschlossen!
      </motion.h2>
      
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="text-lg text-gray-300"
      >
        Du bist bereit für den Kampf! Wähle einen Spielmodus und teste deine neu erlernten Fähigkeiten.
      </motion.p>

      <motion.div
        className="flex flex-col gap-3 mt-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.8 }}
      >
        <Button 
          onClick={() => {
            onTutorialCompleted();
            seasonalRewards.addSeasonalXP(20); // Award XP for completing tutorial
            weeklyChallenges.initializeWeeklyChallenges(); // Initialize weekly challenges
            onComplete();
          }}
          size="lg"
          className="bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-gray-900 font-bold"
        >
          <Play className="w-5 h-5 mr-2" />
          Jetzt spielen!
        </Button>
        
        <Button 
          onClick={() => setCurrentStep(0)}
          variant="outline"
          size="sm"
          className="text-gray-300 border-gray-600"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Tutorial wiederholen
        </Button>
      </motion.div>
    </div>
  );

  const steps: TutorialStep[] = [
    {
      id: 'welcome',
      title: 'Willkommen',
      description: 'Einführung in GridRune',
      component: <WelcomeStep />
    },
    {
      id: 'card-basics',
      title: 'Kartengrundlagen',
      description: 'Verstehe Kartenwerte und -struktur',
      component: <CardBasicsStep />
    },
    {
      id: 'battle',
      title: 'Kampfsystem',
      description: 'Lerne wie Karten kämpfen',
      component: <BattleStep />
    },
    {
      id: 'effects',
      title: 'Karteneffekte',
      description: 'Entdecke spezielle Fähigkeiten',
      component: <EffectsStep />
    },
    {
      id: 'game-modes',
      title: 'Spielmodi',
      description: 'Erkunde verschiedene Spielarten',
      component: <GameModesStep />
    },
    {
      id: 'completion',
      title: 'Abschluss',
      description: 'Du bist bereit!',
      component: <CompletionStep />
    }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentStep(prev => prev + 1);
        setIsAnimating(false);
      }, 300);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentStep(prev => prev - 1);
        setIsAnimating(false);
      }, 300);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-900/95 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        className="bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden border border-gray-600"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 p-6 text-gray-900">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">GridRune Tutorial</h1>
              <p className="text-gray-700">{steps[currentStep].description}</p>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-gray-700 hover:text-gray-900 hover:bg-gray-200"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-gray-700 h-2">
          <motion.div
            className="bg-gradient-to-r from-yellow-600 to-yellow-400 h-full"
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        {/* Content */}
        <div className="p-8 min-h-[400px] flex flex-col justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {steps[currentStep].component}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation */}
        {currentStep < steps.length - 1 && (
          <div className="bg-gray-700 p-6 flex items-center justify-between">
            <Button
              onClick={prevStep}
              disabled={currentStep === 0}
              variant="outline"
              className="text-gray-300 border-gray-600 disabled:opacity-50"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Zurück
            </Button>

            <div className="flex gap-2">
              {steps.map((_, index) => (
                <motion.div
                  key={index}
                  className={`w-3 h-3 rounded-full ${
                    index === currentStep ? 'bg-yellow-400' : 'bg-gray-600'
                  }`}
                  animate={{
                    scale: index === currentStep ? 1.2 : 1,
                  }}
                />
              ))}
            </div>

            <Button
              onClick={nextStep}
              className="bg-yellow-600 hover:bg-yellow-500 text-gray-900"
            >
              Weiter
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}
      </motion.div>
    </div>
  );
}