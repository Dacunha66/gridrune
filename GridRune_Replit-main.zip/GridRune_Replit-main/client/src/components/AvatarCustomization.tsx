import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { AvatarSelector, AvatarDisplay, Avatar, AVAILABLE_AVATARS } from './AvatarSelector';

export { AVAILABLE_AVATARS } from './AvatarSelector';
import { cn } from '../lib/utils';

interface AvatarCustomizationProps {
  onSave: (playerName: string, avatar: Avatar) => void;
  onCancel: () => void;
  currentPlayerName?: string;
  currentAvatar?: Avatar;
  isPlayer2?: boolean;
}

export function AvatarCustomization({ 
  onSave, 
  onCancel, 
  currentPlayerName = '',
  currentAvatar,
  isPlayer2 = false
}: AvatarCustomizationProps) {
  const [playerName, setPlayerName] = useState(currentPlayerName);
  const [selectedAvatar, setSelectedAvatar] = useState<Avatar>(
    currentAvatar || AVAILABLE_AVATARS[0]
  );

  const handleSave = () => {
    if (playerName.trim()) {
      onSave(playerName.trim(), selectedAvatar);
    }
  };

  const defaultNames = isPlayer2 
    ? ['Spieler 2', 'Gegner', 'Rivale', 'Herausforderer']
    : ['Spieler 1', 'Held', 'Champion', 'Krieger'];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl bg-slate-800 border-slate-600">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-white">
            {isPlayer2 ? 'Spieler 2 Anpassen' : 'Spieler Profil Anpassen'}
          </CardTitle>
          <p className="text-slate-400">
            Wähle deinen Namen und Avatar für das Spiel
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Player Name Section */}
          <div className="space-y-3">
            <Label htmlFor="playerName" className="text-white font-medium">
              Spielername
            </Label>
            <Input
              id="playerName"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder={`Gib deinen Namen ein...`}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              maxLength={20}
            />
            <p className="text-xs text-slate-500">
              Oder wähle einen Vorschlag:
            </p>
            <div className="flex flex-wrap gap-2">
              {defaultNames.map((name) => (
                <Button
                  key={name}
                  variant="outline"
                  size="sm"
                  onClick={() => setPlayerName(name)}
                  className="text-xs bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white"
                >
                  {name}
                </Button>
              ))}
            </div>
          </div>

          {/* Avatar Selection Section */}
          <div className="space-y-4">
            <Label className="text-white font-medium">
              Avatar auswählen
            </Label>
            <AvatarSelector
              selectedAvatar={selectedAvatar}
              onSelect={setSelectedAvatar}
              size="medium"
              showNames={true}
            />
          </div>

          {/* Preview Section */}
          <div className="space-y-3">
            <Label className="text-white font-medium">
              Vorschau
            </Label>
            <div className="bg-slate-700 rounded-lg p-4 flex items-center justify-center space-x-4">
              <AvatarDisplay 
                avatar={selectedAvatar}
                size="large"
                showName={false}
              />
              <div className="text-center">
                <p className="text-white font-bold text-lg">
                  {playerName || 'Dein Name'}
                </p>
                <p className="text-slate-400 text-sm">
                  {selectedAvatar.name}
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button
              onClick={onCancel}
              variant="outline"
              className="flex-1 bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white"
            >
              Abbrechen
            </Button>
            <Button
              onClick={handleSave}
              disabled={!playerName.trim()}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Speichern
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}