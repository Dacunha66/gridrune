import { useCardGame } from "../lib/stores/useCardGame";
import { useEffect, useState } from "react";

export function EffectMessages() {
  const effectMessages = useCardGame((state) => state.effectMessages);
  const [displayedMessages, setDisplayedMessages] = useState<string[]>([]);

  useEffect(() => {
    if (effectMessages.length > 0) {
      setDisplayedMessages(effectMessages);
      
      // Clear messages after 4 seconds
      const timer = setTimeout(() => {
        setDisplayedMessages([]);
      }, 4000);
      
      return () => clearTimeout(timer);
    }
  }, [effectMessages]);

  if (displayedMessages.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
      <div className="bg-black/80 text-white rounded-lg p-3 shadow-lg border border-gray-600 max-w-sm">
        <div className="text-center">
          <h3 className="text-sm font-bold text-yellow-400 mb-2">Karteneffekte</h3>
          <div className="space-y-1">
            {displayedMessages.map((message, index) => (
              <div 
                key={index} 
                className="text-xs text-center animate-pulse"
              >
                {message}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}