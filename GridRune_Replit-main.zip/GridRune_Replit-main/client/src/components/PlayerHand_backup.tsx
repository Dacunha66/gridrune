import { useCardGame } from "../lib/stores/useCardGame";
import { Card } from "./Card";
import { cn } from "../lib/utils";
import { useState, useRef, useEffect } from "react";

interface PlayerHandProps {
  player: 1 | 2;
}

export function PlayerHand({ player }: PlayerHandProps) {
  const {
    player1Hand,
    player2Hand,
    selectedCard,
    selectCard,
    currentPlayer,
    gamePhase,
    gameMode,
    updateValidPlacementSlots
  } = useCardGame();

  const hand = player === 1 ? player1Hand : player2Hand;
  const isCurrentPlayer = currentPlayer === player;
  const playerName = player === 1 ? "Blue Player" : "Red Player";
  const playerColor = player === 1 ? "text-blue-400" : "text-red-400";
  const isAIPlayer = gameMode === 'ai' && player === 2;

  // Mobile state
  const [isMobile, setIsMobile] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768); // md breakpoint
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleCardClick = (index: number) => {
    if (isCurrentPlayer && gamePhase === "playing") {
      selectCard(player, index);
      setTimeout(() => updateValidPlacementSlots(), 50);
    }
  };

  return (
    <div className={cn(
      "bg-slate-800 rounded-xl shadow-lg relative h-full",
      isMobile ? "p-0 z-20" : "p-2 sm:p-4 z-30",
      isCurrentPlayer && gamePhase === "playing" && "ring-2 ring-white ring-opacity-50"
    )} style={{ overflow: isMobile ? 'visible' : 'auto' }}>
      
      {/* Only show player name on desktop */}
      {!isMobile && (
        <h3 className={cn("text-xs font-bold mb-1 text-center", playerColor)}>
          {gameMode === 'ai' ? (player === 1 ? "Du" : "KI") : playerName}
          {isCurrentPlayer && gamePhase === "playing" && (
            <span className="text-xs text-white/70"> • Dein Zug</span>
          )}
        </h3>
      )}

      {/* Mobile Horizontal Scrolling Interface */}
      {isMobile && !isAIPlayer ? (
        <div className="relative">
          <div 
            ref={scrollContainerRef}
            className="flex gap-1 overflow-x-auto p-1 scrollbar-hide" 
            style={{ 
              height: '80px',
              scrollSnapType: 'x mandatory',
              scrollBehavior: 'smooth'
            }}
          >
            {hand.map((card, index) => (
              card && (
                <div
                  key={`${card.id}-${index}`}
                  className={cn(
                    "flex-shrink-0 cursor-pointer transition-all duration-200",
                    selectedCard?.player === player && selectedCard?.cardIndex === index
                      ? "ring-2 ring-yellow-400 ring-offset-1 ring-offset-slate-800"
                      : ""
                  )}
                  style={{ 
                    width: '55px', 
                    height: '70px',
                    scrollSnapAlign: 'start'
                  }}
                  onClick={() => handleCardClick(index)}
                >
                  <Card
                    card={card}
                    owner={player === 1 ? "player1" : "player2"}
                    isSelected={selectedCard?.player === player && selectedCard?.cardIndex === index}
                    onClick={() => {}} // Handled by parent div
                    isClickable={isCurrentPlayer && gamePhase === "playing"}
                    isDisabled={!isCurrentPlayer || gamePhase !== "playing"}
                    size="small"
                  />
                </div>
              )
            ))}
            
            {/* Swipe hint indicator */}
            {hand.length > 3 && (
              <div className="flex items-center justify-center text-slate-400 text-xs px-2 flex-shrink-0">
                <span>→</span>
              </div>
            )}
          </div>
          
          {/* Mobile card counter and hint */}
          <div className="text-center pt-1">
            <span className="text-xs text-slate-400">
              {hand.length} Karten{hand.length > 3 ? " • Wische horizontal →" : ""}
            </span>
          </div>
        </div>
      ) : (
        /* Desktop Grid Interface */
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:flex md:flex-wrap md:gap-2 lg:space-y-3 lg:flex-col lg:flex-nowrap justify-center lg:justify-start">
          {hand.map((card, index) => (
            card ? (
              isAIPlayer ? (
                // Hide AI cards - show only small card back
                <div
                  key={`ai-hidden-${index}`}
                  className="w-8 sm:w-12 h-10 sm:h-16 bg-gradient-to-br from-slate-700 to-slate-900 border border-red-600 rounded flex items-center justify-center"
                >
                  <div className="text-red-400 text-sm font-bold">?</div>
                </div>
              ) : (
                <Card
                  key={`${card.id}-${index}`}
                  card={card}
                  owner={player === 1 ? "player1" : "player2"}
                  isSelected={selectedCard?.player === player && selectedCard?.cardIndex === index}
                  onClick={() => handleCardClick(index)}
                  isClickable={isCurrentPlayer && gamePhase === "playing"}
                  isDisabled={!isCurrentPlayer || gamePhase !== "playing"}
                />
              )
            ) : null
          ))}
        </div>
      )}

      {/* Desktop Card Counter */}
      {!isMobile && (
        <div className="mt-2 sm:mt-4 text-center">
          <span className="text-xs sm:text-sm text-slate-400">
            Karten: {hand.length}
          </span>
        </div>
      )}
    </div>
  );
}