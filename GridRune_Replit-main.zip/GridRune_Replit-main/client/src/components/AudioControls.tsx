import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX, Music, Settings, Headphones } from 'lucide-react';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Slider } from './ui/slider';

interface AudioControlsProps {
  className?: string;
}

export function AudioControls({ className = '' }: AudioControlsProps) {
  const {
    isMuted,
    masterVolume,
    musicVolume,
    effectsVolume,
    isBackgroundMusicPlaying,
    backgroundMusicTracks,
    currentTrackIndex,
    toggleMute,
    toggleBackgroundMusic,
    changeBackgroundTrack,
    setMasterVolume,
    setMusicVolume,
    setEffectsVolume
  } = useAudio();

  const [showControls, setShowControls] = useState(false);

  return (
    <div className={`relative ${className}`}>
      {/* Main Audio Toggle Button */}
      <Button
        onClick={() => setShowControls(!showControls)}
        variant="outline"
        size="sm"
        className="bg-slate-800/80 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white backdrop-blur-sm"
      >
        {isMuted ? (
          <VolumeX className="w-4 h-4" />
        ) : (
          <Volume2 className="w-4 h-4" />
        )}
      </Button>

      {/* Expanded Controls Panel */}
      <AnimatePresence>
        {showControls && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute top-12 right-0 bg-slate-900/95 backdrop-blur-lg border border-slate-600 rounded-lg p-4 shadow-2xl z-50 min-w-72"
          >
            {/* Header */}
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-700">
              <Settings className="w-4 h-4 text-slate-400" />
              <h3 className="text-sm font-semibold text-white">Audio-Einstellungen</h3>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2 mb-4">
              <div className="flex gap-2">
                <Button
                  onClick={toggleMute}
                  variant={isMuted ? "destructive" : "outline"}
                  size="sm"
                  className="flex-1"
                >
                  {isMuted ? <VolumeX className="w-4 h-4 mr-2" /> : <Volume2 className="w-4 h-4 mr-2" />}
                  {isMuted ? 'Stumm' : 'Ton an'}
                </Button>
                
                <Button
                  onClick={toggleBackgroundMusic}
                  variant={isBackgroundMusicPlaying ? "default" : "outline"}
                  size="sm"
                  className="flex-1"
                  disabled={isMuted}
                >
                  <Music className="w-4 h-4 mr-2" />
                  {isBackgroundMusicPlaying ? 'Musik an' : 'Musik aus'}
                </Button>
              </div>
              
              {/* Music Track Change Button */}
              {backgroundMusicTracks.length > 1 && (
                <Button
                  onClick={changeBackgroundTrack}
                  variant="outline"
                  size="sm"
                  className="w-full bg-slate-800/50 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white"
                  disabled={isMuted}
                >
                  <Music className="w-4 h-4 mr-2" />
                  Musikthema wechseln ({(backgroundMusicTracks[currentTrackIndex] as any)?.effectName || `${currentTrackIndex + 1}`}/{backgroundMusicTracks.length})
                </Button>
              )}
            </div>

            {/* Volume Controls */}
            <div className="space-y-4">
              {/* Master Volume */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Volume2 className="w-4 h-4" />
                    Gesamtlautstärke
                  </label>
                  <span className="text-xs text-slate-400">
                    {Math.round(masterVolume * 100)}%
                  </span>
                </div>
                <Slider
                  value={[masterVolume]}
                  onValueChange={(value) => setMasterVolume(value[0])}
                  max={1}
                  step={0.05}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>

              {/* Music Volume */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Music className="w-4 h-4" />
                    Hintergrundmusik
                  </label>
                  <span className="text-xs text-slate-400">
                    {Math.round(musicVolume * 100)}%
                  </span>
                </div>
                <Slider
                  value={[musicVolume]}
                  onValueChange={(value) => setMusicVolume(value[0])}
                  max={1}
                  step={0.05}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>

              {/* Effects Volume */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Headphones className="w-4 h-4" />
                    Soundeffekte
                  </label>
                  <span className="text-xs text-slate-400">
                    {Math.round(effectsVolume * 100)}%
                  </span>
                </div>
                <Slider
                  value={[effectsVolume]}
                  onValueChange={(value) => setEffectsVolume(value[0])}
                  max={1}
                  step={0.05}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>
            </div>

            {/* Close Button */}
            <div className="mt-4 pt-2 border-t border-slate-700">
              <Button
                onClick={() => setShowControls(false)}
                variant="ghost"
                size="sm"
                className="w-full text-slate-400 hover:text-white"
              >
                Schließen
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}