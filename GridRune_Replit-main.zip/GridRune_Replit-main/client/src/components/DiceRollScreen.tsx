import { useState, useEffect } from "react";
import { useCardGame } from "../lib/stores/useCardGame";

export function DiceRollScreen() {
  const { setDiceWinner, gameMode, player1Name, player2Name } = useCardGame();
  const [isRolling, setIsRolling] = useState(false);
  const [player1Dice, setPlayer1Dice] = useState<number | null>(null);
  const [player2Dice, setPlayer2Dice] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [currentPlayer1Dice, setCurrentPlayer1Dice] = useState(1);
  const [currentPlayer2Dice, setCurrentPlayer2Dice] = useState(1);

  const diceSymbols = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];

  useEffect(() => {
    // Auto-start the dice roll
    setTimeout(() => {
      handleDiceRoll();
    }, 500);
  }, []);

  const handleDiceRoll = () => {
    setIsRolling(true);
    setPlayer1Dice(null);
    setPlayer2Dice(null);
    setShowResult(false);

    // Animate both dice rolling by rapidly changing values
    let rollCount = 0;
    const rollInterval = setInterval(() => {
      setCurrentPlayer1Dice(Math.floor(Math.random() * 6) + 1);
      setCurrentPlayer2Dice(Math.floor(Math.random() * 6) + 1);
      rollCount++;
      
      if (rollCount >= 12) {
        clearInterval(rollInterval);
        
        // Final dice values
        const finalPlayer1Value = Math.floor(Math.random() * 6) + 1;
        const finalPlayer2Value = Math.floor(Math.random() * 6) + 1;
        
        setCurrentPlayer1Dice(finalPlayer1Value);
        setCurrentPlayer2Dice(finalPlayer2Value);
        setPlayer1Dice(finalPlayer1Value);
        setPlayer2Dice(finalPlayer2Value);
        setIsRolling(false);
        setShowResult(true);

        // Determine winner: higher dice value wins, re-roll on tie
        if (finalPlayer1Value > finalPlayer2Value) {
          const winner = 1;
          // Show result for 1.5 seconds, then proceed
          setTimeout(() => {
            setDiceWinner(winner);
          }, 1500);
        } else if (finalPlayer2Value > finalPlayer1Value) {
          const winner = 2;
          // Show result for 1.5 seconds, then proceed
          setTimeout(() => {
            setDiceWinner(winner);
          }, 1500);
        } else {
          // Tie - re-roll after showing tie result for 1 second
          setTimeout(() => {
            handleDiceRoll();
          }, 1000);
        }
      }
    }, 120);
  };

  const getWinner = () => {
    if (!player1Dice || !player2Dice) return null;
    if (player1Dice > player2Dice) return 1;
    if (player2Dice > player1Dice) return 2;
    return 'tie'; // Return 'tie' for equal values
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center p-4">
      <div className="text-center max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-white mb-4">
          Wer darf beginnen?
        </h2>
        
        <p className="text-slate-300 mb-8 text-lg">
          Beide Spieler würfeln gleichzeitig!
          <br />
          <span className="text-sm">Höhere Zahl gewinnt • Bei Gleichstand wird neu gewürfelt</span>
        </p>
        
        {/* Dual Dice Container */}
        <div className="flex justify-center items-center gap-8 md:gap-16 mb-8">
          
          {/* Player 1 Dice */}
          <div className="text-center">
            <h3 className="text-xl font-bold text-blue-400 mb-4">
              {gameMode === 'ai' ? 'Du' : (player1Name || 'Spieler 1')}
            </h3>
            <div className="relative w-32 h-32 md:w-40 md:h-40">
              <div className={`
                w-full h-full rounded-2xl bg-gradient-to-br from-blue-400 to-blue-600
                border-4 border-blue-300 shadow-2xl flex items-center justify-center
                transition-all duration-200
                ${isRolling ? 'animate-bounce' : ''}
                ${showResult && getWinner() === 1 ? 'scale-110 shadow-3xl ring-4 ring-green-400' : 
                   showResult && getWinner() === 'tie' ? 'scale-105 ring-4 ring-yellow-400' : 'scale-100'}
              `}>
                <div className="text-white text-4xl md:text-6xl font-bold">
                  {diceSymbols[currentPlayer1Dice - 1]}
                </div>
              </div>
              
              {/* Winner glow effect */}
              {showResult && getWinner() === 1 && (
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-green-400 to-blue-600 opacity-30 animate-pulse"></div>
              )}
              {/* Tie glow effect */}
              {showResult && getWinner() === 'tie' && (
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-yellow-400 to-blue-600 opacity-30 animate-pulse"></div>
              )}
            </div>
            {showResult && player1Dice && (
              <p className="text-2xl font-bold text-white mt-4">
                {player1Dice}
              </p>
            )}
          </div>

          {/* VS Text */}
          <div className="text-white text-2xl md:text-4xl font-bold opacity-50">
            VS
          </div>

          {/* Player 2 Dice */}
          <div className="text-center">
            <h3 className="text-xl font-bold text-red-400 mb-4">
              {gameMode === 'ai' ? 'KI' : (player2Name || 'Spieler 2')}
            </h3>
            <div className="relative w-32 h-32 md:w-40 md:h-40">
              <div className={`
                w-full h-full rounded-2xl bg-gradient-to-br from-red-400 to-red-600
                border-4 border-red-300 shadow-2xl flex items-center justify-center
                transition-all duration-200
                ${isRolling ? 'animate-bounce' : ''}
                ${showResult && getWinner() === 2 ? 'scale-110 shadow-3xl ring-4 ring-green-400' : 
                   showResult && getWinner() === 'tie' ? 'scale-105 ring-4 ring-yellow-400' : 'scale-100'}
              `}>
                <div className="text-white text-4xl md:text-6xl font-bold">
                  {diceSymbols[currentPlayer2Dice - 1]}
                </div>
              </div>
              
              {/* Winner glow effect */}
              {showResult && getWinner() === 2 && (
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-green-400 to-red-600 opacity-30 animate-pulse"></div>
              )}
              {/* Tie glow effect */}
              {showResult && getWinner() === 'tie' && (
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-yellow-400 to-red-600 opacity-30 animate-pulse"></div>
              )}
            </div>
            {showResult && player2Dice && (
              <p className="text-2xl font-bold text-white mt-4">
                {player2Dice}
              </p>
            )}
          </div>
        </div>

        {isRolling && (
          <p className="text-white text-xl animate-pulse">
            🎲 Würfel rollen...
          </p>
        )}

        {showResult && player1Dice && player2Dice && (
          <div className="text-center bg-slate-800/80 rounded-xl p-6 mx-auto max-w-md">
            <p className="text-3xl font-bold text-white mb-2">
              {player1Dice} : {player2Dice}
            </p>
            {getWinner() === 'tie' ? (
              <>
                <p className="text-2xl font-bold text-yellow-400 mb-4">
                  Gleichstand!
                </p>
                <p className="text-slate-300 text-sm">
                  Neu würfeln in 2 Sekunden...
                </p>
                <p className="text-slate-400 text-xs mt-2 animate-pulse">
                  🎲 Würfel rollen gleich wieder...
                </p>
              </>
            ) : (
              <>
                <p className="text-2xl font-bold text-green-400 mb-4">
                  {gameMode === 'ai' 
                    ? (getWinner() === 1 ? "Du hast gewonnen!" : "Die KI hat gewonnen!")
                    : `${getWinner() === 1 ? (player1Name || 'Spieler 1') : (player2Name || 'Spieler 2')} hat gewonnen!`
                  }
                </p>
                <p className="text-slate-300 text-sm">
                  {getWinner() === 1 ? (gameMode === 'ai' ? 'Du darfst' : (player1Name || 'Spieler 1') + ' darf') : (gameMode === 'ai' ? 'Die KI darf' : (player2Name || 'Spieler 2') + ' darf')} die O-Karte platzieren
                </p>
                <p className="text-slate-400 text-xs mt-2">
                  Das Spiel startet gleich...
                </p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}