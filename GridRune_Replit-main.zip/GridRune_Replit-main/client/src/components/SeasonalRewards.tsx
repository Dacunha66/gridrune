import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, Trophy, Star, Clock, Gift, Crown, Sparkles, 
  Calendar, Award, Lock, CheckCircle, Snowflake, Cherry,
  Zap, Shield, Swords, Gem, Timer, Target
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { cn } from '../lib/utils';
import { useSeasonalRewards, SeasonalCard, SeasonalTier } from '../lib/stores/useSeasonalRewards';
import { useAudio } from '../lib/stores/useAudio';


interface SeasonalRewardsProps {
  onBack?: () => void;
  onShowReward?: (reward: { xp?: number; gold?: number; diamonds?: number }) => void;
}

export function SeasonalRewards({ onBack, onShowReward }: SeasonalRewardsProps) {
  const [selectedTab, setSelectedTab] = useState('progress');
  const [showCardModal, setShowCardModal] = useState<SeasonalCard | null>(null);
  const [claimingTier, setClaimingTier] = useState<number | null>(null);

  const {
    currentSeason,
    seasonalCards,
    collectedSeasonalCards,
    currentSeasonXP,
    seasonalTiers,
    unclaimedRewards,
    initializeSeasons,
    addSeasonXP,
    claimTierReward,
    getCurrentTier,
    getNextTierProgress,
    getAvailableSeasonalCards,
    hasSeasonalCard,
    getSeasonProgress
  } = useSeasonalRewards();

  const audio = useAudio();

  useEffect(() => {
    initializeSeasons();
  }, [initializeSeasons]);

  const handleClaimReward = async (tier: number) => {
    setClaimingTier(tier);
    
    // Find the tier reward
    const tierData = seasonalTiers.find(t => t.tier === tier);
    if (tierData && onShowReward) {
      // Show animated reward notification
      onShowReward(tierData.reward);
    } else {
      // Fallback: play success sound
      audio.playSuccess();
    }
    
    // Simulate claiming delay for dramatic effect
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const success = claimTierReward(tier);
    if (success) {
      // Add some bonus XP for testing
      if (tier === 1) addSeasonXP(500);
    }
    
    setClaimingTier(null);
  };

  const progress = getNextTierProgress();
  const seasonProgress = getSeasonProgress();
  const availableCards = getAvailableSeasonalCards();
  const currentTier = getCurrentTier();

  const getSeasonIcon = (seasonNumber: number) => {
    switch (seasonNumber) {
      case 1: return <Snowflake className="w-6 h-6" />;
      case 2: return <Cherry className="w-6 h-6" />;
      default: return <Star className="w-6 h-6" />;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Legendär': return 'from-yellow-400 via-orange-500 to-red-500';
      case 'Episch': return 'from-purple-400 via-pink-500 to-purple-600';
      case 'Selten': return 'from-blue-400 via-cyan-500 to-blue-600';
      default: return 'from-gray-400 via-gray-500 to-gray-600';
    }
  };

  if (!currentSeason) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 flex items-center justify-center">
        <div className="text-center">
          <Clock className="w-16 h-16 text-slate-400 mx-auto mb-4 animate-spin" />
          <p className="text-xl text-slate-400">Lade saisonale Belohnungen...</p>
        </div>
      </div>
    );
  }

  const SeasonalCardComponent = ({ card, isOwned }: { card: SeasonalCard; isOwned: boolean }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.05, y: -5 }}
      className="relative cursor-pointer"
      onClick={() => setShowCardModal(card)}
    >
      <div className={cn(
        "relative rounded-xl p-4 border-2",
        isOwned 
          ? `bg-gradient-to-br ${getRarityColor(card.rarity)} border-transparent` 
          : "bg-slate-800/50 border-slate-600 opacity-60"
      )}>
        {isOwned && (
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-white" />
          </div>
        )}
        
        <div className="text-center">
          <div className="text-4xl mb-3">{card.artwork}</div>
          <h3 className="font-bold text-white text-sm mb-1">{card.nameGerman}</h3>
          <Badge 
            variant="secondary" 
            className={cn(
              "text-xs mb-2",
              card.rarity === 'Legendär' && "bg-yellow-600/30 text-yellow-300",
              card.rarity === 'Episch' && "bg-purple-600/30 text-purple-300",
              card.rarity === 'Selten' && "bg-blue-600/30 text-blue-300"
            )}
          >
            {card.rarity}
          </Badge>
          <p className="text-xs text-slate-300 mb-3">{card.descriptionGerman}</p>
          
          <div className="grid grid-cols-2 gap-1 text-xs">
            {card.values.map((value, index) => (
              <div key={index} className="bg-slate-700/50 rounded px-2 py-1">
                {['⬆️', '➡️', '⬇️', '⬅️'][index]} {value}
              </div>
            ))}
          </div>
          
          {!isOwned && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <div className="text-center">
                <Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-300">Stufe {card.unlockTier}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );

  const TierRewardComponent = ({ tier }: { tier: SeasonalTier }) => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className={cn(
        "relative rounded-xl p-4 md:p-6 border-2 transition-all duration-300",
        tier.claimed 
          ? "bg-green-900/30 border-green-500/50" 
          : tier.unlocked
            ? "bg-gradient-to-r from-yellow-900/50 to-orange-900/50 border-yellow-500/50 shadow-lg shadow-yellow-500/20"
            : "bg-slate-800/50 border-slate-600/50 opacity-70"
      )}
    >
      <div className="flex items-center justify-between mb-4 gap-2">
        <div className="flex items-center gap-2 md:gap-3 min-w-0">
          <div className={cn(
            "w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center border-2 flex-shrink-0",
            tier.claimed 
              ? "bg-green-600 border-green-500" 
              : tier.unlocked
                ? "bg-yellow-600 border-yellow-500"
                : "bg-slate-700 border-slate-600"
          )}>
            <span className="text-lg md:text-xl font-bold text-white">{tier.tier}</span>
          </div>
          <div className="min-w-0">
            <h3 className="text-base md:text-lg font-bold text-white">Stufe {tier.tier}</h3>
            <p className="text-xs md:text-sm text-slate-400">{tier.xpRequired.toLocaleString()} XP erforderlich</p>
          </div>
        </div>
        
        {tier.claimed ? (
          <Badge className="bg-green-600 text-white" size="sm">
            <CheckCircle className="w-4 h-4 md:mr-1" />
            <span className="hidden md:inline">Erhalten</span>
          </Badge>
        ) : tier.unlocked ? (
          <Button
            onClick={() => handleClaimReward(tier.tier)}
            disabled={claimingTier === tier.tier}
            className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold"
            size="sm"
          >
            {claimingTier === tier.tier ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-black/30 border-t-black/70 rounded-full animate-spin" />
                <span className="hidden md:inline">Wird beansprucht...</span>
              </div>
            ) : (
              <>
                <Gift className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Beanspruchen</span>
              </>
            )}
          </Button>
        ) : (
          <Badge variant="secondary" className="text-slate-400" size="sm">
            <Lock className="w-4 h-4 md:mr-1" />
            <span className="hidden md:inline">Gesperrt</span>
          </Badge>
        )}
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        {tier.rewards.diamonds && (
          <div className="bg-slate-700/50 rounded-lg p-2 md:p-3 text-center">
            <Gem className="w-5 h-5 md:w-6 md:h-6 text-blue-400 mx-auto mb-1" />
            <p className="text-xs md:text-sm text-white font-bold">{tier.rewards.diamonds}</p>
            <p className="text-xs text-slate-400">Diamanten</p>
          </div>
        )}
        
        {tier.rewards.packs && (
          <div className="bg-slate-700/50 rounded-lg p-2 md:p-3 text-center">
            <Gift className="w-5 h-5 md:w-6 md:h-6 text-green-400 mx-auto mb-1" />
            <p className="text-xs md:text-sm text-white font-bold">{tier.rewards.packs}</p>
            <p className="text-xs text-slate-400">Kartenpack{tier.rewards.packs > 1 ? 's' : ''}</p>
          </div>
        )}
        
        {tier.rewards.cards && tier.rewards.cards.length > 0 && (
          <div className="bg-slate-700/50 rounded-lg p-2 md:p-3 text-center">
            <Sparkles className="w-5 h-5 md:w-6 md:h-6 text-purple-400 mx-auto mb-1" />
            <p className="text-xs md:text-sm text-white font-bold">{tier.rewards.cards.length}</p>
            <p className="text-xs text-slate-400">Saisonkarte{tier.rewards.cards.length > 1 ? 'n' : ''}</p>
          </div>
        )}
        
        {tier.rewards.titleGerman && (
          <div className="bg-slate-700/50 rounded-lg p-2 md:p-3 text-center">
            <Crown className="w-5 h-5 md:w-6 md:h-6 text-yellow-400 mx-auto mb-1" />
            <p className="text-xs md:text-sm text-white truncate font-bold">{tier.rewards.titleGerman}</p>
            <p className="text-xs text-slate-400">Titel</p>
          </div>
        )}
      </div>
    </motion.div>
  );

  return (
    <div className="space-y-6">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-3 mb-2">
            {getSeasonIcon(currentSeason.number)}
            <h1 className="text-2xl md:text-3xl font-bold text-white">{currentSeason.nameGerman}</h1>
          </div>
          <p className="text-slate-300 text-sm md:text-base">{currentSeason.descriptionGerman}</p>
          {unclaimedRewards > 0 && (
            <Badge className="bg-red-600 text-white animate-pulse mt-2">
              {unclaimedRewards} Neue Belohnungen
            </Badge>
          )}
        </div>

        {/* Season Progress Card */}
        <Card className={cn(
          "mb-6 border-2 bg-gradient-to-r",
          currentSeason.backgroundGradient,
          `border-${currentSeason.accentColor}-500/50`
        )}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="flex items-center gap-2 md:gap-3">
                <Trophy className="w-5 h-5 md:w-6 md:h-6 text-yellow-400" />
                <span className="text-lg md:text-xl">Saisonfortschritt</span>
              </CardTitle>
              <div className="text-right">
                <div className="text-xl md:text-2xl font-bold">{currentSeasonXP.toLocaleString()}</div>
                <div className="text-xs md:text-sm text-slate-300">XP diese Saison</div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-3">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs md:text-sm">Stufe {currentTier} → {currentTier + 1}</span>
                  <span className="text-xs md:text-sm">{progress.current}/{progress.required} XP</span>
                </div>
                <Progress value={progress.percentage} className="h-2 md:h-3" />
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 text-center">
                <div>
                  <div className="text-lg md:text-2xl font-bold text-yellow-400">{currentTier}</div>
                  <div className="text-xs text-slate-400">Aktuelle Stufe</div>
                </div>
                <div>
                  <div className="text-lg md:text-2xl font-bold text-purple-400">{collectedSeasonalCards.length}</div>
                  <div className="text-xs text-slate-400">Saisonkarten</div>
                </div>
                <div>
                  <div className="text-lg md:text-2xl font-bold text-green-400">{seasonProgress.percentage.toFixed(0)}%</div>
                  <div className="text-xs text-slate-400">Saison abgeschlossen</div>
                </div>
                <div>
                  <div className="text-lg md:text-2xl font-bold text-blue-400">
                    {Math.max(0, Math.floor((new Date(currentSeason.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))}
                  </div>
                  <div className="text-xs text-slate-400">Tage verbleibend</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 bg-slate-800 mb-6">
            <TabsTrigger value="progress" className="data-[state=active]:bg-yellow-600 data-[state=active]:text-black text-xs md:text-sm">
              <Target className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Fortschritt</span>
            </TabsTrigger>
            <TabsTrigger value="cards" className="data-[state=active]:bg-yellow-600 data-[state=active]:text-black text-xs md:text-sm">
              <Sparkles className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Karten</span>
            </TabsTrigger>
            <TabsTrigger value="rewards" className="data-[state=active]:bg-yellow-600 data-[state=active]:text-black text-xs md:text-sm">
              <Gift className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Belohnungen</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="progress" className="space-y-6">
            <div className="space-y-4">
              {seasonalTiers.map((tier, index) => (
                <TierRewardComponent key={tier.tier} tier={tier} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="cards" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {availableCards.map(card => (
                <SeasonalCardComponent 
                  key={card.id} 
                  card={card} 
                  isOwned={hasSeasonalCard(card.id)}
                />
              ))}
            </div>
            
            {availableCards.length === 0 && (
              <div className="text-center py-12">
                <Sparkles className="w-16 h-16 text-slate-500 mx-auto mb-4" />
                <p className="text-xl text-slate-400">Keine saisonalen Karten verfügbar</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="rewards" className="space-y-6">
            <div className="text-center py-12">
              <Timer className="w-16 h-16 text-slate-500 mx-auto mb-4" />
              <p className="text-xl text-slate-400">Kommende Belohnungen</p>
              <p className="text-slate-500 mt-2">Spiele mehr Spiele um weitere Belohnungen freizuschalten!</p>
              
              <Button
                onClick={() => addSeasonXP(250)}
                className="mt-4 bg-yellow-600 hover:bg-yellow-700 text-black"
              >
                <Zap className="w-4 h-4 mr-2" />
                Bonus XP erhalten (Demo)
              </Button>
            </div>
          </TabsContent>
        </Tabs>

      {/* Card Detail Modal */}
      <AnimatePresence>
        {showCardModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCardModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 50 }}
              className="bg-slate-800 rounded-xl p-6 max-w-md w-full border-2 border-slate-600"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center space-y-4">
                <div className="text-6xl">{showCardModal.artwork}</div>
                <h2 className="text-2xl font-bold text-white">{showCardModal.nameGerman}</h2>
                <Badge className={cn(
                  showCardModal.rarity === 'Legendär' && "bg-yellow-600",
                  showCardModal.rarity === 'Episch' && "bg-purple-600",
                  showCardModal.rarity === 'Selten' && "bg-blue-600"
                )}>
                  {showCardModal.rarity} • Saison {showCardModal.seasonNumber}
                </Badge>
                
                <p className="text-slate-300">{showCardModal.descriptionGerman}</p>
                
                {showCardModal.effectGerman && (
                  <div className="bg-slate-700 rounded-lg p-3">
                    <h3 className="font-bold text-yellow-400 mb-2">Spezialeffekt:</h3>
                    <p className="text-sm text-slate-300">{showCardModal.effectGerman}</p>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-2">
                  {showCardModal.values.map((value, index) => (
                    <div key={index} className="bg-slate-700 rounded-lg p-3 text-center">
                      <div className="text-2xl mb-1">
                        {['⬆️', '➡️', '⬇️', '⬅️'][index]}
                      </div>
                      <div className="text-xl font-bold text-white">{value}</div>
                    </div>
                  ))}
                </div>
                
                <Button
                  onClick={() => setShowCardModal(null)}
                  variant="outline"
                  className="w-full text-white border-slate-600 hover:bg-slate-700"
                >
                  Schließen
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}