import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCardGame } from "../lib/stores/useCardGame";
import { Card } from "./Card";
import { DynamicBackground } from "./DynamicBackground";
import { smartPlacementAnalyzer, PlacementSuggestion } from "../lib/smartPlacement";
import { SmartPlacementIndicator } from "./SmartPlacementIndicator";
import { PlacementIndicator } from "./PlacementIndicator";
import { InvalidPlacementFeedback } from "./InvalidPlacementFeedback";
import { hapticFeedback } from "../lib/hapticFeedback";
import { GameLayerManager, GameCardSlot } from "./ui/GameLayerManager";
import { DragDropOverlay } from "./DragDropOverlay";
import { DragDropManager } from "../lib/dragAndDrop";

import { cn } from "../lib/utils";
import { GameCard } from "../lib/cardData";
import { X } from "lucide-react";
import { TurnIndicator } from "./TurnIndicator";
import { EffectMessages } from "./EffectMessages";
import { mobileCardSelector } from "../lib/mobileCardSelection";
import { MobileCardHighlight } from "./MobileCardHighlight";


interface GameBoardProps {
  hideTitle?: boolean;
  hideMessages?: boolean;
}

export function GameBoard({ hideTitle = false, hideMessages = false }: GameBoardProps = {}) {
  const { 
    board, 
    placeCard, 
    placeOCard, 
    selectedCard, 
    currentPlayer, 
    gamePhase, 
    boardSize, 
    elementFields, 
    coinFlipWinner, 
    blitzschlagTargets, 
    selectBlitzschlagTarget, 
    cloneTargets, 
    selectCloneTarget, 
    battleAnimations, 
    showPlacementGuide, 
    validPlacementSlots, 
    highlightedSlot, 
    setHighlightedSlot, 
    placementStrategies, 
    showStrategicHints,
    invalidPlacementFeedback,
    showInvalidPlacementFeedback,
    hideInvalidPlacementFeedback,
    player1Hand,
    player2Hand,
    selectCard,
    updateValidPlacementSlots,
    dragState,
    setHoveredSlot,
    handleCardDrop
  } = useCardGame();

  // State for mobile card detail view
  const [selectedCardForDetail, setSelectedCardForDetail] = useState<{ card: GameCard; owner: string; index: number } | null>(null);
  const [touchTimeout, setTouchTimeout] = useState<NodeJS.Timeout | null>(null);

  // Mobile detection and smart placement
  const [isMobile, setIsMobile] = useState(false);
  const [smartPlacements, setSmartPlacements] = useState<PlacementSuggestion[]>([]);
  const [showSmartPlacements, setShowSmartPlacements] = useState(false);
  
  // Drag and drop refs
  const boardRef = useRef<HTMLDivElement>(null);
  const [dragManager] = useState(() => new DragDropManager());
  const [snapTarget, setSnapTarget] = useState<{
    slotIndex: number;
    position: { x: number; y: number; width: number; height: number };
    isValid: boolean;
  } | null>(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768); // md breakpoint
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Initialize drag manager with board element
  useEffect(() => {
    if (boardRef.current) {
      dragManager.setBoardElement(boardRef.current);
    }
  }, [dragManager]);

  // Update snap target when dragging
  useEffect(() => {
    if (dragState.isDragging && dragState.currentPosition) {
      const target = dragManager.getSnapTarget(dragState.currentPosition, validPlacementSlots);
      if (target) {
        setSnapTarget({
          slotIndex: target.slotIndex,
          position: target.position,
          isValid: target.isValid
        });
        setHoveredSlot(target.slotIndex);
      } else {
        setSnapTarget(null);
        setHoveredSlot(null);
      }
    } else {
      setSnapTarget(null);
      setHoveredSlot(null);
    }
  }, [dragState.isDragging, dragState.currentPosition, validPlacementSlots, dragManager, setHoveredSlot]);

  // Analyze smart placements when card is selected and mobile
  useEffect(() => {
    if (isMobile && selectedCard && validPlacementSlots.length > 0) {
      const playerOwner = selectedCard.player === 1 ? "player1" : "player2";
      // Filter board to only include non-null slots for analysis
      const filteredBoard = board.map(slot => 
        slot && slot.owner !== "neutral" ? { card: slot.card, owner: slot.owner as "player1" | "player2" } : null
      );
      // Get the selected card from hand
      const { player1Hand, player2Hand } = useCardGame.getState();
      const hand = selectedCard.player === 1 ? player1Hand : player2Hand;
      const card = hand[selectedCard.cardIndex];

      if (card) {
        const analysis = smartPlacementAnalyzer.analyzePlacements(
          card,
          filteredBoard,
          validPlacementSlots,
          playerOwner
        );
        setSmartPlacements(analysis.suggestions);
        setShowSmartPlacements(true);
      }
    } else {
      setSmartPlacements([]);
      setShowSmartPlacements(false);
    }
  }, [isMobile, selectedCard, validPlacementSlots, board]);

  // Auto-hide smart placements after delay
  useEffect(() => {
    if (showSmartPlacements) {
      const timer = setTimeout(() => {
        setShowSmartPlacements(false);
      }, 8000); // Show for 8 seconds

      return () => clearTimeout(timer);
    }
  }, [showSmartPlacements]);



  // Helper function to get element info for a position
  const getElementInfo = (position: number) => {
    return elementFields.find(field => field.position === position);
  };

  // Helper function to get element styling
  const getElementStyling = (element: string) => {
    switch (element) {
      case "fire":
        return "border-red-500 bg-red-900/20";
      case "water":
        return "border-blue-500 bg-blue-900/20";
      case "earth":
        return "border-amber-600 bg-amber-900/20";
      case "lightning":
        return "border-yellow-400 bg-yellow-900/20";
      default:
        return "";
    }
  };

  // Helper function to get element emoji
  const getElementEmoji = (element: string) => {
    switch (element) {
      case "fire":
        return "🔥";
      case "water":
        return "💧";
      case "earth":
        return "🌍";
      case "lightning":
        return "⚡";
      default:
        return "";
    }
  };

  // Helper function to get adjacent positions for any grid size
  const getAdjacentPositions = (index: number, size: number): number[] => {
    const row = Math.floor(index / size);
    const col = index % size;
    const adjacent: number[] = [];

    // Check all 4 directions: up, right, down, left
    const directions = [
      [-1, 0], // up
      [0, 1],  // right
      [1, 0],  // down
      [0, -1]  // left
    ];

    directions.forEach(([dRow, dCol]) => {
      const newRow = row + dRow;
      const newCol = col + dCol;

      // Check if new position is within bounds
      if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size) {
        adjacent.push(newRow * size + newCol);
      }
    });

    return adjacent;
  };

  // Helper function to count adjacent cards for tooltip effects
  const getAdjacentCardsInfo = (index: number) => {
    const slot = board[index];
    if (!slot) return { 
      adjacentOwnCards: 0, 
      adjacentSameElementCards: 0, 
      isOCardOwner: false,
      adjacentToOCard: false 
    };

    const adjacentPositions = getAdjacentPositions(index, gridSize);
    let adjacentOwnCards = 0;
    let adjacentSameElementCards = 0;
    let adjacentToOCard = false;

    adjacentPositions.forEach(pos => {
      const adjacentSlot = board[pos];
      if (adjacentSlot && adjacentSlot.card) {
        // Count adjacent cards of same owner (for verstärkung effect)
        if (adjacentSlot.owner === slot.owner) {
          adjacentOwnCards++;
        }

        // Count adjacent cards of same element (for stärkung effect)
        if (adjacentSlot.card.element === slot.card.element) {
          adjacentSameElementCards++;
        }

        // Check if adjacent to O-card
        if (adjacentSlot.card.id === "O") {
          adjacentToOCard = true;
        }
      }
    });

    // Check if this slot owner is the O-card owner
    const { oCardOwner } = useCardGame.getState();
    const isOCardOwner = slot.owner === oCardOwner && oCardOwner !== "neutral";



    return { 
      adjacentOwnCards, 
      adjacentSameElementCards, 
      isOCardOwner,
      adjacentToOCard 
    };
  };

  const handleSlotClick = (slotIndex: number, event?: React.MouseEvent) => {
    if (gamePhase === "place-o-card") {
      if (board[slotIndex]) {
        // Show feedback for occupied slot
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Position bereits belegt!"
          );
        }
        return;
      }
      placeOCard(slotIndex);
      hapticFeedback.cardPlace();
    } else if (gamePhase === "blitzschlag-target") {
      if (!blitzschlagTargets.includes(slotIndex)) {
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Blitzschlag kann diese Karte nicht angreifen!"
          );
        }
        return;
      }
      selectBlitzschlagTarget(slotIndex);
      hapticFeedback.cardBattle();
    } else if (gamePhase === "clone-target") {
      if (!cloneTargets.includes(slotIndex)) {
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Clone kann diese Karte nicht kopieren!"
          );
        }
        return;
      }
      selectCloneTarget(slotIndex);
      hapticFeedback.medium();
    } else if (gamePhase === "playing") {
      if (!selectedCard) {
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Wählen Sie zuerst eine Karte aus der Hand!"
          );
        }
        hapticFeedback.warning();
        return;
      }
      if (board[slotIndex]) {
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Position bereits belegt!"
          );
        }
        hapticFeedback.error();
        return;
      }
      if (!validPlacementSlots.includes(slotIndex)) {
        if (event) {
          const rect = (event.target as Element).getBoundingClientRect();
          showInvalidPlacementFeedback(
            { x: rect.left + rect.width / 2, y: rect.top },
            "Wählen Sie eine grün markierte Position!"
          );
        }
        hapticFeedback.warning();
        return;
      }
      placeCard(slotIndex);
      hapticFeedback.cardPlace();
    }
  };

  // Touch handlers for mobile
  const handleTouchStart = (index: number) => {
    // Clear any existing timeout
    if (touchTimeout) {
      clearTimeout(touchTimeout);
      setTouchTimeout(null);
    }

    // Show placement guide for valid slots
    if (validPlacementSlots.includes(index)) {
      setHighlightedSlot(index);
    }

    // Show card detail if there's a card at this position
    if (board[index] && board[index]!.card) {
      const timeout = setTimeout(() => {
        setSelectedCardForDetail({
          card: board[index]!.card,
          owner: board[index]!.owner,
          index: index
        });
      }, 500); // Show detail after 0.5s hold
      setTouchTimeout(timeout);
    }
  };

  const handleTouchEnd = (index: number) => {
    // Clear timeout
    if (touchTimeout) {
      clearTimeout(touchTimeout);
      setTouchTimeout(null);
    }

    // Execute click action
    handleSlotClick(index);

    // Clear highlight after short delay
    setTimeout(() => setHighlightedSlot(null), 150);
  };

  const handleTouchCancel = () => {
    if (touchTimeout) {
      clearTimeout(touchTimeout);
      setTouchTimeout(null);
    }
    setHighlightedSlot(null);
  };

  // Only 4x4 is supported
  const gridSize = 4;
  const centerIndex = -1; // No center in 4x4
  const gridCols = "grid-cols-4";

  const totalSlots = gridSize * gridSize;

  return (
    <>
      <DynamicBackground>
        <div />
      </DynamicBackground>
      <div className={cn(
        "bg-slate-800/90 backdrop-blur-sm rounded-xl shadow-2xl overflow-visible border border-white/10",
        isMobile ? "p-0.5" : "p-4 sm:p-6 md:p-8"
      )}>
      {!hideTitle && !isMobile && (
        <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-center mb-2 sm:mb-4 md:mb-6 text-slate-100">
          Battle Grid ({boardSize})
        </h2>
      )}

      {!hideMessages && gamePhase === "place-o-card" && (
        <div className="bg-yellow-600 text-black p-3 rounded-lg mb-4 text-center">
          <p className="font-bold">
            {coinFlipWinner === 1 ? "Du darfst" : "Spieler 2 darf"} die O-Karte platzieren!
          </p>
          <p className="text-sm">Klicke auf ein freies Feld, um die O-Karte zu platzieren.</p>
        </div>
      )}

      {!hideMessages && gamePhase === "blitzschlag-target" && (
        <div className="bg-red-600 text-white p-3 rounded-lg mb-4 text-center">
          <p className="font-bold">🗲 Blitzschlag aktiviert!</p>
          <p className="text-sm">Klicke auf eine gegnerische Karte, um ihr -2 Schaden zuzufügen.</p>
        </div>
      )}

      {!hideMessages && gamePhase === "clone-target" && (
        <div className="bg-blue-600 text-white p-3 rounded-lg mb-4 text-center">
          <p className="font-bold">👥 Clone aktiviert!</p>
          <p className="text-sm">Klicke auf eine benachbarte Karte, um ihre Werte zu kopieren.</p>
        </div>
      )}

      {!hideMessages && !isMobile && showPlacementGuide && selectedCard && validPlacementSlots.length > 0 && gamePhase === "playing" && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white p-4 rounded-xl mb-4 text-center shadow-lg border border-emerald-500/30"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <motion.div 
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-3 h-3 bg-emerald-300 rounded-full"
            />
            <p className="font-bold text-lg">🎯 Platzierungshilfe aktiv</p>
            <motion.div 
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
              className="w-3 h-3 bg-emerald-300 rounded-full"
            />
          </div>
          <p className="text-sm text-emerald-100">
            Wählen Sie eine <span className="font-bold text-white">grün markierte Position</span> für Ihre Karte
          </p>
          <div className="flex items-center justify-center gap-4 mt-3 text-xs">
            <span className="flex items-center gap-1">
              <div className="w-3 h-3 bg-emerald-400 rounded border border-emerald-300"></div>
              Gültige Position
            </span>
            <span className="flex items-center gap-1">
              <div className="w-3 h-3 bg-emerald-300 rounded border border-emerald-200"></div>
              Ausgewählte Position
            </span>
            <span className="text-emerald-200">
              {validPlacementSlots.length} verfügbar
            </span>
          </div>
        </motion.div>
      )}

      <div className={cn(
        "grid justify-center items-center max-w-full overflow-visible relative z-10 mx-auto", 
        boardSize === "4x4" ? "grid-cols-4" : "grid-cols-3",
        boardSize === "4x4" ? (isMobile ? "gap-4" : "gap-4 sm:gap-4 md:gap-5") : "gap-2 sm:gap-3 md:gap-4"
      )} 
           style={{ 
             maxWidth: isMobile ? 'calc(100vw - 6px)' : 'min(100vw - 0.5rem, 100%)',
             width: isMobile ? '100%' : 'auto',
             margin: '0 auto',
             transform: 'none',
             padding: '0',
             justifySelf: 'center',
             alignSelf: 'center'
           }}>
        {Array.from({ length: totalSlots }, (_, index) => {
          const elementInfo = getElementInfo(index);
          return (
            <div
              key={index}
              ref={boardRef}
              data-slot-index={index}
              className={cn(
                "w-full h-full flex items-center justify-center relative border-2 rounded-lg cursor-pointer",
                // Mobile 4x4 optimized sizing - larger for mobile
                boardSize === "4x4" && "w-22 h-32 sm:w-32 sm:h-44 md:w-36 md:h-56",
                // Placement guide highlighting - most prominent with enhanced visuals
                showPlacementGuide && validPlacementSlots.includes(index) && selectedCard && gamePhase === "playing"
                  ? highlightedSlot === index
                    ? "bg-gradient-to-br from-emerald-400/60 to-emerald-600/60 border-emerald-300 border-4 shadow-xl shadow-emerald-300/50 placement-guide-slot-hover animate-pulse"
                    : "bg-gradient-to-br from-emerald-500/40 to-emerald-700/40 border-emerald-400 border-3 placement-guide-slot ring-2 ring-emerald-400/30"
                  : highlightedSlot === index && validPlacementSlots.includes(index)
                  ? "bg-gradient-to-br from-emerald-400/70 to-emerald-600/70 border-emerald-200 border-4 shadow-2xl shadow-emerald-300/60 placement-guide-slot-hover"
                  // Original conditional styling
                  : selectedCard && !board[index] && gamePhase === "playing" && selectedCard.player === 1
                  ? "bg-slate-700 hover:bg-slate-600 border-green-500 hover:border-green-400" 
                  : selectedCard && !board[index] && gamePhase === "playing" && selectedCard.player === 2
                  ? "bg-slate-700 hover:bg-slate-600 border-red-500 hover:border-red-400"
                  : gamePhase === "place-o-card" && !board[index]
                  ? "bg-yellow-900 hover:bg-yellow-800 border-yellow-400"
                  : gamePhase === "blitzschlag-target" && blitzschlagTargets.includes(index)
                  ? "bg-red-900 hover:bg-red-800 border-red-400"
                  : gamePhase === "clone-target" && cloneTargets.includes(index)
                  ? "bg-blue-900 hover:bg-blue-800 border-blue-400"
                  : board[index]?.owner === "player1"
                  ? "bg-slate-900 border-green-500/60"
                  : board[index]?.owner === "player2"
                  ? "bg-slate-900 border-red-500/60"
                  : board[index]?.owner === "neutral"
                  ? "bg-slate-900 border-yellow-500/60"
                  : "bg-slate-900 border-slate-600",
                centerIndex !== -1 && index === centerIndex && "border-yellow-500 border-4",
                elementInfo && getElementStyling(elementInfo.element)
              )}
              style={{ 
                width: isMobile ? '85px' : '128px',
                height: isMobile ? '118px' : '192px'
              }}
              onClick={(e) => {
                e.stopPropagation();
                handleSlotClick(index, e);
              }}
              onMouseEnter={() => validPlacementSlots.includes(index) && setHighlightedSlot(index)}
              onMouseLeave={() => setHighlightedSlot(null)}
              onTouchStart={() => handleTouchStart(index)}
              onTouchEnd={() => handleTouchEnd(index)}
              onTouchCancel={handleTouchCancel}

            >
              {board[index] && (() => {
                const adjacentInfo = getAdjacentCardsInfo(index);
                return (
                  <div className={cn(
                    "relative h-full w-full rounded-lg overflow-visible",
                    board[index]!.owner === "player1" && "bg-blue-600/40",
                    board[index]!.owner === "player2" && "bg-red-600/40", 
                    board[index]!.owner === "neutral" && "bg-yellow-600/40",
                    gamePhase === "blitzschlag-target" && blitzschlagTargets.includes(index) && "ring-4 ring-red-400 ring-opacity-75",
                    gamePhase === "clone-target" && cloneTargets.includes(index) && "ring-4 ring-blue-400 ring-opacity-75"
                  )}>
                    <div className="absolute inset-0 flex items-center justify-center overflow-visible">
                      <Card
                        card={board[index]!.card}
                      owner={board[index]!.owner}
                      originalCard={board[index]!.originalCard}
                      size={isMobile ? "tiny" : "large"}
                      isOnBoard={true}
                      elementBonus={elementInfo && board[index]!.originalCard && board[index]!.originalCard.element === elementInfo.element}
                      showEffectBonuses={true}
                      shieldBroken={board[index]!.shieldBroken}
                      animation={battleAnimations[index]}
                      adjacentOwnCards={adjacentInfo.adjacentOwnCards}
                      adjacentSameElementCards={adjacentInfo.adjacentSameElementCards}
                      isOCardOwner={adjacentInfo.isOCardOwner}
                        adjacentToOCard={adjacentInfo.adjacentToOCard}
                        isClickable={gamePhase === "blitzschlag-target" && blitzschlagTargets.includes(index) || 
                                   gamePhase === "clone-target" && cloneTargets.includes(index)}
                        isDisabled={!(gamePhase === "blitzschlag-target" && blitzschlagTargets.includes(index) || 
                                    gamePhase === "clone-target" && cloneTargets.includes(index))}
                      />
                    </div>
                  </div>
                );
              })()}
              {!board[index] && (
                <div className="absolute inset-0 flex items-center justify-center">
                  {/* Element field display */}
                  {elementInfo && (
                    <span className="text-2xl sm:text-3xl md:text-4xl opacity-40">
                      {getElementEmoji(elementInfo.element)}
                    </span>
                  )}

                  {/* Enhanced placement indicators */}
                  {showPlacementGuide && validPlacementSlots.includes(index) && selectedCard && gamePhase === "playing" && (
                    <PlacementIndicator
                      strategy={placementStrategies[index]}
                      isHighlighted={highlightedSlot === index}
                      isEmpty={true}
                      showStrategicHints={showStrategicHints}
                    />
                  )}

                  {/* Smart Placement Indicators for Mobile */}
                  {isMobile && showSmartPlacements && smartPlacements.find(s => s.index === index) && (
                    <SmartPlacementIndicator
                      suggestion={smartPlacements.find(s => s.index === index)!}
                      isVisible={true}
                      intensity={1}
                    />
                  )}

                  {/* Hover effect for valid placement slots */}
                  {highlightedSlot === index && validPlacementSlots.includes(index) && (
                    <div className="absolute inset-0 bg-emerald-300/20 rounded-lg animate-pulse" />
                  )}

                  {/* Default slot display for non-placement guide modes */}
                  {!(showPlacementGuide && validPlacementSlots.includes(index) && selectedCard && gamePhase === "playing") && (
                    <div className="flex flex-col items-center justify-center">
                      {selectedCard && gamePhase === "playing" && (
                        <div className="text-slate-500 text-xs text-center">
                          {centerIndex !== -1 && index === centerIndex ? "Center" : elementInfo ? elementInfo.element : `Slot ${index + 1}`}
                        </div>
                      )}
                      {gamePhase === "place-o-card" && (
                        <div className="text-yellow-400 text-xs text-center font-bold">
                          O-Card hier platzieren
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
              
              {/* Drop zone for drag and drop */}
              {dragState.isDragging && !board[index] && (
                <div 
                  className="absolute inset-0 z-20 pointer-events-auto"
                  onPointerEnter={() => setHoveredSlot(index)}
                  onPointerLeave={() => setHoveredSlot(null)}
                  onPointerUp={() => handleCardDrop(index)}
                />
              )}
            </div>
          );
        })}
      </div>
      
      {/* Drag and Drop Overlay */}
      <DragDropOverlay 
        draggedCard={dragState.draggedCard}
        dragPosition={dragState.currentPosition}
        isDragging={dragState.isDragging}
        snapTarget={snapTarget}
      />

      {/* Mobile Card Detail Modal */}
      <AnimatePresence>
        {selectedCardForDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
            onClick={() => setSelectedCardForDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-slate-800 rounded-xl p-4 sm:p-6 w-full max-w-xs sm:max-w-sm mx-4 relative border border-white/20"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedCardForDetail(null)}
                className="absolute top-3 right-3 p-2 rounded-full bg-slate-700 hover:bg-slate-600 text-white"
              >
                <X size={18} />
              </button>

              <div className="text-center mb-4">
                <h3 className="text-xl font-bold text-white mb-2">
                  {selectedCardForDetail.card.name}
                </h3>
                <p className="text-sm text-slate-400">
                  Besitzer: {selectedCardForDetail.owner === "player1" ? "Du" : 
                             selectedCardForDetail.owner === "player2" ? "Gegner" : "Neutral"}
                </p>
              </div>

              <div className="flex justify-center mb-4">
                <Card
                  card={selectedCardForDetail.card}
                  owner={selectedCardForDetail.owner as "player1" | "player2" | "neutral"}
                  size="medium"
                  isOnBoard={false}
                  showTooltip={false}
                />
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-slate-700 p-3 rounded-lg">
                  <div className="text-slate-400 mb-1">Werte</div>
                  <div className="space-y-1 text-white">
                    <div>↑ {selectedCardForDetail.card.top}</div>
                    <div>→ {selectedCardForDetail.card.right}</div>
                    <div>↓ {selectedCardForDetail.card.bottom}</div>
                    <div>← {selectedCardForDetail.card.left}</div>
                  </div>
                </div>

                <div className="bg-slate-700 p-3 rounded-lg">
                  <div className="text-slate-400 mb-1">Element</div>
                  <div className="text-white">
                    {selectedCardForDetail.card.element === "fire" && "🔥 Feuer"}
                    {selectedCardForDetail.card.element === "water" && "💧 Wasser"}
                    {selectedCardForDetail.card.element === "earth" && "🌍 Erde"}
                    {selectedCardForDetail.card.element === "lightning" && "⚡ Blitz"}
                    {!selectedCardForDetail.card.element && "🔘 Neutral"}
                  </div>
                </div>
              </div>

              {selectedCardForDetail.card.effect && (
                <div className="mt-3 bg-slate-700 p-3 rounded-lg">
                  <div className="text-white text-xs sm:text-sm break-words">
                    {selectedCardForDetail.card.effect === "schild" && (
                      <>
                        <div className="font-bold text-blue-400 mb-1 text-sm sm:text-base">🛡️ Schild</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Blockiert den ersten Angriff vollständig</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "blitzschlag" && (
                      <>
                        <div className="font-bold text-red-400 mb-1 text-sm sm:text-base">🗲 Blitzschlag</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Wähle eine gegnerische Karte und reduziere alle ihre Werte um 2</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "clone" && (
                      <>
                        <div className="font-bold text-purple-400 mb-1 text-sm sm:text-base">👥 Clone</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Kopiert die Werte einer benachbarten Karte beim Platzieren</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "berserker" && (
                      <>
                        <div className="font-bold text-red-400 mb-1 text-sm sm:text-base">⚔️ Berserker</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Verdoppelte Werte im ersten Kampf – wird dann eine neutrale Karte</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "staerkung" && (
                      <>
                        <div className="font-bold text-green-400 mb-1 text-sm sm:text-base">💪 Stärkung</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Erhöht sich pro angrenzender eigener Karte um +1 je Wert</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "stachelruestung" && (
                      <>
                        <div className="font-bold text-orange-400 mb-1 text-sm sm:text-base">🌵 Stachelrüstung</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Bei Übernahme verliert der Angreifer –1 auf alle Werte</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "anker" && (
                      <>
                        <div className="font-bold text-gray-400 mb-1 text-sm sm:text-base">⚓ Anker</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Diese Karte kann nicht verschoben oder zerstört werden</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "infektion" && (
                      <>
                        <div className="font-bold text-green-600 mb-1 text-sm sm:text-base">🦠 Infektion</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Karte kämpft nicht, alle gegnerischen Karten (außer O-Karte) verlieren –1 auf alle Werte</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "sniper" && (
                      <>
                        <div className="font-bold text-yellow-600 mb-1 text-sm sm:text-base">🎯 Sniper</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Kann direkt eine beliebige gegnerische Karte angreifen</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "verstaerkung" && (
                      <>
                        <div className="font-bold text-cyan-400 mb-1 text-sm sm:text-base">⚡ Verstärkung</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Gibt benachbarten eigenen Karten +1 auf alle Werte</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "stille" && (
                      <>
                        <div className="font-bold text-indigo-400 mb-1 text-sm sm:text-base">🤫 Stille</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Deaktiviert alle Karteneffekte in einem Radius von 2 Feldern</div>
                      </>
                    )}
                    {selectedCardForDetail.card.effect === "tarnung" && (
                      <>
                        <div className="font-bold text-gray-500 mb-1 text-sm sm:text-base">🫥 Tarnung</div>
                        <div className="text-xs sm:text-sm leading-relaxed">Kann in der nächsten Runde nicht angegriffen werden.</div>
                      </>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Invalid Placement Feedback */}
      {invalidPlacementFeedback && (
        <InvalidPlacementFeedback
          isVisible={invalidPlacementFeedback.isVisible}
          position={invalidPlacementFeedback.position}
          message={invalidPlacementFeedback.message}
          onComplete={hideInvalidPlacementFeedback}
        />
      )}

      {/* Mobile Card Highlight Overlay */}
      <MobileCardHighlight 
        isVisible={false}
        mode="selection"
        intensity="medium"
        cardIndex={0}
      />




    </div>
    </>
  );
}