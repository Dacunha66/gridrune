import React from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import { LayeredContainer } from './LayeredContainer';

interface LoadingOverlayProps {
  isVisible: boolean;
  message?: string;
  progress?: number;
}

export function LoadingOverlay({ isVisible, message = 'Laden...', progress }: LoadingOverlayProps) {
  if (!isVisible) return null;

  return (
    <LayeredContainer
      layer="LOADING_SCREEN"
      overlay
      blur
      className="bg-black/80 flex items-center justify-center"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-slate-900 rounded-lg p-8 border border-slate-600 shadow-2xl text-center max-w-sm w-full mx-4"
      >
        <Loader2 className="w-12 h-12 text-blue-400 animate-spin mx-auto mb-4" />
        
        <h3 className="text-lg font-semibold text-white mb-2">{message}</h3>
        
        {progress !== undefined && (
          <div className="w-full bg-slate-700 rounded-full h-2 mb-4">
            <motion.div
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        )}
        
        <p className="text-slate-400 text-sm">Bitte warten...</p>
      </motion.div>
    </LayeredContainer>
  );
}

interface ErrorOverlayProps {
  isVisible: boolean;
  title?: string;
  message: string;
  onRetry?: () => void;
  onDismiss?: () => void;
}

export function ErrorOverlay({ 
  isVisible, 
  title = 'Fehler', 
  message, 
  onRetry, 
  onDismiss 
}: ErrorOverlayProps) {
  if (!isVisible) return null;

  return (
    <LayeredContainer
      layer="ERROR_OVERLAY"
      overlay
      blur
      className="bg-black/80 flex items-center justify-center"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-red-900/90 rounded-lg p-8 border border-red-500 shadow-2xl text-center max-w-md w-full mx-4"
      >
        <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">⚠️</span>
        </div>
        
        <h3 className="text-xl font-bold text-red-100 mb-2">{title}</h3>
        <p className="text-red-200 mb-6 leading-relaxed">{message}</p>
        
        <div className="flex gap-3 justify-center">
          {onRetry && (
            <button
              onClick={onRetry}
              className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-semibold"
            >
              Erneut versuchen
            </button>
          )}
          {onDismiss && (
            <button
              onClick={onDismiss}
              className="px-6 py-2 bg-slate-600 hover:bg-slate-700 text-white rounded-lg transition-colors"
            >
              Schließen
            </button>
          )}
        </div>
      </motion.div>
    </LayeredContainer>
  );
}