import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Eye, EyeOff, Volume2, VolumeX, Trash2, RotateCcw } from 'lucide-react';
import { LayeredContainer } from './LayeredContainer';
import { useLayerManagerContext } from '../../contexts/LayerManagerContext';
import { useCardGame } from '../../lib/stores/useCardGame';
import { useAudio } from '../../lib/stores/useAudio';
import { Z_INDEX } from '../../lib/constants/zIndex';

interface DebugPanelProps {
  isVisible?: boolean;
  onToggle?: () => void;
}

export function DebugPanel({ isVisible = false, onToggle }: DebugPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const layerManager = useLayerManagerContext();
  const { gamePhase, currentPlayer, boardSize, gameMode } = useCardGame();
  const { isMuted, masterVolume } = useAudio();

  const handleClearLayers = (type: 'modal' | 'overlay' | 'notification' | 'all') => {
    layerManager.clearLayers(type);
  };

  return (
    <LayeredContainer layer="DEBUG_PANEL">
      <motion.div
        className="fixed bottom-4 left-4"
        initial={false}
        animate={{
          width: isExpanded ? 320 : 48,
          height: isExpanded ? 'auto' : 48
        }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        <div className="bg-slate-900/95 backdrop-blur-sm border border-slate-600 rounded-lg shadow-2xl overflow-hidden">
          {/* Toggle Button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-12 h-12 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* Debug Content */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 pt-0 text-xs text-slate-300 space-y-3"
              >
                {/* Game State */}
                <div>
                  <h4 className="text-white font-semibold mb-2">Spielstatus</h4>
                  <div className="space-y-1">
                    <div>Phase: <span className="text-blue-400">{gamePhase}</span></div>
                    <div>Spieler: <span className="text-green-400">{currentPlayer}</span></div>
                    <div>Board: <span className="text-purple-400">{boardSize}</span></div>
                    <div>Modus: <span className="text-yellow-400">{gameMode}</span></div>
                  </div>
                </div>

                {/* Layer Manager State */}
                <div>
                  <h4 className="text-white font-semibold mb-2">Layer-System</h4>
                  <div className="space-y-1">
                    <div>Aktive Modals: <span className="text-blue-400">{layerManager.layerState.activeModals.length}</span></div>
                    <div>Game Overlays: <span className="text-green-400">{layerManager.layerState.gameOverlays.length}</span></div>
                    <div>Benachrichtigungen: <span className="text-yellow-400">{layerManager.layerState.notifications.length}</span></div>
                    <div>Max Z-Index: <span className="text-purple-400">{layerManager.layerState.currentMaxZIndex}</span></div>
                  </div>
                </div>

                {/* Audio State */}
                <div>
                  <h4 className="text-white font-semibold mb-2">Audio</h4>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                      <span>{isMuted ? 'Stumm' : 'Aktiv'}</span>
                    </div>
                    <div>Lautstärke: <span className="text-blue-400">{Math.round(masterVolume * 100)}%</span></div>
                  </div>
                </div>

                {/* Layer Controls */}
                <div>
                  <h4 className="text-white font-semibold mb-2">Layer-Kontrollen</h4>
                  <div className="grid grid-cols-2 gap-1">
                    <button
                      onClick={() => handleClearLayers('modal')}
                      className="px-2 py-1 bg-blue-600/20 border border-blue-500/30 rounded text-blue-300 hover:bg-blue-600/30 transition-colors"
                    >
                      Clear Modals
                    </button>
                    <button
                      onClick={() => handleClearLayers('overlay')}
                      className="px-2 py-1 bg-green-600/20 border border-green-500/30 rounded text-green-300 hover:bg-green-600/30 transition-colors"
                    >
                      Clear Overlays
                    </button>
                    <button
                      onClick={() => handleClearLayers('notification')}
                      className="px-2 py-1 bg-yellow-600/20 border border-yellow-500/30 rounded text-yellow-300 hover:bg-yellow-600/30 transition-colors"
                    >
                      Clear Notifs
                    </button>
                    <button
                      onClick={() => handleClearLayers('all')}
                      className="px-2 py-1 bg-red-600/20 border border-red-500/30 rounded text-red-300 hover:bg-red-600/30 transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                {/* Z-Index Reference */}
                <div>
                  <h4 className="text-white font-semibold mb-2">Z-Index Referenz</h4>
                  <div className="space-y-1 max-h-20 overflow-y-auto">
                    <div>Cards: <span className="text-blue-400">{Z_INDEX.CARDS}</span></div>
                    <div>Modals: <span className="text-green-400">{Z_INDEX.MODAL_CONTENT}</span></div>
                    <div>Game Overlay: <span className="text-purple-400">{Z_INDEX.GAME_OVERLAY}</span></div>
                    <div>Emergency: <span className="text-red-400">{Z_INDEX.EMERGENCY}</span></div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </LayeredContainer>
  );
}