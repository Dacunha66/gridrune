import React from 'react';
import { motion } from 'framer-motion';
import { Z_INDEX, zIndexClass } from '../../lib/constants/zIndex';
import { cn } from '../../lib/utils';

interface LayeredContainerProps {
  children: React.ReactNode;
  layer: keyof typeof Z_INDEX;
  className?: string;
  animated?: boolean;
  blur?: boolean;
  overlay?: boolean;
  onClick?: () => void;
}

/**
 * LayeredContainer component for managing z-index layers consistently
 */
export function LayeredContainer({
  children,
  layer,
  className = '',
  animated = false,
  blur = false,
  overlay = false,
  onClick
}: LayeredContainerProps) {
  const zIndex = Z_INDEX[layer];
  const baseClasses = cn(
    'relative',
    zIndexClass(zIndex),
    blur && 'backdrop-blur-sm',
    overlay && 'fixed inset-0',
    className
  );

  if (animated) {
    return (
      <motion.div
        className={baseClasses}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={onClick}
      >
        {children}
      </motion.div>
    );
  }

  return (
    <div className={baseClasses} onClick={onClick}>
      {children}
    </div>
  );
}

/**
 * Modal backdrop component with proper layering
 */
export function ModalBackdrop({
  children,
  onClose,
  className = ''
}: {
  children: React.ReactNode;
  onClose?: () => void;
  className?: string;
}) {
  return (
    <LayeredContainer
      layer="MODAL_BACKDROP"
      overlay
      blur
      animated
      onClick={onClose}
      className={cn('bg-black/50 flex items-center justify-center p-4', className)}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={(e) => e.stopPropagation()}
        className={zIndexClass(Z_INDEX.MODAL_CONTENT)}
      >
        {children}
      </motion.div>
    </LayeredContainer>
  );
}

/**
 * Game overlay component for battle effects and animations
 */
export function GameOverlay({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <LayeredContainer
      layer="GAME_OVERLAY"
      className={cn('absolute inset-0 pointer-events-none', className)}
    >
      {children}
    </LayeredContainer>
  );
}

/**
 * Notification container with proper stacking
 */
export function NotificationContainer({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <LayeredContainer
      layer="NOTIFICATION"
      className={cn('fixed top-4 right-4 space-y-2', className)}
    >
      {children}
    </LayeredContainer>
  );
}

/**
 * Toast container with highest priority for user feedback
 */
export function ToastContainer({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <LayeredContainer
      layer="TOAST"
      className={cn('fixed bottom-4 right-4 space-y-2', className)}
    >
      {children}
    </LayeredContainer>
  );
}