import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LayeredContainer, GameOverlay } from './LayeredContainer';
import { Z_CATEGORIES } from '../../lib/constants/zIndex';
import { cn } from '../../lib/utils';

interface GameLayerManagerProps {
  children: React.ReactNode;
  showPlacementGuide?: boolean;
  showBattleEffects?: boolean;
  showTurnIndicator?: boolean;
  className?: string;
}

/**
 * GameLayerManager orchestrates all game-related visual layers
 * Ensures proper z-index management for game elements
 */
export function GameLayerManager({
  children,
  showPlacementGuide = false,
  showBattleEffects = false,
  showTurnIndicator = false,
  className = ''
}: GameLayerManagerProps) {
  return (
    <LayeredContainer 
      layer="GAME_BOARD" 
      className={cn('relative w-full h-full', className)}
    >
      {/* Base game content */}
      {children}

      {/* Placement Guide Overlay */}
      <AnimatePresence>
        {showPlacementGuide && (
          <LayeredContainer layer="PLACEMENT_GUIDE">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 pointer-events-none"
            >
              {/* Placement guide visualization */}
              <div className="absolute inset-0 bg-blue-500/10 rounded-lg border-2 border-blue-400/50 animate-pulse" />
            </motion.div>
          </LayeredContainer>
        )}
      </AnimatePresence>

      {/* Battle Effects Overlay */}
      <AnimatePresence>
        {showBattleEffects && (
          <LayeredContainer layer="BATTLE_EFFECTS">
            <GameOverlay>
              {/* Battle animations and effects will be rendered here */}
              <div className="absolute inset-0 pointer-events-none">
                {/* Effect particles, damage numbers, etc. */}
              </div>
            </GameOverlay>
          </LayeredContainer>
        )}
      </AnimatePresence>

      {/* Turn Indicator Overlay */}
      <AnimatePresence>
        {showTurnIndicator && (
          <LayeredContainer layer="TURN_INDICATOR">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-slate-900/90 backdrop-blur-sm rounded-lg px-4 py-2 border border-slate-600 shadow-lg"
            >
              <div className="text-white text-sm font-semibold">
                Dein Zug
              </div>
            </motion.div>
          </LayeredContainer>
        )}
      </AnimatePresence>
    </LayeredContainer>
  );
}

/**
 * Card slot component with proper layering for hover and selection states
 */
interface GameCardSlotProps {
  children?: React.ReactNode;
  isHighlighted?: boolean;
  isSelected?: boolean;
  isValidPlacement?: boolean;
  onClick?: () => void;
  className?: string;
}

export function GameCardSlot({
  children,
  isHighlighted = false,
  isSelected = false,
  isValidPlacement = false,
  onClick,
  className = ''
}: GameCardSlotProps) {
  return (
    <LayeredContainer
      layer="CARDS"
      className={cn(
        'relative aspect-[2/3] rounded-lg border-2 transition-all duration-200 cursor-pointer',
        isSelected && 'border-blue-400 bg-blue-400/20',
        isHighlighted && 'border-yellow-400 bg-yellow-400/20',
        isValidPlacement && 'border-green-400 bg-green-400/20',
        !isSelected && !isHighlighted && !isValidPlacement && 'border-slate-600 bg-slate-800/50',
        className
      )}
      onClick={onClick}
    >
      {children}
      
      {/* Hover effect overlay */}
      {(isHighlighted || isSelected || isValidPlacement) && (
        <LayeredContainer layer="CARD_HOVER">
          <div className="absolute inset-0 rounded-lg bg-gradient-to-t from-transparent to-white/10 pointer-events-none" />
        </LayeredContainer>
      )}
    </LayeredContainer>
  );
}

/**
 * Floating card component for drag operations
 */
interface FloatingCardProps {
  children: React.ReactNode;
  position: { x: number; y: number };
  isDragging: boolean;
}

export function FloatingCard({ children, position, isDragging }: FloatingCardProps) {
  if (!isDragging) return null;

  return (
    <LayeredContainer layer="CARD_SELECTED">
      <div 
        className="fixed pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
        style={{ 
          left: position.x, 
          top: position.y,
          zIndex: Z_CATEGORIES.GAME.CARD_SELECTED + 100 // Extra high during drag
        }}
      >
        <motion.div
          initial={{ scale: 1 }}
          animate={{ scale: 1.1, rotate: 5 }}
          className="opacity-90"
        >
          {children}
        </motion.div>
      </div>
    </LayeredContainer>
  );
}