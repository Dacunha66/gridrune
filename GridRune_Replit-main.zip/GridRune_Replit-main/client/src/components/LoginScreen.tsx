import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Separator } from "./ui/separator";
import { User, Mail, Lock, UserPlus, LogIn, Eye, EyeOff, Users } from "lucide-react";
import { useAuth } from "../lib/stores/useAuth";

export function LoginScreen() {
  const { login, register, loginAsGuest, isLoading, error } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [loginData, setLoginData] = useState({
    username: "",
    password: ""
  });
  const [registerData, setRegisterData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(loginData.username, loginData.password);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      return;
    }
    await register({
      username: registerData.username,
      email: registerData.email,
      password: registerData.password,
      displayName: registerData.username // Use username as display name
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-red-950 to-black text-white flex items-center justify-center p-4 relative overflow-hidden">
      {/* Traditional Japanese background patterns */}
      <div className="absolute inset-0 opacity-5">
        <div className="h-full w-full bg-gradient-to-r from-transparent via-amber-500 to-transparent transform rotate-45 scale-150"></div>
        <div className="absolute top-0 left-0 h-full w-full bg-gradient-to-l from-transparent via-red-500 to-transparent transform -rotate-45 scale-150"></div>
      </div>
      
      <div className="max-w-md w-full relative z-10">
        <div className="text-center mb-8">
          {/* GridRune Logo */}
          <div className="mb-6">
            <img 
              src="/gridrune-logo-transparent.png" 
              alt="GridRune Logo" 
              className="h-60 mx-auto"
              style={{
                filter: 'drop-shadow(4px 4px 8px rgba(0, 0, 0, 0.7))'
              }}
            />
          </div>

        </div>

        <Card className="border-4 border-amber-600 relative" style={{
          background: 'linear-gradient(135deg, #f7f3e9 0%, #f0e6d2 50%, #e8d8bb 100%)',
          boxShadow: 'inset 0 0 20px rgba(139, 69, 19, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)'
        }}>
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-amber-700 via-red-500 to-amber-700"></div>
          <CardHeader className="text-center">
            <CardTitle className="text-amber-900 text-2xl font-bold" style={{
              fontFamily: 'serif',
              textShadow: '2px 2px 4px rgba(139, 69, 19, 0.3)'
            }}>
              Anmelden oder Registrieren
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-amber-700 to-red-700 border-2 border-amber-500">
                <TabsTrigger value="login" className="text-amber-100 data-[state=active]:bg-gradient-to-br data-[state=active]:from-amber-500 data-[state=active]:to-amber-600 data-[state=active]:text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Anmelden
                </TabsTrigger>
                <TabsTrigger value="register" className="text-amber-100 data-[state=active]:bg-gradient-to-br data-[state=active]:from-amber-500 data-[state=active]:to-amber-600 data-[state=active]:text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Registrieren
                </TabsTrigger>
              </TabsList>

              {error && (
                <Alert className="mt-4 bg-gradient-to-br from-red-100 to-red-200 border-3 border-red-700">
                  <AlertDescription className="text-red-900 font-semibold" style={{ fontFamily: 'serif' }}>
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <TabsContent value="login" className="space-y-4 mt-6">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-username" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>Benutzername</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="login-username"
                        type="text"
                        value={loginData.username}
                        onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
                        placeholder="Dein Benutzername"
                        className="pl-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>Passwort</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="login-password"
                        type={showPassword ? "text" : "password"}
                        value={loginData.password}
                        onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                        placeholder="Dein Passwort"
                        className="pl-10 pr-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0 hover:bg-amber-200"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4 text-amber-700" />
                        ) : (
                          <Eye className="w-4 h-4 text-amber-700" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isLoading}
                    className="w-full bg-gradient-to-br from-red-700 to-red-900 hover:from-red-600 hover:to-red-800 text-amber-100 font-bold py-3 border-2 border-amber-400 shadow-lg"
                    style={{ fontFamily: 'serif' }}
                  >
                    {isLoading ? "Anmeldung..." : "Anmelden"}
                  </Button>

                  {/* Guest Login Button with Info Tooltip */}
                  <div className="relative group">
                    <Button 
                      type="button"
                      onClick={() => loginAsGuest()}
                      disabled={isLoading}
                      className="w-full bg-gradient-to-br from-blue-600 to-blue-800 hover:from-blue-500 hover:to-blue-700 text-white font-bold py-3 border-2 border-blue-400 shadow-lg relative"
                      style={{ fontFamily: 'serif' }}
                    >
                      <Users className="w-5 h-5 mr-2" />
                      {isLoading ? "Lade..." : "Als Gast spielen"}
                      {/* Info Icon */}
                      <div className="absolute top-2 right-2 w-4 h-4 bg-white/20 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-white">i</span>
                      </div>
                    </Button>
                    
                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-sm rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10 whitespace-nowrap">
                      Spiele ohne Anmeldung. Dein Fortschritt wird nicht gespeichert.
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-800"></div>
                    </div>
                  </div>
                </form>
              </TabsContent>

              <TabsContent value="register" className="space-y-4 mt-6">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-username" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>Benutzername</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="register-username"
                        type="text"
                        value={registerData.username}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, username: e.target.value }))}
                        placeholder="Eindeutiger Benutzername"
                        className="pl-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-email" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>E-Mail</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="register-email"
                        type="email"
                        value={registerData.email}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="deine@email.com"
                        className="pl-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-password" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>Passwort</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="register-password"
                        type={showPassword ? "text" : "password"}
                        value={registerData.password}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, password: e.target.value }))}
                        placeholder="Mindestens 6 Zeichen"
                        className="pl-10 pr-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                        minLength={6}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0 hover:bg-amber-200"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4 text-amber-700" />
                        ) : (
                          <Eye className="w-4 h-4 text-amber-700" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-confirmPassword" className="text-amber-900 font-semibold" style={{ fontFamily: 'serif' }}>Passwort bestätigen</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-amber-700" />
                      <Input
                        id="register-confirmPassword"
                        type={showPassword ? "text" : "password"}
                        value={registerData.confirmPassword}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                        placeholder="Passwort wiederholen"
                        className="pl-10 bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-600 text-amber-900 font-medium focus:border-amber-700"
                        style={{ fontFamily: 'serif' }}
                        required
                      />
                    </div>
                    {registerData.password !== registerData.confirmPassword && registerData.confirmPassword && (
                      <p className="text-red-700 text-sm font-semibold" style={{ fontFamily: 'serif' }}>Passwörter stimmen nicht überein</p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isLoading || registerData.password !== registerData.confirmPassword}
                    className="w-full bg-gradient-to-br from-green-700 to-green-900 hover:from-green-600 hover:to-green-800 text-amber-100 font-bold py-3 border-2 border-amber-400 shadow-lg"
                    style={{ fontFamily: 'serif' }}
                  >
                    {isLoading ? "Registrierung..." : "Registrieren"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>



        <div className="text-center mt-6">
          <div className="bg-gradient-to-br from-amber-100/20 to-amber-200/20 p-3 rounded-lg border border-amber-600/50 backdrop-blur-sm">
            <p className="text-amber-200 text-sm font-medium" style={{ fontFamily: 'serif' }}>
              Durch die Registrierung stimmst du unseren Nutzungsbedingungen zu.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}