import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, X } from 'lucide-react';

interface InvalidPlacementFeedbackProps {
  isVisible: boolean;
  position: { x: number; y: number };
  message: string;
  onComplete: () => void;
}

export function InvalidPlacementFeedback({ 
  isVisible, 
  position, 
  message, 
  onComplete 
}: InvalidPlacementFeedbackProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ 
            opacity: 0, 
            scale: 0.5, 
            x: position.x - 100, 
            y: position.y - 30 
          }}
          animate={{ 
            opacity: 1, 
            scale: 1, 
            x: position.x - 100, 
            y: position.y - 50 
          }}
          exit={{ 
            opacity: 0, 
            scale: 0.8, 
            y: position.y - 80 
          }}
          transition={{ 
            type: "spring", 
            stiffness: 400, 
            damping: 25 
          }}
          className="fixed z-50 pointer-events-none"
          onAnimationComplete={() => {
            setTimeout(onComplete, 1500);
          }}
        >
          <div className="bg-red-600 text-white px-4 py-2 rounded-lg shadow-xl flex items-center gap-2 text-sm font-medium border-2 border-red-500">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5, repeat: 2 }}
            >
              <X className="w-4 h-4" />
            </motion.div>
            <span>{message}</span>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 0.3, repeat: 3 }}
            >
              <AlertCircle className="w-4 h-4" />
            </motion.div>
          </div>
          
          {/* Arrow pointing to invalid position */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-8 border-transparent border-t-red-600"
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}