import React, { useEffect } from 'react';
import { useBadges } from '../lib/stores/useBadges';
import { useCardGame } from '../lib/stores/useCardGame';

/**
 * Helper component to integrate badge tracking with various game events
 * This component listens to game state changes and updates badge progress accordingly
 */
export function BadgeIntegrationHelper() {
  const { updatePlayerStats, playerStats } = useBadges();
  const { winner, gamePhase, gameMode, player1Score, player2Score, boardSize } = useCardGame();

  // Track deck creation events
  useEffect(() => {
    const handleDeckCreation = () => {
      const currentStats = useBadges.getState().playerStats;
      updatePlayerStats({
        decksCreated: currentStats.decksCreated + 1
      });
    };

    // Listen for custom events that could be dispatched when decks are created
    window.addEventListener('deckCreated', handleDeckCreation);
    
    return () => {
      window.removeEventListener('deckCreated', handleDeckCreation);
    };
  }, [updatePlayerStats]);

  // Track card collection events
  useEffect(() => {
    const handleCardCollected = (event: CustomEvent) => {
      const { rarity } = event.detail;
      const currentStats = useBadges.getState().playerStats;
      
      let newStats: Partial<typeof currentStats> = {
        totalCards: currentStats.totalCards + 1
      };

      if (rarity === 'legendary') {
        newStats.legendaryCards = currentStats.legendaryCards + 1;
      }

      if (rarity === 'ultimate') {
        newStats.ultimateCards = currentStats.ultimateCards + 1;
      }

      updatePlayerStats(newStats);
    };

    // Listen for card collection events
    window.addEventListener('cardCollected', handleCardCollected as EventListener);
    
    return () => {
      window.removeEventListener('cardCollected', handleCardCollected as EventListener);
    };
  }, [updatePlayerStats]);

  // Track social events (friend additions, trades)
  useEffect(() => {
    const handleFriendAdded = () => {
      const currentStats = useBadges.getState().playerStats;
      updatePlayerStats({
        friendsAdded: currentStats.friendsAdded + 1
      });
    };

    const handleCardTraded = () => {
      const currentStats = useBadges.getState().playerStats;
      updatePlayerStats({
        cardsTraded: currentStats.cardsTraded + 1
      });
    };

    window.addEventListener('friendAdded', handleFriendAdded);
    window.addEventListener('cardTraded', handleCardTraded);
    
    return () => {
      window.removeEventListener('friendAdded', handleFriendAdded);
      window.removeEventListener('cardTraded', handleCardTraded);
    };
  }, [updatePlayerStats]);

  // Track play time (approximate)
  useEffect(() => {
    let startTime = Date.now();
    
    const updatePlayTime = () => {
      const sessionTime = (Date.now() - startTime) / (1000 * 60 * 60); // Convert to hours
      const currentStats = useBadges.getState().playerStats;
      updatePlayerStats({
        hoursPlayed: currentStats.hoursPlayed + sessionTime
      });
      startTime = Date.now(); // Reset for next interval
    };

    // Update play time every 5 minutes
    const interval = setInterval(updatePlayTime, 5 * 60 * 1000);
    
    // Update on page unload
    window.addEventListener('beforeunload', updatePlayTime);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('beforeunload', updatePlayTime);
      updatePlayTime(); // Final update
    };
  }, [updatePlayerStats]);

  return null; // This component doesn't render anything
}

// Utility functions to dispatch custom events
export const dispatchBadgeEvent = {
  deckCreated: () => {
    window.dispatchEvent(new CustomEvent('deckCreated'));
  },
  
  cardCollected: (rarity: string) => {
    window.dispatchEvent(new CustomEvent('cardCollected', {
      detail: { rarity }
    }));
  },
  
  friendAdded: () => {
    window.dispatchEvent(new CustomEvent('friendAdded'));
  },
  
  cardTraded: () => {
    window.dispatchEvent(new CustomEvent('cardTraded'));
  }
};