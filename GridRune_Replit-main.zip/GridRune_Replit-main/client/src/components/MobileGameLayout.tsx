import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ChevronUp, Settings, Volume2, VolumeX, RotateCcw, HelpCircle, Brain } from 'lucide-react';
import { GameBoard } from './GameBoard';
import { PlayerHand } from './PlayerHand';
import { GameUI } from './GameUI';
import { useCardGame } from '../lib/stores/useCardGame';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { cn } from '../lib/utils';

interface MobileGameLayoutProps {
  onShowMobileTutorial?: () => void;
}

export function MobileGameLayout({ onShowMobileTutorial }: MobileGameLayoutProps) {
  const [navOpen, setNavOpen] = useState(false);
  const [dragY, setDragY] = useState(0);
  
  const { 
    gamePhase, 
    currentPlayer, 
    resetToMenu,
    player1Name,
    player2Name,
    player1Avatar,
    player2Avatar,
    showPlacementGuide,
    setShowPlacementGuide,
    showStrategicHints,
    setShowStrategicHints
  } = useCardGame();
  
  const { 
    masterVolume, 
    setMasterVolume, 
    isMuted, 
    toggleMute 
  } = useAudio();

  // Handle swipe gestures
  const handleDrag = (event: PointerEvent, info: PanInfo) => {
    setDragY(info.offset.y);
  };

  const handleDragEnd = (event: PointerEvent, info: PanInfo) => {
    const threshold = -100; // Swipe up threshold
    
    if (info.offset.y < threshold && info.velocity.y < -500) {
      setNavOpen(true);
    } else if (info.offset.y > 50 && info.velocity.y > 500) {
      setNavOpen(false);
    }
    
    setDragY(0);
  };

  return (
    <div className="h-screen w-full overflow-hidden bg-gradient-to-br from-slate-900 to-slate-700 relative">
      {/* Fixed Game Content */}
      <div className="h-full flex flex-col relative z-10">
        {/* Minimal Top Bar */}
        <div className="h-16 flex items-center justify-between px-4 bg-slate-800/90 backdrop-blur-sm border-b border-slate-600">
          {/* Logo */}
          <img 
            src="/gridrune-logo-transparent.png" 
            alt="GridRune Logo" 
            className="h-10 object-contain"
            style={{ filter: 'drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.7))' }}
          />
          
          {/* Turn Indicator */}
          {(gamePhase === "playing" || gamePhase === "blitzschlag-target" || gamePhase === "clone-target") && (
            <div className={cn(
              "w-10 h-10 rounded-full shadow-lg transition-all duration-500 border-2 flex items-center justify-center",
              currentPlayer === 1 
                ? "bg-blue-600/90 border-blue-300" 
                : "bg-red-600/90 border-red-300"
            )}>
              <div className="text-sm">
                {(currentPlayer === 1 ? player1Avatar : player2Avatar).emoji}
              </div>
            </div>
          )}
          
          {/* Swipe Up Indicator */}
          <motion.div 
            className="flex flex-col items-center cursor-pointer"
            animate={{ y: navOpen ? 0 : [0, -2, 0] }}
            transition={{ repeat: navOpen ? 0 : Infinity, duration: 2 }}
            onClick={() => setNavOpen(!navOpen)}
          >
            <ChevronUp className="w-4 h-4 text-slate-400" />
            <div className="text-xs text-slate-500">Wischen</div>
          </motion.div>
        </div>

        {/* Fixed Game Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Player Hand - Fixed position with slight downward shift */}
          <div className="h-[130px] w-full relative z-20 bg-gradient-to-b from-slate-900/50 to-transparent mt-2">
            <PlayerHand player={1} />
          </div>
          
          {/* Game Board - Fixed in center with mobile padding */}
          <div className="flex-1 flex items-center justify-center w-full overflow-hidden pl-0 pr-1">
            <div className="w-full h-full flex items-center justify-center">
              <GameBoard />
            </div>
          </div>
        </div>
      </div>

      {/* Swipeable Navigation Panel */}
      <motion.div
        className="absolute inset-x-0 top-0 bg-slate-900/95 backdrop-blur-lg border-b border-slate-600 z-30"
        initial={{ y: '-100%' }}
        animate={{ y: navOpen ? '0%' : '-100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.2 }}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        style={{ y: dragY }}
      >
        <div className="p-6 pb-20">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-slate-400" />
              <h2 className="text-lg font-semibold text-white">Einstellungen</h2>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setNavOpen(false)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </Button>
          </div>

          {/* Volume Control */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Volume2 className="w-4 h-4 text-slate-400" />
              <span className="text-sm text-slate-300">Lautstärke</span>
              <span className="text-xs text-slate-500 ml-auto">{Math.round(masterVolume * 100)}%</span>
            </div>
            <Slider
              value={[masterVolume]}
              onValueChange={(value) => setMasterVolume(value[0])}
              max={1}
              step={0.1}
              className="w-full"
            />
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <Button
              onClick={toggleMute}
              variant={isMuted ? "destructive" : "outline"}
              size="sm"
              className="flex items-center gap-2"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              {isMuted ? "Stummgeschaltet" : "Ton an"}
            </Button>
            
            <Button
              onClick={() => onShowMobileTutorial?.()}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <HelpCircle className="w-4 h-4" />
              Tutorial
            </Button>
          </div>

          {/* Game Settings */}
          <div className="space-y-3 mb-6">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-300">Platzierungshilfe</span>
              <Button
                onClick={() => setShowPlacementGuide(!showPlacementGuide)}
                variant={showPlacementGuide ? "default" : "outline"}
                size="sm"
              >
                {showPlacementGuide ? "An" : "Aus"}
              </Button>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-300">Strategische Hinweise</span>
              <Button
                onClick={() => setShowStrategicHints(!showStrategicHints)}
                variant={showStrategicHints ? "default" : "outline"}
                size="sm"
              >
                {showStrategicHints ? "An" : "Aus"}
              </Button>
            </div>
          </div>

          {/* Return to Menu */}
          <Button
            onClick={resetToMenu}
            variant="destructive"
            size="sm"
            className="w-full flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Zum Hauptmenü
          </Button>

          {/* Drag Handle */}
          <div className="flex justify-center mt-4">
            <div className="w-12 h-1 bg-slate-600 rounded-full"></div>
          </div>
        </div>
      </motion.div>

      {/* Backdrop */}
      <AnimatePresence>
        {navOpen && (
          <motion.div
            className="absolute inset-0 bg-black/50 z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setNavOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}