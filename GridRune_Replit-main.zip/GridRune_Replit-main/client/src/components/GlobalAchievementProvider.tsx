import React, { createContext, useContext, useEffect, useState } from 'react';
import { useAchievementUnlock } from './AchievementUnlockAnimation';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { useCardGame } from '../lib/stores/useCardGame';
import { Trophy, Star, Crown, Target, Zap, Shield } from 'lucide-react';
import PlayfulCelebration from './PlayfulCelebration';

// Achievement definitions
const ACHIEVEMENTS = {
  FIRST_WIN: {
    id: 'first-win',
    title: 'Erster Sieg',
    description: 'Gewinne dein erstes Spiel in GridRune',
    rarity: 'common' as const,
    reward: { xp: 100, gold: 200 },
    icon: <Trophy className="w-16 h-16" />,
    condition: (stats: any) => stats.gamesWon >= 1
  },
  WIN_STREAK_5: {
    id: 'win-streak-5',
    title: 'Siegesserie',
    description: 'Gewinne 5 Spiele in Folge',
    rarity: 'uncommon' as const,
    reward: { xp: 300, gold: 500 },
    icon: <Star className="w-16 h-16" />,
    condition: (stats: any) => stats.winStreak >= 5
  },
  CARD_COLLECTOR: {
    id: 'card-collector',
    title: 'Kartensammler',
    description: 'Sammle 50 verschiedene Karten',
    rarity: 'rare' as const,
    reward: { xp: 500, diamonds: 25, title: 'Sammler' },
    icon: <Target className="w-16 h-16" />,
    condition: (stats: any) => stats.cardsCollected >= 50
  },
  QUEST_MASTER: {
    id: 'quest-master',
    title: 'Quest-Meister',
    description: 'Schließe 25 Quests ab',
    rarity: 'epic' as const,
    reward: { xp: 750, diamonds: 50, title: 'Quest-Meister' },
    icon: <Crown className="w-16 h-16" />,
    condition: (stats: any) => stats.questsCompleted >= 25
  },
  LEGENDARY_COLLECTOR: {
    id: 'legendary-collector',
    title: 'Legendenjäger',
    description: 'Sammle deine erste legendäre Karte',
    rarity: 'legendary' as const,
    reward: { xp: 1000, diamonds: 100, title: 'Legendenjäger' },
    icon: <Crown className="w-16 h-16" />,
    condition: (stats: any) => stats.legendaryCards >= 1
  }
};

interface AchievementContextType {
  checkAchievements: () => void;
  triggerSpecialAchievement: (achievementId: string) => void;
}

const AchievementContext = createContext<AchievementContextType | null>(null);

export function GlobalAchievementProvider({ children }: { children: React.ReactNode }) {
  const { triggerAchievement, AchievementUnlockAnimation } = useAchievementUnlock();
  const { stats, claimedAchievements, claimAchievement } = usePlayerProgress();
  const gameState = useCardGame();
  const [celebrationAchievement, setCelebrationAchievement] = useState<any>(null);
  const [showCelebration, setShowCelebration] = useState(false);

  const checkAchievements = () => {
    const safeClaimedAchievements = Array.isArray(claimedAchievements) ? claimedAchievements : [];
    Object.values(ACHIEVEMENTS).forEach(achievement => {
      if (safeClaimedAchievements.includes(achievement.id)) return;
      
      if (achievement.condition(stats)) {
        // Show playful celebration
        setCelebrationAchievement(achievement);
        setShowCelebration(true);
        claimAchievement(achievement.id, achievement.reward);
      }
    });
  };

  const triggerSpecialAchievement = (achievementId: string) => {
    const safeClaimedAchievements = Array.isArray(claimedAchievements) ? claimedAchievements : [];
    const achievement = Object.values(ACHIEVEMENTS).find(a => a.id === achievementId);
    if (achievement && !safeClaimedAchievements.includes(achievement.id)) {
      // Show playful celebration
      setCelebrationAchievement(achievement);
      setShowCelebration(true);
      claimAchievement(achievement.id, achievement.reward);
    }
  };

  // Check achievements when stats change
  useEffect(() => {
    checkAchievements();
  }, [stats.gamesWon, stats.cardsCollected, stats.questsCompleted]);

  // Check for game-specific achievements
  useEffect(() => {
    const safeClaimedAchievements = Array.isArray(claimedAchievements) ? claimedAchievements : [];
    if (gameState.winner === 'player1' && !safeClaimedAchievements.includes('first-win')) {
      // Player won their first game
      triggerSpecialAchievement('first-win');
    }
  }, [gameState.winner]);

  return (
    <AchievementContext.Provider value={{ checkAchievements, triggerSpecialAchievement }}>
      {children}
      <AchievementUnlockAnimation />
      
      {/* Playful Celebration Animation */}
      <PlayfulCelebration
        achievement={celebrationAchievement}
        isVisible={showCelebration}
        onComplete={() => {
          setShowCelebration(false);
          setCelebrationAchievement(null);
        }}
      />
    </AchievementContext.Provider>
  );
}

export function useGlobalAchievements() {
  const context = useContext(AchievementContext);
  if (!context) {
    throw new Error('useGlobalAchievements must be used within GlobalAchievementProvider');
  }
  return context;
}

export default GlobalAchievementProvider;