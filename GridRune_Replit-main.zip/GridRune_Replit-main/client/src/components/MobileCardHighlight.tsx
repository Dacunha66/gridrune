/**
 * Mobile Card Highlight Component
 * Provides enhanced visual feedback for mobile card selection
 */

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SelectionMode } from '../lib/mobileCardSelection';

interface MobileCardHighlightProps {
  isVisible: boolean;
  mode: SelectionMode;
  intensity: number;
  cardIndex: number;
  children: React.ReactNode;
}

export function MobileCardHighlight({
  isVisible,
  mode,
  intensity,
  cardIndex,
  children
}: MobileCardHighlightProps) {
  const getHighlightStyle = () => {
    switch (mode) {
      case SelectionMode.SELECT:
        return {
          borderColor: 'rgb(59, 130, 246)', // Blue
          boxShadow: `0 0 ${intensity * 20}px rgba(59, 130, 246, ${intensity * 0.6})`,
          scale: 1 + (intensity * 0.05),
        };
      case SelectionMode.CONFIRM:
        return {
          borderColor: 'rgb(34, 197, 94)', // Green
          boxShadow: `0 0 ${intensity * 25}px rgba(34, 197, 94, ${intensity * 0.8})`,
          scale: 1 + (intensity * 0.08),
        };
      case SelectionMode.PREVIEW:
        return {
          borderColor: 'rgb(147, 51, 234)', // Purple
          boxShadow: `0 0 ${intensity * 15}px rgba(147, 51, 234, ${intensity * 0.5})`,
          scale: 1 + (intensity * 0.03),
        };
      default:
        return {
          borderColor: 'transparent',
          boxShadow: 'none',
          scale: 1,
        };
    }
  };

  const getPulseAnimation = () => {
    if (mode === SelectionMode.CONFIRM) {
      return {
        scale: [1, 1.1, 1],
        transition: {
          duration: 0.6,
          repeat: Infinity,
          ease: "easeInOut"
        }
      };
    }
    return {};
  };

  return (
    <div className="relative">
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ 
              opacity: intensity,
              ...getHighlightStyle(),
              ...getPulseAnimation()
            }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ 
              duration: 0.2,
              ease: "easeOut"
            }}
            className="absolute inset-0 rounded-lg border-2 pointer-events-none z-50"
            style={{
              borderRadius: '8px',
            }}
          />
        )}
      </AnimatePresence>
      
      {/* Selection indicator */}
      <AnimatePresence>
        {isVisible && mode !== SelectionMode.BROWSE && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute -top-2 -right-2 z-60"
          >
            <div className={`
              w-6 h-6 rounded-full border-2 border-white flex items-center justify-center text-xs font-bold
              ${mode === SelectionMode.SELECT ? 'bg-blue-500' : ''}
              ${mode === SelectionMode.CONFIRM ? 'bg-green-500' : ''}
              ${mode === SelectionMode.PREVIEW ? 'bg-purple-500' : ''}
            `}>
              {mode === SelectionMode.SELECT && '●'}
              {mode === SelectionMode.CONFIRM && '✓'}
              {mode === SelectionMode.PREVIEW && '👁'}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Confidence indicator */}
      <AnimatePresence>
        {isVisible && intensity > 0.7 && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 z-60"
          >
            <div className="w-12 h-1 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-full opacity-80">
              <motion.div
                className="h-full bg-white rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${intensity * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {children}
    </div>
  );
}

export default MobileCardHighlight;