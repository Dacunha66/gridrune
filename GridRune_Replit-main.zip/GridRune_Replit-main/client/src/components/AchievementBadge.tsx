import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  rarity: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  category: 'gameplay' | 'collection' | 'streak' | 'milestone' | 'special' | 'social';
  unlockedAt?: Date;
  progress?: {
    current: number;
    total: number;
  };
}

interface AchievementBadgeProps {
  badge: Badge;
  size?: 'small' | 'medium' | 'large';
  showProgress?: boolean;
  showTooltip?: boolean;
  isLocked?: boolean;
  onClick?: () => void;
}

const rarityStyles = {
  bronze: {
    gradient: 'from-amber-600 to-amber-800',
    glow: 'shadow-lg shadow-amber-500/30',
    border: 'border-amber-500',
    bg: 'bg-gradient-to-br from-amber-100 to-amber-200'
  },
  silver: {
    gradient: 'from-gray-400 to-gray-600',
    glow: 'shadow-lg shadow-gray-400/30',
    border: 'border-gray-400',
    bg: 'bg-gradient-to-br from-gray-100 to-gray-200'
  },
  gold: {
    gradient: 'from-yellow-400 to-yellow-600',
    glow: 'shadow-lg shadow-yellow-400/40',
    border: 'border-yellow-400',
    bg: 'bg-gradient-to-br from-yellow-100 to-yellow-200'
  },
  platinum: {
    gradient: 'from-purple-400 to-purple-600',
    glow: 'shadow-lg shadow-purple-400/40',
    border: 'border-purple-400',
    bg: 'bg-gradient-to-br from-purple-100 to-purple-200'
  },
  diamond: {
    gradient: 'from-blue-400 via-purple-500 to-pink-500',
    glow: 'shadow-xl shadow-blue-400/50',
    border: 'border-blue-400',
    bg: 'bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100'
  }
};

const sizeStyles = {
  small: 'w-12 h-12 text-lg',
  medium: 'w-16 h-16 text-xl',
  large: 'w-20 h-20 text-2xl'
};

export function AchievementBadge({ 
  badge, 
  size = 'medium', 
  showProgress = false,
  showTooltip = true,
  isLocked = false,
  onClick 
}: AchievementBadgeProps) {
  const style = rarityStyles[badge.rarity];
  const sizeClass = sizeStyles[size];
  
  const progressPercentage = badge.progress 
    ? Math.min((badge.progress.current / badge.progress.total) * 100, 100)
    : 100;

  return (
    <motion.div
      className={cn(
        "relative rounded-full border-2 flex items-center justify-center transition-all duration-300",
        sizeClass,
        style.border,
        style.glow,
        isLocked ? "opacity-40 grayscale" : "",
        onClick ? "cursor-pointer hover:scale-110" : "",
        "group"
      )}
      style={{
        background: isLocked 
          ? 'linear-gradient(135deg, #64748b, #475569)'
          : `linear-gradient(135deg, ${style.gradient.replace('from-', '').replace('to-', '').split(' ').join(', ')})`
      }}
      whileHover={onClick ? { scale: 1.1 } : {}}
      whileTap={onClick ? { scale: 0.95 } : {}}
      onClick={onClick}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {/* Badge Icon */}
      <div className={cn(
        "relative z-10 flex items-center justify-center",
        style.bg,
        "rounded-full w-full h-full border",
        isLocked ? "bg-gray-300" : ""
      )}>
        <span className={cn(
          "font-bold drop-shadow-sm",
          isLocked ? "text-gray-600" : "text-slate-800"
        )}>
          {isLocked ? "🔒" : badge.icon}
        </span>
      </div>

      {/* Progress Ring for Locked Badges */}
      {isLocked && badge.progress && showProgress && (
        <div className="absolute inset-0 rounded-full">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              className="text-gray-600"
              opacity="0.3"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              strokeDasharray={`${progressPercentage * 2.83} ${(100 - progressPercentage) * 2.83}`}
              className="text-blue-500"
              strokeLinecap="round"
            />
          </svg>
        </div>
      )}

      {/* New Badge Indicator */}
      {!isLocked && badge.unlockedAt && (() => {
        const unlockedDate = badge.unlockedAt instanceof Date 
          ? badge.unlockedAt 
          : new Date(badge.unlockedAt);
        return !isNaN(unlockedDate.getTime()) && 
               new Date().getTime() - unlockedDate.getTime() < 24 * 60 * 60 * 1000;
      })() && (
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white flex items-center justify-center">
          <span className="text-white text-xs font-bold">!</span>
        </div>
      )}

      {/* Tooltip */}
      {showTooltip && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-20">
          <div className="bg-slate-900 text-white text-xs rounded-lg px-3 py-2 shadow-xl border border-slate-700 whitespace-nowrap">
            <div className="font-bold text-center">{badge.title}</div>
            <div className="text-gray-300 text-center mt-1">{badge.description}</div>
            {badge.progress && isLocked && (
              <div className="text-gray-400 text-center mt-1">
                {badge.progress.current}/{badge.progress.total}
              </div>
            )}
            {badge.unlockedAt && !isLocked && (() => {
              const unlockedDate = badge.unlockedAt instanceof Date 
                ? badge.unlockedAt 
                : new Date(badge.unlockedAt);
              return !isNaN(unlockedDate.getTime());
            })() && (
              <div className="text-gray-400 text-center mt-1">
                Freigeschaltet: {(() => {
                  const unlockedDate = badge.unlockedAt instanceof Date 
                    ? badge.unlockedAt 
                    : new Date(badge.unlockedAt);
                  return unlockedDate.toLocaleDateString('de-DE');
                })()}
              </div>
            )}
            {/* Tooltip Arrow */}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-slate-900"></div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

// Badge Collection Component
interface BadgeCollectionProps {
  badges: Badge[];
  maxDisplay?: number;
  size?: 'small' | 'medium' | 'large';
  onBadgeClick?: (badge: Badge) => void;
}

export function BadgeCollection({ 
  badges, 
  maxDisplay = 6,
  size = 'small',
  onBadgeClick
}: BadgeCollectionProps) {
  const unlockedBadges = badges.filter(b => b.unlockedAt);
  const lockedBadges = badges.filter(b => !b.unlockedAt);
  
  const displayBadges = [
    ...unlockedBadges.slice(0, Math.min(maxDisplay, unlockedBadges.length)),
    ...lockedBadges.slice(0, maxDisplay - unlockedBadges.length)
  ];

  return (
    <div className="flex flex-wrap gap-2 justify-center">
      {displayBadges.map((badge, index) => (
        <AchievementBadge
          key={badge.id}
          badge={badge}
          size={size}
          isLocked={!badge.unlockedAt}
          showProgress={!badge.unlockedAt}
          onClick={() => onBadgeClick?.(badge)}
        />
      ))}
      {badges.length > maxDisplay && (
        <div className={cn(
          "flex items-center justify-center rounded-full border-2 border-dashed border-gray-400 bg-gray-100 text-gray-600 font-bold",
          sizeStyles[size]
        )}>
          +{badges.length - maxDisplay}
        </div>
      )}
    </div>
  );
}