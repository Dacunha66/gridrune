import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCardGame, BoardSize } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ArrowLeft, Save, Plus, Trash2, Sparkles, CheckCircle } from "lucide-react";
import { cn } from "../lib/utils";
import { Card as GameCard } from "./Card";
import { allCards } from "../lib/cardData";
import { GameCard as GameCardType } from "../lib/cardData";
import { useAudio } from "../lib/stores/useAudio";
import { useAchievements } from "../lib/stores/useAchievements";
import { useSeasonalRewards } from "../lib/stores/useSeasonalRewards";
import { useWeeklyChallenges } from "../lib/stores/useWeeklyChallenges";

export function DeckCreator() {
  const { setGamePhase, saveDeck, savedDecks } = useCardGame();
  const { playHit, playSuccess } = useAudio();
  const { onDeckCreated } = useAchievements();
  const seasonalRewards = useSeasonalRewards();
  const weeklyChallenges = useWeeklyChallenges();
  const [deckName, setDeckName] = useState("");
  const [selectedBoardSize, setSelectedBoardSize] = useState<BoardSize>("4x4");
  const [currentDeck, setCurrentDeck] = useState<GameCardType[]>([]);
  const [recentlyAdded, setRecentlyAdded] = useState<string>("");
  const [recentlyRemoved, setRecentlyRemoved] = useState<string>("");

  const getMaxDeckSize = (size: BoardSize): number => {
    // Only 4x4 is supported
    return 15;
  };

  const maxDeckSize = getMaxDeckSize(selectedBoardSize);

  const handleAddCard = (card: GameCardType) => {
    if (currentDeck.length < maxDeckSize) {
      setCurrentDeck([...currentDeck, card]);
      setRecentlyAdded(card.id);
      playHit();
      
      // Clear recently added state after animation
      setTimeout(() => setRecentlyAdded(""), 600);
    }
  };

  const handleRemoveCard = (index: number) => {
    const removedCard = currentDeck[index];
    const newDeck = currentDeck.filter((_, i) => i !== index);
    setCurrentDeck(newDeck);
    setRecentlyRemoved(removedCard.id);
    playHit();
    
    // Clear recently removed state after animation
    setTimeout(() => setRecentlyRemoved(""), 600);
  };

  const handleSaveDeck = () => {
    if (!deckName.trim()) {
      alert("Bitte gib einen Deck-Namen ein!");
      return;
    }

    if (currentDeck.length !== maxDeckSize) {
      alert(`Das Deck muss genau ${maxDeckSize} Karten haben!`);
      return;
    }

    if (savedDecks.length >= 5) {
      alert("Du kannst maximal 5 Decks haben!");
      return;
    }

    saveDeck(deckName.trim(), currentDeck, selectedBoardSize);
    playSuccess();
    onDeckCreated(); // Trigger achievement
    seasonalRewards.addSeasonXP(15); // Award XP for deck creation
    weeklyChallenges.updateTaskProgress('create_deck', 1); // Update weekly challenge
    setGamePhase("deck-management");
  };

  const getAvailableCards = () => {
    return allCards.filter(card => 
      !currentDeck.some(deckCard => deckCard.id === card.id)
    );
  };

  const handleBoardSizeChange = (size: BoardSize) => {
    setSelectedBoardSize(size);
    // Clear deck if changing board size
    setCurrentDeck([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={() => setGamePhase("deck-management")}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zur Verwaltung
          </Button>
          
          <h1 className="text-3xl font-bold">Neues Deck erstellen</h1>
          
          <Button 
            onClick={handleSaveDeck}
            disabled={currentDeck.length !== maxDeckSize || !deckName.trim()}
            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600"
          >
            <Save className="w-4 h-4 mr-2" />
            Deck speichern
          </Button>
        </div>

        {/* Deck Configuration */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-600">
            <CardHeader>
              <CardTitle className="text-white">Deck-Einstellungen</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="deckName" className="text-white">Deck-Name</Label>
                <Input
                  id="deckName"
                  value={deckName}
                  onChange={(e) => setDeckName(e.target.value)}
                  placeholder="Mein Deck"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div>
                <Label className="text-white">Spielfeld-Größe</Label>
                <Select value={selectedBoardSize} onValueChange={handleBoardSizeChange}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="3x3">3x3 (10 Karten)</SelectItem>
                    <SelectItem value="4x4">4x4 (15 Karten)</SelectItem>
                    <SelectItem value="5x5">5x5 (25 Karten)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="text-center pt-4">
                <motion.p 
                  className="text-slate-300"
                  animate={{ 
                    color: currentDeck.length === maxDeckSize ? "#22c55e" : "#cbd5e1",
                    scale: currentDeck.length === maxDeckSize ? 1.05 : 1
                  }}
                >
                  {currentDeck.length} / {maxDeckSize} Karten
                  {currentDeck.length === maxDeckSize && (
                    <motion.span
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="ml-2 text-green-400"
                    >
                      <CheckCircle className="w-4 h-4 inline" />
                    </motion.span>
                  )}
                </motion.p>
                <div className="w-full bg-slate-600 rounded-full h-2 mt-2 overflow-hidden">
                  <motion.div 
                    className={cn(
                      "h-2 rounded-full transition-all duration-500",
                      currentDeck.length === maxDeckSize 
                        ? "bg-gradient-to-r from-green-500 to-emerald-400" 
                        : "bg-gradient-to-r from-blue-500 to-cyan-400"
                    )}
                    initial={{ width: 0 }}
                    animate={{ 
                      width: `${(currentDeck.length / maxDeckSize) * 100}%`,
                      boxShadow: currentDeck.length === maxDeckSize 
                        ? "0 0 10px rgba(34, 197, 94, 0.5)" 
                        : "0 0 5px rgba(59, 130, 246, 0.3)"
                    }}
                    transition={{ type: "spring", stiffness: 100, damping: 15 }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Deck Preview */}
          <Card className="lg:col-span-2 bg-slate-800 border-slate-600">
            <CardHeader>
              <CardTitle className="text-white">Aktuelles Deck</CardTitle>
            </CardHeader>
            <CardContent>
              {currentDeck.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400">Noch keine Karten hinzugefügt</p>
                </div>
              ) : (
                <div className="grid grid-cols-5 gap-2 max-h-64 overflow-y-auto">
                  <AnimatePresence>
                    {currentDeck.map((card, index) => (
                      <motion.div
                        key={`${card.id}-${index}`}
                        initial={{ scale: 0, opacity: 0, rotateY: 90 }}
                        animate={{ 
                          scale: 1, 
                          opacity: 1, 
                          rotateY: 0,
                          filter: recentlyAdded === card.id ? "brightness(1.3) drop-shadow(0 0 12px rgba(34,197,94,0.8))" : "brightness(1)"
                        }}
                        exit={{ 
                          scale: 0, 
                          opacity: 0, 
                          rotateX: -90,
                          transition: { duration: 0.3 }
                        }}
                        transition={{ 
                          type: "spring", 
                          stiffness: 200, 
                          damping: 20,
                          delay: index * 0.05
                        }}
                        className="relative group"
                      >
                        <motion.div 
                          style={{ transform: 'scale(0.6)', transformOrigin: 'center' }}
                          whileHover={{ 
                            scale: 0.65, 
                            rotateY: 5,
                            z: 20
                          }}
                          transition={{ type: "spring", stiffness: 300, damping: 20 }}
                        >
                          <GameCard
                            card={card}
                            isSelected={false}
                            onClick={() => {}}
                            isClickable={false}
                            isDisabled={true}
                          />
                        </motion.div>
                        
                        {/* Remove button with enhanced animation */}
                        <motion.div
                          initial={{ scale: 0, opacity: 0 }}
                          whileHover={{ scale: 1.1 }}
                          className="absolute -top-2 -right-2"
                        >
                          <Button
                            onClick={() => handleRemoveCard(index)}
                            variant="destructive"
                            size="sm"
                            className="w-6 h-6 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200 hover:shadow-lg hover:shadow-red-500/50"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </motion.div>

                        {/* Recently added sparkle effect */}
                        {recentlyAdded === card.id && (
                          <motion.div
                            initial={{ scale: 0, opacity: 1 }}
                            animate={{ scale: [1, 1.5, 1], opacity: [1, 0.7, 0] }}
                            transition={{ duration: 0.6, repeat: 2 }}
                            className="absolute inset-0 pointer-events-none flex items-center justify-center"
                          >
                            <Sparkles className="w-8 h-8 text-green-400" />
                          </motion.div>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Available Cards */}
        <Card className="bg-slate-800 border-slate-600">
          <CardHeader>
            <CardTitle className="text-white">Verfügbare Karten</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4 max-h-96 overflow-y-auto">
              {getAvailableCards().map((card, index) => (
                <motion.div 
                  key={card.id} 
                  className="relative group"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ 
                    delay: index * 0.02,
                    type: "spring",
                    stiffness: 200,
                    damping: 20
                  }}
                  whileHover={{ 
                    scale: 1.05, 
                    z: 10,
                    transition: { type: "spring", stiffness: 400, damping: 25 }
                  }}
                >
                  <motion.div 
                    style={{ transform: 'scale(0.7)', transformOrigin: 'center' }}
                    whileHover={{ 
                      scale: 0.75,
                      rotateY: currentDeck.length < maxDeckSize ? 5 : 0,
                      filter: currentDeck.length < maxDeckSize 
                        ? "brightness(1.1) drop-shadow(0 4px 12px rgba(59,130,246,0.4))"
                        : "brightness(0.6) grayscale(0.5)"
                    }}
                    whileTap={currentDeck.length < maxDeckSize ? { 
                      scale: 0.68, 
                      rotateX: 5,
                      transition: { duration: 0.1 }
                    } : {}}
                  >
                    <GameCard
                      card={card}
                      isSelected={false}
                      onClick={() => handleAddCard(card)}
                      isClickable={currentDeck.length < maxDeckSize}
                      isDisabled={currentDeck.length >= maxDeckSize}
                    />
                  </motion.div>
                  
                  {/* Enhanced Add button */}
                  <motion.div
                    className="absolute -top-2 -right-2"
                    initial={{ scale: 0, opacity: 0 }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Button
                      onClick={() => handleAddCard(card)}
                      disabled={currentDeck.length >= maxDeckSize}
                      variant="secondary"
                      size="sm"
                      className={cn(
                        "w-6 h-6 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200",
                        currentDeck.length < maxDeckSize 
                          ? "hover:shadow-lg hover:shadow-blue-500/50 bg-blue-600 hover:bg-blue-500 text-white" 
                          : "opacity-30 cursor-not-allowed"
                      )}
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </motion.div>

                  {/* Card availability indicator */}
                  {currentDeck.length >= maxDeckSize && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="absolute inset-0 bg-gray-900/70 rounded-lg flex items-center justify-center pointer-events-none"
                    >
                      <span className="text-xs text-gray-400 font-semibold bg-gray-800/80 px-2 py-1 rounded">
                        Deck voll
                      </span>
                    </motion.div>
                  )}

                  {/* Recently removed highlight effect */}
                  {recentlyRemoved === card.id && (
                    <motion.div
                      initial={{ opacity: 0, scale: 1.2 }}
                      animate={{ opacity: [0.8, 0.4, 0], scale: [1.2, 1.1, 1] }}
                      transition={{ duration: 0.8 }}
                      className="absolute inset-0 bg-green-400/20 rounded-lg pointer-events-none border-2 border-green-400/40"
                    />
                  )}
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}