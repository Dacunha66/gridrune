import { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { cn } from "../lib/utils";
import { BoardSlot } from "../lib/stores/useCardGame";
import { GameCard } from "../lib/cardData";

interface ValueTooltipProps {
  currentValue: number;
  originalValue: number;
  card: GameCard;
  slot?: BoardSlot;
  position: 'top' | 'right' | 'bottom' | 'left';
  shieldBroken?: boolean;
  elementBonus?: boolean;
  adjacentOwnCards?: number;
  adjacentSameElementCards?: number;
  isOCardOwner?: boolean;
  adjacentToOCard?: boolean;
  children: React.ReactNode;
}

export function ValueTooltip({ 
  currentValue, 
  originalValue, 
  card, 
  slot,
  position,
  shieldBroken = false,
  elementBonus = false,
  adjacentOwnCards = 0,
  adjacentSameElementCards = 0,
  isOCardOwner = false,
  adjacentToOCard = false,
  children 
}: ValueTooltipProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const triggerRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  // Calculate tooltip position dynamically when hovered
  useEffect(() => {
    if (!isHovered || !triggerRef.current) return;

    const rect = triggerRef.current.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    // Estimated tooltip dimensions (will be adjusted by CSS)
    const tooltipWidth = 200;
    const tooltipHeight = 80;
    const gap = 12;

    let top = 0;
    let left = 0;

    switch (position) {
      case 'top':
        top = rect.top - tooltipHeight - gap;
        left = rect.left + rect.width / 2 - tooltipWidth / 2;
        // Adjust if outside viewport
        if (top < 0) {
          top = rect.bottom + gap; // Flip to bottom
        }
        if (left < 0) left = gap;
        if (left + tooltipWidth > viewportWidth) left = viewportWidth - tooltipWidth - gap;
        break;
      case 'bottom':
        top = rect.bottom + gap;
        left = rect.left + rect.width / 2 - tooltipWidth / 2;
        if (top + tooltipHeight > viewportHeight) {
          top = rect.top - tooltipHeight - gap; // Flip to top
        }
        if (left < 0) left = gap;
        if (left + tooltipWidth > viewportWidth) left = viewportWidth - tooltipWidth - gap;
        break;
      case 'left':
        top = rect.top + rect.height / 2 - tooltipHeight / 2;
        left = rect.left - tooltipWidth - gap;
        if (left < 0) {
          left = rect.right + gap; // Flip to right
        }
        if (top < 0) top = gap;
        if (top + tooltipHeight > viewportHeight) top = viewportHeight - tooltipHeight - gap;
        break;
      case 'right':
        top = rect.top + rect.height / 2 - tooltipHeight / 2;
        left = rect.right + gap;
        if (left + tooltipWidth > viewportWidth) {
          left = rect.left - tooltipWidth - gap; // Flip to left
        }
        if (top < 0) top = gap;
        if (top + tooltipHeight > viewportHeight) top = viewportHeight - tooltipHeight - gap;
        break;
    }

    setTooltipPosition({ top, left });
  }, [isHovered, position]);
  
  // Calculate if there's a value change or potential bonus
  const hasChange = currentValue !== originalValue;
  
  // Only show potential bonus if there's actually a meaningful bonus available
  const hasPotentialBonus = !hasChange && (
    elementBonus || 
    (card.effect === "verstaerkung" && adjacentOwnCards > 0) ||
    (card.effect === "staerkung" && adjacentSameElementCards > 0)
    // Removed isOCardOwner and adjacentToOCard as they don't give guaranteed bonuses
  );
  
  // Show tooltip when there's useful information - be more selective
  const shouldShowTooltip = hasChange || hasPotentialBonus;

  const difference = currentValue - originalValue;
  const isPositive = difference > 0;

  // Determine the source of the bonus/malus
  const getChangeSource = () => {
    const sources: string[] = [];
    
    // Show actual value changes first
    if (hasChange) {
      if (isPositive && difference >= 1) {
        let remainingBonus = difference;
        
        // Check if element bonus is active
        if (elementBonus) {
          sources.push("🌟 Elementfeld-Bonus (+1)");
          remainingBonus -= 1;
        }
        
        // Check if remaining bonus is from O-card
        if (remainingBonus > 0) {
          sources.push(`⭕ O-Karte Bonus (+${remainingBonus})`);
        }
      }
      
      // Check for Verstärkung effect (adjacent own cards)
      if (card.effect === "verstaerkung" && isPositive && adjacentOwnCards > 0) {
        // Only show if the bonus matches the adjacent count
        const expectedBonus = adjacentOwnCards;
        if (difference >= expectedBonus) {
          sources.push(`💪 Verstärkung: ${adjacentOwnCards} eigene Nachbarkarte${adjacentOwnCards > 1 ? 'n' : ''} (+${adjacentOwnCards})`);
        }
      }
      
      // Check for Berserker effect (first combat doubles values)
      if (card.effect === "berserker" && isPositive && difference === originalValue) {
        sources.push("🔥 Berserker: Werte verdoppelt im ersten Kampf (+100%)");
      }
      
      // Check for Staerkung effect (adjacent same element cards)
      if (card.effect === "staerkung" && isPositive && adjacentSameElementCards > 0) {
        // Only show if the bonus matches the adjacent count
        const expectedBonus = adjacentSameElementCards;
        if (difference >= expectedBonus) {
          sources.push(`💎 Stärkung: ${adjacentSameElementCards} benachbarte ${card.element}-Karte${adjacentSameElementCards > 1 ? 'n' : ''} (+${adjacentSameElementCards})`);
        }
      }
    }
    
    // Show potential bonuses that haven't been applied yet
    if (!hasChange && hasPotentialBonus) {
      if (elementBonus) {
        sources.push("🌟 Elementfeld-Bonus verfügbar (+1 im Kampf)");
      }
      
      if (card.effect === "verstaerkung" && adjacentOwnCards > 0) {
        sources.push(`💪 Verstärkung verfügbar: ${adjacentOwnCards} eigene Nachbarkarte${adjacentOwnCards > 1 ? 'n' : ''} (+${adjacentOwnCards} im Kampf)`);
      }
      
      if (card.effect === "staerkung" && adjacentSameElementCards > 0) {
        sources.push(`💎 Stärkung verfügbar: ${adjacentSameElementCards} benachbarte ${card.element}-Karte${adjacentSameElementCards > 1 ? 'n' : ''} (+${adjacentSameElementCards} im Kampf)`);
      }
    }
    
    // If no specific bonus sources found, provide basic information
    if (sources.length === 0 && hasChange) {
      sources.push(`Grundwert: ${originalValue} → ${currentValue}`);
      if (difference > 0) {
        sources.push("✨ Unbekannter Bonus aktiv");
      } else if (difference < 0) {
        sources.push("💔 Schaden erhalten");
      }
    }
    
    // Shield effect removed (for shield cards when broken)
    if (!isPositive && card.effect === "schild" && shieldBroken) {
      sources.push("🛡️💔 Schild zerbrochen");
    }
    
    // Damage from Blitzschlag attack
    if (!isPositive && difference === -2) {
      sources.push("⚡ Blitzschlag-Angriff (-2)");
    }
    
    // General damage from various effects
    if (!isPositive && difference === -1) {
      sources.push("💥 Schaden durch Effekt (-1)");
    }
    
    // Generic positive bonus from other effects
    if (isPositive && sources.length === 0) {
      if (difference === 1) {
        sources.push("✨ Bonus-Effekt (+1)");
      } else {
        sources.push(`✨ Verstärkungseffekt (+${difference})`);
      }
    }
    
    // Generic negative malus from other effects  
    if (!isPositive && sources.length === 0) {
      sources.push(`💔 Schwächungseffekt (${difference})`);
    }
    
    return sources;
  };

  const sources = getChangeSource();

  // If no useful content to show, return plain children
  if (!shouldShowTooltip) {
    return <div>{children}</div>;
  }

  return (
    <div 
      ref={triggerRef}
      className="relative inline-block cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {children}
      
      {isHovered && createPortal(
        <div 
          ref={tooltipRef}
          className="fixed z-[99999] px-3 py-2 text-xs font-medium text-white bg-gray-900 rounded-lg shadow-xl border border-gray-600 pointer-events-none max-w-xs"
          style={{
            top: `${tooltipPosition.top}px`,
            left: `${tooltipPosition.left}px`,
          }}>
          
          <div className="relative z-10">
            {hasChange && (
              <div className={cn(
                "font-bold mb-1",
                isPositive ? "text-green-400" : "text-red-400"
              )}>
                {originalValue} → {currentValue} ({isPositive ? '+' : ''}{difference})
              </div>
            )}
            
            {!hasChange && hasPotentialBonus && (
              <div className="font-bold mb-1 text-blue-400">
                Kampf-Boni verfügbar
              </div>
            )}
            
            {sources.length > 0 ? sources.map((source, index) => (
              <div key={index} className="text-gray-300 leading-tight">
                {source}
              </div>
            )) : (
              <div className="text-gray-300 leading-tight">
                Grundwert: {currentValue}
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}