import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, X, Gift, Star, Diamond } from "lucide-react";
import { Button } from "./ui/button";
import { Achievement, useAchievements } from "../lib/stores/useAchievements";
import { useAudio } from "../lib/stores/useAudio";

interface AchievementNotificationProps {
  achievement: Achievement;
  onClose: () => void;
  onViewDetails: () => void;
}

const getRarityStyles = (rarity: string) => {
  switch (rarity) {
    case "legendary":
      return {
        gradient: "from-yellow-400 via-amber-500 to-orange-600",
        glow: "shadow-2xl shadow-yellow-500/50",
        border: "border-yellow-400",
        sparkles: true
      };
    case "epic":
      return {
        gradient: "from-purple-400 via-violet-500 to-indigo-600",
        glow: "shadow-2xl shadow-purple-500/50", 
        border: "border-purple-400",
        sparkles: true
      };
    case "rare":
      return {
        gradient: "from-blue-400 via-cyan-500 to-teal-600",
        glow: "shadow-xl shadow-blue-500/40",
        border: "border-blue-400",
        sparkles: false
      };
    default:
      return {
        gradient: "from-gray-400 via-slate-500 to-gray-600",
        glow: "shadow-lg shadow-gray-500/30",
        border: "border-gray-400",
        sparkles: false
      };
  }
};

export function AchievementNotification({ 
  achievement, 
  onClose, 
  onViewDetails 
}: AchievementNotificationProps) {
  const { playSuccess } = useAudio();
  const [isVisible, setIsVisible] = useState(false);
  const styles = getRarityStyles(achievement.rarity);

  useEffect(() => {
    setIsVisible(true);
    playSuccess();
    
    // Auto close after 8 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 500);
    }, 8000);

    return () => clearTimeout(timer);
  }, [onClose, playSuccess]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 500);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: -100 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: -100 }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
          className="fixed top-4 right-4 z-50 max-w-sm w-full"
        >
          <motion.div
            className={`relative bg-slate-900 rounded-xl border-2 ${styles.border} ${styles.glow} overflow-hidden`}
            animate={{
              boxShadow: [
                styles.glow,
                styles.glow.replace("shadow-2xl", "shadow-3xl"),
                styles.glow
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {/* Background gradient overlay */}
            <div className={`absolute inset-0 bg-gradient-to-br ${styles.gradient} opacity-10`} />
            
            {/* Sparkle effects for epic/legendary */}
            {styles.sparkles && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute"
                    style={{
                      left: `${20 + (i * 15)}%`,
                      top: `${10 + (i % 3) * 25}%`
                    }}
                    animate={{
                      opacity: [0, 1, 0],
                      scale: [0.5, 1, 0.5],
                      rotate: [0, 180, 360]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.3,
                      ease: "easeInOut"
                    }}
                  >
                    <Star className="w-3 h-3 text-yellow-300" />
                  </motion.div>
                ))}
              </div>
            )}

            {/* Close button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="absolute top-2 right-2 text-white hover:bg-white/20 w-6 h-6 p-0"
            >
              <X className="w-3 h-3" />
            </Button>

            <div className="relative p-4">
              {/* Header */}
              <div className="flex items-start gap-3 mb-3">
                <motion.div
                  animate={{ 
                    rotate: [0, 10, -10, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    duration: 0.8, 
                    repeat: 2,
                    ease: "easeInOut"
                  }}
                  className="text-2xl"
                >
                  {achievement.icon}
                </motion.div>
                <div className="flex-1 min-w-0">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Trophy className={`w-4 h-4 ${styles.border.replace('border-', 'text-')}`} />
                      <span className="text-xs font-medium text-gray-300 uppercase tracking-wide">
                        Erfolg freigeschaltet
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white truncate">
                      {achievement.title}
                    </h3>
                  </motion.div>
                </div>
              </div>

              {/* Description */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-sm text-gray-300 mb-3 leading-relaxed"
              >
                {achievement.description}
              </motion.p>

              {/* Reward */}
              {achievement.reward && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  className={`flex items-center gap-2 p-2 rounded-lg bg-gradient-to-r ${styles.gradient} bg-opacity-20 border border-opacity-30 ${styles.border}`}
                >
                  <Gift className="w-4 h-4 text-yellow-300" />
                  <span className="text-sm text-white font-medium">
                    Belohnung: 
                    {achievement.reward.type === "diamonds" && (
                      <span className="flex items-center gap-1 ml-1">
                        <Diamond className="w-3 h-3 text-cyan-300" />
                        {achievement.reward.amount}
                      </span>
                    )}
                  </span>
                </motion.div>
              )}

              {/* Action buttons */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="flex gap-2 mt-4"
              >
                <Button
                  onClick={onViewDetails}
                  variant="outline"
                  size="sm"
                  className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
                >
                  Details anzeigen
                </Button>
                <Button
                  onClick={handleClose}
                  size="sm"
                  className={`bg-gradient-to-r ${styles.gradient} text-white font-medium hover:opacity-90 transition-opacity`}
                >
                  Super!
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Main notification manager component
export function AchievementNotificationManager() {
  const { pendingNotifications, clearNotifications, markAsViewed } = useAchievements();
  const [currentNotification, setCurrentNotification] = useState<Achievement | null>(null);

  useEffect(() => {
    if (pendingNotifications.length > 0 && !currentNotification) {
      setCurrentNotification(pendingNotifications[0]);
    }
  }, [pendingNotifications, currentNotification]);

  const handleClose = () => {
    if (currentNotification) {
      markAsViewed(currentNotification.id);
      setCurrentNotification(null);
      
      // Remove from pending and show next if any
      const remaining = pendingNotifications.slice(1);
      if (remaining.length === 0) {
        clearNotifications();
      } else {
        setTimeout(() => {
          setCurrentNotification(remaining[0]);
        }, 1000);
      }
    }
  };

  const handleViewDetails = () => {
    // TODO: Open achievements panel or modal
    console.log("Opening achievements panel...");
    handleClose();
  };

  if (!currentNotification) return null;

  return (
    <AchievementNotification
      achievement={currentNotification}
      onClose={handleClose}
      onViewDetails={handleViewDetails}
    />
  );
}