import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AchievementBadge, BadgeCollection, type Badge } from './AchievementBadge';
import { useBadges } from '../lib/stores/useBadges';
import { cn } from '../lib/utils';

interface PlayerBadgeShowcaseProps {
  isOpen: boolean;
  onClose: () => void;
}

const categoryLabels = {
  gameplay: 'Gameplay',
  collection: 'Sammlung',
  streak: 'Serien',
  milestone: 'Meilensteine',
  special: 'Besonders',
  social: 'Sozial'
};

const rarityLabels = {
  bronze: 'Bronze',
  silver: 'Silber', 
  gold: 'Gold',
  platinum: 'Platin',
  diamond: 'Diamant'
};

export function PlayerBadgeShowcase({ isOpen, onClose }: PlayerBadgeShowcaseProps) {
  const { badges, milestones, playerStats, getBadgesByCategory, getUnlockedBadges } = useBadges();
  const [selectedCategory, setSelectedCategory] = useState<Badge['category'] | 'all'>('all');
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  
  const unlockedBadges = getUnlockedBadges();
  const categories: (Badge['category'] | 'all')[] = ['all', 'gameplay', 'collection', 'streak', 'milestone', 'special', 'social'];
  
  const filteredBadges = selectedCategory === 'all' 
    ? badges 
    : getBadgesByCategory(selectedCategory);

  const handleBadgeClick = (badge: Badge) => {
    setSelectedBadge(badge);
  };

  const getProgressForBadge = (badge: Badge) => {
    const milestone = milestones.find(m => m.badgeId === badge.id);
    if (milestone) {
      return {
        current: milestone.current,
        total: milestone.target
      };
    }
    return undefined;
  };

  const getStatisticsCards = () => [
    { label: 'Freigeschaltete Abzeichen', value: unlockedBadges.length, total: badges.length },
    { label: 'Gespielte Spiele', value: playerStats.totalGames },
    { label: 'Siege', value: playerStats.totalWins },
    { label: 'Längste Siegesserie', value: playerStats.longestWinStreak },
    { label: 'Gesammelte Karten', value: playerStats.totalCards },
    { label: 'Spielzeit (Stunden)', value: Math.floor(playerStats.hoursPlayed) }
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          className="bg-slate-900 rounded-xl shadow-2xl border border-slate-700 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-6 border-b border-slate-700">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Meine Abzeichen</h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>
            
            {/* Statistics Summary */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
              {getStatisticsCards().map((stat, index) => (
                <div key={index} className="bg-slate-800 rounded-lg p-3">
                  <div className="text-gray-400 text-xs">{stat.label}</div>
                  <div className="text-white font-bold text-lg">
                    {stat.value}
                    {stat.total && <span className="text-gray-400">/{stat.total}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Category Filter */}
          <div className="p-4 border-b border-slate-700">
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={cn(
                    "px-4 py-2 rounded-full text-sm font-medium transition-all",
                    selectedCategory === category
                      ? "bg-blue-600 text-white"
                      : "bg-slate-700 text-gray-300 hover:bg-slate-600"
                  )}
                >
                  {category === 'all' ? 'Alle' : categoryLabels[category]}
                </button>
              ))}
            </div>
          </div>

          {/* Badge Grid */}
          <div className="p-6">
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
              {filteredBadges.map(badge => {
                const progress = getProgressForBadge(badge);
                return (
                  <motion.div
                    key={badge.id}
                    layout
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col items-center"
                  >
                    <AchievementBadge
                      badge={{ ...badge, progress }}
                      size="medium"
                      isLocked={!badge.unlockedAt}
                      showProgress={true}
                      onClick={() => handleBadgeClick({ ...badge, progress })}
                    />
                    <div className="text-xs text-gray-400 mt-2 text-center">
                      {badge.title}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {filteredBadges.length === 0 && (
              <div className="text-center text-gray-400 py-8">
                Keine Abzeichen in dieser Kategorie gefunden.
              </div>
            )}
          </div>
        </motion.div>

        {/* Badge Detail Modal */}
        {selectedBadge && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-60 p-4"
            onClick={() => setSelectedBadge(null)}
          >
            <div
              className="bg-slate-900 rounded-xl shadow-2xl border border-slate-700 max-w-md w-full p-6"
              onClick={e => e.stopPropagation()}
            >
              <div className="text-center">
                <div className="mb-4 flex justify-center">
                  <AchievementBadge
                    badge={selectedBadge}
                    size="large"
                    isLocked={!selectedBadge.unlockedAt}
                    showProgress={true}
                    showTooltip={false}
                  />
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">
                  {selectedBadge.title}
                </h3>
                
                <p className="text-gray-300 mb-4">
                  {selectedBadge.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="bg-slate-800 rounded-lg p-3">
                    <div className="text-gray-400">Seltenheit</div>
                    <div className="text-white font-medium">
                      {rarityLabels[selectedBadge.rarity]}
                    </div>
                  </div>
                  
                  <div className="bg-slate-800 rounded-lg p-3">
                    <div className="text-gray-400">Kategorie</div>
                    <div className="text-white font-medium">
                      {categoryLabels[selectedBadge.category]}
                    </div>
                  </div>
                </div>
                
                {selectedBadge.progress && (
                  <div className="mt-4 bg-slate-800 rounded-lg p-3">
                    <div className="text-gray-400 text-sm mb-2">Fortschritt</div>
                    <div className="flex justify-between text-white font-medium mb-2">
                      <span>{selectedBadge.progress.current}</span>
                      <span>{selectedBadge.progress.total}</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{
                          width: `${Math.min((selectedBadge.progress.current / selectedBadge.progress.total) * 100, 100)}%`
                        }}
                      />
                    </div>
                  </div>
                )}
                
                {selectedBadge.unlockedAt && (
                  <div className="mt-4 text-green-400 text-sm">
                    ✓ Freigeschaltet am {selectedBadge.unlockedAt.toLocaleDateString('de-DE')}
                  </div>
                )}
                
                <button
                  onClick={() => setSelectedBadge(null)}
                  className="mt-6 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Schließen
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}