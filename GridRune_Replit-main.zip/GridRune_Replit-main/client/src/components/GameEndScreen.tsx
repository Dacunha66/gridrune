import { useCardGame } from "../lib/stores/useCardGame";
import { useAchievements } from "../lib/stores/useAchievements";
import { useSeasonalRewards } from "../lib/stores/useSeasonalRewards";
import { useWeeklyChallenges } from "../lib/stores/useWeeklyChallenges";
import { useBadges } from "../lib/stores/useBadges";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Trophy, RotateCcw, Home, Eye, Sparkles } from "lucide-react";
import { cn } from "../lib/utils";
import { AvatarDisplay } from './AvatarSelector';
import { useState, useEffect, useRef } from "react";
import { GameBoard } from "./GameBoard";

export function GameEndScreen() {
  const { 
    winner, 
    player1Score, 
    player2Score, 
    gameMode, 
    initializeGame, 
    resetToMenu,
    player1Name,
    player2Name,
    player1Avatar,
    player2Avatar,
    boardSize
  } = useCardGame();
  const { onGameWon } = useAchievements();
  const { updatePlayerStats, playerStats } = useBadges();
  const seasonalRewards = useSeasonalRewards();
  const weeklyChallenges = useWeeklyChallenges();
  const [showBoard, setShowBoard] = useState(false);
  const [xpEarned, setXpEarned] = useState(0);
  const processedGame = useRef(false);

  // Trigger achievement and badge progress when game ends
  useEffect(() => {
    if (processedGame.current) return;
    
    // Update game statistics for badges
    const newStats = {
      totalGames: playerStats.totalGames + 1,
      ...(gameMode !== "ai" && { multiplayerGames: playerStats.multiplayerGames + 1 })
    };

    if (winner === "player1") {
      onGameWon();
      
      // Update win-related stats for badges
      const isPerfectGame = player1Score === (boardSize === "4x4" ? 8 : 5);
      const newWinStreak = playerStats.currentWinStreak + 1;
      
      Object.assign(newStats, {
        totalWins: playerStats.totalWins + 1,
        currentWinStreak: newWinStreak,
        longestWinStreak: Math.max(playerStats.longestWinStreak, newWinStreak),
        ...(isPerfectGame && { perfectGames: playerStats.perfectGames + 1 })
      });
      
      // Award seasonal XP based on game mode and performance
      const baseXP = gameMode === "ai" ? 50 : 25;
      const bonusXP = (player1Score > player2Score + 3) ? 25 : 0; // Bonus for dominant wins
      const totalXP = baseXP + bonusXP;
      seasonalRewards.addSeasonXP(totalXP);
      setXpEarned(totalXP);
      
      // Update weekly challenge progress
      weeklyChallenges.updateTaskProgress('win_5_games', (weeklyChallenges.currentChallenge?.tasks.find(t => t.id === 'win_5_games')?.progress || 0) + 1);
      weeklyChallenges.updateTaskProgress('play_10_games', (weeklyChallenges.currentChallenge?.tasks.find(t => t.id === 'play_10_games')?.progress || 0) + 1);
      
      if (gameMode === "ai") {
        weeklyChallenges.updateTaskProgress('defeat_ai_hard', (weeklyChallenges.currentChallenge?.tasks.find(t => t.id === 'defeat_ai_hard')?.progress || 0) + 1);
      }
      
      // Check for perfect game in weekly challenges
      if (isPerfectGame) {
        weeklyChallenges.updateTaskProgress('perfect_games', (weeklyChallenges.currentChallenge?.tasks.find(t => t.id === 'perfect_games')?.progress || 0) + 1);
      }
    } else {
      // Reset win streak on loss
      Object.assign(newStats, {
        currentWinStreak: 0
      });
      
      if (gameMode !== "ai") {
        // Award XP for participating in multiplayer even when losing
        seasonalRewards.addSeasonXP(10);
        setXpEarned(10);
        
        // Update weekly challenge for participation
        weeklyChallenges.updateTaskProgress('play_10_games', (weeklyChallenges.currentChallenge?.tasks.find(t => t.id === 'play_10_games')?.progress || 0) + 1);
      }
    }
    
    // Update badge statistics
    updatePlayerStats(newStats);
    
    processedGame.current = true;
  }, [winner, onGameWon, gameMode, player1Score, player2Score, seasonalRewards, weeklyChallenges, boardSize, playerStats, updatePlayerStats]);

  const getWinnerText = () => {
    if (winner === "tie") {
      return "Unentschieden!";
    }
    
    if (gameMode === "ai") {
      return winner === "player1" ? `${player1Name} hat gewonnen!` : "KI hat gewonnen!";
    }
    
    return winner === "player1" ? `${player1Name} hat gewonnen!` : `${player2Name} hat gewonnen!`;
  };

  const getWinnerColor = () => {
    if (winner === "tie") return "text-yellow-400";
    if (gameMode === "ai") {
      return winner === "player1" ? "text-green-400" : "text-red-400";
    }
    return winner === "player1" ? "text-blue-400" : "text-red-400";
  };

  const getWinnerIcon = () => {
    if (winner === "tie") return "🤝";
    if (gameMode === "ai") {
      return winner === "player1" ? "🎉" : "🤖";
    }
    return winner === "player1" ? "🔵" : "🔴";
  };

  if (showBoard) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Finales Spielfeld</h2>
            <Button 
              onClick={() => setShowBoard(false)}
              variant="outline"
              className="border-green-400 text-green-400 hover:bg-green-400 hover:text-white"
            >
              <Eye className="w-4 h-4 mr-2" />
              Zurück zum Ergebnis
            </Button>
          </div>
          <div className="flex justify-center">
            <GameBoard hideTitle={true} hideMessages={true} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white flex items-center justify-center p-4">
      <Card className="bg-slate-800 border-slate-600 max-w-md w-full">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-6 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full w-20 h-20 flex items-center justify-center">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <CardTitle className={cn("text-4xl font-bold mb-2", getWinnerColor())}>
            {getWinnerText()}
          </CardTitle>
          
          {/* Winner's Avatar */}
          {winner !== "tie" && (
            <div className="mb-4 flex justify-center">
              <AvatarDisplay 
                avatar={winner === "player1" ? player1Avatar : player2Avatar}
                size="large"
                showName={false}
              />
            </div>
          )}
          
          <div className="text-6xl mb-4">
            {getWinnerIcon()}
          </div>
        </CardHeader>
        
        <CardContent className="text-center">

          {/* Seasonal XP Earned Display */}
          {xpEarned > 0 && (
            <div className="bg-gradient-to-r from-cyan-600/20 to-blue-600/20 border border-cyan-400/30 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-center gap-2 text-cyan-300">
                <Sparkles className="w-5 h-5" />
                <span className="text-lg font-semibold">
                  +{xpEarned} Saison XP erhalten!
                </span>
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="text-sm text-cyan-400/70 mt-1">
                Fortschritt in der {seasonalRewards.currentSeason?.name || 'aktuellen Saison'}
              </div>
            </div>
          )}
          
          <div className="space-y-3">
            <Button 
              onClick={() => setShowBoard(!showBoard)}
              variant="outline"
              className="w-full border-green-400 text-green-400 hover:bg-green-400 hover:text-white py-3 text-lg"
            >
              <Eye className="w-5 h-5 mr-2" />
              {showBoard ? "Ergebnis zeigen" : "Spielfeld ansehen"}
            </Button>
            
            <Button 
              onClick={initializeGame}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Nochmal spielen
            </Button>
            
            <Button 
              onClick={resetToMenu}
              variant="outline"
              className="w-full text-white border-slate-600 hover:bg-slate-700 font-semibold py-3 px-6 rounded-lg transition-colors"
            >
              <Home className="w-4 h-4 mr-2" />
              Zurück zum Menü
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}