/**
 * Mobile Selection Guide Component
 * Provides contextual help and feedback for mobile card selection
 */

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SelectionMode } from '../lib/mobileCardSelection';

interface MobileSelectionGuideProps {
  isVisible: boolean;
  mode: SelectionMode;
  selectedCardIndex: number | null;
  totalCards: number;
  onDismiss?: () => void;
}

const selectionInstructions = {
  [SelectionMode.BROWSE]: {
    title: "Karten durchsuchen",
    instructions: [
      "Tippen: Karte auswählen",
      "Lang drücken: Schnellauswahl",
      "Doppelt tippen: Sofort bestätigen",
      "Wischen: Zwischen Karten navigieren"
    ],
    color: "text-slate-400"
  },
  [SelectionMode.SELECT]: {
    title: "Karte auswählen",
    instructions: [
      "Tippen: Auswahl bestätigen",
      "Andere Karte tippen: Auswahl ändern",
      "Lang drücken: Kartendetails anzeigen"
    ],
    color: "text-blue-400"
  },
  [SelectionMode.CONFIRM]: {
    title: "Auswahl bestätigt",
    instructions: [
      "Karte wird automatisch gespielt",
      "Tippen Sie auf das Spielfeld",
      "Andere Karte: Auswahl ändern"
    ],
    color: "text-green-400"
  },
  [SelectionMode.PREVIEW]: {
    title: "Kartenvorschau",
    instructions: [
      "Tippen: Karte auswählen",
      "Andere Karte: Vorschau wechseln",
      "Wischen: Navigation verlassen"
    ],
    color: "text-purple-400"
  }
};

export function MobileSelectionGuide({
  isVisible,
  mode,
  selectedCardIndex,
  totalCards,
  onDismiss
}: MobileSelectionGuideProps) {
  const currentInstructions = selectionInstructions[mode];

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.9 }}
          className="fixed bottom-4 left-4 right-4 z-50 lg:hidden"
        >
          <div className="bg-slate-900/95 backdrop-blur-sm border border-slate-600 rounded-xl p-4 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className={`font-bold text-sm ${currentInstructions.color}`}>
                {currentInstructions.title}
              </h3>
              {onDismiss && (
                <button
                  onClick={onDismiss}
                  className="text-slate-400 hover:text-white w-6 h-6 flex items-center justify-center rounded-full hover:bg-slate-700"
                >
                  ×
                </button>
              )}
            </div>
            
            {/* Selection Status */}
            {selectedCardIndex !== null && (
              <div className="bg-slate-800 rounded-lg p-2 mb-3">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${
                    mode === SelectionMode.SELECT ? 'bg-blue-400' :
                    mode === SelectionMode.CONFIRM ? 'bg-green-400' :
                    mode === SelectionMode.PREVIEW ? 'bg-purple-400' : 'bg-slate-400'
                  }`} />
                  <span className="text-xs text-slate-300">
                    Karte {selectedCardIndex + 1} von {totalCards}
                  </span>
                  <div className={`ml-auto px-2 py-1 rounded text-xs font-medium ${
                    mode === SelectionMode.SELECT ? 'bg-blue-500/20 text-blue-300' :
                    mode === SelectionMode.CONFIRM ? 'bg-green-500/20 text-green-300' :
                    mode === SelectionMode.PREVIEW ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-500/20 text-slate-300'
                  }`}>
                    {mode === SelectionMode.SELECT && 'Ausgewählt'}
                    {mode === SelectionMode.CONFIRM && 'Bestätigt'}
                    {mode === SelectionMode.PREVIEW && 'Vorschau'}
                    {mode === SelectionMode.BROWSE && 'Durchsuchen'}
                  </div>
                </div>
              </div>
            )}
            
            {/* Instructions */}
            <div className="space-y-1">
              {currentInstructions.instructions.map((instruction, index) => (
                <motion.div
                  key={instruction}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-2 text-xs text-slate-300"
                >
                  <div className="w-1 h-1 bg-slate-500 rounded-full flex-shrink-0" />
                  {instruction}
                </motion.div>
              ))}
            </div>
            
            {/* Quick Tips */}
            <div className="mt-3 pt-3 border-t border-slate-700">
              <div className="text-xs text-slate-400">
                💡 <strong>Tipp:</strong> {
                  mode === SelectionMode.BROWSE ? "Wischen Sie horizontal für mehr Karten" :
                  mode === SelectionMode.SELECT ? "Doppelt tippen für Schnellauswahl" :
                  mode === SelectionMode.CONFIRM ? "Platzieren Sie die Karte auf dem Spielfeld" :
                  "Lang drücken für Kartendetails"
                }
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default MobileSelectionGuide;