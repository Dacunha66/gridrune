import { useState } from "react";
import { useCardGame } from "../lib/stores/useCardGame";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ArrowLeft, Plus, Trash2, RotateCcw } from "lucide-react";
import { Card as GameCard } from "./Card";
import { allCards } from "../lib/cardData";
import { GameCard as GameCardType } from "../lib/cardData";
import { CARD_EFFECTS } from "../lib/cardEffects";
import { CardDetailModal } from "./CardDetailModal";

export function DeckEditor() {
  const { 
    player1Cards, 
    setPlayer1Cards, 
    setGamePhase, 
    boardSize, 
    savedDecks, 
    currentEditingDeck, 
    saveDeck 
  } = useCardGame();
  const [selectedCollection, setSelectedCollection] = useState<GameCardType[]>(allCards);
  const [selectedCard, setSelectedCard] = useState<GameCardType | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const getMaxDeckSize = () => {
    switch (boardSize) {
      case "3x3": return 10; // 5 Handkarten + 5 zusätzliche
      case "4x4": return 15; // 5 Handkarten + 10 zusätzliche für Hauptspiel
      case "5x5": return 25; // Vollständiges erweitertes Deck
      default: return 10;
    }
  };
  
  const getBoardSizeLabel = () => {
    switch (boardSize) {
      case "3x3": return "3x3 (Casual)";
      case "4x4": return "4x4 (Hauptspiel)";
      case "5x5": return "5x5 (Erweitert)";
      default: return "Unbekannt";
    }
  };
  
  const maxDeckSize = getMaxDeckSize();
  
  const handleAddCard = (card: GameCardType) => {
    if (player1Cards.length < maxDeckSize) {
      setPlayer1Cards([...player1Cards, card]);
    }
  };

  const handleRemoveCard = (index: number) => {
    const newDeck = player1Cards.filter((_, i) => i !== index);
    setPlayer1Cards(newDeck);
  };

  const handleReplaceCard = (index: number, newCard: GameCardType) => {
    const newDeck = [...player1Cards];
    newDeck[index] = newCard;
    setPlayer1Cards(newDeck);
  };

  const resetToDefaultDeck = () => {
    // Standard-Deck wiederherstellen
    const defaultDeck = allCards.slice(0, maxDeckSize);
    setPlayer1Cards(defaultDeck);
  };

  const getAvailableCards = () => {
    return selectedCollection.filter(card => 
      !player1Cards.some(playerCard => playerCard.id === card.id)
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            onClick={() => setGamePhase("menu")}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zum Menü
          </Button>
          
          <div>
            <h1 className="text-3xl font-bold">Deck bearbeiten</h1>
            <p className="text-slate-300 mt-1">Spielfeld: {getBoardSizeLabel()} - Deck: {player1Cards.length}/{maxDeckSize} Karten</p>
          </div>
          
          <Button 
            onClick={resetToDefaultDeck}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Standard-Deck
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Aktuelles Deck */}
          <Card className="bg-slate-800 border-slate-600">
            <CardHeader>
              <CardTitle className="text-white text-xl">
                Dein Deck ({player1Cards.length}/{maxDeckSize})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4">
                {player1Cards.map((card, index) => (
                  <div key={`deck-${card.id}-${index}`} className="flex items-center gap-4 p-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-all duration-200 hover:shadow-lg group">
                    <div className="flex-shrink-0 cursor-pointer transform transition-all duration-200 hover:scale-105 hover:-translate-y-1" onClick={() => {
                      setSelectedCard(card);
                      setIsDetailModalOpen(true);
                    }}>
                      <GameCard 
                        card={card}
                        onClick={() => {
                          setSelectedCard(card);
                          setIsDetailModalOpen(true);
                        }}
                      />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold text-white">{card.name}</h3>
                      <div className="text-sm text-slate-300 grid grid-cols-2 gap-2 mt-1">
                        <span>Oben: {card.top}</span>
                        <span>Rechts: {card.right}</span>
                        <span>Unten: {card.bottom}</span>
                        <span>Links: {card.left}</span>
                      </div>
                      {card.effect && (
                        <div className="text-sm mt-2">
                          <div className="text-yellow-400 flex items-center gap-1 mb-1">
                            <span>{CARD_EFFECTS[card.effect].symbol}</span>
                            <span className="font-medium">{CARD_EFFECTS[card.effect].name}</span>
                          </div>
                          <div className="text-slate-400 text-xs leading-relaxed">
                            {CARD_EFFECTS[card.effect].description}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button
                      onClick={() => handleRemoveCard(index)}
                      variant="outline"
                      size="sm"
                      className="text-red-400 border-red-400 hover:bg-red-400 hover:text-white"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                
                {/* Leere Plätze anzeigen */}
                {Array.from({ length: maxDeckSize - player1Cards.length }).map((_, index) => (
                  <div key={`empty-${index}`} className="p-3 bg-slate-700/50 rounded-lg border-2 border-dashed border-slate-600 text-center text-slate-400">
                    Leerer Platz
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Verfügbare Karten */}
          <Card className="bg-slate-800 border-slate-600">
            <CardHeader>
              <CardTitle className="text-white text-xl">
                Verfügbare Karten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto">
                {getAvailableCards().map((card) => (
                  <div key={`available-${card.id}`} className="flex items-center gap-4 p-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-all duration-200 hover:shadow-lg group">
                    <div className="flex-shrink-0 cursor-pointer transform transition-all duration-200 hover:scale-105 hover:-translate-y-1" onClick={() => {
                      setSelectedCard(card);
                      setIsDetailModalOpen(true);
                    }}>
                      <GameCard 
                        card={card}
                        onClick={() => {
                          setSelectedCard(card);
                          setIsDetailModalOpen(true);
                        }}
                      />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold text-white">{card.name}</h3>
                      <div className="text-sm text-slate-300 grid grid-cols-2 gap-2 mt-1">
                        <span>Oben: {card.top}</span>
                        <span>Rechts: {card.right}</span>
                        <span>Unten: {card.bottom}</span>
                        <span>Links: {card.left}</span>
                      </div>
                      {card.effect && (
                        <div className="text-sm mt-2">
                          <div className="text-yellow-400 flex items-center gap-1 mb-1">
                            <span>{CARD_EFFECTS[card.effect].symbol}</span>
                            <span className="font-medium">{CARD_EFFECTS[card.effect].name}</span>
                          </div>
                          <div className="text-slate-400 text-xs leading-relaxed">
                            {CARD_EFFECTS[card.effect].description}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button
                      onClick={() => handleAddCard(card)}
                      disabled={player1Cards.length >= maxDeckSize}
                      variant="outline"
                      size="sm"
                      className="text-green-400 border-green-400 hover:bg-green-400 hover:text-white disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Hinweise */}
        <div className="mt-8 p-4 bg-slate-800 rounded-lg border border-slate-600">
          <h3 className="text-lg font-semibold text-white mb-2">Hinweise:</h3>
          <ul className="text-slate-300 text-sm space-y-1">
            <li>• Du kannst bis zu {maxDeckSize} Karten in deinem Deck haben ({boardSize === "5x5" ? "5x5 Modus" : "3x3 Modus"})</li>
            <li>• Klicke auf das Plus-Symbol um eine Karte hinzuzufügen</li>
            <li>• Klicke auf das Mülleimer-Symbol um eine Karte zu entfernen</li>
            <li>• Jede Karte kann nur einmal im Deck sein</li>
          </ul>
        </div>

        {/* Card Detail Modal */}
        <CardDetailModal
          card={selectedCard}
          isOpen={isDetailModalOpen}
          onClose={() => {
            setIsDetailModalOpen(false);
            setSelectedCard(null);
          }}
        />
      </div>
    </div>
  );
}