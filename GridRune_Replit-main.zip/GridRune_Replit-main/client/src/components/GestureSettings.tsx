import React, { useState, useEffect } from 'react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Slider } from "./ui/slider";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { Vibrate, VolumeX, Volume2, Smartphone, Hand, Zap } from "lucide-react";
import { hapticFeedback } from "../lib/hapticFeedback";
import { cn } from "../lib/utils";

interface GestureSettingsProps {
  onClose?: () => void;
}

export function GestureSettings({ onClose }: GestureSettingsProps) {
  const [hapticEnabled, setHapticEnabled] = useState(hapticFeedback.getEnabled());
  const [isSupported, setIsSupported] = useState(hapticFeedback.isHapticSupported());
  const [gestureIntensity, setGestureIntensity] = useState(50);
  const [showGestureHelp, setShowGestureHelp] = useState(false);

  useEffect(() => {
    setIsSupported(hapticFeedback.isHapticSupported());
  }, []);

  const handleHapticToggle = (enabled: boolean) => {
    setHapticEnabled(enabled);
    hapticFeedback.setEnabled(enabled);
    
    if (enabled) {
      // Test haptic feedback when enabling
      hapticFeedback.selection();
    }
  };

  const testHapticType = (type: string) => {
    if (!hapticEnabled) return;
    
    switch (type) {
      case 'light':
        hapticFeedback.light();
        break;
      case 'medium':
        hapticFeedback.medium();
        break;
      case 'heavy':
        hapticFeedback.heavy();
        break;
      case 'selection':
        hapticFeedback.selection();
        break;
      case 'success':
        hapticFeedback.success();
        break;
      case 'error':
        hapticFeedback.error();
        break;
      case 'cardSelect':
        hapticFeedback.cardSelect();
        break;
      case 'cardPlace':
        hapticFeedback.cardPlace();
        break;
      case 'cardBattle':
        hapticFeedback.cardBattle();
        break;
    }
  };

  const gestureGuide = [
    {
      title: "Karten Navigation",
      gestures: [
        { name: "Links/Rechts wischen", description: "Durch Handkarten scrollen", icon: "👈👉" },
        { name: "Hoch/Runter wischen", description: "Modus wechseln (Swipe ↔ Select)", icon: "👆👇" }
      ]
    },
    {
      title: "Karten Auswahl", 
      gestures: [
        { name: "Einfacher Tap", description: "Karte auswählen", icon: "👆" },
        { name: "Langer Druck", description: "Schnell-Auswahl", icon: "🔸" },
        { name: "Doppel-Tap", description: "Auswählen & Bestätigen", icon: "👆👆" }
      ]
    },
    {
      title: "Spielfeld Interaktion",
      gestures: [
        { name: "Tap leeres Feld", description: "Karte platzieren", icon: "🎯" },
        { name: "Tap besetztes Feld", description: "Karten-Details anzeigen", icon: "ℹ️" },
        { name: "Langer Druck", description: "Erweiterte Karten-Info", icon: "📋" }
      ]
    }
  ];

  return (
    <Card className="bg-slate-800 border-slate-600 p-6 max-w-lg mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Smartphone className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Gesten & Haptik</h2>
        </div>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            ✕
          </Button>
        )}
      </div>

      {/* Haptic Feedback Settings */}
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Vibrate className="w-5 h-5 text-purple-400" />
            Haptisches Feedback
          </h3>
          
          {!isSupported && (
            <div className="bg-amber-900/50 border border-amber-600 rounded-lg p-3">
              <p className="text-amber-200 text-sm">
                ⚠️ Ihr Gerät unterstützt kein haptisches Feedback
              </p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <Label htmlFor="haptic-toggle" className="text-slate-300">
              Haptik aktivieren
            </Label>
            <Switch 
              id="haptic-toggle"
              checked={hapticEnabled && isSupported}
              onCheckedChange={handleHapticToggle}
              disabled={!isSupported}
            />
          </div>

          {hapticEnabled && isSupported && (
            <div className="space-y-3">
              <Label className="text-slate-300 text-sm">Intensität testen:</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => testHapticType('light')}
                  className="text-xs"
                >
                  Leicht
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => testHapticType('medium')}
                  className="text-xs"
                >
                  Mittel
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => testHapticType('heavy')}
                  className="text-xs"
                >
                  Stark
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label className="text-slate-300 text-sm">Spiel-Feedback testen:</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => testHapticType('cardSelect')}
                    className="text-xs"
                  >
                    🃏 Karte wählen
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => testHapticType('cardPlace')}
                    className="text-xs"
                  >
                    🎯 Karte legen
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => testHapticType('cardBattle')}
                    className="text-xs"
                  >
                    ⚔️ Kampf
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => testHapticType('success')}
                    className="text-xs"
                  >
                    ✅ Erfolg
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Gesture Guide */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Hand className="w-5 h-5 text-green-400" />
              Gesten-Guide
            </h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShowGestureHelp(!showGestureHelp)}
            >
              {showGestureHelp ? "Verbergen" : "Anzeigen"}
            </Button>
          </div>

          {showGestureHelp && (
            <div className="space-y-4">
              {gestureGuide.map((section, index) => (
                <div key={index} className="bg-slate-700/50 rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-3">{section.title}</h4>
                  <div className="space-y-2">
                    {section.gestures.map((gesture, gIndex) => (
                      <div key={gIndex} className="flex items-center gap-3">
                        <span className="text-lg">{gesture.icon}</span>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-slate-200">{gesture.name}</div>
                          <div className="text-xs text-slate-400">{gesture.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Mobile-specific tips */}
        <div className="bg-blue-900/30 border border-blue-600/50 rounded-lg p-4">
          <h4 className="font-semibold text-blue-200 mb-2 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Mobile Tipps
          </h4>
          <ul className="text-sm text-blue-100 space-y-1">
            <li>• Hoch/Runter wischen wechselt zwischen Scroll- und Auswahl-Modus</li>
            <li>• Doppel-Tap für schnelle Kartenauswahl</li>
            <li>• Langer Druck zeigt Karten-Details</li>
            <li>• Grüne Punkte zeigen gültige Positionen</li>
          </ul>
        </div>
      </div>
    </Card>
  );
}