import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { useMultiplayer } from '../lib/stores/useMultiplayer';
import { useCardGame } from '../lib/stores/useCardGame';

export function MultiplayerLobby() {
  const [roomIdInput, setRoomIdInput] = useState('');
  const [playerNameInput, setPlayerNameInput] = useState('');
  const {
    isConnected,
    roomId,
    playerName,
    roomPlayers,
    isHost,
    gameStarted,
    connect,
    disconnect,
    joinRoom,
    leaveRoom,
    toggleReady,
    setPlayerName
  } = useMultiplayer();

  const { startMultiplayerGame } = useCardGame();

  useEffect(() => {
    if (!isConnected) {
      connect();
    }

    return () => {
      if (isConnected) {
        disconnect();
      }
    };
  }, []);

  useEffect(() => {
    if (gameStarted) {
      startMultiplayerGame();
    }
  }, [gameStarted]);

  const handleJoinRoom = () => {
    if (roomIdInput.trim() && playerNameInput.trim()) {
      setPlayerName(playerNameInput.trim());
      joinRoom(roomIdInput.trim(), playerNameInput.trim());
    }
  };

  const generateRoomId = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleCreateRoom = () => {
    if (playerNameInput.trim()) {
      const newRoomId = generateRoomId();
      setRoomIdInput(newRoomId);
      setPlayerName(playerNameInput.trim());
      joinRoom(newRoomId, playerNameInput.trim());
    }
  };

  if (!isConnected) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Card className="w-96 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-center text-white">Gegner wird gesucht...</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
            </div>
            <div className="text-center text-slate-300">
              Verbindung zum Server wird hergestellt...
            </div>
            <div className="flex justify-center">
              <Button
                variant="outline"
                onClick={() => {
                  disconnect();
                  window.location.reload(); // Return to main menu
                }}
                className="text-white border-slate-600 hover:bg-slate-700"
              >
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (roomId) {
    const currentPlayer = roomPlayers.find(p => p.name === playerName);
    const opponent = roomPlayers.find(p => p.name !== playerName);
    
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Card className="w-96 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-center text-white">Spielraum: {roomId}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-white">
              <h3 className="font-bold mb-2">Spieler ({roomPlayers.length}/2):</h3>
              <div className="space-y-2">
                {roomPlayers.map((player, index) => (
                  <div 
                    key={player.id} 
                    className={`flex justify-between items-center p-2 rounded ${
                      player.name === playerName ? 'bg-purple-600' : 'bg-slate-600'
                    }`}
                  >
                    <span>
                      {player.name} {player.name === playerName && '(Du)'}
                      {index === 0 && isHost && ' (Host)'}
                    </span>
                    <span className={`px-2 py-1 rounded text-xs ${
                      player.ready ? 'bg-green-600' : 'bg-red-600'
                    }`}>
                      {player.ready ? 'Bereit' : 'Nicht bereit'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {roomPlayers.length < 2 && (
              <div className="text-center text-slate-400">
                Warte auf zweiten Spieler...
              </div>
            )}

            <div className="flex gap-2">
              <Button 
                onClick={toggleReady}
                className={`flex-1 ${
                  currentPlayer?.ready 
                    ? 'bg-red-600 hover:bg-red-700' 
                    : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {currentPlayer?.ready ? 'Nicht bereit' : 'Bereit'}
              </Button>
              
              <Button 
                onClick={leaveRoom}
                variant="outline"
                className="border-slate-600 text-white hover:bg-slate-700"
              >
                Verlassen
              </Button>
            </div>

            {roomPlayers.length === 2 && roomPlayers.every(p => p.ready) && (
              <div className="text-center text-green-400 font-bold">
                Spiel startet...
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Card className="w-96 bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-center text-white">Multiplayer Lobby</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-white text-sm font-medium mb-2">
              Dein Name:
            </label>
            <Input
              type="text"
              value={playerNameInput}
              onChange={(e) => setPlayerNameInput(e.target.value)}
              placeholder="Spielername eingeben"
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div>
            <label className="block text-white text-sm font-medium mb-2">
              Raum-ID:
            </label>
            <Input
              type="text"
              value={roomIdInput}
              onChange={(e) => setRoomIdInput(e.target.value.toUpperCase())}
              placeholder="Raum-ID eingeben"
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={handleJoinRoom}
              disabled={!roomIdInput.trim() || !playerNameInput.trim()}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              Raum beitreten
            </Button>
            
            <Button 
              onClick={handleCreateRoom}
              disabled={!playerNameInput.trim()}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              Raum erstellen
            </Button>
          </div>

          <div className="text-center">
            <Button 
              onClick={() => window.location.reload()}
              variant="outline"
              className="border-slate-600 text-white hover:bg-slate-700"
            >
              Zurück zum Menü
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}