import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Avatar } from "./ui/avatar";
import { 
  User, 
  Trophy, 
  Target, 
  Calendar, 
  TrendingUp, 
  Award, 
  Star, 
  Crown, 
  Zap,
  ArrowLeft,
  Edit3,
  Save,
  X,
  Users,
  BarChart3,
  Clock,
  Flame,
  Shield,
  Sword,
  Medal
} from "lucide-react";
import { useAuth } from "../lib/stores/useAuth";
import { AvatarDisplay, AvatarSelector } from "./AvatarSelector";
import { AVAILABLE_AVATARS } from "./AvatarCustomization";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface DetailedPlayerStats {
  profile: {
    id: number;
    displayName: string;
    level: number;
    experience: number;
    favoriteAvatar: string;
    memberSince: string;
    lastSeen: string;
  };
  gameStats: {
    totalGames: number;
    totalWins: number;
    totalLosses: number;
    winRate: number;
    winStreak: number;
    bestWinStreak: number;
    averageGameDuration: number;
    longestGame: number;
    shortestGame: number;
  };
  rankedStats: {
    currentRank: string;
    rankedPoints: number;
    highestRankThisSeason: string;
    seasonWins: number;
    seasonLosses: number;
    rankedWinRate: number;
    rankedWinStreak: number;
    totalPointsEarned: number;
    rankedGamesPlayed: number;
  };
  recentGames: Array<{
    id: number;
    opponent: string;
    isWin: boolean;
    gameMode: string;
    boardSize: string;
    duration: number;
    rankedPointsChanged: number;
    playedAt: string;
  }>;
  monthlyPerformance: Array<{
    month: string;
    games: number;
    wins: number;
    winRate: number;
    pointsGained: number;
  }>;
  achievements: {
    total: number;
    recentlyUnlocked: Array<{
      id: number;
      title: string;
      description: string;
      icon: string;
      unlockedAt: string;
    }>;
  };
}

interface EnhancedPlayerProfileProps {
  onBack: () => void;
}

export function EnhancedPlayerProfile({ onBack }: EnhancedPlayerProfileProps) {
  const { user, updateProfile, isLoading, isGuest } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [detailedStats, setDetailedStats] = useState<DetailedPlayerStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [editForm, setEditForm] = useState({
    displayName: user?.displayName || "",
    favoriteAvatar: user?.favoriteAvatar || "warrior"
  });

  useEffect(() => {
    if (user && !isGuest) {
      loadDetailedStats();
    } else {
      setStatsLoading(false);
    }
  }, [user, isGuest]);

  const loadDetailedStats = async () => {
    try {
      setStatsLoading(true);
      const response = await fetch('/api/player/detailed-stats', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const stats = await response.json();
        setDetailedStats(stats);
      } else {
        console.error('Failed to load detailed stats');
      }
    } catch (error) {
      console.error('Error loading detailed stats:', error);
    } finally {
      setStatsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      await updateProfile(editForm);
      setIsEditing(false);
      await loadDetailedStats();
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getRankColor = (rank: string) => {
    if (rank.includes('bronze')) return 'text-amber-600';
    if (rank.includes('silver')) return 'text-gray-400';
    if (rank.includes('gold')) return 'text-yellow-500';
    if (rank.includes('platinum')) return 'text-cyan-400';
    if (rank.includes('diamond')) return 'text-blue-400';
    if (rank.includes('master')) return 'text-purple-400';
    if (rank.includes('grandmaster')) return 'text-red-400';
    return 'text-slate-400';
  };

  const getRankDisplay = (rank: string) => {
    return rank.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (isGuest) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
            <CardContent className="p-8 text-center">
              <Crown className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
              <h2 className="text-2xl font-bold mb-4">Gast-Modus</h2>
              <p className="text-slate-300 mb-6">
                Registriere dich für ein vollständiges Spielerprofil mit detaillierten Statistiken, 
                Erfolgen und Spielhistorie.
              </p>
              <div className="flex gap-4 justify-center">
                <Button onClick={onBack} variant="outline" className="text-white border-slate-600">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Zurück zum Menü
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (statsLoading || !detailedStats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zum Menü
          </Button>
          
          <div className="text-center">
            <h1 className="text-3xl font-bold">Spielerprofil</h1>
            <p className="text-slate-400">Detaillierte Statistiken und Erfolge</p>
          </div>
          
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant="outline"
            className="text-white border-slate-600 hover:bg-slate-700"
          >
            {isEditing ? (
              <>
                <X className="w-4 h-4 mr-2" />
                Abbrechen
              </>
            ) : (
              <>
                <Edit3 className="w-4 h-4 mr-2" />
                Bearbeiten
              </>
            )}
          </Button>
        </div>

        {/* Profile Overview */}
        <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              {/* Avatar */}
              <div className="relative">
                <AvatarDisplay 
                  avatar={AVAILABLE_AVATARS.find(a => a.id === detailedStats.profile.favoriteAvatar) || AVAILABLE_AVATARS[0]}
                  size="large"
                  showName={false}
                />
                <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-1">
                  <Crown className="w-4 h-4 text-yellow-900" />
                </div>
                <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 bg-slate-700 px-2 py-1 rounded-full">
                  <span className="text-xs font-bold">Lvl {detailedStats.profile.level}</span>
                </div>
              </div>

              {/* Basic Info */}
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Anzeigename</label>
                      <input
                        type="text"
                        value={editForm.displayName}
                        onChange={(e) => setEditForm({ ...editForm, displayName: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Avatar</label>
                      <AvatarSelector
                        selectedAvatar={AVAILABLE_AVATARS.find(a => a.id === editForm.favoriteAvatar)}
                        onSelect={(avatar) => setEditForm({ ...editForm, favoriteAvatar: avatar.id })}
                        size="small"
                        className="grid-cols-6"
                      />
                    </div>
                    <Button onClick={handleSaveProfile} disabled={isLoading}>
                      <Save className="w-4 h-4 mr-2" />
                      Speichern
                    </Button>
                  </div>
                ) : (
                  <div>
                    <h2 className="text-2xl font-bold mb-2">{detailedStats.profile.displayName}</h2>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-slate-400">Mitglied seit:</span>
                        <div className="font-medium">
                          {format(new Date(detailedStats.profile.memberSince), 'dd. MMMM yyyy', { locale: de })}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400">Letzter Login:</span>
                        <div className="font-medium">
                          {format(new Date(detailedStats.profile.lastSeen), 'dd.MM.yyyy HH:mm', { locale: de })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-slate-700/50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-green-400">{detailedStats.gameStats.totalWins}</div>
                  <div className="text-sm text-slate-300">Siege</div>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-blue-400">{detailedStats.rankedStats.rankedPoints}</div>
                  <div className="text-sm text-slate-300">Ranked Punkte</div>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-yellow-400">{detailedStats.gameStats.winRate}%</div>
                  <div className="text-sm text-slate-300">Siegesrate</div>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-purple-400">{detailedStats.achievements.total}</div>
                  <div className="text-sm text-slate-300">Erfolge</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Statistics Tabs */}
        <Tabs defaultValue="stats" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 border border-slate-600">
            <TabsTrigger value="stats" className="text-white data-[state=active]:bg-slate-700">
              <BarChart3 className="w-4 h-4 mr-2" />
              Statistiken
            </TabsTrigger>
            <TabsTrigger value="ranked" className="text-white data-[state=active]:bg-slate-700">
              <Trophy className="w-4 h-4 mr-2" />
              Ranked
            </TabsTrigger>
            <TabsTrigger value="history" className="text-white data-[state=active]:bg-slate-700">
              <Clock className="w-4 h-4 mr-2" />
              Verlauf
            </TabsTrigger>
            <TabsTrigger value="achievements" className="text-white data-[state=active]:bg-slate-700">
              <Award className="w-4 h-4 mr-2" />
              Erfolge
            </TabsTrigger>
          </TabsList>

          {/* General Statistics */}
          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Game Overview */}
              <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <Target className="w-5 h-5 mr-2" />
                    Spiel-Übersicht
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                      <div className="text-2xl font-bold text-blue-400">{detailedStats.gameStats.totalGames}</div>
                      <div className="text-sm text-slate-300">Gesamt Spiele</div>
                    </div>
                    <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                      <div className="text-2xl font-bold text-green-400">{detailedStats.gameStats.totalWins}</div>
                      <div className="text-sm text-slate-300">Siege</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Siegesrate</span>
                      <span className="text-green-400">{detailedStats.gameStats.winRate}%</span>
                    </div>
                    <Progress value={detailedStats.gameStats.winRate} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Aktuelle Serie:</span>
                      <div className="font-bold text-orange-400 flex items-center">
                        <Flame className="w-4 h-4 mr-1" />
                        {detailedStats.gameStats.winStreak}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Beste Serie:</span>
                      <div className="font-bold text-yellow-400">{detailedStats.gameStats.bestWinStreak}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Performance Metrics */}
              <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex justify-between items-center p-3 bg-slate-700/30 rounded-lg">
                      <span className="text-slate-300">Durchschnittliche Spieldauer</span>
                      <span className="font-bold text-blue-400">
                        {formatDuration(detailedStats.gameStats.averageGameDuration)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-700/30 rounded-lg">
                      <span className="text-slate-300">Längstes Spiel</span>
                      <span className="font-bold text-red-400">
                        {formatDuration(detailedStats.gameStats.longestGame)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-700/30 rounded-lg">
                      <span className="text-slate-300">Schnellstes Spiel</span>
                      <span className="font-bold text-green-400">
                        {formatDuration(detailedStats.gameStats.shortestGame)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Performance Chart */}
            {detailedStats.monthlyPerformance.length > 0 && (
              <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Monatliche Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={detailedStats.monthlyPerformance}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis 
                          dataKey="month" 
                          stroke="#9CA3AF"
                          tickFormatter={(value) => format(new Date(value), 'MMM', { locale: de })}
                        />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#1E293B', 
                            border: '1px solid #475569',
                            borderRadius: '8px'
                          }}
                          labelFormatter={(value) => format(new Date(value), 'MMMM yyyy', { locale: de })}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="winRate" 
                          stroke="#10B981" 
                          fill="#10B981" 
                          fillOpacity={0.3}
                          name="Siegesrate (%)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Ranked Statistics */}
          <TabsContent value="ranked" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Current Rank */}
              <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <Trophy className="w-5 h-5 mr-2" />
                    Aktueller Rang
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <div className={`text-4xl font-bold ${getRankColor(detailedStats.rankedStats.currentRank)}`}>
                      {getRankDisplay(detailedStats.rankedStats.currentRank)}
                    </div>
                    <div className="text-2xl font-bold text-blue-400 mt-2">
                      {detailedStats.rankedStats.rankedPoints} LP
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Saison Höchstrang:</span>
                      <span className={getRankColor(detailedStats.rankedStats.highestRankThisSeason)}>
                        {getRankDisplay(detailedStats.rankedStats.highestRankThisSeason)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Ranked Spiele:</span>
                      <span className="text-blue-400">{detailedStats.rankedStats.rankedGamesPlayed}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Ranked Siegesrate:</span>
                      <span className="text-green-400">{detailedStats.rankedStats.rankedWinRate}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Season Stats */}
              <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <Medal className="w-5 h-5 mr-2" />
                    Saison-Statistiken
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                      <div className="text-xl font-bold text-green-400">{detailedStats.rankedStats.seasonWins}</div>
                      <div className="text-sm text-slate-300">S. Siege</div>
                    </div>
                    <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                      <div className="text-xl font-bold text-red-400">{detailedStats.rankedStats.seasonLosses}</div>
                      <div className="text-sm text-slate-300">S. Niederlagen</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Ranked Serie</span>
                      <span className="text-orange-400 flex items-center">
                        <Flame className="w-4 h-4 mr-1" />
                        {detailedStats.rankedStats.rankedWinStreak}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Punkte verdient</span>
                      <span className="text-yellow-400">+{detailedStats.rankedStats.totalPointsEarned}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Game History */}
          <TabsContent value="history" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Clock className="w-5 h-5 mr-2" />
                  Letzte Spiele
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {detailedStats.recentGames.map((game) => (
                    <motion.div
                      key={game.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`p-4 rounded-lg border-l-4 ${
                        game.isWin 
                          ? 'bg-green-900/20 border-green-500' 
                          : 'bg-red-900/20 border-red-500'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Badge 
                            variant={game.isWin ? "default" : "destructive"}
                            className={game.isWin ? "bg-green-600" : "bg-red-600"}
                          >
                            {game.isWin ? 'SIEG' : 'NIEDERLAGE'}
                          </Badge>
                          <div>
                            <div className="font-medium">vs {game.opponent}</div>
                            <div className="text-sm text-slate-400">
                              {game.gameMode} • {game.boardSize} • {formatDuration(game.duration)}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-slate-400">
                            {format(new Date(game.playedAt), 'dd.MM HH:mm', { locale: de })}
                          </div>
                          {game.rankedPointsChanged !== 0 && (
                            <div className={`text-sm font-bold ${
                              game.rankedPointsChanged > 0 ? 'text-green-400' : 'text-red-400'
                            }`}>
                              {game.rankedPointsChanged > 0 ? '+' : ''}{game.rankedPointsChanged} LP
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements */}
          <TabsContent value="achievements" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-600 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Award className="w-5 h-5 mr-2" />
                  Neueste Erfolge
                </CardTitle>
              </CardHeader>
              <CardContent>
                {detailedStats.achievements.recentlyUnlocked.length === 0 ? (
                  <div className="text-center py-8 text-slate-400">
                    <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Noch keine Erfolge freigeschaltet</p>
                    <p className="text-sm">Spiele mehr, um Erfolge zu sammeln!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {detailedStats.achievements.recentlyUnlocked.map((achievement) => (
                      <motion.div
                        key={achievement.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="p-4 bg-slate-700/30 rounded-lg border border-slate-600"
                      >
                        <div className="flex items-start space-x-3">
                          <div className="text-2xl">{achievement.icon}</div>
                          <div className="flex-1">
                            <h3 className="font-bold text-yellow-400">{achievement.title}</h3>
                            <p className="text-sm text-slate-300 mb-2">{achievement.description}</p>
                            <p className="text-xs text-slate-400">
                              Freigeschaltet: {format(new Date(achievement.unlockedAt), 'dd.MM.yyyy', { locale: de })}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}