import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Trophy, Target, Clock, Users, Award, Star, Zap, Crown, Calendar, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { useWeeklyChallenges, type ChallengeTask, type LeaderboardEntry } from '../lib/stores/useWeeklyChallenges';
import { usePlayerProgress } from '../lib/stores/usePlayerProgress';
import { useAudio } from '../lib/stores/useAudio';
import { cn } from '../lib/utils';

interface WeeklyChallengesProps {
  onBack: () => void;
  onShowReward?: (reward: { xp?: number; gold?: number; diamonds?: number }) => void;
}

export function WeeklyChallenges({ onBack, onShowReward }: WeeklyChallengesProps) {
  const {
    currentChallenge,
    globalLeaderboard,
    userRank,
    weeklyXPEarned,
    initializeWeeklyChallenges,
    updateTaskProgress,
    completeTask,
    addChallengeXP
  } = useWeeklyChallenges();
  
  const { addReward } = usePlayerProgress();
  
  const audio = useAudio();
  const [selectedTab, setSelectedTab] = useState<'challenges' | 'leaderboard'>('challenges');
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [claimedTasks, setClaimedTasks] = useState<Set<string>>(new Set());

  useEffect(() => {
    initializeWeeklyChallenges();
  }, [initializeWeeklyChallenges]);

  // Calculate time left in current challenge
  useEffect(() => {
    if (!currentChallenge) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const endTime = new Date(currentChallenge.endDate).getTime();
      const difference = endTime - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        
        setTimeLeft(`${days}T ${hours}h ${minutes}m`);
      } else {
        setTimeLeft('Beendet');
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [currentChallenge]);

  const claimTaskReward = (task: ChallengeTask) => {
    if (claimedTasks.has(task.id)) return;
    
    // Show animated reward notification if callback provided
    if (onShowReward) {
      onShowReward(task.reward);
    } else {
      // Fallback: Add rewards directly to player progress
      addReward(task.reward);
      audio.playSuccess();
    }
    
    // Mark as claimed
    setClaimedTasks(prev => new Set(prev).add(task.id));
  };

  if (!currentChallenge) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
        <div className="max-w-4xl mx-auto">
          <Button onClick={onBack} variant="outline" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück
          </Button>
          <div className="text-center py-20">
            <div className="text-6xl mb-4">⏳</div>
            <h2 className="text-2xl font-bold mb-4">Lade Herausforderungen...</h2>
          </div>
        </div>
      </div>
    );
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    if (rank <= 10) return '🏆';
    if (rank <= 50) return '⭐';
    return '👤';
  };

  const completedTasks = currentChallenge.tasks.filter(task => task.completed).length;
  const totalTasks = currentChallenge.tasks.length;
  const completionPercentage = (completedTasks / totalTasks) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
            Wöchentliche Herausforderungen
          </h1>
          <p className="text-slate-300 text-sm md:text-base mb-2">{currentChallenge.titleGerman}</p>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-500/20 border border-orange-500/30 rounded-full">
            <Clock className="w-4 h-4 text-orange-400" />
            <span className="text-sm text-orange-300">Verbleibt: {timeLeft}</span>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="bg-slate-800/50 border-slate-600 mb-6">
          <CardContent className="p-4 md:p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-xl md:text-2xl font-bold text-green-400">{completedTasks}/{totalTasks}</div>
                <div className="text-xs md:text-sm text-slate-400">Aufgaben erledigt</div>
              </div>
              <div className="text-center">
                <div className="text-xl md:text-2xl font-bold text-blue-400">{weeklyXPEarned}</div>
                <div className="text-xs md:text-sm text-slate-400">XP diese Woche</div>
              </div>
              <div className="text-center">
                <div className="text-xl md:text-2xl font-bold text-purple-400">#{userRank}</div>
                <div className="text-xs md:text-sm text-slate-400">Dein Rang</div>
              </div>
              <div className="text-center">
                <div className="text-xl md:text-2xl font-bold text-yellow-400">{currentChallenge.totalParticipants}</div>
                <div className="text-xs md:text-sm text-slate-400">Teilnehmer</div>
              </div>
            </div>
            
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span>Wochenfortschritt</span>
                <span>{Math.round(completionPercentage)}%</span>
              </div>
              <Progress value={completionPercentage} className="h-3" />
            </div>
          </CardContent>
        </Card>

        {/* Navigation Tabs - Mobile Responsive */}
        <div className="flex space-x-2 mb-6">
          <Button
            onClick={() => setSelectedTab('challenges')}
            variant={selectedTab === 'challenges' ? 'default' : 'outline'}
            className={cn(
              'flex-1',
              selectedTab === 'challenges' 
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white' 
                : 'border-slate-600 text-slate-300 hover:bg-slate-700'
            )}
          >
            <Target className="w-4 h-4 md:mr-2" />
            <span className="hidden md:inline">Herausforderungen</span>
            <span className="md:hidden">Quests</span>
          </Button>
          <Button
            onClick={() => setSelectedTab('leaderboard')}
            variant={selectedTab === 'leaderboard' ? 'default' : 'outline'}
            className={cn(
              'flex-1',
              selectedTab === 'leaderboard' 
                ? 'bg-gradient-to-r from-yellow-600 to-orange-600 text-white' 
                : 'border-slate-600 text-slate-300 hover:bg-slate-700'
            )}
          >
            <Globe className="w-4 h-4 md:mr-2" />
            <span className="hidden md:inline">Globale Rangliste</span>
            <span className="md:hidden">Rang</span>
          </Button>
        </div>

        <AnimatePresence mode="wait">
          {selectedTab === 'challenges' && (
            <motion.div
              key="challenges"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              {currentChallenge.tasks.map((task, index) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  index={index} 
                  claimedTasks={claimedTasks}
                  onClaimReward={claimTaskReward}
                />
              ))}
            </motion.div>
          )}

          {selectedTab === 'leaderboard' && (
            <motion.div
              key="leaderboard"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <LeaderboardDisplay leaderboard={globalLeaderboard} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function TaskCard({ 
  task, 
  index, 
  claimedTasks, 
  onClaimReward 
}: { 
  task: ChallengeTask; 
  index: number; 
  claimedTasks: Set<string>;
  onClaimReward: (task: ChallengeTask) => void;
}) {
  const progressPercentage = Math.min((task.progress / task.target) * 100, 100);
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Einfach': return 'text-green-400 border-green-400';
      case 'Mittel': return 'text-yellow-400 border-yellow-400';
      case 'Schwer': return 'text-orange-400 border-orange-400';
      case 'Episch': return 'text-purple-400 border-purple-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case 'Einfach': return '🟢';
      case 'Mittel': return '🟡';
      case 'Schwer': return '🟠';
      case 'Episch': return '🟣';
      default: return '⚪';
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className={cn(
        'bg-slate-800/50 border-2 transition-all duration-300',
        task.completed 
          ? 'border-green-500 bg-green-900/20' 
          : 'border-slate-600 hover:border-slate-500'
      )}>
        <CardContent className="p-4 md:p-6">
          <div className="flex items-start justify-between mb-4 gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 md:gap-3 mb-2">
                <div className="text-xl md:text-2xl flex-shrink-0">
                  {task.completed ? '✅' : getDifficultyIcon(task.difficulty)}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-lg md:text-xl font-bold text-white truncate">{task.nameGerman}</h3>
                  <p className="text-slate-400 text-xs md:text-sm line-clamp-2">{task.descriptionGerman}</p>
                </div>
              </div>
            </div>
            
            <div className="text-right flex-shrink-0">
              <div className={cn(
                'inline-flex items-center px-2 md:px-3 py-1 rounded-full text-xs font-semibold border',
                getDifficultyColor(task.difficulty)
              )}>
                <span className="hidden md:inline">{task.difficulty}</span>
                <span className="md:hidden">{task.difficulty.charAt(0)}</span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-xs md:text-sm mb-2">
              <span className="text-slate-400">Fortschritt</span>
              <span className="text-white font-semibold">{task.progress}/{task.target}</span>
            </div>
            <Progress 
              value={progressPercentage} 
              className={cn(
                'h-2',
                task.completed ? '[&>div]:bg-green-500' : '[&>div]:bg-blue-500'
              )} 
            />
          </div>

          {/* Rewards */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 md:gap-4 flex-wrap">
              <div className="flex items-center gap-1 text-blue-400">
                <Zap className="w-4 h-4" />
                <span className="font-semibold text-sm md:text-base">{task.reward.xp} XP</span>
              </div>
              {task.reward.diamonds && (
                <div className="flex items-center gap-1 text-cyan-400">
                  <Star className="w-4 h-4" />
                  <span className="font-semibold text-sm md:text-base">{task.reward.diamonds} 💎</span>
                </div>
              )}
              {task.reward.gold && (
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star className="w-4 h-4" />
                  <span className="font-semibold text-sm md:text-base">{task.reward.gold} 🪙</span>
                </div>
              )}
              {task.reward.cards && (
                <div className="flex items-center gap-1 text-purple-400">
                  <Award className="w-4 h-4" />
                  <span className="font-semibold text-sm md:text-base">{task.reward.cards.length} Karten</span>
                </div>
              )}
              {task.reward.packs && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <Trophy className="w-4 h-4" />
                  <span className="font-semibold text-sm md:text-base">{task.reward.packs} Packs</span>
                </div>
              )}
            </div>
            
            {task.completed && !claimedTasks.has(task.id) && (
              <Button
                onClick={() => onClaimReward(task)}
                className="bg-gradient-to-r from-green-600 to-emerald-600 text-white hover:from-green-500 hover:to-emerald-500 flex-shrink-0"
                size="sm"
              >
                <Award className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Abholen</span>
              </Button>
            )}
            {task.completed && claimedTasks.has(task.id) && (
              <div className="flex items-center gap-2 text-green-400 font-semibold flex-shrink-0">
                <Award className="w-4 h-4" />
                <span className="hidden md:inline">Erhalten</span>
                <span className="md:hidden">✓</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function getRankIcon(rank: number): string {
  if (rank === 1) return '🥇';
  if (rank === 2) return '🥈';
  if (rank === 3) return '🥉';
  if (rank <= 10) return '🏆';
  return '⭐';
}

function LeaderboardDisplay({ leaderboard }: { leaderboard: LeaderboardEntry[] }) {
  return (
    <Card className="bg-slate-800/50 border-slate-600">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-yellow-400">
          <Globe className="w-5 h-5" />
          Globale Rangliste
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="space-y-1">
          {leaderboard.slice(0, 50).map((entry, index) => (
            <motion.div
              key={entry.playerId}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.02 }}
              className={cn(
                'flex items-center justify-between p-4 border-b border-slate-700/50',
                entry.isCurrentUser && 'bg-blue-900/30 border-blue-600/50',
                index < 3 && 'bg-gradient-to-r from-yellow-900/20 to-orange-900/20'
              )}
            >
              <div className="flex items-center gap-4">
                <div className="text-2xl w-8 text-center">
                  {getRankIcon(entry.rank)}
                </div>
                <div className="text-xl font-bold text-white w-8">
                  #{entry.rank}
                </div>
                <div className="text-2xl">{entry.avatar}</div>
                <div>
                  <div className={cn(
                    'font-semibold',
                    entry.isCurrentUser ? 'text-blue-400' : 'text-white'
                  )}>
                    {entry.playerName}
                  </div>
                  {entry.country && (
                    <div className="text-sm text-slate-400">{entry.country}</div>
                  )}
                </div>
                {entry.badge && (
                  <div className="px-2 py-1 rounded-full text-xs font-semibold bg-yellow-600/20 text-yellow-400 border border-yellow-600/30">
                    {entry.badge}
                  </div>
                )}
              </div>
              
              <div className="text-right">
                <div className="text-lg font-bold text-blue-400">{entry.totalXP} XP</div>
                <div className="text-sm text-slate-400">{entry.tasksCompleted} Aufgaben</div>
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default WeeklyChallenges;