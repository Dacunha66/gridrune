import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { RotateCcw, Shuffle, Play } from 'lucide-react';

export function CardFlipDemo() {
  const [isFlipped, setIsFlipped] = useState(false);
  const [flipDirection, setFlipDirection] = useState<'horizontal' | 'vertical' | 'diagonal'>('horizontal');
  const [animationSpeed, setAnimationSpeed] = useState(0.6);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleReset = () => {
    setIsFlipped(false);
  };

  const flipStyle = {
    transitionDuration: `${animationSpeed}s`,
    transformStyle: 'preserve-3d' as const
  };

  const getFlipTransform = () => {
    if (!isFlipped) return 'rotateY(0deg)';
    
    switch (flipDirection) {
      case 'horizontal':
        return 'rotateY(180deg)';
      case 'vertical':
        return 'rotateX(180deg)';
      case 'diagonal':
        return 'rotateY(180deg) rotateX(45deg)';
      default:
        return 'rotateY(180deg)';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">🃏 Kartenumdreh-Animation Demo</h1>
          <p className="text-xl text-slate-300">Erlebe die neuen animierten Karteneffekte</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Card Display */}
          <div className="flex flex-col items-center">
            <div className="card-flip-container mb-6" style={{ perspective: '1000px' }}>
              <div 
                className="card-flip-inner w-64 h-96 relative transition-transform"
                style={{
                  ...flipStyle,
                  transform: getFlipTransform()
                }}
              >
                {/* Card Front */}
                <div 
                  className="card-face card-face-front absolute w-full h-full bg-gradient-to-br from-purple-600 to-blue-800 rounded-lg border-4 border-purple-400 p-4 shadow-2xl"
                  style={{ backfaceVisibility: 'hidden' }}
                >
                  <div className="h-full flex flex-col">
                    <div className="text-center mb-4">
                      <h3 className="text-xl font-bold">Feuer-Drache</h3>
                      <p className="text-purple-200">Legendär ⭐</p>
                    </div>
                    
                    <div className="flex-1 flex items-center justify-center">
                      <div className="text-8xl">🐉</div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div></div>
                      <div className="bg-red-500 rounded px-2 py-1 font-bold">8</div>
                      <div></div>
                      <div className="bg-blue-500 rounded px-2 py-1 font-bold">3</div>
                      <div></div>
                      <div className="bg-green-500 rounded px-2 py-1 font-bold">2</div>
                      <div></div>
                      <div className="bg-yellow-500 rounded px-2 py-1 font-bold">4</div>
                      <div></div>
                    </div>
                  </div>
                </div>

                {/* Card Back */}
                <div 
                  className="card-face card-face-back absolute w-full h-96 bg-gradient-to-br from-slate-600 to-slate-800 rounded-lg border-4 border-blue-400 p-4 shadow-2xl flex flex-col items-center justify-center"
                  style={{ 
                    backfaceVisibility: 'hidden',
                    transform: 'rotateY(180deg)'
                  }}
                >
                  <div className="text-6xl mb-4">🃏</div>
                  <div className="text-2xl font-bold mb-2">DACUNHA</div>
                  <div className="text-lg text-slate-300">CARDS</div>
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-lg"></div>
                </div>
              </div>
            </div>

            <div className="text-center text-slate-300">
              Status: {isFlipped ? 'Rückseite' : 'Vorderseite'}
            </div>
          </div>

          {/* Controls */}
          <Card className="bg-slate-800 border-slate-600">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Play className="w-5 h-5" />
                Animation Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Flip Direction */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Dreh-Richtung
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'horizontal', label: 'Horizontal' },
                    { value: 'vertical', label: 'Vertikal' },
                    { value: 'diagonal', label: 'Diagonal' }
                  ].map((option) => (
                    <Button
                      key={option.value}
                      variant={flipDirection === option.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFlipDirection(option.value as any)}
                      className="text-xs"
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Animation Speed */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Geschwindigkeit: {animationSpeed}s
                </label>
                <input
                  type="range"
                  min="0.2"
                  max="2.0"
                  step="0.1"
                  value={animationSpeed}
                  onChange={(e) => setAnimationSpeed(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>Schnell</span>
                  <span>Langsam</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button
                  onClick={handleFlip}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <Shuffle className="w-4 h-4 mr-2" />
                  Karte umdrehen
                </Button>
                
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Zurücksetzen
                </Button>
              </div>

              <div className="text-xs text-slate-400 p-3 bg-slate-700 rounded">
                <strong>Tipp:</strong> Diese Animationen können auf alle Karten im Spiel angewendet werden - 
                beim Platzieren, bei Kämpfen oder bei Seltenheits-Upgrades!
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Back to Menu */}
        <div className="text-center mt-8">
          <Button 
            onClick={() => window.location.reload()}
            variant="outline" 
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            Zurück zum Hauptmenü
          </Button>
        </div>
      </div>
    </div>
  );
}