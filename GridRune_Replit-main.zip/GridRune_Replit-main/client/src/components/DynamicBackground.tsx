import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Rarity, RARITY_CONFIG } from '../lib/cardData';

interface DynamicBackgroundProps {
  dominantRarity?: Rarity;
  intensity?: number;
  children: React.ReactNode;
}

interface BackgroundConfig {
  gradient: string;
  particles: {
    count: number;
    color: string;
    size: string;
    duration: number;
  };
  overlay: string;
  animation: string;
}

const BACKGROUND_CONFIGS: Record<Rarity, BackgroundConfig> = {
  common: {
    gradient: 'bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900',
    particles: {
      count: 15,
      color: '#94a3b8',
      size: '2px',
      duration: 8000
    },
    overlay: 'bg-slate-900/20',
    animation: 'bg-slide-slow'
  },
  uncommon: {
    gradient: 'bg-gradient-to-br from-emerald-900/30 via-slate-800 to-emerald-900/20',
    particles: {
      count: 25,
      color: '#4ade80',
      size: '3px',
      duration: 6000
    },
    overlay: 'bg-emerald-900/10',
    animation: 'bg-shimmer'
  },
  rare: {
    gradient: 'bg-gradient-to-br from-blue-900/40 via-slate-800 to-blue-900/30',
    particles: {
      count: 35,
      color: '#60a5fa',
      size: '3px',
      duration: 5000
    },
    overlay: 'bg-blue-900/15',
    animation: 'bg-flow'
  },
  epic: {
    gradient: 'bg-gradient-to-br from-purple-900/50 via-slate-800 to-purple-900/40',
    particles: {
      count: 45,
      color: '#c084fc',
      size: '4px',
      duration: 4000
    },
    overlay: 'bg-purple-900/20',
    animation: 'bg-pulse'
  },
  legendary: {
    gradient: 'bg-gradient-to-br from-amber-900/60 via-slate-800 to-yellow-900/50',
    particles: {
      count: 60,
      color: '#facc15',
      size: '5px',
      duration: 3000
    },
    overlay: 'bg-amber-900/25',
    animation: 'bg-aurora'
  }
};

export function DynamicBackground({ dominantRarity, intensity = 1, children }: DynamicBackgroundProps) {
  const [activeConfig, setActiveConfig] = useState<BackgroundConfig>(BACKGROUND_CONFIGS.common);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([]);

  useEffect(() => {
    if (dominantRarity) {
      setActiveConfig(BACKGROUND_CONFIGS[dominantRarity]);
    } else {
      setActiveConfig(BACKGROUND_CONFIGS.common);
    }
  }, [dominantRarity]);

  useEffect(() => {
    const particleCount = Math.floor(activeConfig.particles.count * intensity);
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * activeConfig.particles.duration
    }));
    setParticles(newParticles);
  }, [activeConfig, intensity]);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Animated Gradient Background */}
      <AnimatePresence mode="wait">
        <motion.div
          key={dominantRarity || 'default'}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
          className={`fixed inset-0 ${activeConfig.gradient} ${activeConfig.animation}`}
          style={{ zIndex: -20 }}
        />
      </AnimatePresence>

      {/* Particle Layer */}
      <div className="fixed inset-0 pointer-events-none" style={{ zIndex: -15 }}>
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute rounded-full opacity-30"
            style={{
              backgroundColor: activeConfig.particles.color,
              width: activeConfig.particles.size,
              height: activeConfig.particles.size,
              left: `${particle.x}%`,
              top: `${particle.y}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 0.6, 0],
              scale: [0.5, 1, 0.5],
            }}
            transition={{
              duration: activeConfig.particles.duration / 1000,
              repeat: Infinity,
              delay: particle.delay / 1000,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>

      {/* Animated Overlay */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`overlay-${dominantRarity || 'default'}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 2, ease: "easeInOut" }}
          className={`fixed inset-0 ${activeConfig.overlay}`}
          style={{ zIndex: -10 }}
        />
      </AnimatePresence>

      {/* Content */}
      <div className="relative z-0">
        {children}
      </div>
    </div>
  );
}

// Hook to calculate dominant rarity from cards
export function useDominantRarity(cards: Array<{ rarity?: Rarity }>): Rarity | undefined {
  const [dominantRarity, setDominantRarity] = useState<Rarity | undefined>();

  useEffect(() => {
    if (!cards.length) {
      setDominantRarity(undefined);
      return;
    }

    // Count rarity occurrences with weighted scoring
    const rarityWeights: Record<Rarity, number> = {
      common: 1,
      uncommon: 2,
      rare: 4,
      epic: 8,
      legendary: 16
    };

    const rarityCounts: Record<string, number> = {};
    let totalScore = 0;

    cards.forEach(card => {
      if (card.rarity) {
        rarityCounts[card.rarity] = (rarityCounts[card.rarity] || 0) + rarityWeights[card.rarity];
        totalScore += rarityWeights[card.rarity];
      }
    });

    // Find the rarity with highest weighted score
    let maxScore = 0;
    let dominant: Rarity | undefined;

    Object.entries(rarityCounts).forEach(([rarity, score]) => {
      if (score > maxScore) {
        maxScore = score;
        dominant = rarity as Rarity;
      }
    });

    setDominantRarity(dominant);
  }, [cards]);

  return dominantRarity;
}