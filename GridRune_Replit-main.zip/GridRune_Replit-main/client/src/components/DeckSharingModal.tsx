import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Share2, Download, Copy, Check, Heart, Search, Clock, TrendingUp, Star, Tag, User } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { useDeckSharing, type SharedDeck, type DeckShareData } from '../lib/stores/useDeckSharing';
import { useAudio } from '../lib/stores/useAudio';
import { GameCard } from '../lib/cardData';
import { BoardSize } from '../lib/stores/useCardGame';
import { cn } from '../lib/utils';

interface DeckSharingModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'share' | 'import';
  deckToShare?: {
    name: string;
    cards: GameCard[];
    boardSize: BoardSize;
  };
  onDeckImported?: (deck: SharedDeck) => void;
}

export function DeckSharingModal({ 
  isOpen, 
  onClose, 
  mode, 
  deckToShare, 
  onDeckImported 
}: DeckSharingModalProps) {
  const {
    shareDeck,
    importDeck,
    validateShareCode,
    likeDeck,
    addToFavorites,
    favoriteDecks,
    getPopularDecks,
    getRecentDecks,
    searchDecks,
    exportDeckToClipboard
  } = useDeckSharing();
  
  const { playSuccess, playHit } = useAudio();
  
  // Share mode states
  const [shareDescription, setShareDescription] = useState('');
  const [shareTags, setShareTags] = useState('');
  const [sharedDeck, setSharedDeck] = useState<SharedDeck | null>(null);
  const [copied, setCopied] = useState(false);
  
  // Import mode states
  const [importCode, setImportCode] = useState('');
  const [importError, setImportError] = useState('');
  const [selectedTab, setSelectedTab] = useState<'code' | 'browse' | 'favorites'>('browse');
  const [searchQuery, setSearchQuery] = useState('');
  const [browseMode, setBrowseMode] = useState<'popular' | 'recent'>('popular');
  
  // Browse decks
  const [displayedDecks, setDisplayedDecks] = useState<SharedDeck[]>([]);

  useEffect(() => {
    if (mode === 'import' && isOpen) {
      updateDisplayedDecks();
    }
  }, [mode, isOpen, selectedTab, browseMode, searchQuery]);

  const updateDisplayedDecks = () => {
    if (selectedTab === 'browse') {
      if (searchQuery.trim()) {
        setDisplayedDecks(searchDecks(searchQuery));
      } else {
        setDisplayedDecks(browseMode === 'popular' ? getPopularDecks() : getRecentDecks());
      }
    } else if (selectedTab === 'favorites') {
      const favDecks = useDeckSharing.getState().sharedDecks.filter(deck => 
        favoriteDecks.includes(deck.shareCode)
      );
      setDisplayedDecks(favDecks);
    }
  };

  const handleShareDeck = () => {
    if (!deckToShare) return;

    const deckData: DeckShareData = {
      name: deckToShare.name,
      cards: deckToShare.cards,
      boardSize: deckToShare.boardSize,
      description: shareDescription,
      tags: shareTags.split(',').map(tag => tag.trim()).filter(Boolean),
      createdBy: 'Spieler', // In real app, this would be the authenticated user
      version: '1.0'
    };

    const shared = shareDeck(deckData);
    setSharedDeck(shared);
    playSuccess();
  };

  const handleCopyShareCode = async () => {
    if (!sharedDeck) return;
    
    try {
      await navigator.clipboard.writeText(sharedDeck.shareCode);
      setCopied(true);
      playSuccess();
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy share code:', error);
    }
  };

  const handleExportToClipboard = async () => {
    if (!deckToShare) return;

    const deckData: DeckShareData = {
      name: deckToShare.name,
      cards: deckToShare.cards,
      boardSize: deckToShare.boardSize,
      description: shareDescription,
      tags: shareTags.split(',').map(tag => tag.trim()).filter(Boolean),
      createdBy: 'Spieler',
      version: '1.0'
    };

    const success = await exportDeckToClipboard(deckData);
    if (success) {
      playSuccess();
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      playHit();
    }
  };

  const handleImportDeck = (shareCode?: string) => {
    const codeToImport = shareCode || importCode;
    
    if (!validateShareCode(codeToImport)) {
      setImportError('Ungültiger Share-Code Format');
      playHit();
      return;
    }

    const deck = importDeck(codeToImport);
    if (deck) {
      onDeckImported?.(deck);
      playSuccess();
      onClose();
    } else {
      setImportError('Deck nicht gefunden oder Code ungültig');
      playHit();
    }
  };

  const handleLikeDeck = (shareCode: string) => {
    likeDeck(shareCode);
    playSuccess();
    updateDisplayedDecks();
  };

  const handleFavoriteDeck = (shareCode: string) => {
    if (favoriteDecks.includes(shareCode)) {
      useDeckSharing.getState().removeFromFavorites(shareCode);
    } else {
      addToFavorites(shareCode);
    }
    playSuccess();
    updateDisplayedDecks();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-slate-800 rounded-xl border border-slate-600 w-full max-w-4xl max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-600">
          <div className="flex items-center gap-3">
            {mode === 'share' ? (
              <>
                <Share2 className="w-6 h-6 text-blue-400" />
                <h2 className="text-2xl font-bold text-white">Deck Teilen</h2>
              </>
            ) : (
              <>
                <Download className="w-6 h-6 text-green-400" />
                <h2 className="text-2xl font-bold text-white">Deck Importieren</h2>
              </>
            )}
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          {mode === 'share' ? (
            <ShareContent
              deckToShare={deckToShare}
              shareDescription={shareDescription}
              setShareDescription={setShareDescription}
              shareTags={shareTags}
              setShareTags={setShareTags}
              sharedDeck={sharedDeck}
              copied={copied}
              onShareDeck={handleShareDeck}
              onCopyShareCode={handleCopyShareCode}
              onExportToClipboard={handleExportToClipboard}
            />
          ) : (
            <ImportContent
              selectedTab={selectedTab}
              setSelectedTab={setSelectedTab}
              importCode={importCode}
              setImportCode={setImportCode}
              importError={importError}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              browseMode={browseMode}
              setBrowseMode={setBrowseMode}
              displayedDecks={displayedDecks}
              favoriteDecks={favoriteDecks}
              onImportDeck={handleImportDeck}
              onLikeDeck={handleLikeDeck}
              onFavoriteDeck={handleFavoriteDeck}
            />
          )}
        </div>
      </motion.div>
    </div>
  );
}

// Share Content Component
function ShareContent({
  deckToShare,
  shareDescription,
  setShareDescription,
  shareTags,
  setShareTags,
  sharedDeck,
  copied,
  onShareDeck,
  onCopyShareCode,
  onExportToClipboard
}: any) {
  if (sharedDeck) {
    return (
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="text-6xl mb-4">🎉</div>
          <h3 className="text-2xl font-bold text-white mb-2">Deck erfolgreich geteilt!</h3>
          <p className="text-slate-400">Dein Deck ist jetzt für andere Spieler verfügbar</p>
        </motion.div>

        <Card className="bg-slate-700/50 border-slate-600">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h4 className="text-lg font-semibold text-white">{sharedDeck.name}</h4>
              <div className="bg-slate-800 p-4 rounded-lg border border-slate-600">
                <p className="text-sm text-slate-400 mb-2">Share-Code</p>
                <p className="text-xl font-mono text-cyan-400 break-all">{sharedDeck.shareCode}</p>
              </div>
              
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={onCopyShareCode}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                  {copied ? 'Kopiert!' : 'Code Kopieren'}
                </Button>
                
                <Button
                  onClick={onExportToClipboard}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Vollständig Exportieren
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-white mb-2">
          "{deckToShare?.name}" teilen
        </h3>
        <p className="text-slate-400">
          Füge eine Beschreibung und Tags hinzu, um dein Deck zu teilen
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Beschreibung (optional)
          </label>
          <Textarea
            value={shareDescription}
            onChange={(e) => setShareDescription(e.target.value)}
            placeholder="Beschreibe die Strategie und Besonderheiten deines Decks..."
            className="bg-slate-700 border-slate-600 text-white"
            rows={3}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Tags (kommagetrennt)
          </label>
          <Input
            value={shareTags}
            onChange={(e) => setShareTags(e.target.value)}
            placeholder="z.B. Aggressiv, Blitzschlag, Legendär"
            className="bg-slate-700 border-slate-600 text-white"
          />
        </div>

        <div className="flex gap-2 justify-center pt-4">
          <Button
            onClick={onShareDeck}
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Deck Teilen
          </Button>
          
          <Button
            onClick={onExportToClipboard}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Copy className="w-4 h-4 mr-2" />
            In Zwischenablage
          </Button>
        </div>
      </div>
    </div>
  );
}

// Import Content Component
function ImportContent({
  selectedTab,
  setSelectedTab,
  importCode,
  setImportCode,
  importError,
  searchQuery,
  setSearchQuery,
  browseMode,
  setBrowseMode,
  displayedDecks,
  favoriteDecks,
  onImportDeck,
  onLikeDeck,
  onFavoriteDeck
}: any) {
  return (
    <div className="space-y-6">
      {/* Navigation Tabs */}
      <div className="flex space-x-2">
        <Button
          onClick={() => setSelectedTab('browse')}
          variant={selectedTab === 'browse' ? 'default' : 'outline'}
          className={cn(
            'flex-1',
            selectedTab === 'browse'
              ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white'
              : 'border-slate-600 text-slate-300 hover:bg-slate-700'
          )}
        >
          <Search className="w-4 h-4 mr-2" />
          Durchsuchen
        </Button>
        
        <Button
          onClick={() => setSelectedTab('code')}
          variant={selectedTab === 'code' ? 'default' : 'outline'}
          className={cn(
            'flex-1',
            selectedTab === 'code'
              ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
              : 'border-slate-600 text-slate-300 hover:bg-slate-700'
          )}
        >
          <Copy className="w-4 h-4 mr-2" />
          Code Eingeben
        </Button>
        
        <Button
          onClick={() => setSelectedTab('favorites')}
          variant={selectedTab === 'favorites' ? 'default' : 'outline'}
          className={cn(
            'flex-1',
            selectedTab === 'favorites'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white'
              : 'border-slate-600 text-slate-300 hover:bg-slate-700'
          )}
        >
          <Heart className="w-4 h-4 mr-2" />
          Favoriten
        </Button>
      </div>

      <AnimatePresence mode="wait">
        {selectedTab === 'code' && (
          <motion.div
            key="code"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-4"
          >
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Share-Code eingeben
              </label>
              <Input
                value={importCode}
                onChange={(e) => {
                  setImportCode(e.target.value);
                  if (importError) setImportCode('');
                }}
                placeholder="GR-XXXX-YYYY-ZZZZZZ"
                className="bg-slate-700 border-slate-600 text-white font-mono"
              />
              {importError && (
                <p className="text-red-400 text-sm mt-2">{importError}</p>
              )}
            </div>
            
            <Button
              onClick={() => onImportDeck()}
              disabled={!importCode.trim()}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Deck Importieren
            </Button>
          </motion.div>
        )}

        {(selectedTab === 'browse' || selectedTab === 'favorites') && (
          <motion.div
            key="browse"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            {selectedTab === 'browse' && (
              <>
                <div className="flex gap-2">
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Deck suchen..."
                    className="flex-1 bg-slate-700 border-slate-600 text-white"
                  />
                  <Button
                    onClick={() => setBrowseMode('popular')}
                    variant={browseMode === 'popular' ? 'default' : 'outline'}
                    size="sm"
                    className="border-slate-600"
                  >
                    <TrendingUp className="w-4 h-4 mr-1" />
                    Beliebt
                  </Button>
                  <Button
                    onClick={() => setBrowseMode('recent')}
                    variant={browseMode === 'recent' ? 'default' : 'outline'}
                    size="sm"
                    className="border-slate-600"
                  >
                    <Clock className="w-4 h-4 mr-1" />
                    Neu
                  </Button>
                </div>
              </>
            )}
            
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {displayedDecks.map((deck) => (
                <DeckCard
                  key={deck.id}
                  deck={deck}
                  isFavorite={favoriteDecks.includes(deck.shareCode)}
                  onImport={() => onImportDeck(deck.shareCode)}
                  onLike={() => onLikeDeck(deck.shareCode)}
                  onFavorite={() => onFavoriteDeck(deck.shareCode)}
                />
              ))}
              
              {displayedDecks.length === 0 && (
                <div className="text-center py-8 text-slate-400">
                  <div className="text-4xl mb-2">🔍</div>
                  <p>Keine Decks gefunden</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Deck Card Component
function DeckCard({ deck, isFavorite, onImport, onLike, onFavorite }: {
  deck: SharedDeck;
  isFavorite: boolean;
  onImport: () => void;
  onLike: () => void;
  onFavorite: () => void;
}) {
  return (
    <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h4 className="font-semibold text-white">{deck.name}</h4>
              <span className="text-xs px-2 py-1 rounded-full bg-slate-600 text-slate-300">
                {deck.boardSize}
              </span>
            </div>
            
            {deck.description && (
              <p className="text-sm text-slate-400 mb-3">{deck.description}</p>
            )}
            
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {deck.createdBy}
              </div>
              <div className="flex items-center gap-1">
                <Heart className="w-3 h-3" />
                {deck.likes}
              </div>
              <div className="flex items-center gap-1">
                <Download className="w-3 h-3" />
                {deck.downloads}
              </div>
            </div>
            
            {deck.tags && deck.tags.length > 0 && (
              <div className="flex gap-1 mt-2">
                {deck.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="text-xs px-2 py-1 rounded-full bg-blue-600/20 text-blue-400"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex flex-col gap-2 ml-4">
            <Button
              onClick={onImport}
              size="sm"
              className="bg-green-600 hover:bg-green-700"
            >
              <Download className="w-3 h-3 mr-1" />
              Import
            </Button>
            
            <div className="flex gap-1">
              <Button
                onClick={onLike}
                size="sm"
                variant="outline"
                className="border-slate-600 p-2"
              >
                <Heart className="w-3 h-3" />
              </Button>
              
              <Button
                onClick={onFavorite}
                size="sm"
                variant="outline"
                className={cn(
                  'border-slate-600 p-2',
                  isFavorite && 'bg-pink-600/20 border-pink-600 text-pink-400'
                )}
              >
                <Star className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default DeckSharingModal;