import { useState, useCallback } from 'react';
import { NotificationType } from '../components/ui/SystemNotification';

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message?: string;
  autoClose?: boolean;
  duration?: number;
}

/**
 * Hook for managing system notifications
 */
export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  /**
   * Add a new notification
   */
  const addNotification = useCallback((
    notification: Omit<Notification, 'id'>
  ) => {
    const id = `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const newNotification: Notification = {
      id,
      autoClose: true,
      duration: 5000,
      ...notification
    };

    setNotifications(prev => [...prev, newNotification]);
    return id;
  }, []);

  /**
   * Remove a notification by ID
   */
  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  /**
   * Clear all notifications
   */
  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  /**
   * Shorthand methods for different notification types
   */
  const success = useCallback((title: string, message?: string) => {
    return addNotification({ type: 'success', title, message });
  }, [addNotification]);

  const error = useCallback((title: string, message?: string) => {
    return addNotification({ 
      type: 'error', 
      title, 
      message, 
      autoClose: false // Errors should stay until manually dismissed
    });
  }, [addNotification]);

  const warning = useCallback((title: string, message?: string) => {
    return addNotification({ type: 'warning', title, message });
  }, [addNotification]);

  const info = useCallback((title: string, message?: string) => {
    return addNotification({ type: 'info', title, message });
  }, [addNotification]);

  /**
   * Update an existing notification
   */
  const updateNotification = useCallback((id: string, updates: Partial<Omit<Notification, 'id'>>) => {
    setNotifications(prev => prev.map(n => 
      n.id === id ? { ...n, ...updates } : n
    ));
  }, []);

  return {
    notifications,
    addNotification,
    removeNotification,
    clearNotifications,
    updateNotification,
    // Shorthand methods
    success,
    error,
    warning,
    info
  };
}

export type NotificationManager = ReturnType<typeof useNotifications>;