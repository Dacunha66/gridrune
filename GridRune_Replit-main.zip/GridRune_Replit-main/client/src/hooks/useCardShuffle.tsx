import { useState, useCallback } from 'react';

export function useCardShuffle() {
  const [isShuffling, setIsShuffling] = useState(false);
  const [pendingTransition, setPendingTransition] = useState<(() => void) | null>(null);

  const triggerShuffle = useCallback((onComplete?: () => void) => {
    if (isShuffling) return; // Prevent multiple simultaneous shuffles
    
    setIsShuffling(true);
    setPendingTransition(() => onComplete);
  }, [isShuffling]);

  const completeShuffle = useCallback(() => {
    setIsShuffling(false);
    if (pendingTransition) {
      pendingTransition();
      setPendingTransition(null);
    }
  }, [pendingTransition]);

  return {
    isShuffling,
    triggerShuffle,
    completeShuffle
  };
}