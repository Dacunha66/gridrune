import { useState, useCallback, useRef, useEffect } from 'react';
import { Z_INDEX } from '../lib/constants/zIndex';

interface LayerState {
  activeModals: string[];
  gameOverlays: string[];
  notifications: string[];
  currentMaxZIndex: number;
}

/**
 * Custom hook for managing UI layers and z-index stack
 */
export function useLayerManager() {
  const [layerState, setLayerState] = useState<LayerState>({
    activeModals: [],
    gameOverlays: [],
    notifications: [],
    currentMaxZIndex: Z_INDEX.EMERGENCY
  });

  const layerStackRef = useRef<Map<string, number>>(new Map());

  /**
   * Add a new layer to the stack
   */
  const pushLayer = useCallback((layerId: string, type: 'modal' | 'overlay' | 'notification') => {
    setLayerState(prev => {
      const newZIndex = prev.currentMaxZIndex + 1;
      layerStackRef.current.set(layerId, newZIndex);

      return {
        ...prev,
        currentMaxZIndex: newZIndex,
        [type === 'modal' ? 'activeModals' : 
         type === 'overlay' ? 'gameOverlays' : 'notifications']: [
          ...prev[type === 'modal' ? 'activeModals' : 
                   type === 'overlay' ? 'gameOverlays' : 'notifications'],
          layerId
        ]
      };
    });

    return layerStackRef.current.get(layerId)!;
  }, []);

  /**
   * Remove a layer from the stack
   */
  const popLayer = useCallback((layerId: string, type: 'modal' | 'overlay' | 'notification') => {
    setLayerState(prev => {
      layerStackRef.current.delete(layerId);

      return {
        ...prev,
        [type === 'modal' ? 'activeModals' : 
         type === 'overlay' ? 'gameOverlays' : 'notifications']: prev[
          type === 'modal' ? 'activeModals' : 
          type === 'overlay' ? 'gameOverlays' : 'notifications'
        ].filter(id => id !== layerId)
      };
    });
  }, []);

  /**
   * Get the z-index for a specific layer
   */
  const getLayerZIndex = useCallback((layerId: string): number => {
    return layerStackRef.current.get(layerId) || Z_INDEX.BASE;
  }, []);

  /**
   * Check if a layer is currently active
   */
  const isLayerActive = useCallback((layerId: string): boolean => {
    return layerStackRef.current.has(layerId);
  }, []);

  /**
   * Get the top-most modal (if any)
   */
  const getTopModal = useCallback((): string | null => {
    if (layerState.activeModals.length === 0) return null;
    return layerState.activeModals[layerState.activeModals.length - 1];
  }, [layerState.activeModals]);

  /**
   * Check if modals are blocking game interaction
   */
  const areModalsBlocking = useCallback((): boolean => {
    return layerState.activeModals.length > 0;
  }, [layerState.activeModals.length]);

  /**
   * Clear all layers of a specific type
   */
  const clearLayers = useCallback((type: 'modal' | 'overlay' | 'notification' | 'all') => {
    setLayerState(prev => {
      if (type === 'all') {
        layerStackRef.current.clear();
        return {
          activeModals: [],
          gameOverlays: [],
          notifications: [],
          currentMaxZIndex: Z_INDEX.EMERGENCY
        };
      }

      const layersToRemove = prev[
        type === 'modal' ? 'activeModals' : 
        type === 'overlay' ? 'gameOverlays' : 'notifications'
      ];

      layersToRemove.forEach(id => layerStackRef.current.delete(id));

      return {
        ...prev,
        [type === 'modal' ? 'activeModals' : 
         type === 'overlay' ? 'gameOverlays' : 'notifications']: []
      };
    });
  }, []);

  /**
   * Handle escape key to close top-most modal
   */
  const handleEscape = useCallback(() => {
    const topModal = getTopModal();
    if (topModal) {
      popLayer(topModal, 'modal');
      return true; // Handled
    }
    return false; // Not handled
  }, [getTopModal, popLayer]);

  /**
   * Set up escape key listener
   */
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        handleEscape();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleEscape]);

  return {
    // State
    layerState,
    
    // Actions
    pushLayer,
    popLayer,
    clearLayers,
    
    // Queries
    getLayerZIndex,
    isLayerActive,
    getTopModal,
    areModalsBlocking,
    
    // Utilities
    handleEscape
  };
}

/**
 * Layer manager context for providing layer state throughout the app
 */
export type LayerManagerContextType = ReturnType<typeof useLayerManager>;