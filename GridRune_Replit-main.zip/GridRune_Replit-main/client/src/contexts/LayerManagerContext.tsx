import React, { createContext, useContext, ReactNode } from 'react';
import { useLayerManager, LayerManagerContextType } from '../hooks/useLayerManager';

// Create the context
const LayerManagerContext = createContext<LayerManagerContextType | null>(null);

// Context provider component
interface LayerManagerProviderProps {
  children: ReactNode;
}

export function LayerManagerProvider({ children }: LayerManagerProviderProps) {
  const layerManager = useLayerManager();

  return (
    <LayerManagerContext.Provider value={layerManager}>
      {children}
    </LayerManagerContext.Provider>
  );
}

// Hook to use the layer manager context
export function useLayerManagerContext(): LayerManagerContextType {
  const context = useContext(LayerManagerContext);
  
  if (!context) {
    throw new Error('useLayerManagerContext must be used within a LayerManagerProvider');
  }
  
  return context;
}

// Export the context for direct access if needed
export { LayerManagerContext };