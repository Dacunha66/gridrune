import { Router } from 'express';
import { eq, desc, and, gte, count, avg, max, sum, sql, or, min } from 'drizzle-orm';
import { db } from '../storage';
import { users, achievements, playerStats, gameHistory, seasonRewards } from '../../shared/schema';
import { requireAuth } from '../middleware/auth';

const router = Router();

// Get player achievements
router.get('/achievements', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const userAchievements = await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.unlockedAt));
    
    res.json(userAchievements);
  } catch (error) {
    console.error('Error fetching achievements:', error);
    res.status(500).json({ error: 'Fehler beim Laden der Erfolge' });
  }
});

// Get player stats
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const userStats = await db
      .select()
      .from(playerStats)
      .where(eq(playerStats.userId, userId));
    
    res.json(userStats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Fehler beim Laden der Statistiken' });
  }
});

// Get detailed player statistics
router.get('/detailed-stats', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get basic user info
    const user = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .then(rows => rows[0]);

    if (!user) {
      return res.status(404).json({ error: 'Benutzer nicht gefunden' });
    }

    // Get game history stats
    const gameHistoryStats = await db
      .select({
        totalGames: count(),
        totalWins: count(gameHistory.winnerId),
        averageDuration: avg(gameHistory.duration),
        longestGame: max(gameHistory.duration),
        shortestGame: min(gameHistory.duration),
      })
      .from(gameHistory)
      .where(
        and(
          or(
            eq(gameHistory.player1Id, userId),
            eq(gameHistory.player2Id, userId)
          )
        )
      )
      .then(rows => rows[0]);

    // Get ranked games specific stats
    const rankedStats = await db
      .select({
        rankedGames: count(),
        rankedWins: count(gameHistory.winnerId),
        totalPointsEarned: sum(gameHistory.rankedPointsChanged),
      })
      .from(gameHistory)
      .where(
        and(
          eq(gameHistory.gameMode, 'ranked'),
          or(
            eq(gameHistory.player1Id, userId),
            eq(gameHistory.player2Id, userId)
          )
        )
      )
      .then(rows => rows[0]);

    // Get recent games (last 10)
    const recentGames = await db
      .select({
        id: gameHistory.id,
        gameMode: gameHistory.gameMode,
        boardSize: gameHistory.boardSize,
        duration: gameHistory.duration,
        finalScore: gameHistory.finalScore,
        playedAt: gameHistory.playedAt,
        isWin: gameHistory.winnerId,
        opponent: users.displayName,
        rankedPointsChanged: gameHistory.rankedPointsChanged,
      })
      .from(gameHistory)
      .leftJoin(
        users,
        or(
          and(eq(gameHistory.player1Id, userId), eq(users.id, gameHistory.player2Id)),
          and(eq(gameHistory.player2Id, userId), eq(users.id, gameHistory.player1Id))
        )
      )
      .where(
        or(
          eq(gameHistory.player1Id, userId),
          eq(gameHistory.player2Id, userId)
        )
      )
      .orderBy(desc(gameHistory.playedAt))
      .limit(10);

    // Get monthly performance (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    const monthlyPerformance = await db
      .select({
        month: sql`DATE_TRUNC('month', ${gameHistory.playedAt})`,
        games: count(),
        wins: count(gameHistory.winnerId),
        pointsGained: sum(gameHistory.rankedPointsChanged),
      })
      .from(gameHistory)
      .where(
        and(
          or(
            eq(gameHistory.player1Id, userId),
            eq(gameHistory.player2Id, userId)
          ),
          gte(gameHistory.playedAt, sixMonthsAgo)
        )
      )
      .groupBy(sql`DATE_TRUNC('month', ${gameHistory.playedAt})`)
      .orderBy(desc(sql`DATE_TRUNC('month', ${gameHistory.playedAt})`));

    // Calculate additional stats
    const winRate = gameHistoryStats.totalGames > 0 
      ? Math.round((gameHistoryStats.totalWins / gameHistoryStats.totalGames) * 100)
      : 0;

    const rankedWinRate = rankedStats.rankedGames > 0
      ? Math.round((rankedStats.rankedWins / rankedStats.rankedGames) * 100)
      : 0;

    const detailedStats = {
      // Basic Profile Info
      profile: {
        id: user.id,
        displayName: user.displayName,
        level: user.level,
        experience: user.experience,
        favoriteAvatar: user.favoriteAvatar,
        memberSince: user.createdAt,
        lastSeen: user.lastSeen,
      },
      
      // Game Statistics
      gameStats: {
        totalGames: gameHistoryStats.totalGames || 0,
        totalWins: gameHistoryStats.totalWins || 0,
        totalLosses: (gameHistoryStats.totalGames || 0) - (gameHistoryStats.totalWins || 0),
        winRate,
        winStreak: user.winStreak,
        bestWinStreak: user.bestWinStreak,
        averageGameDuration: Math.round(gameHistoryStats.averageDuration || 0),
        longestGame: gameHistoryStats.longestGame || 0,
        shortestGame: gameHistoryStats.shortestGame || 0,
      },

      // Ranked Statistics  
      rankedStats: {
        currentRank: user.currentRank,
        rankedPoints: user.rankedPoints,
        highestRankThisSeason: user.highestRankThisSeason,
        seasonWins: user.seasonWins,
        seasonLosses: user.seasonLosses,
        rankedWinRate,
        rankedWinStreak: user.rankedWinStreak,
        totalPointsEarned: rankedStats.totalPointsEarned || 0,
        rankedGamesPlayed: rankedStats.rankedGames || 0,
      },

      // Performance Data
      recentGames: recentGames.map(game => ({
        ...game,
        isWin: game.isWin === userId,
        opponent: game.opponent || 'Computer',
      })),

      monthlyPerformance: monthlyPerformance.map(month => ({
        month: month.month,
        games: month.games,
        wins: month.wins,
        winRate: month.games > 0 ? Math.round((month.wins / month.games) * 100) : 0,
        pointsGained: month.pointsGained || 0,
      })),

      // Achievement Summary
      achievements: {
        total: await db
          .select({ count: count() })
          .from(achievements)
          .where(eq(achievements.userId, userId))
          .then(rows => rows[0]?.count || 0),
        recentlyUnlocked: await db
          .select()
          .from(achievements)
          .where(eq(achievements.userId, userId))
          .orderBy(desc(achievements.unlockedAt))
          .limit(3),
      }
    };

    res.json(detailedStats);
  } catch (error) {
    console.error('Error fetching detailed stats:', error);
    res.status(500).json({ error: 'Fehler beim Laden der detaillierten Statistiken' });
  }
});

// Get player game history
router.get('/history', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    
    const history = await db
      .select({
        id: gameHistory.id,
        gameMode: gameHistory.gameMode,
        boardSize: gameHistory.boardSize,
        duration: gameHistory.duration,
        finalScore: gameHistory.finalScore,
        rankedPointsChanged: gameHistory.rankedPointsChanged,
        playedAt: gameHistory.playedAt,
        isWin: gameHistory.winnerId,
        opponent: users.displayName,
      })
      .from(gameHistory)
      .leftJoin(
        users,
        or(
          and(eq(gameHistory.player1Id, userId), eq(users.id, gameHistory.player2Id)),
          and(eq(gameHistory.player2Id, userId), eq(users.id, gameHistory.player1Id))
        )
      )
      .where(
        or(
          eq(gameHistory.player1Id, userId),
          eq(gameHistory.player2Id, userId)
        )
      )
      .orderBy(desc(gameHistory.playedAt))
      .limit(limit)
      .offset(offset);

    const formattedHistory = history.map(game => ({
      id: game.id,
      opponent: game.opponent || 'Computer',
      result: game.isWin === userId ? 'win' : 'loss',
      gameMode: game.gameMode,
      boardSize: game.boardSize,
      duration: game.duration,
      finalScore: game.finalScore,
      rankedPointsChanged: game.rankedPointsChanged,
      playedAt: game.playedAt,
    }));

    res.json(formattedHistory);
  } catch (error) {
    console.error('Error fetching game history:', error);
    res.status(500).json({ error: 'Fehler beim Laden der Spielhistorie' });
  }
});

// Update player stat
router.post('/stats', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const { statType, increment = 1 } = req.body;

    if (!statType) {
      return res.status(400).json({ error: 'Statistik-Typ ist erforderlich' });
    }

    // Check if stat exists
    const existingStat = await db
      .select()
      .from(playerStats)
      .where(
        and(
          eq(playerStats.userId, userId),
          eq(playerStats.statType, statType)
        )
      )
      .then(rows => rows[0]);

    if (existingStat) {
      // Update existing stat
      await db
        .update(playerStats)
        .set({
          value: existingStat.value + increment,
          updatedAt: new Date(),
        })
        .where(eq(playerStats.id, existingStat.id));
    } else {
      // Create new stat
      await db
        .insert(playerStats)
        .values({
          userId,
          statType,
          value: increment,
        });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Error updating player stat:', error);
    res.status(500).json({ error: 'Fehler beim Aktualisieren der Statistik' });
  }
});

export default router;