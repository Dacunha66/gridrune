import express, { type Request, Response, NextFunction } from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const httpServer = createServer(app);
  const server = await registerRoutes(app);
  
  // Setup Socket.io for multiplayer
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Game rooms management
  const gameRooms = new Map<string, {
    players: Array<{ id: string; name: string; ready: boolean }>;
    gameState: any;
    maxPlayers: number;
  }>();

  io.on('connection', (socket) => {
    log(`Player connected: ${socket.id}`);

    // Join or create game room
    socket.on('joinRoom', (data: { roomId: string; playerName: string }) => {
      const { roomId, playerName } = data;
      
      if (!gameRooms.has(roomId)) {
        // Create new room
        gameRooms.set(roomId, {
          players: [],
          gameState: null,
          maxPlayers: 2
        });
      }

      const room = gameRooms.get(roomId)!;
      
      if (room.players.length >= room.maxPlayers) {
        socket.emit('roomFull');
        return;
      }

      // Add player to room
      room.players.push({
        id: socket.id,
        name: playerName,
        ready: false
      });

      socket.join(roomId);
      socket.emit('joinedRoom', { roomId, playerId: socket.id });
      io.to(roomId).emit('roomUpdate', room.players);
    });

    // Player ready status
    socket.on('playerReady', (data: { roomId: string }) => {
      const room = gameRooms.get(data.roomId);
      if (!room) return;

      const player = room.players.find(p => p.id === socket.id);
      if (player) {
        player.ready = !player.ready;
        io.to(data.roomId).emit('roomUpdate', room.players);

        // Start game if both players ready
        if (room.players.length === 2 && room.players.every(p => p.ready)) {
          io.to(data.roomId).emit('gameStart');
        }
      }
    });

    // Game moves
    socket.on('gameMove', (data: { roomId: string; move: any }) => {
      const room = gameRooms.get(data.roomId);
      if (!room) return;

      // Broadcast move to other players in room
      socket.to(data.roomId).emit('opponentMove', data.move);
    });

    // Handle disconnection
    socket.on('disconnect', () => {
      log(`Player disconnected: ${socket.id}`);
      
      // Remove player from all rooms
      for (const [roomId, room] of gameRooms.entries()) {
        const playerIndex = room.players.findIndex(p => p.id === socket.id);
        if (playerIndex !== -1) {
          room.players.splice(playerIndex, 1);
          
          if (room.players.length === 0) {
            gameRooms.delete(roomId);
          } else {
            io.to(roomId).emit('playerDisconnected', socket.id);
            io.to(roomId).emit('roomUpdate', room.players);
          }
          break;
        }
      }
    });
  });

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, httpServer);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client
  const port = 5000;
  httpServer.listen(port, "0.0.0.0", () => {
    log(`serving on port ${port}`);
  });
})();
