import { 
  users, 
  achievements,
  playerStats,
  gameHistory,
  type User, 
  type InsertUser,
  type UpdateUserProfile,
  type Achievement,
  type PlayerStat,
  type GameHistory
} from "../shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

// Initialize database connection
const queryClient = postgres(process.env.DATABASE_URL!);
export const db = drizzle(queryClient);

export interface IStorage {
  // User management
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  insertUser(user: InsertUser): Promise<User>;
  updateUserProfile(userId: number, data: UpdateUserProfile): Promise<User>;
  updateUserOnlineStatus(userId: number, isOnline: boolean): Promise<void>;
  
  // Achievements
  getUserAchievements(userId: number): Promise<Achievement[]>;
  insertAchievement(achievement: any): Promise<Achievement>;
  checkAndAwardAchievements(userId: number): Promise<void>;
  
  // Player Stats
  getUserStats(userId: number): Promise<PlayerStat[]>;
  updatePlayerStats(userId: number, stats: any): Promise<void>;
  
  // Game History
  getUserGameHistory(userId: number): Promise<any[]>;
  insertGameHistory(gameData: any): Promise<GameHistory>;
  
  // Leaderboard
  getLeaderboard(): Promise<any[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private achievements: Map<number, Achievement>;
  private stats: Map<number, PlayerStat>;
  private gameHistory: Map<number, GameHistory>;
  private currentUserId: number;
  private currentAchievementId: number;
  private currentStatId: number;
  private currentGameId: number;

  constructor() {
    this.users = new Map();
    this.achievements = new Map();
    this.stats = new Map();
    this.gameHistory = new Map();
    this.currentUserId = 1;
    this.currentAchievementId = 1;
    this.currentStatId = 1;
    this.currentGameId = 1;
  }

  async getUserById(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async insertUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      profileImage: "default_avatar.png",
      level: 1,
      experience: 0,
      totalGames: 0,
      totalWins: 0,
      totalLosses: 0,
      winStreak: 0,
      bestWinStreak: 0,
      favoriteAvatar: "warrior",
      isOnline: true,
      lastSeen: now,
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserProfile(userId: number, data: UpdateUserProfile): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error('Benutzer nicht gefunden');
    }

    const updatedUser = {
      ...user,
      ...data,
      updatedAt: new Date()
    };

    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserOnlineStatus(userId: number, isOnline: boolean): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = {
        ...user,
        isOnline,
        lastSeen: new Date(),
        updatedAt: new Date()
      };
      this.users.set(userId, updatedUser);
    }
  }

  async getUserAchievements(userId: number): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(
      achievement => achievement.userId === userId
    );
  }

  async insertAchievement(achievement: any): Promise<Achievement> {
    const id = this.currentAchievementId++;
    const newAchievement: Achievement = {
      ...achievement,
      id,
      unlockedAt: new Date()
    };
    this.achievements.set(id, newAchievement);
    return newAchievement;
  }

  async checkAndAwardAchievements(userId: number): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;

    const userAchievements = await this.getUserAchievements(userId);
    const achievementTypes = userAchievements.map(a => a.achievementType);

    // First Win Achievement
    if (user.totalWins >= 1 && !achievementTypes.includes('first_win')) {
      await this.insertAchievement({
        userId,
        achievementType: 'first_win',
        title: 'Erster Sieg',
        description: 'Gewinne dein erstes Spiel',
        icon: '🏆'
      });
    }

    // Win Streak Achievements
    if (user.winStreak >= 5 && !achievementTypes.includes('win_streak_5')) {
      await this.insertAchievement({
        userId,
        achievementType: 'win_streak_5',
        title: 'Siegesserie',
        description: 'Gewinne 5 Spiele in Folge',
        icon: '🔥'
      });
    }

    // Games Played Achievements
    if (user.totalGames >= 10 && !achievementTypes.includes('games_played_10')) {
      await this.insertAchievement({
        userId,
        achievementType: 'games_played_10',
        title: 'Erfahren',
        description: 'Spiele 10 Spiele',
        icon: '⭐'
      });
    }
  }

  async getUserStats(userId: number): Promise<PlayerStat[]> {
    return Array.from(this.stats.values()).filter(
      stat => stat.userId === userId
    );
  }

  async updatePlayerStats(userId: number, statsUpdate: any): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;

    // Update user's basic stats
    const updatedUser = {
      ...user,
      totalGames: user.totalGames + (statsUpdate.totalGames || 0),
      totalWins: user.totalWins + (statsUpdate.totalWins || 0),
      totalLosses: user.totalLosses + (statsUpdate.totalLosses || 0),
      updatedAt: new Date()
    };

    // Update win streak
    if (statsUpdate.totalWins > 0) {
      updatedUser.winStreak = user.winStreak + 1;
      updatedUser.bestWinStreak = Math.max(user.bestWinStreak, updatedUser.winStreak);
    } else if (statsUpdate.totalLosses > 0) {
      updatedUser.winStreak = 0;
    }

    // Update experience and level
    const expGain = statsUpdate.totalWins * 100 + statsUpdate.totalGames * 10;
    updatedUser.experience = user.experience + expGain;
    updatedUser.level = Math.floor(updatedUser.experience / 1000) + 1;

    this.users.set(userId, updatedUser);

    // Update detailed stats
    for (const [statType, value] of Object.entries(statsUpdate)) {
      if (typeof value === 'number' && value > 0) {
        const existingStat = Array.from(this.stats.values()).find(
          s => s.userId === userId && s.statType === statType
        );

        if (existingStat) {
          const updatedStat = {
            ...existingStat,
            value: existingStat.value + value,
            updatedAt: new Date()
          };
          this.stats.set(existingStat.id, updatedStat);
        } else {
          const newStat: PlayerStat = {
            id: this.currentStatId++,
            userId,
            statType,
            value,
            updatedAt: new Date()
          };
          this.stats.set(newStat.id, newStat);
        }
      }
    }
  }

  async getUserGameHistory(userId: number): Promise<any[]> {
    return Array.from(this.gameHistory.values())
      .filter(game => game.player1Id === userId || game.player2Id === userId)
      .map(game => {
        const isPlayer1 = game.player1Id === userId;
        const opponentId = isPlayer1 ? game.player2Id : game.player1Id;
        const opponent = this.users.get(opponentId);
        
        let result: 'win' | 'loss' | 'draw' = 'draw';
        if (game.winnerId === userId) result = 'win';
        else if (game.winnerId && game.winnerId !== userId) result = 'loss';

        return {
          id: game.id,
          opponent: opponent?.displayName || 'Unbekannt',
          result,
          gameMode: game.gameMode,
          boardSize: game.boardSize,
          playedAt: game.playedAt
        };
      })
      .sort((a, b) => new Date(b.playedAt).getTime() - new Date(a.playedAt).getTime());
  }

  async insertGameHistory(gameData: any): Promise<GameHistory> {
    const id = this.currentGameId++;
    const game: GameHistory = {
      ...gameData,
      id,
      playedAt: new Date()
    };
    this.gameHistory.set(id, game);
    return game;
  }

  async getLeaderboard(): Promise<any[]> {
    return Array.from(this.users.values())
      .filter(user => user.totalGames > 0)
      .sort((a, b) => {
        // Sort by win rate, then by total wins
        const aWinRate = a.totalWins / a.totalGames;
        const bWinRate = b.totalWins / b.totalGames;
        if (aWinRate !== bWinRate) return bWinRate - aWinRate;
        return b.totalWins - a.totalWins;
      })
      .slice(0, 50)
      .map((user, index) => ({
        rank: index + 1,
        displayName: user.displayName,
        level: user.level,
        totalWins: user.totalWins,
        totalGames: user.totalGames,
        winRate: Math.round((user.totalWins / user.totalGames) * 100),
        favoriteAvatar: user.favoriteAvatar
      }));
  }
}

export const storage = new MemStorage();
