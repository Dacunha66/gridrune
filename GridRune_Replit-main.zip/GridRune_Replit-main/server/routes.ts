import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { insertUserSchema, updateUserProfileSchema, insertGameHistorySchema } from "../shared/schema";
import playerRoutes from "./routes/player";
// PayPal integration - imported conditionally to avoid startup errors

// Session middleware setup
import session from "express-session";
import connectPgSimple from "connect-pg-simple";

// Extend session type for userId
declare module 'express-session' {
  interface SessionData {
    userId?: number;
  }
}

const PgSession = connectPgSimple(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    store: new PgSession({
      conString: process.env.DATABASE_URL,
      tableName: 'session'
    }),
    secret: process.env.SESSION_SECRET || 'dacunha-cards-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true if using HTTPS
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
  }));

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session?.userId) {
      return res.status(401).json({ error: 'Nicht authentifiziert' });
    }
    next();
  };

  // Auth Routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ error: 'Benutzername bereits vergeben' });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ error: 'E-Mail bereits registriert' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const newUser = await storage.insertUser({
        ...userData,
        password: hashedPassword
      });

      // Set session
      req.session.userId = newUser.id;
      
      // Don't send password back
      const { password, ...userWithoutPassword } = newUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Registrierung fehlgeschlagen' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: 'Ungültige Anmeldedaten' });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Ungültige Anmeldedaten' });
      }

      // Update online status
      await storage.updateUserOnlineStatus(user.id, true);

      // Set session
      req.session.userId = user.id;
      
      // Don't send password back
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Anmeldung fehlgeschlagen' });
    }
  });

  app.post('/api/auth/logout', requireAuth, async (req, res) => {
    try {
      // Update online status
      await storage.updateUserOnlineStatus(req.session.userId!, false);
      
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ error: 'Abmeldung fehlgeschlagen' });
        }
        res.clearCookie('connect.sid');
        res.json({ message: 'Erfolgreich abgemeldet' });
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Abmeldung fehlgeschlagen' });
    }
  });

  app.get('/api/auth/me', async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: 'Nicht authentifiziert' });
      }

      const user = await storage.getUserById(req.session.userId);
      if (!user) {
        return res.status(404).json({ error: 'Benutzer nicht gefunden' });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Fehler beim Laden des Profils' });
    }
  });

  app.put('/api/auth/profile', requireAuth, async (req, res) => {
    try {
      const updateData = updateUserProfileSchema.parse(req.body);
      
      const updatedUser = await storage.updateUserProfile(req.session.userId!, updateData);
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Profil-Update fehlgeschlagen' });
    }
  });

  // Player Stats Routes
  app.get('/api/player/achievements', requireAuth, async (req, res) => {
    try {
      const achievements = await storage.getUserAchievements(req.session.userId!);
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Fehler beim Laden der Errungenschaften' });
    }
  });

  app.get('/api/player/stats', requireAuth, async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.session.userId!);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Fehler beim Laden der Statistiken' });
    }
  });

  app.get('/api/player/history', requireAuth, async (req, res) => {
    try {
      const history = await storage.getUserGameHistory(req.session.userId!);
      res.json(history);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Fehler beim Laden der Spielhistorie' });
    }
  });

  // Game Result Tracking
  app.post('/api/game/result', requireAuth, async (req, res) => {
    try {
      const gameData = insertGameHistorySchema.parse(req.body);
      
      // Save game to history
      const gameRecord = await storage.insertGameHistory(gameData);
      
      // Update player stats
      await storage.updatePlayerStats(req.session.userId!, {
        totalGames: 1,
        totalWins: gameData.winnerId === req.session.userId! ? 1 : 0,
        totalLosses: gameData.winnerId && gameData.winnerId !== req.session.userId! ? 1 : 0
      });

      // Check for achievements
      await storage.checkAndAwardAchievements(req.session.userId!);

      res.json(gameRecord);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Fehler beim Speichern des Spielergebnisses' });
    }
  });

  // Leaderboard
  app.get('/api/leaderboard', async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Fehler beim Laden der Bestenliste' });
    }
  });

  // Player routes for enhanced profile system
  app.use('/api/player', playerRoutes);

  // PayPal routes - only register if environment variables are available
  const hasPayPalConfig = process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET;
  
  if (hasPayPalConfig) {
    try {
      // Dynamic import to avoid startup errors when PayPal env vars are missing
      const { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } = await import("./paypal");
      
      app.get("/paypal/setup", async (req, res) => {
        await loadPaypalDefault(req, res);
      });

      app.post("/paypal/order", async (req, res) => {
        // Request body should contain: { intent, amount, currency }
        await createPaypalOrder(req, res);
      });

      app.post("/paypal/order/:orderID/capture", async (req, res) => {
        await capturePaypalOrder(req, res);
      });
      
      console.log("✅ PayPal integration enabled");
    } catch (error) {
      console.warn("⚠️ PayPal integration failed to load:", error);
    }
  } else {
    console.log("ℹ️ PayPal integration disabled - missing environment variables");
    
    // Provide fallback routes that return appropriate errors
    app.get("/paypal/setup", (req, res) => {
      res.status(503).json({ error: "PayPal integration not configured" });
    });

    app.post("/paypal/order", (req, res) => {
      res.status(503).json({ error: "PayPal integration not configured" });
    });

    app.post("/paypal/order/:orderID/capture", (req, res) => {
      res.status(503).json({ error: "PayPal integration not configured" });
    });
  }

  const httpServer = createServer(app);

  return httpServer;
}
