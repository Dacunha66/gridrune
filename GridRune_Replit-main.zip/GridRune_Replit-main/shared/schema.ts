import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  profileImage: text("profile_image").default("default_avatar.png"),
  level: integer("level").default(1),
  experience: integer("experience").default(0),
  totalGames: integer("total_games").default(0),
  totalWins: integer("total_wins").default(0),
  totalLosses: integer("total_losses").default(0),
  winStreak: integer("win_streak").default(0),
  bestWinStreak: integer("best_win_streak").default(0),
  favoriteAvatar: text("favorite_avatar").default("warrior"),
  isOnline: boolean("is_online").default(false),
  lastSeen: timestamp("last_seen").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  // Ranking System Fields
  rankedPoints: integer("ranked_points").default(0),
  currentRank: text("current_rank").default("bronze_iii"),
  highestRankThisSeason: text("highest_rank_this_season").default("bronze_iii"),
  seasonWins: integer("season_wins").default(0),
  seasonLosses: integer("season_losses").default(0),
  rankedWinStreak: integer("ranked_win_streak").default(0),
  lastMatchTimestamp: timestamp("last_match_timestamp"),
  lastSeasonId: text("last_season_id"),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  achievementType: text("achievement_type").notNull(), // 'first_win', 'win_streak_5', 'games_played_100', etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const playerStats = pgTable("player_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  statType: text("stat_type").notNull(), // 'cards_played', 'battles_won', 'effects_triggered', etc.
  value: integer("value").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const gameHistory = pgTable("game_history", {
  id: serial("id").primaryKey(),
  player1Id: integer("player1_id").notNull().references(() => users.id),
  player2Id: integer("player2_id").notNull().references(() => users.id),
  winnerId: integer("winner_id").references(() => users.id),
  gameMode: text("game_mode").notNull(), // 'ai', 'local', 'multiplayer', 'ranked'
  boardSize: text("board_size").notNull(), // '3x3', '4x4'
  duration: integer("duration"), // in seconds
  finalScore: json("final_score"), // { player1: number, player2: number }
  rankedPointsChanged: integer("ranked_points_changed").default(0), // +/- points for ranked matches
  playedAt: timestamp("played_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  displayName: true,
});

export const updateUserProfileSchema = createInsertSchema(users).pick({
  displayName: true,
  profileImage: true,
  favoriteAvatar: true,
}).partial();

// Matchmaking queue for ranked games
export const matchmakingQueue = pgTable("matchmaking_queue", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  rankedPoints: integer("ranked_points").notNull(),
  currentRank: text("current_rank").notNull(),
  queuedAt: timestamp("queued_at").defaultNow(),
  preferredOpponentRange: integer("preferred_opponent_range").default(300), // Max point difference
  isActive: boolean("is_active").default(true),
});

// Season rewards tracking
export const seasonRewards = pgTable("season_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  seasonId: text("season_id").notNull(),
  finalRank: text("final_rank").notNull(),
  finalPoints: integer("final_points").notNull(),
  rewardsClaimed: boolean("rewards_claimed").default(false),
  rewardData: json("reward_data"), // JSON object of rewards
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  userId: true,
  achievementType: true,
  title: true,
  description: true,
  icon: true,
});

export const insertMatchmakingQueueSchema = createInsertSchema(matchmakingQueue).pick({
  userId: true,
  rankedPoints: true,
  currentRank: true,
  preferredOpponentRange: true,
});

export const insertSeasonRewardsSchema = createInsertSchema(seasonRewards).pick({
  userId: true,
  seasonId: true,
  finalRank: true,
  finalPoints: true,
  rewardData: true,
});

export const insertGameHistorySchema = createInsertSchema(gameHistory).pick({
  player1Id: true,
  player2Id: true,
  winnerId: true,
  gameMode: true,
  boardSize: true,
  duration: true,
  finalScore: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
export type User = typeof users.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type PlayerStat = typeof playerStats.$inferSelect;
export type GameHistory = typeof gameHistory.$inferSelect;
