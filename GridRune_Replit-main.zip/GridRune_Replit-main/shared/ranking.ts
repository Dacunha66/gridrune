export interface RankTier {
  id: string;
  name: string;
  tier: number; // III = 3, II = 2, I = 1
  minPoints: number;
  maxPoints: number;
  emoji: string;
  color: string;
  seasonReward: SeasonReward;
}

export interface SeasonReward {
  basicPacks?: number;
  premiumPacks?: number;
  legendaryPacks?: number;
  eventPacks?: number;
  gold?: number;
  diamonds?: number;
  specialItems?: string[];
}

export interface PlayerRank {
  userId: string;
  currentPoints: number;
  currentRank: string;
  highestRankThisSeason: string;
  seasonWins: number;
  seasonLosses: number;
  winStreak: number;
  lastMatchTimestamp: number;
}

export interface MatchmakingResult {
  player1Id: string;
  player2Id: string;
  averageRank: number;
  rankDifference: number;
  estimatedMatchQuality: number;
}

// Rangsystem Definition
export const RANK_TIERS: RankTier[] = [
  // Bronze
  {
    id: "bronze_iii",
    name: "Bronze III",
    tier: 3,
    minPoints: 0,
    maxPoints: 166,
    emoji: "🥉",
    color: "#cd7f32",
    seasonReward: { basicPacks: 1 }
  },
  {
    id: "bronze_ii",
    name: "Bronze II", 
    tier: 2,
    minPoints: 167,
    maxPoints: 333,
    emoji: "🥉",
    color: "#cd7f32",
    seasonReward: { basicPacks: 1, gold: 200 }
  },
  {
    id: "bronze_i",
    name: "Bronze I",
    tier: 1,
    minPoints: 334,
    maxPoints: 499,
    emoji: "🥉",
    color: "#cd7f32",
    seasonReward: { basicPacks: 1, gold: 300 }
  },

  // Silber
  {
    id: "silver_iii",
    name: "Silber III",
    tier: 3,
    minPoints: 500,
    maxPoints: 666,
    emoji: "🪙",
    color: "#c0c0c0",
    seasonReward: { basicPacks: 2, gold: 400 }
  },
  {
    id: "silver_ii",
    name: "Silber II",
    tier: 2,
    minPoints: 667,
    maxPoints: 833,
    emoji: "🪙",
    color: "#c0c0c0",
    seasonReward: { basicPacks: 2, gold: 600 }
  },
  {
    id: "silver_i",
    name: "Silber I",
    tier: 1,
    minPoints: 834,
    maxPoints: 999,
    emoji: "🪙",
    color: "#c0c0c0",
    seasonReward: { premiumPacks: 1, diamonds: 10 }
  },

  // Gold
  {
    id: "gold_iii",
    name: "Gold III",
    tier: 3,
    minPoints: 1000,
    maxPoints: 1166,
    emoji: "🛡",
    color: "#ffd700",
    seasonReward: { premiumPacks: 1, diamonds: 15 }
  },
  {
    id: "gold_ii",
    name: "Gold II",
    tier: 2,
    minPoints: 1167,
    maxPoints: 1333,
    emoji: "🛡",
    color: "#ffd700",
    seasonReward: { premiumPacks: 1, diamonds: 30 }
  },
  {
    id: "gold_i",
    name: "Gold I",
    tier: 1,
    minPoints: 1334,
    maxPoints: 1499,
    emoji: "🛡",
    color: "#ffd700",
    seasonReward: { premiumPacks: 2, diamonds: 50 }
  },

  // Platin
  {
    id: "platinum_iii",
    name: "Platin III",
    tier: 3,
    minPoints: 1500,
    maxPoints: 1666,
    emoji: "🔥",
    color: "#e5e4e2",
    seasonReward: { legendaryPacks: 1, diamonds: 50 }
  },
  {
    id: "platinum_ii",
    name: "Platin II",
    tier: 2,
    minPoints: 1667,
    maxPoints: 1833,
    emoji: "🔥",
    color: "#e5e4e2",
    seasonReward: { legendaryPacks: 1, diamonds: 100 }
  },
  {
    id: "platinum_i",
    name: "Platin I",
    tier: 1,
    minPoints: 1834,
    maxPoints: 1999,
    emoji: "🔥",
    color: "#e5e4e2",
    seasonReward: { legendaryPacks: 2, specialItems: ["exklusives Emblem"] }
  },

  // Diamant
  {
    id: "diamond_iii",
    name: "Diamant III",
    tier: 3,
    minPoints: 2000,
    maxPoints: 2166,
    emoji: "💎",
    color: "#b9f2ff",
    seasonReward: { legendaryPacks: 2, diamonds: 150 }
  },
  {
    id: "diamond_ii",
    name: "Diamant II",
    tier: 2,
    minPoints: 2167,
    maxPoints: 2333,
    emoji: "💎",
    color: "#b9f2ff",
    seasonReward: { legendaryPacks: 3, diamonds: 200 }
  },
  {
    id: "diamond_i",
    name: "Diamant I",
    tier: 1,
    minPoints: 2334,
    maxPoints: 2499,
    emoji: "💎",
    color: "#b9f2ff",
    seasonReward: { legendaryPacks: 3, specialItems: ["Spezialkarte"] }
  },

  // Mythisch
  {
    id: "mythic_iii",
    name: "Mythisch III",
    tier: 3,
    minPoints: 2500,
    maxPoints: 2666,
    emoji: "🐉",
    color: "#ff6ec7",
    seasonReward: { legendaryPacks: 3, eventPacks: 1 }
  },
  {
    id: "mythic_ii",
    name: "Mythisch II",
    tier: 2,
    minPoints: 2667,
    maxPoints: 2833,
    emoji: "🐉",
    color: "#ff6ec7",
    seasonReward: { legendaryPacks: 3, specialItems: ["exklusiver Avatar"] }
  },
  {
    id: "mythic_i",
    name: "Mythisch I",
    tier: 1,
    minPoints: 2834,
    maxPoints: 2999,
    emoji: "🐉",
    color: "#ff6ec7",
    seasonReward: { legendaryPacks: 4, diamonds: 250 }
  },

  // Legende
  {
    id: "legend_iii",
    name: "Legende III",
    tier: 3,
    minPoints: 3000,
    maxPoints: 3099,
    emoji: "👑",
    color: "#ff0080",
    seasonReward: { legendaryPacks: 4, specialItems: ["animierter Titel"] }
  },
  {
    id: "legend_ii",
    name: "Legende II",
    tier: 2,
    minPoints: 3100,
    maxPoints: 3249,
    emoji: "👑",
    color: "#ff0080",
    seasonReward: { legendaryPacks: 5, specialItems: ["exklusive Karte"] }
  },
  {
    id: "legend_i",
    name: "Legende I",
    tier: 1,
    minPoints: 3250,
    maxPoints: 999999,
    emoji: "👑",
    color: "#ff0080",
    seasonReward: { diamonds: 500, specialItems: ["Legendärer Titel", "einzigartige Karte"] }
  }
];

// Hilfsfunktionen für Rangsystem
export function getRankByPoints(points: number): RankTier {
  return RANK_TIERS.find(rank => points >= rank.minPoints && points <= rank.maxPoints) || RANK_TIERS[0];
}

export function getRankById(rankId: string): RankTier | undefined {
  return RANK_TIERS.find(rank => rank.id === rankId);
}

export function getPointsForWin(winnerPoints: number, loserPoints: number): number {
  const rankDifference = Math.abs(winnerPoints - loserPoints);
  
  // Grundpunkte für Sieg
  let basePoints = 25;
  
  // Bonus für Sieg gegen höher eingestufte Spieler
  if (loserPoints > winnerPoints) {
    const bonus = Math.min(15, Math.floor(rankDifference / 100));
    basePoints += bonus;
  }
  
  // Weniger Punkte für Sieg gegen niedriger eingestufte Spieler
  if (winnerPoints > loserPoints) {
    const penalty = Math.min(15, Math.floor(rankDifference / 150));
    basePoints -= penalty;
  }
  
  return Math.max(10, basePoints); // Mindestens 10 Punkte
}

export function getPointsForLoss(winnerPoints: number, loserPoints: number): number {
  const rankDifference = Math.abs(winnerPoints - loserPoints);
  
  // Grundpunkte-Verlust
  let baseLoss = -20;
  
  // Weniger Verlust gegen höher eingestufte Spieler
  if (winnerPoints > loserPoints) {
    const reduction = Math.min(10, Math.floor(rankDifference / 150));
    baseLoss += reduction;
  }
  
  // Mehr Verlust gegen niedriger eingestufte Spieler
  if (loserPoints > winnerPoints) {
    const penalty = Math.min(10, Math.floor(rankDifference / 200));
    baseLoss -= penalty;
  }
  
  return Math.max(-30, baseLoss); // Maximal -30 Punkte
}

// Matchmaking-Algorithmus
export function findMatch(searchingPlayer: PlayerRank, availablePlayers: PlayerRank[]): MatchmakingResult | null {
  if (availablePlayers.length === 0) return null;
  
  const playerRank = getRankByPoints(searchingPlayer.currentPoints);
  
  // Sortiere verfügbare Spieler nach Rangähnlichkeit
  const sortedPlayers = availablePlayers
    .filter(player => player.userId !== searchingPlayer.userId)
    .map(player => ({
      player,
      rankDifference: Math.abs(player.currentPoints - searchingPlayer.currentPoints),
      rank: getRankByPoints(player.currentPoints)
    }))
    .sort((a, b) => a.rankDifference - b.rankDifference);
  
  if (sortedPlayers.length === 0) return null;
  
  const bestMatch = sortedPlayers[0];
  const averageRank = (searchingPlayer.currentPoints + bestMatch.player.currentPoints) / 2;
  
  // Berechne Match-Qualität (0-100)
  const maxAcceptableRankDiff = 300;
  const quality = Math.max(0, 100 - (bestMatch.rankDifference / maxAcceptableRankDiff) * 100);
  
  return {
    player1Id: searchingPlayer.userId,
    player2Id: bestMatch.player.userId,
    averageRank: averageRank,
    rankDifference: bestMatch.rankDifference,
    estimatedMatchQuality: Math.round(quality)
  };
}

// Saison-Management
export interface Season {
  id: string;
  name: string;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
}

export function getCurrentSeason(): Season {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  
  const seasonStart = new Date(year, month, 1);
  const seasonEnd = new Date(year, month + 1, 0, 23, 59, 59);
  
  return {
    id: `season_${year}_${month + 1}`,
    name: `Saison ${month + 1}/${year}`,
    startDate: seasonStart,
    endDate: seasonEnd,
    isActive: true
  };
}

export function isNewSeason(lastSeasonId: string): boolean {
  const currentSeason = getCurrentSeason();
  return currentSeason.id !== lastSeasonId;
}